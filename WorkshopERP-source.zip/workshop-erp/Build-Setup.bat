@echo off
title Build Workshop ERP Setup
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js is not installed. Run Start-WorkshopERP.bat first.
  pause
  exit /b 1
)
if not exist node_modules\electron call npm install
call npm run dist
if errorlevel 1 (
  echo  Build failed.
  pause
  exit /b 1
)
echo.
echo  Done. The installer is in the "dist" folder.
explorer dist
pause
