@echo off
title Workshop ERP
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js is not installed.
  echo  1^) The download page will open now. Download "Windows Installer (.msi)" - LTS version.
  echo  2^) Install it with the default options ^(Next, Next, Install^).
  echo  3^) Then double-click this file again.
  echo.
  start https://nodejs.org/en/download
  pause
  exit /b 1
)
if not exist node_modules\electron (
  echo.
  echo  First run: downloading required components ^(needs internet ONE time only, 5-10 minutes^)...
  echo.
  call npm install
  if errorlevel 1 (
    echo.
    echo  Installation failed. Check the internet connection and try again.
    pause
    exit /b 1
  )
)
echo  Starting Workshop ERP...
call npm start
