'use strict';
// Regenerates build/icon.png and build/icon.ico from build/icon.svg (needs `npm i -D sharp`).
const fs = require('fs');
const path = require('path');
let sharp; try { sharp = require('sharp'); } catch (_) { console.error('sharp is not installed: npm i -D sharp'); process.exit(1); }
const dir = path.join(__dirname, '..', 'build');
const svg = fs.readFileSync(path.join(dir, 'icon.svg'));
(async () => {
  await sharp(svg).resize(512, 512).png().toFile(path.join(dir, 'icon.png'));
  const sizes = [16, 24, 32, 48, 64, 128, 256];
  const pngs = await Promise.all(sizes.map((s) => sharp(svg).resize(s, s).png().toBuffer()));
  const head = Buffer.alloc(6); head.writeUInt16LE(0, 0); head.writeUInt16LE(1, 2); head.writeUInt16LE(sizes.length, 4);
  let offset = 6 + 16 * sizes.length;
  const dirs = sizes.map((s, i) => {
    const e = Buffer.alloc(16);
    e.writeUInt8(s >= 256 ? 0 : s, 0); e.writeUInt8(s >= 256 ? 0 : s, 1); e.writeUInt8(0, 2); e.writeUInt8(0, 3);
    e.writeUInt16LE(1, 4); e.writeUInt16LE(32, 6); e.writeUInt32LE(pngs[i].length, 8); e.writeUInt32LE(offset, 12);
    offset += pngs[i].length; return e;
  });
  fs.writeFileSync(path.join(dir, 'icon.ico'), Buffer.concat([head, ...dirs, ...pngs]));
  console.log('icons written');
})();
