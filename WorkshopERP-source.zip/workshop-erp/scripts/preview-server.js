'use strict';
/**
 * Browser preview server — for development and UI testing only (the real product is the
 * Electron desktop app). It runs the SAME backend (App + Router + SQLite) and serves the
 * renderer on http://127.0.0.1:<port>. Bound to localhost only; nothing leaves the machine.
 *
 *   node scripts/preview-server.js [--data <dir>] [--port 5178]
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { App } = require('../src/main/core/app');

const argv = process.argv.slice(2);
const opt = (name, def) => { const i = argv.indexOf(`--${name}`); return i >= 0 ? argv[i + 1] : def; };
const PORT = Number(opt('port', process.env.PORT || 5178));
const DATA = path.resolve(opt('data', path.join(__dirname, '..', '.preview-data')));
const ROOT = path.join(__dirname, '..', 'src', 'renderer');
const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8'));

const app = new App({ dataDir: DATA, appVersion: pkg.version });
app.open();

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.woff2': 'font/woff2', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/api') {
    let body = '';
    req.on('data', (c) => { body += c; if (body.length > 60e6) req.destroy(); });
    req.on('end', () => {
      let out;
      try { const { method, args } = JSON.parse(body || '{}'); out = app.invoke(method, args || {}); } catch (e) { out = { ok: false, error: { message: 'طلب غير صالح', code: 'BAD_REQUEST', technical: e.message } }; }
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify(out));
    });
    return;
  }
  const url = decodeURIComponent(req.url.split('?')[0]);
  const file = path.normalize(path.join(ROOT, url === '/' ? 'index.html' : url));
  if (!file.startsWith(ROOT)) { res.writeHead(403); res.end(); return; }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(data);
  });
});
server.listen(PORT, '127.0.0.1', () => console.log(`Preview: http://127.0.0.1:${PORT}  (data: ${DATA})`));
const stop = () => { try { app.close(); } catch (_) { /* ignore */ } process.exit(0); };
process.on('SIGINT', stop); process.on('SIGTERM', stop);
