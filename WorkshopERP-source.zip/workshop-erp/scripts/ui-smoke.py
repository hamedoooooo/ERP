# UI smoke test: opens every page/tab/report in Chromium and reports any JS error.
# Usage: npm run preview (data with user admin/secret1), then: python scripts/ui-smoke.py
# Requires: pip install playwright && playwright install chromium
import asyncio, sys, json, os
from playwright.async_api import async_playwright
BASE=os.environ.get('BASE','http://127.0.0.1:5178/')
ROUTES=['dashboard','products','products/1','inventory','inventory?tab=moves','inventory?tab=transfers','inventory?tab=adjustments','inventory?tab=warehouses','counts','counts/1',
 'purchases','purchases/new','purchases/1','purchase-returns','purchase-returns/new','suppliers','suppliers/1','sales','sales/new','sales/new?mo=1','sales/1','sales-returns','sales-returns/new','customers','customers/1',
 'mo','mo/new','mo/1','mo/1?tab=moves','mo/1?tab=labor','mo/1?tab=costs','mo/1?tab=profit','mo/1?tab=info','mo/2','boms','boms/1','boms/new','workers',
 'payments','expenses','cash','cash?tab=bank','cash?tab=moves','accounting','accounting?tab=balance','accounting?tab=trial','accounting?tab=journal','accounting?tab=ledger','accounting?tab=coa','accounting?tab=opening','accounting?tab=check',
 'reports','users','users?tab=roles','settings','settings?tab=money','settings?tab=inventory','settings?tab=manufacturing','settings?tab=statuses','settings?tab=system','backup','audit']
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(**({'executable_path': os.environ['CHROME']} if os.environ.get('CHROME') else {}))
        pg=await b.new_page(viewport={'width':1400,'height':900})
        errs=[]
        pg.on('pageerror', lambda e: errs.append(('pageerror', str(e))))
        pg.on('console', lambda m: errs.append(('console', m.text)) if m.type=='error' else None)
        await pg.goto(BASE); await pg.wait_for_selector('form')
        await pg.fill('[name=username]','admin'); await pg.fill('[name=password]','secret1'); await pg.click('button[type=submit]')
        await pg.wait_for_selector('.nav a')
        cat = await pg.evaluate("fetch('/api',{method:'POST',body:JSON.stringify({method:'reports.catalog'})}).then(r=>r.json())")
        routes = ROUTES + ['reports/'+r['id'] for r in cat['data']]
        bad=[]
        for r in routes:
            n=len(errs)
            await pg.goto(BASE+'#/'+r); await pg.wait_for_timeout(700)
            txt = await pg.inner_text('#page')
            alert = await pg.query_selector('#page .alert.bad')
            at = (await alert.inner_text()) if alert else ''
            if len(errs)>n or 'جارِ' in txt[:40] or at:
                bad.append((r, errs[n:], at[:200], txt[:80].replace('\n',' ')))
        for x in bad: print(x)
        print('checked', len(routes), 'bad', len(bad))
        await b.close()
asyncio.run(main())
