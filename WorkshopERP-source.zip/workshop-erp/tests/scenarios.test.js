'use strict';
/* Run: npm test   (uses Node's built-in test runner + node:sqlite, no network needed) */
process.env.WERP_SQLITE_DRIVER = process.env.WERP_SQLITE_DRIVER || 'node';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { App } = require('../src/main/core/app');

const quiet = { log() {}, info() {}, warn() {}, error: (...a) => console.error(...a) };
const tmp = (n) => fs.mkdtempSync(path.join(os.tmpdir(), `werp-${n}-`));
const near = (a, b, msg, eps = 0.011) => assert.ok(Math.abs(a - b) < eps, `${msg}: expected ${b}, got ${a}`);

function call(app, m, a) {
  const r = app.invoke(m, a);
  if (!r.ok) throw new Error(`${m}: ${r.error.message}${r.error.technical ? ' | ' + r.error.technical : ''}`);
  return r.data;
}
function fail(app, m, a) {
  const r = app.invoke(m, a);
  assert.equal(r.ok, false, `${m} should fail`);
  return r.error;
}

function consistency(app, label) {
  const tb = call(app, 'accounting.trial', {});
  assert.ok(tb.balanced, `${label}: trial balance must balance`);
  const bs = call(app, 'accounting.balanceSheet', {});
  assert.ok(bs.balanced, `${label}: balance sheet must balance (A=${bs.total_assets} L=${bs.total_liabilities} E=${bs.total_equity})`);
  const chk = call(app, 'accounting.inventoryCheck', {});
  near(chk.inventory_diff, 0, `${label}: GL inventory vs stock valuation`, 0.05);
  near(chk.wip_diff, 0, `${label}: GL WIP vs open orders`, 0.05);
}

const dir = tmp('main');
let app;
const ids = {};

test('setup + login', () => {
  app = new App({ dataDir: dir, appVersion: '1.0.0-test', logger: quiet }).open();
  assert.equal(call(app, 'auth.status').needsSetup, true);
  call(app, 'auth.setup', { username: 'admin', fullName: 'مدير', password: 'secret1', passwordConfirm: 'secret1', companyName: 'ورشة الاختبار' });
  call(app, 'auth.logout');
  assert.equal(fail(app, 'products.list', {}).code, 'AUTH');
  assert.equal(fail(app, 'auth.login', { username: 'admin', password: 'wrong' }).code, 'AUTH');
  call(app, 'auth.login', { username: 'admin', password: 'secret1' });
  ids.wh = call(app, 'warehouses.list')[0].id;
  ids.unitM = call(app, 'units.list').find((u) => u.name === 'متر').id;
  ids.unitPc = call(app, 'units.list').find((u) => u.name === 'قطعة').id;
});

test('Scenario A — purchase', () => {
  ids.sup = call(app, 'suppliers.save', { name: 'مورد أ', phone: '0100' });
  ids.cat = call(app, 'categories.save', { name: 'خامات' });
  ids.matA = call(app, 'products.save', { name: 'مادة A', kind: 'raw', unit_id: ids.unitM, category_id: ids.cat, purchase_price: 10, min_qty: 20 });
  ids.accB = call(app, 'products.save', { name: 'إكسسوار B', kind: 'accessory', unit_id: ids.unitPc, purchase_price: 4 });
  // 100 units of A @10, 50 of B @4, 10% discount on header, part paid
  const r = call(app, 'purchases.create', { supplier_id: ids.sup, warehouse_id: ids.wh, date: '2026-09-01', lines: [{ product_id: ids.matA, qty: 100, unit_price: 10 }, { product_id: ids.accB, qty: 50, unit_price: 4 }], discount: 120, paid: 500, pay_method: 'cash' });
  ids.pi = r.id;
  const pA = call(app, 'products.get', { id: ids.matA });
  assert.equal(pA.qty, 100, 'stock of A should be 100');
  near(pA.avg_cost, 9, 'discount must flow into item cost (10 × 0.9)');
  const sup = call(app, 'suppliers.list', {}).rows.find((s) => s.id === ids.sup);
  near(sup.invoices_total, 1080, 'supplier purchases total');
  near(sup.paid, 500, 'supplier paid');
  near(sup.balance, 580, 'supplier balance = remaining');
  consistency(app, 'A');
});

test('Scenario B — manufacturing with BOM, actual consumption, labor, direct cost, overhead', () => {
  ids.prod = call(app, 'products.save', { name: 'منتج X', kind: 'finished', unit_id: ids.unitPc, sale_price: 500 });
  ids.bom = call(app, 'boms.save', { product_id: ids.prod, items: [{ product_id: ids.matA, qty: 10 }, { product_id: ids.accB, qty: 5 }] });
  const bom = call(app, 'boms.get', { id: ids.bom });
  near(bom.total_cost, 10 * 9 + 5 * 3.6, 'BOM cost');
  // cannot issue more than stock
  const mo = call(app, 'mo.create', { product_id: ids.prod, qty: 2, warehouse_id: ids.wh, overhead_type: 'percent', overhead_value: 10, agreed_price: 400 });
  ids.mo = mo.id;
  let d = call(app, 'mo.get', { id: ids.mo });
  near(d.materials.find((m) => m.product_id === ids.matA).planned_qty, 20, 'planned A');
  const e = fail(app, 'mo.issue', { mo_id: ids.mo, lines: [{ product_id: ids.matA, qty: 1000 }] });
  assert.match(e.message, /المتاح/);
  // actual 23 vs planned 20 (waste)
  const iss = call(app, 'mo.issue', { mo_id: ids.mo, lines: [{ product_id: ids.matA, qty: 23 }, { product_id: ids.accB, qty: 10 }] });
  assert.ok(iss.warnings.length >= 1, 'over-issue warning');
  call(app, 'mo.returnMaterial', { mo_id: ids.mo, product_id: ids.accB, qty: 1 });
  call(app, 'mo.addLabor', { mo_id: ids.mo, worker_name: 'عامل 1', rate_type: 'hour', qty: 8, rate: 25, pay_method: 'accrued' });
  call(app, 'mo.addCost', { mo_id: ids.mo, description: 'نقل', amount: 30, pay_method: 'cash' });
  d = call(app, 'mo.get', { id: ids.mo });
  assert.equal(d.stage, 'active');
  const a = d.materials.find((m) => m.product_id === ids.matA);
  near(a.actual_qty, 23, 'actual A'); near(a.diff_qty, 3, 'waste A'); near(a.waste_pct, 15, 'waste % A');
  const done = call(app, 'mo.complete', { id: ids.mo, produced_qty: 2 });
  const material = 23 * 9; const acc = 9 * 3.6; const labor = 200; const other = 30;
  const overhead = (material + acc + labor + other) * 0.10;
  near(done.total_cost, material + acc + labor + other + overhead, 'total manufacturing cost');
  const p = call(app, 'products.get', { id: ids.prod });
  assert.equal(p.qty, 2, 'finished goods in stock');
  near(p.avg_cost, done.unit_cost, 'finished avg cost = unit cost', 0.001);
  d = call(app, 'mo.get', { id: ids.mo });
  near(d.material_cost, material, 'material bucket'); near(d.accessories_cost, acc, 'accessories bucket'); near(d.labor_cost, 200, 'labor'); near(d.overhead_cost, overhead, 'overhead');
  assert.equal(fail(app, 'mo.addLabor', { mo_id: ids.mo, worker_name: 'x', rate_type: 'manual', total: 5 }).code, 'VALIDATION');
  consistency(app, 'B');
});

test('Scenario C — sale linked to the manufacturing order', () => {
  ids.cust = call(app, 'customers.save', { name: 'عميل 1', phone: '0111' });
  const moOpt = call(app, 'sales.moOptions', {});
  assert.ok(moOpt.find((m) => m.id === ids.mo));
  const unitCost = call(app, 'mo.get', { id: ids.mo }).unit_cost;
  const r = call(app, 'sales.create', { customer_id: ids.cust, warehouse_id: ids.wh, lines: [{ product_id: ids.prod, qty: 2, unit_price: 400, mo_id: ids.mo }], paid: 0 });
  ids.si = r.id;
  const inv = call(app, 'sales.get', { id: ids.si });
  near(inv.cost_total, unitCost * 2, 'COGS = MO cost');
  near(inv.gross_profit, 800 - unitCost * 2, 'profit on invoice');
  assert.equal(call(app, 'products.get', { id: ids.prod }).qty, 0, 'finished goods deducted');
  const inc = call(app, 'accounting.income', {});
  near(inc.net_sales, 800, 'revenue recorded');
  near(inc.cogs - 0, unitCost * 2 - call(app, 'mo.get', { id: ids.mo }).overhead_cost, 'COGS net of applied overhead credit');
  const d = call(app, 'mo.get', { id: ids.mo });
  assert.equal(d.profit.revenue_basis, 'actual');
  near(d.profit.gross_profit, 800 - d.total_cost, 'MO profitability');
  // over-selling blocked
  assert.match(fail(app, 'sales.create', { customer_id: ids.cust, warehouse_id: ids.wh, lines: [{ product_id: ids.prod, qty: 1, unit_price: 400 }] }).message, /المتاح/);
  consistency(app, 'C');
});

test('Scenario D — collection from customer', () => {
  const before = call(app, 'cash.summary').cash;
  call(app, 'payments.create', { direction: 'in', party_type: 'customer', party_id: ids.cust, amount: 300, method: 'cash' });
  const c = call(app, 'customers.list', {}).rows.find((x) => x.id === ids.cust);
  near(c.balance, 500, 'customer balance after collection');
  near(c.paid, 300, 'customer paid');
  near(call(app, 'cash.summary').cash, before + 300, 'cash increased');
  const st = call(app, 'statements.party', { party_type: 'customer', party_id: ids.cust });
  near(st.closing, 500, 'statement closing');
  consistency(app, 'D');
});

test('Scenario E — stocktaking', () => {
  const cnt = call(app, 'counts.create', { warehouse_id: ids.wh, date: '2026-09-20' });
  const g = call(app, 'counts.get', { id: cnt.id });
  const itemA = g.items.find((i) => i.product_id === ids.matA);
  near(itemA.system_qty, 77, 'system qty A (100 - 23)');
  call(app, 'counts.saveItems', { id: cnt.id, items: [{ product_id: ids.matA, actual_qty: 75, reason: 'تلف' }] });
  const g2 = call(app, 'counts.get', { id: cnt.id });
  const a2 = g2.items.find((i) => i.product_id === ids.matA);
  near(a2.diff, -2, 'count diff'); near(a2.diff_value, -18, 'diff value');
  const r = call(app, 'counts.approve', { id: cnt.id });
  assert.equal(r.differences, 1);
  assert.equal(call(app, 'products.get', { id: ids.matA }).qty, 75, 'stock updated after count');
  assert.equal(call(app, 'counts.get', { id: cnt.id }).status, 'approved');
  consistency(app, 'E');
});

test('returns, voids, expenses, opening balances, cash moves keep books consistent', () => {
  call(app, 'purchaseReturns.create', { invoice_id: ids.pi, lines: [{ product_id: ids.matA, qty: 5, unit_price: 9 }], settle: 'account' });
  near(call(app, 'suppliers.list', {}).rows.find((s) => s.id === ids.sup).balance, 580 - 45, 'supplier after purchase return');
  const sr = call(app, 'salesReturns.create', { invoice_id: ids.si, lines: [{ product_id: ids.prod, qty: 1, unit_price: 400 }], settle: 'account' });
  near(call(app, 'customers.list', {}).rows.find((c) => c.id === ids.cust).balance, 100, 'customer after sales return');
  assert.equal(call(app, 'products.get', { id: ids.prod }).qty, 1);
  consistency(app, 'returns');
  // voiding the invoice is blocked while a return exists
  assert.match(fail(app, 'sales.void', { id: ids.si, reason: 'x' }).message, /مرتجعات/);
  call(app, 'salesReturns.void', { id: sr.id, reason: 'خطأ' });
  call(app, 'sales.void', { id: ids.si, reason: 'خطأ إدخال' });
  assert.equal(call(app, 'products.get', { id: ids.prod }).qty, 2, 'stock restored after void');
  near(call(app, 'accounting.income', {}).net_sales, 0, 'voided sale leaves revenue');
  consistency(app, 'voids');
  call(app, 'expenses.create', { category_id: call(app, 'expenseCategories.list')[0].id, amount: 150, method: 'cash', description: 'أجور إدارية' });
  call(app, 'opening.create', { kind: 'customer', party_id: ids.cust, amount: 250 });
  call(app, 'opening.create', { kind: 'cash', amount: 1000 });
  call(app, 'inventory.opening', { warehouse_id: ids.wh, lines: [{ product_id: ids.accB, qty: 10, unit_cost: 5 }] });
  call(app, 'cash.createMove', { kind: 'pay_wages', amount: 200, method: 'cash' });
  call(app, 'cash.createMove', { kind: 'deposit', amount: 100 });
  const wh2 = call(app, 'warehouses.save', { name: 'مخزن 2' });
  call(app, 'transfers.create', { from_warehouse_id: ids.wh, to_warehouse_id: wh2, lines: [{ product_id: ids.matA, qty: 5 }] });
  call(app, 'adjustments.create', { warehouse_id: wh2, reason: 'كسر', lines: [{ product_id: ids.matA, qty_diff: -1 }] });
  consistency(app, 'misc');
  // a second MO cancelled after issuing: materials go back, labor written off
  const mo2 = call(app, 'mo.create', { product_id: ids.prod, qty: 1, warehouse_id: ids.wh });
  call(app, 'mo.issue', { mo_id: mo2.id, lines: [{ product_id: ids.matA, qty: 4 }] });
  call(app, 'mo.addLabor', { mo_id: mo2.id, worker_name: 'عامل', rate_type: 'fixed', total: 50, pay_method: 'cash' });
  const before = call(app, 'products.get', { id: ids.matA }).qty;
  const c = call(app, 'mo.cancel', { id: mo2.id, reason: 'إلغاء العميل' });
  near(c.write_off, 50, 'labor written off');
  assert.equal(call(app, 'products.get', { id: ids.matA }).qty, before + 4);
  consistency(app, 'mo cancel');
  // reopen completed MO then complete again
  call(app, 'mo.reopen', { id: ids.mo });
  call(app, 'mo.complete', { id: ids.mo, produced_qty: 2 });
  consistency(app, 'mo reopen');
  // every report runs
  const catalog = call(app, 'reports.catalog');
  assert.ok(catalog.length >= 22, 'at least 22 reports');
  for (const r of catalog) {
    const params = { product_id: ids.matA, customer_id: ids.cust, supplier_id: ids.sup };
    const out = call(app, 'reports.run', { id: r.id, params });
    assert.ok(Array.isArray(out.rows), `report ${r.id} rows`);
  }
  const dash = call(app, 'dashboard.get', { from: '2026-01-01', to: '2026-12-31' });
  assert.ok(dash.months.length === 12);
  assert.ok(call(app, 'search.global', { q: 'مادة' }).length > 0);
  assert.ok(call(app, 'audit.list', {}).total > 10, 'audit trail recorded');
});

test('permissions are enforced server-side', () => {
  const roles = call(app, 'roles.list').roles;
  const emp = roles.find((r) => r.name === 'موظف');
  call(app, 'users.save', { username: 'emp', full_name: 'موظف', role_id: emp.id, password: 'emp123' });
  call(app, 'auth.logout');
  call(app, 'auth.login', { username: 'emp', password: 'emp123' });
  assert.equal(fail(app, 'backup.restore', { path: 'x', confirm: true }).code, 'FORBIDDEN');
  assert.equal(fail(app, 'settings.save', { section: 'tax', value: { enabled: true } }).code, 'FORBIDDEN');
  assert.equal(fail(app, 'sales.void', { id: 1, reason: 'x' }).code, 'FORBIDDEN');
  const mo = call(app, 'mo.get', { id: ids.mo });
  assert.equal(mo.total_cost, undefined, 'employee does not see costs');
  call(app, 'auth.logout');
  call(app, 'auth.login', { username: 'admin', password: 'secret1' });
});

test('Scenario F — backup, change data, restore, data comes back (encrypted)', () => {
  const snap = { products: call(app, 'products.list', { all: true }).total, bal: call(app, 'customers.list', {}).rows.find((c) => c.id === ids.cust).balance };
  assert.equal(fail(app, 'backup.create', { password: '123456', passwordConfirm: '999999' }).code, 'VALIDATION');
  const b = call(app, 'backup.create', { password: 'pass123', passwordConfirm: 'pass123' });
  assert.ok(fs.existsSync(b.path) && /Workshop_Backup_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}\.backup$/.test(b.file));
  // change test data
  call(app, 'products.save', { name: 'صنف بعد النسخة', kind: 'raw', unit_id: ids.unitPc });
  call(app, 'payments.create', { direction: 'in', party_type: 'customer', party_id: ids.cust, amount: 50, method: 'cash' });
  // simulate closing the program
  app.close(); app = new App({ dataDir: dir, appVersion: '1.0.0-test', logger: quiet }).open();
  call(app, 'auth.login', { username: 'admin', password: 'secret1' });
  const info = call(app, 'backup.inspect', { path: b.path });
  assert.equal(info.encrypted, true); assert.ok(info.createdAt && info.appVersion && info.schemaVersion);
  assert.equal(fail(app, 'backup.restore', { path: b.path, password: 'wrong', confirm: true }).code, 'BAD_PASSWORD');
  const r = call(app, 'backup.restore', { path: b.path, password: 'pass123', confirm: true });
  assert.ok(fs.existsSync(r.safetyBackup), 'automatic safety backup before restore');
  assert.equal(call(app, 'products.list', { all: true }).total, snap.products, 'products restored');
  near(call(app, 'customers.list', {}).rows.find((c) => c.id === ids.cust).balance, snap.bal, 'balances restored');
  // corrupted file is rejected without touching data
  const bad = path.join(dir, 'bad.backup'); const buf = fs.readFileSync(b.path); buf[buf.length - 10] ^= 0xff; fs.writeFileSync(bad, buf);
  assert.equal(fail(app, 'backup.restore', { path: bad, password: 'pass123', confirm: true }).code, 'BAD_PASSWORD');
  consistency(app, 'after restore');
});

test('Machine transfer — backup restored into a fresh install', () => {
  const b = call(app, 'backup.create', {});
  const usb = tmp('usb'); const copy = path.join(usb, path.basename(b.path)); fs.copyFileSync(b.path, copy);
  const expected = {
    products: call(app, 'products.list', { all: true }).total, trial: call(app, 'accounting.trial', {}).total_debit,
    income: call(app, 'accounting.income', {}).net_profit, company: call(app, 'settings.get').company.companyName,
  };
  const other = new App({ dataDir: tmp('pc2'), appVersion: '1.0.0-test', logger: quiet }).open();
  call(other, 'auth.setup', { username: 'temp', fullName: 'مؤقت', password: 'temp12', passwordConfirm: 'temp12' });
  call(other, 'backup.restore', { path: copy, confirm: true });
  call(other, 'auth.logout');
  call(other, 'auth.login', { username: 'admin', password: 'secret1' });
  assert.equal(call(other, 'products.list', { all: true }).total, expected.products);
  near(call(other, 'accounting.trial', {}).total_debit, expected.trial, 'journal identical');
  near(call(other, 'accounting.income', {}).net_profit, expected.income, 'profit identical');
  assert.equal(call(other, 'settings.get').company.companyName, expected.company);
  other.close();
});

test('legacy localStorage import', () => {
  const legacy = {
    coa: [{ code: '6900', name: 'ضيافة', type: 'expense', nature: 'debit' }],
    customers: [{ id: 't1', name: 'عميل قديم', phone: '1', balance: 320 }],
    suppliers: [{ id: 't2', name: 'مورد قديم', balance: 150 }],
    items: [{ id: 'i1', name: 'صنف قديم', category: 'قديم', unit: 'قطعة', purchasePrice: 7, salePrice: 12, qty: 40, avgCost: 6.5 }],
    transactions: [{ journal: [{ account: '1100', debit: 900, credit: 0 }, { account: '3100', debit: 0, credit: 900 }] }],
  };
  const r = call(app, 'backup.importLegacy', { data: JSON.stringify(legacy) });
  assert.equal(r.products, 1); assert.equal(r.customers, 1); assert.equal(r.openings, 3);
  assert.equal(fail(app, 'backup.importLegacy', { data: legacy }).code, 'ALREADY_IMPORTED');
  consistency(app, 'legacy import');
});

test('auto backup keeps last N', () => {
  call(app, 'settings.save', { section: 'backup', value: { keepLast: 2, schedule: 'daily' } });
  for (let i = 0; i < 4; i++) { app.runAuto(); const t = Date.now(); while (Date.now() - t < 1100) { /* distinct timestamps */ } }
  const d = app.resolveBackupDir().dir;
  assert.equal(fs.readdirSync(d).filter((f) => f.endsWith('_auto.backup')).length, 2);
  // missing drive falls back safely
  call(app, 'settings.save', { section: 'backup', value: { location: path.join(__filename, 'not-a-dir') } });
  const res = call(app, 'backup.create', {});
  assert.ok(res.warning, 'fallback warning when location missing');
  app.close();
});
