'use strict';
const crypto = require('crypto');
const { AppError, str, nowISO, reqId } = require('../core/util');

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(String(password), salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
  return { hash, salt };
}

function verifyPassword(password, hash, salt) {
  const h = crypto.scryptSync(String(password), salt, 64, { N: 16384, r: 8, p: 1 });
  const b = Buffer.from(hash, 'hex');
  return b.length === h.length && crypto.timingSafeEqual(b, h);
}

function checkPasswordPolicy(ctx, password) {
  const min = ctx.settings().security.minPasswordLength || 6;
  if (!password || String(password).length < min) throw new AppError(`كلمة المرور يجب ألا تقل عن ${min} أحرف`, 'VALIDATION');
}

function loadSessionUser(db, id) {
  const u = db.get('SELECT u.id, u.username, u.full_name, u.role_id, u.active, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?', id);
  if (!u) return null;
  const perms = new Set(db.all('SELECT perm_code FROM role_permissions WHERE role_id = ?', u.role_id).map((r) => r.perm_code));
  return { ...u, perms };
}

const publicUser = (u) => (u ? { id: u.id, username: u.username, fullName: u.full_name, roleId: u.role_id, roleName: u.role_name, permissions: [...u.perms] } : null);

module.exports = {
  'auth.status': {
    public: true,
    fn(ctx) {
      const n = Number(ctx.db.val('SELECT COUNT(*) FROM users')) || 0;
      const s = ctx.settings();
      return { needsSetup: n === 0, appName: s.company.appName, companyName: s.company.companyName, version: ctx.appVersion, user: publicUser(ctx.user) };
    },
  },
  'auth.setup': {
    public: true, write: true,
    fn(ctx, a) {
      if ((Number(ctx.db.val('SELECT COUNT(*) FROM users')) || 0) > 0) throw new AppError('تم إعداد النظام بالفعل', 'FORBIDDEN');
      const username = str(a.username, 'اسم المستخدم', { required: true, max: 50 });
      const fullName = str(a.fullName, 'الاسم', { required: true, max: 100 });
      checkPasswordPolicy(ctx, a.password);
      if (a.password !== a.passwordConfirm) throw new AppError('كلمتا المرور غير متطابقتين', 'VALIDATION');
      const role = ctx.db.get("SELECT id FROM roles WHERE name = 'مدير النظام'");
      const { hash, salt } = hashPassword(a.password);
      const id = ctx.db.insert('users', { username, full_name: fullName, password_hash: hash, password_salt: salt, role_id: role.id, created_at: nowISO() });
      ctx.setSetting('company', {
        appName: str(a.appName, 'اسم البرنامج', { max: 120 }) || ctx.settings().company.appName,
        companyName: str(a.companyName, 'اسم المنشأة', { max: 150 }),
      });
      if (a.currencySymbol) ctx.setSetting('currency', { symbol: str(a.currencySymbol, 'رمز العملة', { max: 10 }), code: str(a.currencyCode, 'كود العملة', { max: 10 }) || 'EGP' });
      ctx.user = loadSessionUser(ctx.db, id);
      ctx.audit('setup', { entity: 'users', entityId: id, notes: 'الإعداد الأول للنظام' });
      return publicUser(ctx.user);
    },
  },
  'auth.login': {
    public: true, write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const u = db.get('SELECT * FROM users WHERE username = ?', str(a.username, 'اسم المستخدم', { required: true }));
      const bad = new AppError('اسم المستخدم أو كلمة المرور غير صحيحة', 'AUTH');
      if (!u) throw bad;
      if (!u.active) throw new AppError('هذا المستخدم موقوف. تواصل مع مدير النظام.', 'AUTH');
      if (u.locked_until && u.locked_until > nowISO()) throw new AppError('تم إيقاف الدخول مؤقتًا بسبب محاولات خاطئة متكررة. حاول بعد دقائق.', 'AUTH');
      if (!verifyPassword(a.password || '', u.password_hash, u.password_salt)) {
        const sec = ctx.settings().security;
        const fails = u.failed_attempts + 1;
        const lock = fails >= sec.lockAfterFailures ? new Date(Date.now() + sec.lockMinutes * 60000).toISOString() : null;
        db.update('users', u.id, { failed_attempts: lock ? 0 : fails, locked_until: lock });
        ctx.audit('login_failed', { entity: 'users', entityId: u.id, notes: u.username });
        throw bad;
      }
      db.update('users', u.id, { failed_attempts: 0, locked_until: null, last_login_at: nowISO() });
      ctx.user = loadSessionUser(db, u.id);
      ctx.audit('login', { entity: 'users', entityId: u.id });
      return publicUser(ctx.user);
    },
  },
  'auth.logout': { public: true, write: true, fn(ctx) { if (ctx.user) ctx.audit('logout', { entity: 'users', entityId: ctx.user.id }); ctx.user = null; return true; } },
  'auth.me': { fn(ctx) { return publicUser(ctx.user); } },
  'auth.changePassword': {
    write: true,
    fn(ctx, a) {
      const u = ctx.db.get('SELECT * FROM users WHERE id = ?', ctx.userId());
      if (!verifyPassword(a.current || '', u.password_hash, u.password_salt)) throw new AppError('كلمة المرور الحالية غير صحيحة', 'VALIDATION');
      checkPasswordPolicy(ctx, a.password);
      if (a.password !== a.passwordConfirm) throw new AppError('كلمتا المرور غير متطابقتين', 'VALIDATION');
      const { hash, salt } = hashPassword(a.password);
      ctx.db.update('users', u.id, { password_hash: hash, password_salt: salt, updated_at: nowISO() });
      ctx.audit('change_password', { entity: 'users', entityId: u.id });
      return true;
    },
  },

  // ---------------- users ----------------
  'users.list': {
    perm: 'users.manage',
    fn(ctx) {
      return ctx.db.all('SELECT u.id, u.username, u.full_name, u.role_id, r.name AS role_name, u.active, u.last_login_at, u.created_at FROM users u JOIN roles r ON r.id = u.role_id ORDER BY u.id');
    },
  },
  'users.save': {
    perm: 'users.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const data = {
        username: str(a.username, 'اسم المستخدم', { required: true, max: 50 }),
        full_name: str(a.full_name, 'الاسم', { required: true, max: 100 }),
        role_id: reqId(a.role_id, 'الدور'),
        active: a.active === undefined ? 1 : (a.active ? 1 : 0),
      };
      const dup = db.get('SELECT id FROM users WHERE username = ? AND id <> ?', data.username, a.id || 0);
      if (dup) throw new AppError('اسم المستخدم مستخدم بالفعل', 'VALIDATION');
      if (a.id) {
        const old = db.get('SELECT * FROM users WHERE id = ?', a.id);
        if (!old) throw new AppError('المستخدم غير موجود', 'NOT_FOUND');
        if (old.id === ctx.userId() && (!data.active || data.role_id !== old.role_id)) {
          const stillAdmin = db.get("SELECT 1 FROM role_permissions WHERE role_id = ? AND perm_code = 'users.manage'", data.role_id);
          if (!data.active || !stillAdmin) throw new AppError('لا يمكنك إيقاف حسابك أو سحب صلاحية إدارة المستخدمين من نفسك', 'VALIDATION');
        }
        if (a.password) { checkPasswordPolicy(ctx, a.password); Object.assign(data, (({ hash, salt }) => ({ password_hash: hash, password_salt: salt }))(hashPassword(a.password))); }
        data.updated_at = nowISO();
        db.update('users', a.id, data);
        ctx.audit('update', { entity: 'users', entityId: a.id, oldData: old, newData: data });
        return a.id;
      }
      checkPasswordPolicy(ctx, a.password);
      const { hash, salt } = hashPassword(a.password);
      const id = db.insert('users', { ...data, password_hash: hash, password_salt: salt, created_at: nowISO() });
      ctx.audit('create', { entity: 'users', entityId: id, newData: data });
      return id;
    },
  },

  // ---------------- roles ----------------
  'roles.list': {
    perm: 'users.manage',
    fn(ctx) {
      const roles = ctx.db.all('SELECT r.*, (SELECT COUNT(*) FROM users u WHERE u.role_id = r.id) AS users_count FROM roles r ORDER BY r.id');
      roles.forEach((r) => { r.permissions = ctx.db.all('SELECT perm_code FROM role_permissions WHERE role_id = ?', r.id).map((x) => x.perm_code); });
      return { roles, permissions: ctx.db.all('SELECT * FROM permissions ORDER BY sort') };
    },
  },
  'roles.save': {
    perm: 'users.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const name = str(a.name, 'اسم الدور', { required: true, max: 60 });
      const perms = Array.isArray(a.permissions) ? a.permissions : [];
      const valid = new Set(db.all('SELECT code FROM permissions').map((r) => r.code));
      perms.forEach((p) => { if (!valid.has(p)) throw new AppError('صلاحية غير معروفة: ' + p, 'VALIDATION'); });
      if (db.get('SELECT id FROM roles WHERE name = ? AND id <> ?', name, a.id || 0)) throw new AppError('اسم الدور مستخدم بالفعل', 'VALIDATION');
      let id = a.id;
      if (id) {
        const old = db.get('SELECT * FROM roles WHERE id = ?', id);
        if (!old) throw new AppError('الدور غير موجود', 'NOT_FOUND');
        const oldPerms = db.all('SELECT perm_code FROM role_permissions WHERE role_id = ?', id).map((r) => r.perm_code);
        if (id === ctx.user.role_id && !perms.includes('users.manage')) throw new AppError('لا يمكنك إزالة صلاحية إدارة المستخدمين من دورك الحالي', 'VALIDATION');
        db.update('roles', id, { name, description: str(a.description, 'الوصف', { max: 200 }) });
        db.run('DELETE FROM role_permissions WHERE role_id = ?', id);
        ctx.audit('update', { entity: 'roles', entityId: id, oldData: { ...old, permissions: oldPerms }, newData: { name, permissions: perms } });
      } else {
        id = db.insert('roles', { name, description: str(a.description, 'الوصف', { max: 200 }), created_at: nowISO() });
        ctx.audit('create', { entity: 'roles', entityId: id, newData: { name, permissions: perms } });
      }
      perms.forEach((p) => db.run('INSERT INTO role_permissions(role_id, perm_code) VALUES (?,?)', id, p));
      if (ctx.user) ctx.user = loadSessionUser(db, ctx.user.id);
      return id;
    },
  },
  'roles.delete': {
    perm: 'users.manage', write: true,
    fn(ctx, a) {
      const r = ctx.db.get('SELECT * FROM roles WHERE id = ?', a.id);
      if (!r) throw new AppError('الدور غير موجود', 'NOT_FOUND');
      if (r.is_system) throw new AppError('لا يمكن حذف الأدوار الأساسية، يمكنك تعديل صلاحياتها', 'VALIDATION');
      if (Number(ctx.db.val('SELECT COUNT(*) FROM users WHERE role_id = ?', r.id)) > 0) throw new AppError('لا يمكن حذف دور مرتبط بمستخدمين', 'VALIDATION');
      ctx.db.run('DELETE FROM roles WHERE id = ?', r.id);
      ctx.audit('delete', { entity: 'roles', entityId: r.id, oldData: r });
      return true;
    },
  },
};

module.exports.hashPassword = hashPassword;
module.exports.loadSessionUser = loadSessionUser;
module.exports.publicUser = publicUser;
