'use strict';
const { AppError, str, num, nowISO, idOrNull } = require('../core/util');
const { paged, addSearch } = require('../core/query');
const { ACC } = require('../core/ledger');

function ensureUnique(db, table, col, value, id, label) {
  if (db.get(`SELECT id FROM ${table} WHERE ${col} = ? AND id <> ?`, value, id || 0)) throw new AppError(`${label} "${value}" مستخدم بالفعل`, 'VALIDATION');
}

/** Delete master row only if unreferenced; otherwise explain and suggest deactivation. */
function safeDelete(ctx, table, id, label, refs) {
  const db = ctx.db;
  const row = db.get(`SELECT * FROM ${table} WHERE id = ?`, id);
  if (!row) throw new AppError(`${label} غير موجود`, 'NOT_FOUND');
  for (const [sql, what] of refs) {
    if (Number(db.val(sql, id)) > 0) throw new AppError(`لا يمكن حذف ${label} "${row.name || row.code}" لأنه مستخدم في ${what}. يمكنك إيقافه بدلًا من الحذف.`, 'IN_USE');
  }
  db.run(`DELETE FROM ${table} WHERE id = ?`, id);
  ctx.audit('delete', { entity: table, entityId: id, oldData: row });
  return true;
}

function toggleActive(ctx, table, id) {
  const row = ctx.db.get(`SELECT * FROM ${table} WHERE id = ?`, id);
  if (!row) throw new AppError('السجل غير موجود', 'NOT_FOUND');
  ctx.db.update(table, id, { active: row.active ? 0 : 1 });
  ctx.audit(row.active ? 'deactivate' : 'activate', { entity: table, entityId: id, notes: row.name || '' });
  return !row.active;
}

const partyBalanceSql = (type) => {
  const acct = type === 'customer' ? ACC.AR : ACC.AP;
  const expr = type === 'customer' ? 'l.debit - l.credit' : 'l.credit - l.debit';
  return `(SELECT COALESCE(SUM(${expr}),0) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
     WHERE e.status='posted' AND l.account_code='${acct}' AND l.party_type='${type}' AND l.party_id = x.id)`;
};
const partyPaidSql = (type) => (type === 'customer'
  ? `(SELECT COALESCE(SUM(CASE WHEN e.doc_type IN ('sale','receipt') THEN l.credit WHEN e.doc_type='payment' THEN -l.debit ELSE 0 END),0)
      FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id WHERE e.status='posted' AND l.account_code='${ACC.AR}' AND l.party_type='customer' AND l.party_id=x.id)`
  : `(SELECT COALESCE(SUM(CASE WHEN e.doc_type IN ('purchase','payment') THEN l.debit WHEN e.doc_type='receipt' THEN -l.credit ELSE 0 END),0)
      FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id WHERE e.status='posted' AND l.account_code='${ACC.AP}' AND l.party_type='supplier' AND l.party_id=x.id)`);

function partyList(ctx, type, a) {
  const table = type === 'customer' ? 'customers' : 'suppliers';
  const docTable = type === 'customer' ? 'sales_invoices' : 'purchase_invoices';
  const retTable = type === 'customer' ? 'sales_returns' : 'purchase_returns';
  const fk = type === 'customer' ? 'customer_id' : 'supplier_id';
  const where = []; const params = [];
  addSearch(where, params, a.q, ['x.name', 'x.code', 'x.phone', 'x.email']);
  if (a.id) { where.push('x.id = ?'); params.push(Number(a.id)); }
  if (a.active === 'active') where.push('x.active = 1');
  if (a.active === 'inactive') where.push('x.active = 0');
  const bal = partyBalanceSql(type);
  if (a.balance === 'due') where.push(`${bal} > 0.004`);
  return paged(ctx.db, {
    select: `x.*, ${bal} AS balance, ${partyPaidSql(type)} AS paid,
      (SELECT COALESCE(SUM(total),0) FROM ${docTable} d WHERE d.${fk} = x.id AND d.status='posted') AS invoices_total,
      (SELECT COALESCE(SUM(total),0) FROM ${retTable} d WHERE d.${fk} = x.id AND d.status='posted') AS returns_total`,
    from: `${table} x`, where, params,
    sortMap: { name: 'x.name', code: 'x.code', balance: 'balance', invoices_total: 'invoices_total' },
    defaultSort: 'x.name', sort: a.sort, dir: a.dir, page: a.page, pageSize: a.pageSize, all: a.all,
  });
}

function partySave(ctx, type, a) {
  const db = ctx.db;
  const table = type === 'customer' ? 'customers' : 'suppliers';
  const label = type === 'customer' ? 'العميل' : 'المورد';
  const data = {
    name: str(a.name, `اسم ${label}`, { required: true, max: 150 }),
    phone: str(a.phone, 'الهاتف', { max: 50 }), email: str(a.email, 'البريد', { max: 120 }),
    address: str(a.address, 'العنوان', { max: 300 }), contact_person: str(a.contact_person, 'مسؤول التواصل', { max: 100 }),
    tax_no: str(a.tax_no, 'الرقم الضريبي', { max: 50 }), notes: str(a.notes, 'ملاحظات', { max: 2000 }),
  };
  if (type === 'customer') data.credit_limit = num(a.credit_limit, 'حد الائتمان', { min: 0 });
  if (a.id) {
    const old = db.get(`SELECT * FROM ${table} WHERE id = ?`, a.id);
    if (!old) throw new AppError(`${label} غير موجود`, 'NOT_FOUND');
    if (a.code && a.code !== old.code) { ensureUnique(db, table, 'code', a.code.trim(), a.id, 'الكود'); data.code = a.code.trim(); }
    data.updated_at = nowISO();
    db.update(table, a.id, data);
    ctx.audit('update', { entity: table, entityId: a.id, oldData: old, newData: data });
    return a.id;
  }
  data.code = ctx.code(table, type, a.code);
  ensureUnique(db, table, 'code', data.code, 0, 'الكود');
  data.created_at = nowISO();
  const id = db.insert(table, data);
  ctx.audit('create', { entity: table, entityId: id, newData: data });
  return id;
}

/** Light list for pickers, with current balance (from the ledger). */
function partyOptionsQ(ctx, type) {
  const acc = type === 'customer' ? "'1300'" : "'2100'";
  const sign = type === 'customer' ? 'l.debit - l.credit' : 'l.credit - l.debit';
  return ctx.db.all(`SELECT t.id, t.code, t.name, t.phone, t.active, ${type === 'customer' ? 't.credit_limit' : '0 AS credit_limit'},
      COALESCE((SELECT SUM(${sign}) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status='posted' AND l.account_code = ${acc} AND l.party_type = '${type}' AND l.party_id = t.id),0) AS balance
    FROM ${type}s t WHERE t.active = 1 ORDER BY t.name`);
}

module.exports = {
  // ---------------- categories ----------------
  'categories.list': { fn(ctx) { return ctx.db.all('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS products_count FROM categories c ORDER BY c.name'); } },
  'categories.save': {
    perm: 'products.edit', write: true,
    fn(ctx, a) {
      const name = str(a.name, 'اسم التصنيف', { required: true, max: 100 });
      ensureUnique(ctx.db, 'categories', 'name', name, a.id, 'التصنيف');
      const data = { name, notes: str(a.notes, 'ملاحظات', { max: 500 }), parent_id: idOrNull(a.parent_id) };
      if (data.parent_id && data.parent_id === a.id) throw new AppError('لا يمكن أن يكون التصنيف أبًا لنفسه', 'VALIDATION');
      if (a.id) { const old = ctx.db.get('SELECT * FROM categories WHERE id=?', a.id); ctx.db.update('categories', a.id, data); ctx.audit('update', { entity: 'categories', entityId: a.id, oldData: old, newData: data }); return a.id; }
      const id = ctx.db.insert('categories', { ...data, created_at: nowISO() });
      ctx.audit('create', { entity: 'categories', entityId: id, newData: data });
      return id;
    },
  },
  'categories.delete': {
    perm: 'products.edit', write: true,
    fn(ctx, a) { return safeDelete(ctx, 'categories', a.id, 'التصنيف', [['SELECT COUNT(*) FROM products WHERE category_id = ?', 'أصناف'], ['SELECT COUNT(*) FROM categories WHERE parent_id = ?', 'تصنيفات فرعية']]); },
  },

  // ---------------- units ----------------
  'units.list': { fn(ctx) { return ctx.db.all('SELECT u.*, (SELECT COUNT(*) FROM products p WHERE p.unit_id = u.id) AS products_count FROM units u ORDER BY u.id'); } },
  'units.save': {
    perm: 'products.edit', write: true,
    fn(ctx, a) {
      const name = str(a.name, 'اسم الوحدة', { required: true, max: 50 });
      ensureUnique(ctx.db, 'units', 'name', name, a.id, 'الوحدة');
      const data = { name, symbol: str(a.symbol, 'الرمز', { max: 20 }) || name, allow_fraction: a.allow_fraction === false || a.allow_fraction === 0 ? 0 : 1 };
      if (a.id) { ctx.db.update('units', a.id, data); ctx.audit('update', { entity: 'units', entityId: a.id, newData: data }); return a.id; }
      const id = ctx.db.insert('units', { ...data, created_at: nowISO() });
      ctx.audit('create', { entity: 'units', entityId: id, newData: data });
      return id;
    },
  },
  'units.delete': { perm: 'products.edit', write: true, fn(ctx, a) { return safeDelete(ctx, 'units', a.id, 'الوحدة', [['SELECT COUNT(*) FROM products WHERE unit_id = ?', 'أصناف']]); } },

  // ---------------- warehouses ----------------
  'warehouses.list': {
    fn(ctx) {
      return ctx.db.all(`SELECT w.*, (SELECT COUNT(*) FROM stock s WHERE s.warehouse_id = w.id AND ABS(s.qty) > 0.00001) AS items_count,
        (SELECT COALESCE(SUM(s.qty * p.avg_cost),0) FROM stock s JOIN products p ON p.id = s.product_id WHERE s.warehouse_id = w.id) AS stock_value
        FROM warehouses w ORDER BY w.is_default DESC, w.name`);
    },
  },
  'warehouses.save': {
    perm: 'inventory.adjust', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const name = str(a.name, 'اسم المخزن', { required: true, max: 100 });
      ensureUnique(db, 'warehouses', 'name', name, a.id, 'المخزن');
      const data = { name, notes: str(a.notes, 'ملاحظات', { max: 500 }) };
      let id = a.id;
      if (id) { db.update('warehouses', id, data); ctx.audit('update', { entity: 'warehouses', entityId: id, newData: data }); } else {
        data.code = ctx.code('warehouses', 'warehouse', a.code);
        ensureUnique(db, 'warehouses', 'code', data.code, 0, 'كود المخزن');
        id = db.insert('warehouses', { ...data, created_at: nowISO() });
        ctx.audit('create', { entity: 'warehouses', entityId: id, newData: data });
      }
      if (a.is_default) { db.run('UPDATE warehouses SET is_default = 0'); db.run('UPDATE warehouses SET is_default = 1, active = 1 WHERE id = ?', id); }
      return id;
    },
  },
  'warehouses.toggle': {
    perm: 'inventory.adjust', write: true,
    fn(ctx, a) {
      const w = ctx.db.get('SELECT * FROM warehouses WHERE id = ?', a.id);
      if (w && w.is_default && w.active) throw new AppError('لا يمكن إيقاف المخزن الافتراضي', 'VALIDATION');
      return toggleActive(ctx, 'warehouses', a.id);
    },
  },
  'warehouses.delete': {
    perm: 'data.delete', write: true,
    fn(ctx, a) {
      const w = ctx.db.get('SELECT * FROM warehouses WHERE id = ?', a.id);
      if (w && w.is_default) throw new AppError('لا يمكن حذف المخزن الافتراضي', 'VALIDATION');
      ctx.db.run('DELETE FROM stock WHERE warehouse_id = ? AND ABS(qty) < 0.00001', a.id);
      return safeDelete(ctx, 'warehouses', a.id, 'المخزن', [['SELECT COUNT(*) FROM inventory_transactions WHERE warehouse_id = ?', 'حركات مخزون'], ['SELECT COUNT(*) FROM stock WHERE warehouse_id = ?', 'أرصدة مخزون']]);
    },
  },

  // ---------------- customers / suppliers ----------------
  'customers.list': { perm: ['customers.manage', 'sales.view', 'sales.create'], fn: (ctx, a) => partyList(ctx, 'customer', a || {}) },
  'customers.get': {
    perm: ['customers.manage', 'sales.view'],
    fn(ctx, a) {
      const r = partyList(ctx, 'customer', { id: a.id, all: true, active: 'all' }).rows.find((x) => x.id === Number(a.id));
      if (!r) throw new AppError('العميل غير موجود', 'NOT_FOUND');
      return r;
    },
  },
  'customers.options': { fn(ctx) { return partyOptionsQ(ctx, 'customer'); } },
  'customers.save': { perm: 'customers.manage', write: true, fn: (ctx, a) => partySave(ctx, 'customer', a) },
  'customers.toggle': { perm: 'customers.manage', write: true, fn: (ctx, a) => toggleActive(ctx, 'customers', a.id) },
  'customers.delete': {
    perm: 'data.delete', write: true,
    fn: (ctx, a) => safeDelete(ctx, 'customers', a.id, 'العميل', [
      ["SELECT COUNT(*) FROM journal_lines WHERE party_type='customer' AND party_id = ?", 'قيود محاسبية'],
      ['SELECT COUNT(*) FROM sales_invoices WHERE customer_id = ?', 'فواتير بيع'],
      ['SELECT COUNT(*) FROM manufacturing_orders WHERE customer_id = ?', 'أوامر تصنيع'],
    ]),
  },
  'suppliers.list': { perm: ['suppliers.manage', 'purchases.view', 'purchases.create'], fn: (ctx, a) => partyList(ctx, 'supplier', a || {}) },
  'suppliers.get': {
    perm: ['suppliers.manage', 'purchases.view'],
    fn(ctx, a) {
      const r = partyList(ctx, 'supplier', { id: a.id, all: true, active: 'all' }).rows.find((x) => x.id === Number(a.id));
      if (!r) throw new AppError('المورد غير موجود', 'NOT_FOUND');
      return r;
    },
  },
  'suppliers.options': { fn(ctx) { return partyOptionsQ(ctx, 'supplier'); } },
  'suppliers.save': { perm: 'suppliers.manage', write: true, fn: (ctx, a) => partySave(ctx, 'supplier', a) },
  'suppliers.toggle': { perm: 'suppliers.manage', write: true, fn: (ctx, a) => toggleActive(ctx, 'suppliers', a.id) },
  'suppliers.delete': {
    perm: 'data.delete', write: true,
    fn: (ctx, a) => safeDelete(ctx, 'suppliers', a.id, 'المورد', [
      ["SELECT COUNT(*) FROM journal_lines WHERE party_type='supplier' AND party_id = ?", 'قيود محاسبية'],
      ['SELECT COUNT(*) FROM purchase_invoices WHERE supplier_id = ?', 'فواتير شراء'],
      ['SELECT COUNT(*) FROM products WHERE default_supplier_id = ?', 'أصناف (مورد افتراضي)'],
    ]),
  },

  // ---------------- workers ----------------
  'workers.list': {
    perm: ['manufacturing.view', 'manufacturing.manage'],
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['w.name', 'w.code', 'w.job', 'w.phone']);
      if (a.onlyActive) where.push('w.active = 1');
      return ctx.db.all(`SELECT w.*, (SELECT COALESCE(SUM(total),0) FROM mo_labor l WHERE l.worker_id = w.id AND l.status='posted') AS labor_total
        FROM workers w ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY w.active DESC, w.name`, ...params);
    },
  },
  'workers.save': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const data = {
        name: str(a.name, 'اسم العامل', { required: true, max: 100 }), phone: str(a.phone, 'الهاتف', { max: 50 }), job: str(a.job, 'الوظيفة', { max: 100 }),
        rate_type: ['hour', 'day', 'piece', 'fixed', 'manual'].includes(a.rate_type) ? a.rate_type : 'day',
        rate: num(a.rate, 'الأجر', { min: 0 }), notes: str(a.notes, 'ملاحظات', { max: 500 }),
      };
      if (a.id) { ctx.db.update('workers', a.id, data); ctx.audit('update', { entity: 'workers', entityId: a.id, newData: data }); return a.id; }
      data.code = ctx.code('workers', 'worker', a.code);
      const id = ctx.db.insert('workers', { ...data, created_at: nowISO() });
      ctx.audit('create', { entity: 'workers', entityId: id, newData: data });
      return id;
    },
  },
  'workers.toggle': { perm: 'manufacturing.manage', write: true, fn: (ctx, a) => toggleActive(ctx, 'workers', a.id) },

  // ---------------- expense categories ----------------
  'expenseCategories.list': {
    fn(ctx) {
      return ctx.db.all(`SELECT c.*, a.name AS account_name, (SELECT COALESCE(SUM(amount),0) FROM expenses x WHERE x.category_id = c.id AND x.status='posted') AS total
        FROM expense_categories c JOIN accounts a ON a.code = c.account_code ORDER BY c.name`);
    },
  },
  'expenseCategories.save': {
    perm: 'expenses.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const name = str(a.name, 'اسم التصنيف', { required: true, max: 100 });
      ensureUnique(db, 'expense_categories', 'name', name, a.id, 'التصنيف');
      if (a.id) {
        const old = db.get('SELECT * FROM expense_categories WHERE id = ?', a.id);
        db.update('expense_categories', a.id, { name });
        db.run('UPDATE accounts SET name = ? WHERE code = ? AND is_system = 0', name, old.account_code);
        ctx.audit('update', { entity: 'expense_categories', entityId: a.id, oldData: old, newData: { name } });
        return a.id;
      }
      // every expense category gets its own expense account so the P&L breaks down by category
      let code = a.account_code && db.get("SELECT code FROM accounts WHERE code = ? AND type = 'expense'", a.account_code) ? a.account_code : null;
      if (!code) {
        const max = Number(db.val("SELECT MAX(CAST(code AS INTEGER)) FROM accounts WHERE type='expense' AND code GLOB '6[0-9][0-9][0-9]'")) || 6000;
        code = String(max + 100 > 6999 ? max + 1 : max + 100);
        db.insert('accounts', { code, name, type: 'expense', nature: 'debit', is_system: 0, created_at: nowISO() });
      }
      const id = db.insert('expense_categories', { name, account_code: code, created_at: nowISO() });
      ctx.audit('create', { entity: 'expense_categories', entityId: id, newData: { name, account_code: code } });
      return id;
    },
  },
  'expenseCategories.toggle': { perm: 'expenses.manage', write: true, fn: (ctx, a) => toggleActive(ctx, 'expense_categories', a.id) },

  // ---------------- chart of accounts (from the original system) ----------------
  'accounts.list': {
    perm: ['accounting.view', 'accounting.manage'],
    fn(ctx) {
      return ctx.db.all(`SELECT a.*,
        (SELECT COALESCE(SUM(l.debit),0) FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id WHERE e.status='posted' AND l.account_code=a.code) AS debit,
        (SELECT COALESCE(SUM(l.credit),0) FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id WHERE e.status='posted' AND l.account_code=a.code) AS credit
        FROM accounts a ORDER BY a.code`).map((r) => ({ ...r, balance: r.nature === 'debit' ? r.debit - r.credit : r.credit - r.debit }));
    },
  },
  'accounts.save': {
    perm: 'accounting.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const code = str(a.code, 'كود الحساب', { required: true, max: 10 });
      const name = str(a.name, 'اسم الحساب', { required: true, max: 100 });
      if (!/^[0-9]+$/.test(code)) throw new AppError('كود الحساب يجب أن يكون أرقامًا فقط', 'VALIDATION');
      const types = ['asset', 'liability', 'equity', 'revenue', 'cogs', 'expense'];
      const existing = db.get('SELECT * FROM accounts WHERE code = ?', code);
      if (a.isNew && existing) throw new AppError('الكود مستخدم بالفعل', 'VALIDATION');
      if (existing) {
        db.run('UPDATE accounts SET name = ? WHERE code = ?', name, code);
        ctx.audit('update', { entity: 'accounts', entityId: code, oldData: existing, newData: { name } });
        return code;
      }
      if (!types.includes(a.type)) throw new AppError('نوع الحساب غير صحيح', 'VALIDATION');
      const nature = a.nature === 'credit' ? 'credit' : 'debit';
      db.insert('accounts', { code, name, type: a.type, nature, is_system: 0, created_at: nowISO() });
      ctx.audit('create', { entity: 'accounts', entityId: code, newData: { code, name, type: a.type, nature } });
      return code;
    },
  },

  // ---------------- manufacturing statuses ----------------
  'moStatuses.list': { fn(ctx) { return ctx.db.all('SELECT * FROM mo_statuses ORDER BY sort, code'); } },
  'moStatuses.save': {
    perm: 'settings.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const name = str(a.name, 'اسم الحالة', { required: true, max: 50 });
      const color = /^#[0-9a-fA-F]{6}$/.test(a.color || '') ? a.color : '#6b6455';
      const existing = a.code ? db.get('SELECT * FROM mo_statuses WHERE code = ?', a.code) : null;
      if (existing) {
        db.run('UPDATE mo_statuses SET name = ?, color = ?, sort = ?, active = ? WHERE code = ?', name, color, Number(a.sort) || existing.sort,
          existing.is_system ? 1 : (a.active === false ? 0 : 1), existing.code);
        ctx.audit('update', { entity: 'mo_statuses', entityId: existing.code, oldData: existing, newData: { name, color } });
        return existing.code;
      }
      // custom statuses are "in production" stages; system stages (done/cancelled) stay under system control
      const stage = a.stage === 'open' ? 'open' : 'active';
      const code = 'custom_' + Date.now().toString(36);
      db.run('INSERT INTO mo_statuses(code,name,color,stage,sort,is_system,active) VALUES (?,?,?,?,?,0,1)', code, name, color, stage, Number(a.sort) || 50);
      ctx.audit('create', { entity: 'mo_statuses', entityId: code, newData: { name, color, stage } });
      return code;
    },
  },

  // ---------------- settings ----------------
  'settings.get': { fn(ctx) { return ctx.settings(); } },
  'settings.save': {
    perm: 'settings.manage', write: true,
    fn(ctx, a) {
      const old = ctx.settings()[a.section];
      const v = a.value || {};
      if (a.section === 'currency') {
        v.decimals = Math.min(4, Math.max(0, parseInt(v.decimals, 10) || 0));
        if (!String(v.symbol || '').trim()) throw new AppError('من فضلك أدخل رمز العملة', 'VALIDATION');
      }
      if (a.section === 'tax') v.defaultRate = num(v.defaultRate, 'نسبة الضريبة', { min: 0 });
      if (a.section === 'backup' && v.keepLast !== undefined) v.keepLast = Math.max(1, Math.min(365, parseInt(v.keepLast, 10) || 10));
      if (a.section === 'company' && v.appName !== undefined && !String(v.appName).trim()) throw new AppError('اسم البرنامج مطلوب', 'VALIDATION');
      const saved = ctx.setSetting(a.section, v);
      ctx.audit('settings', { entity: 'settings', entityId: a.section, oldData: old, newData: saved });
      return saved;
    },
  },
};

module.exports.partyBalanceSql = partyBalanceSql;
