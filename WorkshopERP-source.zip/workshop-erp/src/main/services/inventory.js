'use strict';
const { AppError, str, num, money, qtyR, nowISO, reqId, isoDate, EPS, todayISO } = require('../core/util');
const { paged, addSearch, addDateRange } = require('../core/query');
const ledger = require('../core/ledger');
const inv = require('../core/inventory');
const docs = require('../core/docs');

const { ACC } = ledger;

function valueCost(p, given) {
  const g = Number(given);
  if (given !== undefined && given !== '' && given !== null && Number.isFinite(g) && g >= 0) return g;
  return p.avg_cost > 0 ? p.avg_cost : (p.last_purchase_price || p.purchase_price || 0);
}

/** Posts adjustment lines (qty_diff +/-) and its journal. contra = account opposite to inventory. */
function applyAdjustment(ctx, { warehouseId, date, source, countId, reason, lines, contra, typeIn, typeOut }) {
  const db = ctx.db;
  const docNo = ctx.nextNo('adjustment');
  const id = db.insert('inventory_adjustments', { doc_no: docNo, date, warehouse_id: warehouseId, source, count_id: countId || null, reason, total_value: 0, created_by: ctx.userId(), created_at: nowISO() });
  let gain = 0; let loss = 0;
  for (const l of lines) {
    const p = inv.product(db, l.product_id);
    if (!p.is_stocked) throw new AppError(`"${p.name}" خدمة ولا يُخزَّن`, 'VALIDATION');
    const q = qtyR(l.qty_diff);
    if (Math.abs(q) < EPS) continue;
    let r;
    if (q > 0) { r = inv.receive(ctx, { productId: p.id, warehouseId, qty: q, unitCost: valueCost(p, l.unit_cost), type: typeIn, docType: 'adjustment', docId: id, docNo, date, notes: l.reason || reason }); gain += r.total; }
    else { r = inv.issue(ctx, { productId: p.id, warehouseId, qty: -q, type: typeOut, docType: 'adjustment', docId: id, docNo, date, notes: l.reason || reason }); loss += r.total; }
    db.insert('inventory_adjustment_items', { adjustment_id: id, product_id: p.id, qty_diff: q, unit_cost: r.unitCost, value: q > 0 ? r.total : -r.total, reason: str(l.reason, 'السبب', { max: 200 }) });
  }
  gain = money(gain); loss = money(loss);
  if (gain === 0 && loss === 0 && !db.get('SELECT 1 FROM inventory_adjustment_items WHERE adjustment_id = ?', id)) throw new AppError('لا توجد فروقات لتسجيلها', 'VALIDATION');
  db.update('inventory_adjustments', id, { total_value: money(gain - loss) });
  ledger.post(ctx, {
    date, docType: 'adjustment', docId: id, docNo, description: `${source === 'opening' ? 'رصيد مخزون افتتاحي' : source === 'count' ? 'تسوية جرد' : 'تسوية مخزون'} ${docNo}${reason ? ' — ' + reason : ''}`,
    lines: [{ account: ACC.INVENTORY, debit: gain }, { account: contra, credit: gain }, { account: contra, debit: loss }, { account: ACC.INVENTORY, credit: loss }],
  });
  ctx.audit('inventory_adjust', { entity: 'inventory_adjustments', entityId: id, docNo, newData: { source, warehouseId, gain, loss, lines } });
  return { id, doc_no: docNo, gain, loss };
}

function getCount(db, id) {
  const c = db.get('SELECT c.*, w.name AS warehouse_name, u.full_name AS user_name, a.full_name AS approver_name, ad.doc_no AS adjustment_no FROM stock_counts c JOIN warehouses w ON w.id = c.warehouse_id LEFT JOIN users u ON u.id = c.created_by LEFT JOIN users a ON a.id = c.approved_by LEFT JOIN inventory_adjustments ad ON ad.id = c.adjustment_id WHERE c.id = ?', id);
  if (!c) throw new AppError('الجرد غير موجود', 'NOT_FOUND');
  c.items = db.all(`SELECT i.*, p.code AS product_code, p.name AS product_name, un.name AS unit_name, p.avg_cost, cat.name AS category_name,
      (SELECT COALESCE(SUM(s.qty),0) FROM stock s WHERE s.product_id = i.product_id AND s.warehouse_id = ?) AS current_qty
    FROM stock_count_items i JOIN products p ON p.id = i.product_id JOIN units un ON un.id = p.unit_id LEFT JOIN categories cat ON cat.id = p.category_id WHERE i.count_id = ? ORDER BY p.name`, c.warehouse_id, id);
  c.items.forEach((i) => {
    const sys = c.status === 'draft' ? i.current_qty : i.system_qty;
    const cost = c.status === 'draft' ? i.avg_cost : i.unit_cost;
    i.system_qty = qtyR(sys);
    i.diff = i.actual_qty === null ? null : qtyR(i.actual_qty - sys);
    i.diff_value = i.diff === null ? null : money(i.diff * cost);
    i.unit_cost = cost;
  });
  c.counted = c.items.filter((i) => i.actual_qty !== null).length;
  c.total_diff_value = money(c.items.reduce((s, i) => s + (i.diff_value || 0), 0));
  return c;
}

module.exports = {
  valueCost,
  'inventory.movements': {
    perm: 'inventory.view',
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['p.name', 'p.code', 't.doc_no', 't.notes']);
      addDateRange(where, params, 't.date', a.from, a.to);
      if (a.product_id) { where.push('t.product_id = ?'); params.push(a.product_id); }
      if (a.warehouse_id) { where.push('t.warehouse_id = ?'); params.push(a.warehouse_id); }
      if (a.type) { where.push('t.type = ?'); params.push(a.type); }
      const r = paged(ctx.db, {
        select: 't.*, p.name AS product_name, p.code AS product_code, un.name AS unit_name, w.name AS warehouse_name, u.full_name AS user_name',
        from: 'inventory_transactions t JOIN products p ON p.id = t.product_id JOIN units un ON un.id = p.unit_id JOIN warehouses w ON w.id = t.warehouse_id LEFT JOIN users u ON u.id = t.user_id',
        where, params, sortMap: { date: 't.date', product_name: 'p.name' }, defaultSort: 't.date DESC, t.id DESC', sort: a.sort, dir: a.dir || 'desc', page: a.page, pageSize: a.pageSize, all: a.all,
      });
      r.rows.forEach((x) => { x.type_label = inv.TYPE_LABELS[x.type] || x.type; });
      return r;
    },
  },
  'inventory.types': { fn() { return Object.entries(inv.TYPE_LABELS).map(([value, label]) => ({ value, label })); } },
  'inventory.summary': {
    perm: 'inventory.view',
    fn(ctx) {
      return ctx.db.get(`SELECT COUNT(DISTINCT p.id) AS products, COALESCE(SUM(s.qty * p.avg_cost),0) AS value FROM products p LEFT JOIN stock s ON s.product_id = p.id WHERE p.is_stocked = 1 AND p.active = 1`);
    },
  },

  // ---------------- adjustments & opening stock ----------------
  'adjustments.list': {
    perm: 'inventory.view',
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addDateRange(where, params, 'd.date', a.from, a.to);
      if (a.source) { where.push('d.source = ?'); params.push(a.source); }
      addSearch(where, params, a.q, ['d.doc_no', 'd.reason']);
      return paged(ctx.db, { select: 'd.*, w.name AS warehouse_name, u.full_name AS user_name', from: 'inventory_adjustments d JOIN warehouses w ON w.id = d.warehouse_id LEFT JOIN users u ON u.id = d.created_by',
        where, params, defaultSort: 'd.date DESC, d.id', dir: 'desc', page: a.page, pageSize: a.pageSize, all: a.all });
    },
  },
  'adjustments.get': {
    perm: 'inventory.view',
    fn(ctx, a) {
      const d = ctx.db.get('SELECT d.*, w.name AS warehouse_name, u.full_name AS user_name FROM inventory_adjustments d JOIN warehouses w ON w.id = d.warehouse_id LEFT JOIN users u ON u.id = d.created_by WHERE d.id = ?', a.id);
      if (!d) throw new AppError('غير موجود', 'NOT_FOUND');
      d.lines = ctx.db.all('SELECT i.*, p.name AS product_name, p.code AS product_code, un.name AS unit_name FROM inventory_adjustment_items i JOIN products p ON p.id = i.product_id JOIN units un ON un.id = p.unit_id WHERE i.adjustment_id = ?', d.id);
      return d;
    },
  },
  'adjustments.create': {
    perm: 'inventory.adjust', write: true,
    fn(ctx, a) {
      const warehouseId = reqId(a.warehouse_id, 'المخزن'); inv.warehouse(ctx.db, warehouseId);
      const reason = str(a.reason, 'سبب التسوية', { required: true, max: 300 });
      const lines = (a.lines || []).filter((l) => l && l.product_id).map((l, i) => ({ product_id: Number(l.product_id), qty_diff: num(l.qty_diff, `فرق الكمية (السطر ${i + 1})`, { required: true, allowZero: false }), unit_cost: l.unit_cost, reason: l.reason }));
      if (!lines.length) throw new AppError('أضف صنفًا واحدًا على الأقل', 'VALIDATION');
      return applyAdjustment(ctx, { warehouseId, date: isoDate(a.date), source: 'manual', reason, lines, contra: ACC.INV_DIFF, typeIn: 'adjustment_in', typeOut: 'adjustment_out' });
    },
  },
  'inventory.opening': {
    perm: 'inventory.adjust', write: true,
    fn(ctx, a) {
      const warehouseId = reqId(a.warehouse_id, 'المخزن'); inv.warehouse(ctx.db, warehouseId);
      const lines = (a.lines || []).filter((l) => l && l.product_id).map((l, i) => ({
        product_id: Number(l.product_id), qty_diff: num(l.qty, `الكمية (السطر ${i + 1})`, { required: true, allowZero: false }),
        unit_cost: num(l.unit_cost, `التكلفة (السطر ${i + 1})`, { min: 0 }), reason: 'رصيد افتتاحي',
      }));
      if (!lines.length) throw new AppError('أضف صنفًا واحدًا على الأقل', 'VALIDATION');
      return applyAdjustment(ctx, { warehouseId, date: isoDate(a.date), source: 'opening', reason: str(a.notes, 'ملاحظات', { max: 300 }) || 'رصيد افتتاحي', lines, contra: ACC.OPENING, typeIn: 'opening_in', typeOut: 'opening_out' });
    },
  },
  'adjustments.void': {
    perm: 'inventory.adjust', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const reason = docs.voidReason(a);
      const d = module.exports['adjustments.get'].fn(ctx, a);
      if (d.status !== 'posted') throw new AppError('ملغي بالفعل', 'VALIDATION');
      if (d.source === 'count') throw new AppError('تسوية الجرد تُلغى بإلغاء الجرد نفسه غير متاح بعد الاعتماد؛ سجّل تسوية يدوية معاكسة بدلًا من ذلك.', 'VALIDATION');
      let delta = 0;
      for (const l of d.lines) {
        if (l.qty_diff > 0) {
          const r = inv.issue(ctx, { productId: l.product_id, warehouseId: d.warehouse_id, qty: l.qty_diff, unitCost: l.unit_cost, type: 'void_reversal', docType: 'adjustment', docId: d.id, docNo: d.doc_no, date: todayISO(), notes: 'إلغاء: ' + reason, allowNegative: false });
          delta += l.value - r.total;
        } else {
          inv.receive(ctx, { productId: l.product_id, warehouseId: d.warehouse_id, qty: -l.qty_diff, unitCost: l.unit_cost, type: 'void_reversal', docType: 'adjustment', docId: d.id, docNo: d.doc_no, date: todayISO(), notes: 'إلغاء: ' + reason });
        }
      }
      ledger.voidEntries(ctx, 'adjustment', d.id);
      docs.inventoryGLAdjust(ctx, delta, d.doc_no);
      db.update('inventory_adjustments', d.id, { status: 'void', voided_at: nowISO(), void_reason: reason });
      ctx.audit('void', { entity: 'inventory_adjustments', entityId: d.id, docNo: d.doc_no, notes: reason });
      return true;
    },
  },

  // ---------------- transfers ----------------
  'transfers.list': {
    perm: 'inventory.view',
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addDateRange(where, params, 'd.date', a.from, a.to);
      return paged(ctx.db, { select: 'd.*, f.name AS from_name, t.name AS to_name, (SELECT COUNT(*) FROM stock_transfer_items i WHERE i.transfer_id = d.id) AS items_count',
        from: 'stock_transfers d JOIN warehouses f ON f.id = d.from_warehouse_id JOIN warehouses t ON t.id = d.to_warehouse_id', where, params, defaultSort: 'd.date DESC, d.id', page: a.page, pageSize: a.pageSize });
    },
  },
  'transfers.get': {
    perm: 'inventory.view',
    fn(ctx, a) {
      const d = ctx.db.get('SELECT d.*, f.name AS from_name, t.name AS to_name FROM stock_transfers d JOIN warehouses f ON f.id = d.from_warehouse_id JOIN warehouses t ON t.id = d.to_warehouse_id WHERE d.id = ?', a.id);
      if (!d) throw new AppError('غير موجود', 'NOT_FOUND');
      d.lines = ctx.db.all('SELECT i.*, p.name AS product_name, p.code AS product_code, un.name AS unit_name FROM stock_transfer_items i JOIN products p ON p.id = i.product_id JOIN units un ON un.id = p.unit_id WHERE i.transfer_id = ?', d.id);
      return d;
    },
  },
  'transfers.create': {
    perm: 'inventory.adjust', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const fromId = reqId(a.from_warehouse_id, 'المخزن المحوَّل منه'); const toId = reqId(a.to_warehouse_id, 'المخزن المحوَّل إليه');
      if (fromId === toId) throw new AppError('اختر مخزنين مختلفين', 'VALIDATION');
      const lines = docs.parseLines(ctx, (a.lines || []).map((l) => ({ ...l, unit_price: 0 })), { stockedOnly: true });
      const date = isoDate(a.date);
      const docNo = ctx.nextNo('transfer');
      const id = db.insert('stock_transfers', { doc_no: docNo, date, from_warehouse_id: fromId, to_warehouse_id: toId, notes: str(a.notes, 'ملاحظات', { max: 500 }), created_by: ctx.userId(), created_at: nowISO() });
      for (const l of lines) {
        inv.transfer(ctx, { productId: l.product_id, fromId, toId, qty: l.qty, docType: 'transfer', docId: id, docNo, date });
        db.insert('stock_transfer_items', { transfer_id: id, product_id: l.product_id, qty: l.qty });
      }
      ctx.audit('create', { entity: 'stock_transfers', entityId: id, docNo, newData: { fromId, toId, lines: lines.map((l) => ({ product_id: l.product_id, qty: l.qty })) } });
      return { id, doc_no: docNo };
    },
  },
  'transfers.void': {
    perm: 'inventory.adjust', write: true,
    fn(ctx, a) {
      const d = module.exports['transfers.get'].fn(ctx, a);
      if (d.status !== 'posted') throw new AppError('ملغي بالفعل', 'VALIDATION');
      for (const l of d.lines) inv.transfer(ctx, { productId: l.product_id, fromId: d.to_warehouse_id, toId: d.from_warehouse_id, qty: l.qty, docType: 'transfer', docId: d.id, docNo: d.doc_no, date: todayISO(), notes: 'إلغاء التحويل' });
      ctx.db.update('stock_transfers', d.id, { status: 'void', voided_at: nowISO() });
      ctx.audit('void', { entity: 'stock_transfers', entityId: d.id, docNo: d.doc_no });
      return true;
    },
  },

  // ---------------- stock counts (stocktaking) ----------------
  'counts.list': {
    perm: ['stockcount.manage', 'inventory.view'],
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addDateRange(where, params, 'c.date', a.from, a.to);
      if (a.status) { where.push('c.status = ?'); params.push(a.status); }
      return paged(ctx.db, { select: `c.*, w.name AS warehouse_name, (SELECT COUNT(*) FROM stock_count_items i WHERE i.count_id = c.id) AS items_count,
          (SELECT COUNT(*) FROM stock_count_items i WHERE i.count_id = c.id AND i.actual_qty IS NOT NULL) AS counted_count`,
        from: 'stock_counts c JOIN warehouses w ON w.id = c.warehouse_id', where, params, defaultSort: 'c.date DESC, c.id', page: a.page, pageSize: a.pageSize });
    },
  },
  'counts.get': { perm: ['stockcount.manage', 'inventory.view'], fn: (ctx, a) => getCount(ctx.db, a.id) },
  'counts.create': {
    perm: 'stockcount.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const warehouseId = reqId(a.warehouse_id, 'المخزن'); inv.warehouse(db, warehouseId);
      const where = ['p.is_stocked = 1', 'p.active = 1']; const params = [];
      if (a.category_id) { where.push('p.category_id = ?'); params.push(a.category_id); }
      if (a.onlyWithStock) { where.push('EXISTS (SELECT 1 FROM stock s WHERE s.product_id = p.id AND s.warehouse_id = ? AND ABS(s.qty) > 0.00001)'); params.push(warehouseId); }
      const products = db.all(`SELECT p.id, p.avg_cost, (SELECT COALESCE(SUM(qty),0) FROM stock s WHERE s.product_id = p.id AND s.warehouse_id = ${Number(warehouseId)}) AS qty FROM products p WHERE ${where.join(' AND ')} ORDER BY p.name`, ...params);
      if (!products.length) throw new AppError('لا توجد أصناف مطابقة للجرد', 'VALIDATION');
      const docNo = ctx.nextNo('stock_count');
      const id = db.insert('stock_counts', { doc_no: docNo, date: isoDate(a.date), warehouse_id: warehouseId, notes: str(a.notes, 'ملاحظات', { max: 500 }), created_by: ctx.userId(), created_at: nowISO() });
      products.forEach((p) => db.insert('stock_count_items', { count_id: id, product_id: p.id, system_qty: p.qty, actual_qty: null, unit_cost: p.avg_cost }));
      ctx.audit('create', { entity: 'stock_counts', entityId: id, docNo, newData: { warehouseId, items: products.length } });
      return { id, doc_no: docNo };
    },
  },
  'counts.saveItems': {
    perm: 'stockcount.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const c = db.get('SELECT * FROM stock_counts WHERE id = ?', a.id);
      if (!c) throw new AppError('الجرد غير موجود', 'NOT_FOUND');
      if (c.status !== 'draft') throw new AppError('لا يمكن تعديل جرد معتمد أو ملغي', 'VALIDATION');
      (a.items || []).forEach((i) => {
        const actual = i.actual_qty === '' || i.actual_qty === null || i.actual_qty === undefined ? null : qtyR(num(i.actual_qty, 'الكمية الفعلية', { min: 0 }));
        db.run('UPDATE stock_count_items SET actual_qty = ?, reason = ? WHERE count_id = ? AND product_id = ?', actual, str(i.reason, 'السبب', { max: 200 }), c.id, i.product_id);
      });
      return getCount(db, c.id);
    },
  },
  'counts.approve': {
    perm: 'stockcount.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const c = getCount(db, a.id);
      if (c.status !== 'draft') throw new AppError('الجرد معتمد أو ملغي بالفعل', 'VALIDATION');
      if (!c.counted) throw new AppError('لم يتم إدخال أي كمية فعلية بعد', 'VALIDATION');
      // freeze the system quantities and costs at approval time
      c.items.forEach((i) => db.run('UPDATE stock_count_items SET system_qty = ?, unit_cost = ? WHERE id = ?', i.system_qty, i.avg_cost, i.id));
      const lines = c.items.filter((i) => i.actual_qty !== null && Math.abs(i.diff) > EPS).map((i) => ({ product_id: i.product_id, qty_diff: i.diff, reason: i.reason || 'فرق جرد' }));
      let adj = null;
      if (lines.length) adj = applyAdjustment(ctx, { warehouseId: c.warehouse_id, date: c.date, source: 'count', countId: c.id, reason: `جرد ${c.doc_no}`, lines, contra: ACC.INV_DIFF, typeIn: 'count_in', typeOut: 'count_out' });
      db.update('stock_counts', c.id, { status: 'approved', approved_by: ctx.userId(), approved_at: nowISO(), adjustment_id: adj ? adj.id : null });
      ctx.audit('count_approve', { entity: 'stock_counts', entityId: c.id, docNo: c.doc_no, newData: { differences: lines.length, gain: adj ? adj.gain : 0, loss: adj ? adj.loss : 0 } });
      return { adjustment: adj, differences: lines.length };
    },
  },
  'counts.cancel': {
    perm: 'stockcount.manage', write: true,
    fn(ctx, a) {
      const c = ctx.db.get('SELECT * FROM stock_counts WHERE id = ?', a.id);
      if (!c || c.status !== 'draft') throw new AppError('يمكن إلغاء الجرد غير المعتمد فقط', 'VALIDATION');
      ctx.db.update('stock_counts', c.id, { status: 'cancelled' });
      ctx.audit('cancel', { entity: 'stock_counts', entityId: c.id, docNo: c.doc_no });
      return true;
    },
  },
};
module.exports.applyAdjustment = applyAdjustment;
