'use strict';
const { AppError, str, money, nowISO, idOrNull, reqId, isoDate, EPS, todayISO } = require('../core/util');
const { paged, addSearch, addDateRange } = require('../core/query');
const ledger = require('../core/ledger');
const inv = require('../core/inventory');
const docs = require('../core/docs');

const { ACC } = ledger;

function supplierRow(db, id) {
  const s = db.get('SELECT * FROM suppliers WHERE id = ?', id);
  if (!s) throw new AppError('المورد غير موجود', 'NOT_FOUND');
  return s;
}

function getInvoice(db, id) {
  const d = db.get(`SELECT d.*, s.name AS supplier_name, s.code AS supplier_code, s.phone AS supplier_phone, w.name AS warehouse_name, u.full_name AS user_name
    FROM purchase_invoices d LEFT JOIN suppliers s ON s.id = d.supplier_id JOIN warehouses w ON w.id = d.warehouse_id LEFT JOIN users u ON u.id = d.created_by WHERE d.id = ?`, id);
  if (!d) throw new AppError('الفاتورة غير موجودة', 'NOT_FOUND');
  d.lines = db.all(`SELECT i.*, p.code AS product_code, p.name AS product_name, un.name AS unit_name,
      (SELECT COALESCE(SUM(ri.qty),0) FROM purchase_return_items ri JOIN purchase_returns r ON r.id = ri.return_id
        WHERE r.invoice_id = i.invoice_id AND ri.product_id = i.product_id AND r.status='posted') AS returned_qty
    FROM purchase_items i JOIN products p ON p.id = i.product_id JOIN units un ON un.id = p.unit_id WHERE i.invoice_id = ? ORDER BY i.id`, id);
  d.remaining = money(d.total - d.paid);
  return d;
}

function getReturn(db, id) {
  const d = db.get(`SELECT d.*, s.name AS supplier_name, w.name AS warehouse_name, pi.doc_no AS invoice_no, u.full_name AS user_name
    FROM purchase_returns d LEFT JOIN suppliers s ON s.id = d.supplier_id JOIN warehouses w ON w.id = d.warehouse_id
    LEFT JOIN purchase_invoices pi ON pi.id = d.invoice_id LEFT JOIN users u ON u.id = d.created_by WHERE d.id = ?`, id);
  if (!d) throw new AppError('المرتجع غير موجود', 'NOT_FOUND');
  d.lines = db.all('SELECT i.*, p.code AS product_code, p.name AS product_name, un.name AS unit_name FROM purchase_return_items i JOIN products p ON p.id = i.product_id JOIN units un ON un.id = p.unit_id WHERE i.return_id = ?', id);
  return d;
}

module.exports = {
  'purchases.list': {
    perm: 'purchases.view',
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['d.doc_no', 's.name', 'd.supplier_ref', 'd.notes']);
      addDateRange(where, params, 'd.date', a.from, a.to);
      if (a.supplier_id) { where.push('d.supplier_id = ?'); params.push(a.supplier_id); }
      if (a.status) { where.push('d.status = ?'); params.push(a.status); }
      const r = paged(ctx.db, {
        select: 'd.id, d.doc_no, d.date, d.supplier_id, s.name AS supplier_name, w.name AS warehouse_name, d.subtotal, d.discount, d.tax, d.total, d.paid, d.total - d.paid AS remaining, d.status, d.supplier_ref',
        from: 'purchase_invoices d LEFT JOIN suppliers s ON s.id = d.supplier_id JOIN warehouses w ON w.id = d.warehouse_id',
        where, params, sortMap: { date: 'd.date', doc_no: 'd.doc_no', total: 'd.total', supplier_name: 's.name' },
        defaultSort: 'd.date DESC, d.id', sort: a.sort, dir: a.dir || 'desc', page: a.page, pageSize: a.pageSize, all: a.all,
      });
      r.sum = ctx.db.get(`SELECT COALESCE(SUM(d.total),0) AS total, COALESCE(SUM(d.paid),0) AS paid FROM purchase_invoices d LEFT JOIN suppliers s ON s.id = d.supplier_id ${where.length ? 'WHERE ' + where.join(' AND ') + " AND d.status='posted'" : "WHERE d.status='posted'"}`, ...params);
      return r;
    },
  },
  'purchases.get': { perm: 'purchases.view', fn: (ctx, a) => getInvoice(ctx.db, a.id) },
  'purchases.create': {
    perm: 'purchases.create', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const date = isoDate(a.date);
      const supplierId = idOrNull(a.supplier_id);
      const supplier = supplierId ? supplierRow(db, supplierId) : null;
      const warehouseId = reqId(a.warehouse_id, 'المخزن');
      inv.warehouse(db, warehouseId);
      const lines = docs.parseLines(ctx, a.lines, { priceLabel: 'سعر الشراء' });
      const t = docs.totals(lines, a.discount, docs.taxRate(ctx, a.tax_rate));
      const paid = docs.paidAmount(a.paid, t.total, !!supplier);
      if (!supplier && paid < t.total - EPS) throw new AppError('الشراء الآجل يتطلب اختيار المورد', 'VALIDATION');
      const payMethod = a.pay_method === 'bank' ? 'bank' : 'cash';
      const docNo = ctx.nextNo('purchase');
      const id = db.insert('purchase_invoices', {
        doc_no: docNo, date, supplier_id: supplierId, warehouse_id: warehouseId, supplier_ref: str(a.supplier_ref, 'رقم فاتورة المورد', { max: 60 }),
        subtotal: t.subtotal, discount: t.discount, tax_rate: t.tax_rate, tax: t.tax, total: t.total, paid, pay_method: payMethod,
        notes: str(a.notes, 'ملاحظات', { max: 2000 }), status: 'posted', created_by: ctx.userId(), created_at: nowISO(),
      });
      let invValue = 0; let serviceValue = 0;
      for (const l of lines) {
        db.insert('purchase_items', { invoice_id: id, product_id: l.product_id, qty: l.qty, unit_price: l.unit_price, line_total: l.line_total, unit_cost: l.net_unit, notes: str(l.notes, 'ملاحظات', { max: 300 }) });
        if (l.product.is_stocked) {
          const r = inv.receive(ctx, { productId: l.product_id, warehouseId, qty: l.qty, unitCost: l.net_unit, type: 'purchase', docType: 'purchase', docId: id, docNo, date, isPurchase: true });
          invValue += r.total;
        } else {
          serviceValue += l.net_total;
          db.update('products', l.product_id, { last_purchase_price: l.net_unit, last_purchase_date: date });
        }
      }
      const cash = ledger.cashAccount(payMethod);
      const jl = [
        { account: ACC.INVENTORY, debit: invValue, memo: 'أصناف مخزنية' },
        { account: ACC.OTHER_EXP, debit: serviceValue, memo: 'خدمات مشتراة' },
        { account: ACC.VAT_IN, debit: t.tax },
      ];
      if (supplier) {
        jl.push({ account: ACC.AP, credit: t.total, partyType: 'supplier', partyId: supplierId });
        if (paid > 0) jl.push({ account: ACC.AP, debit: paid, partyType: 'supplier', partyId: supplierId, memo: 'مدفوع مع الفاتورة' }, { account: cash, credit: paid });
      } else {
        jl.push({ account: cash, credit: t.total });
      }
      ledger.post(ctx, { date, docType: 'purchase', docId: id, docNo, description: `فاتورة شراء ${docNo}${supplier ? ' — ' + supplier.name : ' — نقدًا'}`, lines: jl });
      ctx.audit('create', { entity: 'purchase_invoices', entityId: id, docNo, newData: { ...t, paid, lines: lines.map((l) => ({ product_id: l.product_id, qty: l.qty, price: l.unit_price })) } });
      return { id, doc_no: docNo };
    },
  },
  'purchases.void': {
    perm: 'purchases.void', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const reason = docs.voidReason(a);
      const d = getInvoice(db, a.id);
      if (d.status === 'void') throw new AppError('الفاتورة ملغاة بالفعل', 'VALIDATION');
      if (Number(db.val("SELECT COUNT(*) FROM purchase_returns WHERE invoice_id = ? AND status='posted'", d.id)) > 0) throw new AppError('ألغِ مرتجعات هذه الفاتورة أولًا', 'VALIDATION');
      // check stock first so the error explains what blocks the void
      for (const l of d.lines) {
        const p = inv.product(db, l.product_id);
        if (!p.is_stocked) continue;
        const avail = inv.whQty(db, l.product_id, d.warehouse_id);
        if (avail < l.qty - EPS) throw new AppError(`لا يمكن إلغاء الفاتورة لأن "${p.name}" تم استخدام جزء منه (المتاح ${avail} من ${l.qty}). استخدم مرتجع شراء بالكمية المتاحة بدلًا من الإلغاء.`, 'IN_USE');
      }
      let booked = 0; let reversed = 0;
      for (const l of d.lines) {
        const p = inv.product(db, l.product_id);
        if (!p.is_stocked) continue;
        booked += money(l.qty * l.unit_cost);
        reversed += inv.issue(ctx, { productId: l.product_id, warehouseId: d.warehouse_id, qty: l.qty, unitCost: l.unit_cost, type: 'void_reversal', docType: 'purchase', docId: d.id, docNo: d.doc_no, date: todayISO(), notes: 'إلغاء: ' + reason, allowNegative: false }).total;
      }
      ledger.voidEntries(ctx, 'purchase', d.id);
      docs.inventoryGLAdjust(ctx, booked - reversed, d.doc_no);
      db.update('purchase_invoices', d.id, { status: 'void', voided_at: nowISO(), void_reason: reason });
      ctx.audit('void', { entity: 'purchase_invoices', entityId: d.id, docNo: d.doc_no, oldData: { status: 'posted', total: d.total }, newData: { status: 'void' }, notes: reason });
      return true;
    },
  },

  // ---------------- purchase returns ----------------
  'purchaseReturns.list': {
    perm: 'purchases.view',
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['d.doc_no', 's.name', 'pi.doc_no']);
      addDateRange(where, params, 'd.date', a.from, a.to);
      if (a.supplier_id) { where.push('d.supplier_id = ?'); params.push(a.supplier_id); }
      if (a.status) { where.push('d.status = ?'); params.push(a.status); }
      return paged(ctx.db, {
        select: 'd.id, d.doc_no, d.date, s.name AS supplier_name, pi.doc_no AS invoice_no, w.name AS warehouse_name, d.subtotal, d.tax, d.total, d.cost_total, d.settle, d.status',
        from: 'purchase_returns d LEFT JOIN suppliers s ON s.id = d.supplier_id JOIN warehouses w ON w.id = d.warehouse_id LEFT JOIN purchase_invoices pi ON pi.id = d.invoice_id',
        where, params, sortMap: { date: 'd.date', doc_no: 'd.doc_no', total: 'd.total' }, defaultSort: 'd.date DESC, d.id', sort: a.sort, dir: a.dir || 'desc', page: a.page, pageSize: a.pageSize, all: a.all,
      });
    },
  },
  'purchaseReturns.get': { perm: 'purchases.view', fn: (ctx, a) => getReturn(ctx.db, a.id) },
  'purchaseReturns.create': {
    perm: 'purchases.create', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const date = isoDate(a.date);
      let supplierId = idOrNull(a.supplier_id);
      const invoiceId = idOrNull(a.invoice_id);
      let invoice = null;
      if (invoiceId) {
        invoice = getInvoice(db, invoiceId);
        if (invoice.status !== 'posted') throw new AppError('لا يمكن الإرجاع على فاتورة ملغاة', 'VALIDATION');
        if (supplierId && invoice.supplier_id && supplierId !== invoice.supplier_id) throw new AppError('المورد لا يطابق مورد الفاتورة', 'VALIDATION');
        supplierId = invoice.supplier_id;
      }
      const supplier = supplierId ? supplierRow(db, supplierId) : null;
      const settle = ['account', 'cash', 'bank'].includes(a.settle) ? a.settle : 'account';
      if (settle === 'account' && !supplier) throw new AppError('اختر المورد لخصم المرتجع من حسابه، أو اختر استرداد نقدي', 'VALIDATION');
      const warehouseId = invoice ? (idOrNull(a.warehouse_id) || invoice.warehouse_id) : reqId(a.warehouse_id, 'المخزن');
      const lines = docs.parseLines(ctx, a.lines, { stockedOnly: true, priceLabel: 'سعر المرتجع' });
      if (invoice) {
        for (const l of lines) {
          const src = invoice.lines.filter((x) => x.product_id === l.product_id);
          if (!src.length) throw new AppError(`"${l.product.name}" غير موجود في الفاتورة ${invoice.doc_no}`, 'VALIDATION');
          const bought = src.reduce((s, x) => s + x.qty, 0); const returned = src[0].returned_qty;
          if (l.qty > bought - returned + EPS) throw new AppError(`كمية المرتجع من "${l.product.name}" أكبر من المتبقي في الفاتورة (${money(bought - returned)})`, 'VALIDATION');
        }
      }
      const rate = invoice ? invoice.tax_rate : docs.taxRate(ctx, a.tax_rate);
      const t = docs.totals(lines, 0, rate);
      const docNo = ctx.nextNo('purchase_return');
      const id = db.insert('purchase_returns', {
        doc_no: docNo, date, supplier_id: supplierId, invoice_id: invoiceId, warehouse_id: warehouseId, subtotal: t.subtotal, tax_rate: t.tax_rate, tax: t.tax, total: t.total,
        cost_total: 0, settle, notes: str(a.notes, 'ملاحظات', { max: 2000 }), status: 'posted', created_by: ctx.userId(), created_at: nowISO(),
      });
      let costTotal = 0;
      for (const l of lines) {
        const r = inv.issue(ctx, { productId: l.product_id, warehouseId, qty: l.qty, type: 'purchase_return', docType: 'purchase_return', docId: id, docNo, date });
        db.insert('purchase_return_items', { return_id: id, product_id: l.product_id, qty: l.qty, unit_price: l.unit_price, line_total: l.line_total, unit_cost: r.unitCost, cost_total: r.total });
        costTotal += r.total;
      }
      costTotal = money(costTotal);
      db.update('purchase_returns', id, { cost_total: costTotal });
      const variance = money(t.subtotal - costTotal); // >0: refund above stock value → reduces cost of sales
      const jl = [
        settle === 'account' ? { account: ACC.AP, debit: t.total, partyType: 'supplier', partyId: supplierId } : { account: ledger.cashAccount(settle), debit: t.total },
        { account: ACC.VAT_IN, credit: t.tax },
        { account: ACC.INVENTORY, credit: costTotal },
        variance >= 0 ? { account: ACC.COGS, credit: variance, memo: 'فرق سعر مرتجع الشراء' } : { account: ACC.COGS, debit: -variance, memo: 'فرق سعر مرتجع الشراء' },
      ];
      ledger.post(ctx, { date, docType: 'purchase_return', docId: id, docNo, description: `مرتجع شراء ${docNo}${supplier ? ' — ' + supplier.name : ''}${invoice ? ' على ' + invoice.doc_no : ''}`, lines: jl });
      ctx.audit('create', { entity: 'purchase_returns', entityId: id, docNo, newData: { ...t, cost_total: costTotal } });
      return { id, doc_no: docNo };
    },
  },
  'purchaseReturns.void': {
    perm: 'purchases.void', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const reason = docs.voidReason(a);
      const d = getReturn(db, a.id);
      if (d.status === 'void') throw new AppError('المرتجع ملغى بالفعل', 'VALIDATION');
      for (const l of d.lines) {
        inv.receive(ctx, { productId: l.product_id, warehouseId: d.warehouse_id, qty: l.qty, unitCost: l.unit_cost, type: 'void_reversal', docType: 'purchase_return', docId: d.id, docNo: d.doc_no, date: todayISO(), notes: 'إلغاء: ' + reason });
      }
      ledger.voidEntries(ctx, 'purchase_return', d.id);
      db.update('purchase_returns', d.id, { status: 'void', voided_at: nowISO(), void_reason: reason });
      ctx.audit('void', { entity: 'purchase_returns', entityId: d.id, docNo: d.doc_no, notes: reason });
      return true;
    },
  },
};
