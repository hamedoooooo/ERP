'use strict';
const { AppError, str, money, nowISO, idOrNull, reqId, isoDate, EPS, todayISO, fmtNum } = require('../core/util');
const { paged, addSearch, addDateRange } = require('../core/query');
const ledger = require('../core/ledger');
const inv = require('../core/inventory');
const docs = require('../core/docs');

const { ACC } = ledger;

function customerRow(db, id) {
  const c = db.get('SELECT * FROM customers WHERE id = ?', id);
  if (!c) throw new AppError('العميل غير موجود', 'NOT_FOUND');
  return c;
}

function getInvoice(db, id) {
  const d = db.get(`SELECT d.*, c.name AS customer_name, c.code AS customer_code, c.phone AS customer_phone, c.address AS customer_address, w.name AS warehouse_name, u.full_name AS user_name
    FROM sales_invoices d LEFT JOIN customers c ON c.id = d.customer_id JOIN warehouses w ON w.id = d.warehouse_id LEFT JOIN users u ON u.id = d.created_by WHERE d.id = ?`, id);
  if (!d) throw new AppError('الفاتورة غير موجودة', 'NOT_FOUND');
  d.lines = db.all(`SELECT i.*, p.code AS product_code, p.name AS product_name, un.name AS unit_name, mo.doc_no AS mo_no,
      (SELECT COALESCE(SUM(ri.qty),0) FROM sales_return_items ri JOIN sales_returns r ON r.id = ri.return_id WHERE ri.sales_item_id = i.id AND r.status='posted') AS returned_qty
    FROM sales_items i JOIN products p ON p.id = i.product_id JOIN units un ON un.id = p.unit_id LEFT JOIN manufacturing_orders mo ON mo.id = i.mo_id WHERE i.invoice_id = ? ORDER BY i.id`, id);
  d.remaining = money(d.total - d.paid);
  d.gross_profit = money(d.subtotal - d.discount - d.cost_total);
  return d;
}

function getReturn(db, id) {
  const d = db.get(`SELECT d.*, c.name AS customer_name, w.name AS warehouse_name, si.doc_no AS invoice_no, u.full_name AS user_name
    FROM sales_returns d LEFT JOIN customers c ON c.id = d.customer_id JOIN warehouses w ON w.id = d.warehouse_id
    LEFT JOIN sales_invoices si ON si.id = d.invoice_id LEFT JOIN users u ON u.id = d.created_by WHERE d.id = ?`, id);
  if (!d) throw new AppError('المرتجع غير موجود', 'NOT_FOUND');
  d.lines = db.all('SELECT i.*, p.code AS product_code, p.name AS product_name, un.name AS unit_name FROM sales_return_items i JOIN products p ON p.id = i.product_id JOIN units un ON un.id = p.unit_id WHERE i.return_id = ?', id);
  return d;
}

module.exports = {
  'sales.list': {
    perm: 'sales.view',
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['d.doc_no', 'c.name', 'd.notes']);
      addDateRange(where, params, 'd.date', a.from, a.to);
      if (a.customer_id) { where.push('d.customer_id = ?'); params.push(a.customer_id); }
      if (a.status) { where.push('d.status = ?'); params.push(a.status); }
      const canCost = ctx.can('costs.view');
      const r = paged(ctx.db, {
        select: `d.id, d.doc_no, d.date, d.customer_id, c.name AS customer_name, w.name AS warehouse_name, d.subtotal, d.discount, d.tax, d.total, d.paid,
          d.total - d.paid AS remaining, d.status ${canCost ? ', d.cost_total, d.subtotal - d.discount - d.cost_total AS gross_profit' : ''}`,
        from: 'sales_invoices d LEFT JOIN customers c ON c.id = d.customer_id JOIN warehouses w ON w.id = d.warehouse_id',
        where, params, sortMap: { date: 'd.date', doc_no: 'd.doc_no', total: 'd.total', customer_name: 'c.name' },
        defaultSort: 'd.date DESC, d.id', sort: a.sort, dir: a.dir || 'desc', page: a.page, pageSize: a.pageSize, all: a.all,
      });
      r.sum = ctx.db.get(`SELECT COALESCE(SUM(d.total),0) AS total, COALESCE(SUM(d.paid),0) AS paid FROM sales_invoices d LEFT JOIN customers c ON c.id = d.customer_id ${where.length ? 'WHERE ' + where.join(' AND ') + " AND d.status='posted'" : "WHERE d.status='posted'"}`, ...params);
      return r;
    },
  },
  'sales.get': {
    perm: 'sales.view',
    fn(ctx, a) {
      const d = getInvoice(ctx.db, a.id);
      if (!ctx.can('costs.view')) { delete d.cost_total; delete d.gross_profit; d.lines.forEach((l) => { delete l.unit_cost; delete l.cost_total; }); }
      return d;
    },
  },
  /** Completed manufacturing orders that still have units to sell (for linking invoice lines). */
  'sales.moOptions': {
    perm: 'sales.create',
    fn(ctx, a = {}) {
      return ctx.db.all(`SELECT mo.id, mo.doc_no, mo.product_id, mo.customer_id, mo.produced_qty, mo.unit_cost, mo.agreed_price, c.name AS customer_name,
          mo.produced_qty - COALESCE((SELECT SUM(si.qty) FROM sales_items si JOIN sales_invoices s ON s.id = si.invoice_id WHERE si.mo_id = mo.id AND s.status='posted'),0) AS remaining
        FROM manufacturing_orders mo JOIN mo_statuses st ON st.code = mo.status LEFT JOIN customers c ON c.id = mo.customer_id
        WHERE st.stage = 'done' ${a.customer_id ? 'AND (mo.customer_id IS NULL OR mo.customer_id = ' + Number(a.customer_id) + ')' : ''}
        ORDER BY mo.id DESC`).filter((r) => r.remaining > EPS);
    },
  },
  'sales.create': {
    perm: 'sales.create', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const date = isoDate(a.date);
      const customerId = idOrNull(a.customer_id);
      const customer = customerId ? customerRow(db, customerId) : null;
      if (customer && !customer.active) throw new AppError(`العميل "${customer.name}" موقوف`, 'VALIDATION');
      const warehouseId = reqId(a.warehouse_id, 'المخزن');
      inv.warehouse(db, warehouseId);
      const lines = docs.parseLines(ctx, a.lines, { priceLabel: 'سعر البيع' });
      const t = docs.totals(lines, a.discount, docs.taxRate(ctx, a.tax_rate));
      const paid = docs.paidAmount(a.paid, t.total, !!customer);
      const payMethod = a.pay_method === 'bank' ? 'bank' : 'cash';
      // manufacturing order links
      for (const l of lines) {
        l.mo_id = idOrNull(l.mo_id);
        if (!l.mo_id) continue;
        const mo = db.get(`SELECT mo.*, st.stage FROM manufacturing_orders mo JOIN mo_statuses st ON st.code = mo.status WHERE mo.id = ?`, l.mo_id);
        if (!mo) throw new AppError('أمر التصنيع المرتبط غير موجود', 'VALIDATION');
        if (mo.product_id !== l.product_id) throw new AppError(`أمر التصنيع ${mo.doc_no} لا يخص الصنف "${l.product.name}"`, 'VALIDATION');
        if (mo.stage !== 'done') throw new AppError(`أمر التصنيع ${mo.doc_no} لم يكتمل بعد`, 'VALIDATION');
        const sold = Number(db.val("SELECT COALESCE(SUM(si.qty),0) FROM sales_items si JOIN sales_invoices s ON s.id = si.invoice_id WHERE si.mo_id = ? AND s.status='posted'", mo.id)) || 0;
        const already = lines.filter((x) => x !== l && x.mo_id === l.mo_id && lines.indexOf(x) < lines.indexOf(l)).reduce((s, x) => s + x.qty, 0);
        if (l.qty > mo.produced_qty - sold - already + EPS) throw new AppError(`الكمية المتبقية للبيع من أمر التصنيع ${mo.doc_no} هي ${money(mo.produced_qty - sold - already)}`, 'VALIDATION');
        l.mo = mo;
      }
      // credit limit
      if (customer && customer.credit_limit > 0) {
        const bal = ledger.partyBalance(db, 'customer', customer.id);
        const after = money(bal + t.total - paid);
        if (after > customer.credit_limit + EPS && !a.confirmOverLimit) {
          throw new AppError(`رصيد العميل بعد الفاتورة (${fmtNum(after)}) يتجاوز حد الائتمان (${fmtNum(customer.credit_limit)}).`, 'CREDIT_LIMIT', { balanceAfter: after, limit: customer.credit_limit });
        }
      }
      const docNo = ctx.nextNo('sale');
      const id = db.insert('sales_invoices', {
        doc_no: docNo, date, customer_id: customerId, warehouse_id: warehouseId, subtotal: t.subtotal, discount: t.discount, tax_rate: t.tax_rate, tax: t.tax,
        total: t.total, paid, pay_method: payMethod, cost_total: 0, notes: str(a.notes, 'ملاحظات', { max: 2000 }), status: 'posted', created_by: ctx.userId(), created_at: nowISO(),
      });
      let cogs = 0;
      for (const l of lines) {
        let cost = { unitCost: 0, total: 0 };
        if (l.product.is_stocked) {
          cost = inv.issue(ctx, {
            productId: l.product_id, warehouseId, qty: l.qty, type: 'sale', docType: 'sale', docId: id, docNo, date,
            unitCost: l.mo ? l.mo.unit_cost : undefined, // make-to-order: cost of the actual job
          });
        }
        db.insert('sales_items', {
          invoice_id: id, product_id: l.product_id, mo_id: l.mo_id, qty: l.qty, unit_price: l.unit_price, line_total: l.line_total, net_total: l.net_total,
          unit_cost: cost.unitCost, cost_total: cost.total, notes: str(l.notes, 'ملاحظات', { max: 300 }),
        });
        cogs += cost.total;
      }
      cogs = money(cogs);
      db.update('sales_invoices', id, { cost_total: cogs });
      const cash = ledger.cashAccount(payMethod);
      const jl = [];
      if (customer) {
        jl.push({ account: ACC.AR, debit: t.total, partyType: 'customer', partyId: customerId });
        if (paid > 0) jl.push({ account: cash, debit: paid }, { account: ACC.AR, credit: paid, partyType: 'customer', partyId: customerId, memo: 'مدفوع مع الفاتورة' });
      } else {
        jl.push({ account: cash, debit: t.total });
      }
      jl.push({ account: ACC.SALES, credit: t.net }, { account: ACC.VAT_OUT, credit: t.tax }, { account: ACC.COGS, debit: cogs }, { account: ACC.INVENTORY, credit: cogs });
      ledger.post(ctx, { date, docType: 'sale', docId: id, docNo, description: `فاتورة بيع ${docNo}${customer ? ' — ' + customer.name : ' — نقدًا'}`, lines: jl });
      ctx.audit('create', { entity: 'sales_invoices', entityId: id, docNo, newData: { ...t, paid, cogs } });
      return { id, doc_no: docNo };
    },
  },
  'sales.void': {
    perm: 'sales.void', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const reason = docs.voidReason(a);
      const d = getInvoice(db, a.id);
      if (d.status === 'void') throw new AppError('الفاتورة ملغاة بالفعل', 'VALIDATION');
      if (Number(db.val("SELECT COUNT(*) FROM sales_returns WHERE invoice_id = ? AND status='posted'", d.id)) > 0) throw new AppError('ألغِ مرتجعات هذه الفاتورة أولًا', 'VALIDATION');
      for (const l of d.lines) {
        const p = inv.product(db, l.product_id);
        if (!p.is_stocked) continue;
        inv.receive(ctx, { productId: l.product_id, warehouseId: d.warehouse_id, qty: l.qty, unitCost: l.unit_cost, type: 'void_reversal', docType: 'sale', docId: d.id, docNo: d.doc_no, date: todayISO(), notes: 'إلغاء: ' + reason });
      }
      ledger.voidEntries(ctx, 'sale', d.id);
      db.update('sales_invoices', d.id, { status: 'void', voided_at: nowISO(), void_reason: reason });
      ctx.audit('void', { entity: 'sales_invoices', entityId: d.id, docNo: d.doc_no, oldData: { status: 'posted', total: d.total }, newData: { status: 'void' }, notes: reason });
      return true;
    },
  },

  // ---------------- sales returns ----------------
  'salesReturns.list': {
    perm: 'sales.view',
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['d.doc_no', 'c.name', 'si.doc_no']);
      addDateRange(where, params, 'd.date', a.from, a.to);
      if (a.customer_id) { where.push('d.customer_id = ?'); params.push(a.customer_id); }
      if (a.status) { where.push('d.status = ?'); params.push(a.status); }
      return paged(ctx.db, {
        select: 'd.id, d.doc_no, d.date, c.name AS customer_name, si.doc_no AS invoice_no, w.name AS warehouse_name, d.subtotal, d.tax, d.total, d.cost_total, d.settle, d.status',
        from: 'sales_returns d LEFT JOIN customers c ON c.id = d.customer_id JOIN warehouses w ON w.id = d.warehouse_id LEFT JOIN sales_invoices si ON si.id = d.invoice_id',
        where, params, sortMap: { date: 'd.date', doc_no: 'd.doc_no', total: 'd.total' }, defaultSort: 'd.date DESC, d.id', sort: a.sort, dir: a.dir || 'desc', page: a.page, pageSize: a.pageSize, all: a.all,
      });
    },
  },
  'salesReturns.get': { perm: 'sales.view', fn: (ctx, a) => getReturn(ctx.db, a.id) },
  'salesReturns.create': {
    perm: 'sales.create', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const date = isoDate(a.date);
      let customerId = idOrNull(a.customer_id);
      const invoiceId = idOrNull(a.invoice_id);
      let invoice = null;
      if (invoiceId) {
        invoice = getInvoice(db, invoiceId);
        if (invoice.status !== 'posted') throw new AppError('لا يمكن الإرجاع على فاتورة ملغاة', 'VALIDATION');
        customerId = invoice.customer_id;
      }
      const customer = customerId ? customerRow(db, customerId) : null;
      const settle = ['account', 'cash', 'bank'].includes(a.settle) ? a.settle : 'account';
      if (settle === 'account' && !customer) throw new AppError('اختر العميل لإضافة المرتجع لحسابه، أو اختر رد نقدي', 'VALIDATION');
      const warehouseId = invoice ? (idOrNull(a.warehouse_id) || invoice.warehouse_id) : reqId(a.warehouse_id, 'المخزن');
      const lines = docs.parseLines(ctx, a.lines, { priceLabel: 'سعر المرتجع' });
      for (const l of lines) {
        if (invoice) {
          const src = l.sales_item_id ? invoice.lines.find((x) => x.id === Number(l.sales_item_id)) : invoice.lines.find((x) => x.product_id === l.product_id && x.qty - x.returned_qty > EPS);
          if (!src) throw new AppError(`"${l.product.name}" غير موجود في الفاتورة ${invoice.doc_no} أو تم إرجاعه بالكامل`, 'VALIDATION');
          if (l.qty > src.qty - src.returned_qty + EPS) throw new AppError(`كمية المرتجع من "${l.product.name}" أكبر من المتبقي في الفاتورة (${money(src.qty - src.returned_qty)})`, 'VALIDATION');
          l.sales_item_id = src.id; l.unit_cost = src.unit_cost;
        } else {
          l.sales_item_id = null; l.unit_cost = l.product.avg_cost;
        }
      }
      const rate = invoice ? invoice.tax_rate : docs.taxRate(ctx, a.tax_rate);
      const t = docs.totals(lines, 0, rate);
      const docNo = ctx.nextNo('sale_return');
      const id = db.insert('sales_returns', {
        doc_no: docNo, date, customer_id: customerId, invoice_id: invoiceId, warehouse_id: warehouseId, subtotal: t.subtotal, tax_rate: t.tax_rate, tax: t.tax, total: t.total,
        cost_total: 0, settle, notes: str(a.notes, 'ملاحظات', { max: 2000 }), status: 'posted', created_by: ctx.userId(), created_at: nowISO(),
      });
      let costTotal = 0;
      for (const l of lines) {
        let cost = { unitCost: 0, total: 0 };
        if (l.product.is_stocked) cost = inv.receive(ctx, { productId: l.product_id, warehouseId, qty: l.qty, unitCost: l.unit_cost, type: 'sale_return', docType: 'sale_return', docId: id, docNo, date });
        db.insert('sales_return_items', { return_id: id, product_id: l.product_id, sales_item_id: l.sales_item_id, qty: l.qty, unit_price: l.unit_price, line_total: l.line_total, unit_cost: cost.unitCost, cost_total: cost.total });
        costTotal += cost.total;
      }
      costTotal = money(costTotal);
      db.update('sales_returns', id, { cost_total: costTotal });
      const jl = [
        { account: ACC.SALES_RETURNS, debit: t.subtotal }, { account: ACC.VAT_OUT, debit: t.tax },
        settle === 'account' ? { account: ACC.AR, credit: t.total, partyType: 'customer', partyId: customerId } : { account: ledger.cashAccount(settle), credit: t.total },
        { account: ACC.INVENTORY, debit: costTotal }, { account: ACC.COGS, credit: costTotal },
      ];
      ledger.post(ctx, { date, docType: 'sale_return', docId: id, docNo, description: `مرتجع بيع ${docNo}${customer ? ' — ' + customer.name : ''}${invoice ? ' على ' + invoice.doc_no : ''}`, lines: jl });
      ctx.audit('create', { entity: 'sales_returns', entityId: id, docNo, newData: { ...t, cost_total: costTotal } });
      return { id, doc_no: docNo };
    },
  },
  'salesReturns.void': {
    perm: 'sales.void', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const reason = docs.voidReason(a);
      const d = getReturn(db, a.id);
      if (d.status === 'void') throw new AppError('المرتجع ملغى بالفعل', 'VALIDATION');
      let booked = 0; let reversed = 0;
      for (const l of d.lines) {
        const p = inv.product(db, l.product_id);
        if (!p.is_stocked) continue;
        booked += l.cost_total;
        reversed += inv.issue(ctx, { productId: l.product_id, warehouseId: d.warehouse_id, qty: l.qty, unitCost: l.unit_cost, type: 'void_reversal', docType: 'sale_return', docId: d.id, docNo: d.doc_no, date: todayISO(), notes: 'إلغاء: ' + reason, allowNegative: false }).total;
      }
      ledger.voidEntries(ctx, 'sale_return', d.id);
      docs.inventoryGLAdjust(ctx, booked - reversed, d.doc_no);
      db.update('sales_returns', d.id, { status: 'void', voided_at: nowISO(), void_reason: reason });
      ctx.audit('void', { entity: 'sales_returns', entityId: d.id, docNo: d.doc_no, notes: reason });
      return true;
    },
  },
};
