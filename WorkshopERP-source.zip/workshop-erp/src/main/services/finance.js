'use strict';
const { AppError, str, num, money, nowISO, idOrNull, reqId, isoDate } = require('../core/util');
const { paged, addSearch, addDateRange } = require('../core/query');
const ledger = require('../core/ledger');
const docs = require('../core/docs');

const { ACC } = ledger;
const METHOD = { cash: 'الصندوق', bank: 'البنك', credit: 'آجل (مستحق)' };
const CASH_KINDS = {
  deposit: { label: 'إيداع من الصندوق إلى البنك', lines: (a) => [{ account: ACC.BANK, debit: a }, { account: ACC.CASH, credit: a }] },
  withdraw: { label: 'سحب من البنك إلى الصندوق', lines: (a) => [{ account: ACC.CASH, debit: a }, { account: ACC.BANK, credit: a }] },
  capital_in: { label: 'إضافة رأس مال', lines: (a, c) => [{ account: c, debit: a }, { account: ACC.CAPITAL, credit: a }] },
  owner_draw: { label: 'مسحوبات شخصية', lines: (a, c) => [{ account: ACC.DRAWINGS, debit: a }, { account: c, credit: a }] },
  pay_wages: { label: 'سداد أجور مستحقة', lines: (a, c) => [{ account: ACC.WAGES_PAYABLE, debit: a }, { account: c, credit: a }] },
  pay_accrued: { label: 'سداد مصروفات مستحقة', lines: (a, c) => [{ account: ACC.ACCRUED, debit: a }, { account: c, credit: a }] },
  other_in: { label: 'إيراد آخر', lines: (a, c) => [{ account: c, debit: a }, { account: ACC.OTHER_INCOME, credit: a }] },
  other_out: { label: 'صرف آخر', lines: (a, c) => [{ account: ACC.OTHER_EXP, debit: a }, { account: c, credit: a }] },
};

function partyName(db, type, id) {
  const r = db.get(`SELECT name FROM ${type === 'customer' ? 'customers' : 'suppliers'} WHERE id = ?`, id);
  if (!r) throw new AppError(type === 'customer' ? 'العميل غير موجود' : 'المورد غير موجود', 'NOT_FOUND');
  return r.name;
}

function cashWarning(db, method) {
  const b = ledger.balance(db, ledger.cashAccount(method)).balance;
  return b < -0.004 ? `تنبيه: رصيد ${method === 'bank' ? 'البنك' : 'الصندوق'} أصبح سالبًا (${b.toFixed(2)})` : null;
}

function statement(db, type, id, from, to) {
  const acct = type === 'customer' ? ACC.AR : ACC.AP;
  const sign = type === 'customer' ? 1 : -1;
  const opening = from ? ledger.balance(db, acct, { to: prevDay(from), partyType: type, partyId: id }).balance : 0;
  const where = ["e.status='posted'", 'l.account_code = ?', 'l.party_type = ?', 'l.party_id = ?'];
  const p = [acct, type, id];
  addDateRange(where, p, 'e.date', from, to);
  const rows = db.all(`SELECT e.date, e.doc_type, e.doc_id, e.doc_no, e.description, l.debit, l.credit, l.memo FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
    WHERE ${where.join(' AND ')} ORDER BY e.date, e.id, l.id`, ...p);
  let run = opening; let td = 0; let tc = 0;
  rows.forEach((r) => { run = money(run + sign * (r.debit - r.credit)); r.balance = run; td += r.debit; tc += r.credit; });
  return { party: { id, type, name: partyName(db, type, id) }, from, to, opening, rows, total_debit: money(td), total_credit: money(tc), closing: run };
}

function prevDay(d) { const x = new Date(d + 'T00:00:00Z'); x.setUTCDate(x.getUTCDate() - 1); return x.toISOString().slice(0, 10); }

function accountTotals(db, from, to) {
  const where = ["e.status='posted'"]; const p = [];
  addDateRange(where, p, 'e.date', from, to);
  return db.all(`SELECT a.code, a.name, a.type, a.nature, COALESCE(SUM(l.debit),0) AS debit, COALESCE(SUM(l.credit),0) AS credit
    FROM accounts a LEFT JOIN (journal_lines l JOIN journal_entries e ON e.id = l.entry_id AND ${where.join(' AND ')}) ON l.account_code = a.code
    GROUP BY a.code ORDER BY a.code`, ...p).map((r) => ({ ...r, debit: money(r.debit), credit: money(r.credit), balance: money(r.nature === 'debit' ? r.debit - r.credit : r.credit - r.debit) }));
}

function incomeStatement(db, from, to) {
  const acc = accountTotals(db, from, to);
  const by = (t) => acc.filter((a) => a.type === t && Math.abs(a.balance) > 0.004);
  const rev = by('revenue');
  const sales = rev.filter((a) => a.code === ACC.SALES).reduce((s, a) => s + a.balance, 0);
  const returns = rev.filter((a) => a.code === ACC.SALES_RETURNS).reduce((s, a) => s + a.balance, 0);
  const otherIncome = rev.filter((a) => a.code !== ACC.SALES && a.code !== ACC.SALES_RETURNS).reduce((s, a) => s + (a.nature === 'credit' ? a.balance : -a.balance), 0);
  const netSales = money(sales - returns);
  const cogsRows = by('cogs');
  const cogs = money(cogsRows.reduce((s, a) => s + a.balance, 0));
  const gross = money(netSales - cogs);
  const opexRows = by('expense');
  const opex = money(opexRows.reduce((s, a) => s + a.balance, 0));
  const net = money(gross - opex + otherIncome);
  return { from, to, sales: money(sales), returns: money(returns), net_sales: netSales, cogs, cogs_rows: cogsRows, gross_profit: gross,
    gross_margin: netSales ? money(gross / netSales * 100) : null, opex, opex_rows: opexRows, other_income: money(otherIncome), other_rows: rev.filter((a) => ![ACC.SALES, ACC.SALES_RETURNS].includes(a.code)),
    net_profit: net, net_margin: netSales ? money(net / netSales * 100) : null };
}

function balanceSheet(db, to) {
  const acc = accountTotals(db, null, to);
  const pick = (t) => acc.filter((a) => a.type === t && Math.abs(a.balance) > 0.004);
  const assets = pick('asset'); const liabilities = pick('liability');
  const equity = pick('equity').map((a) => ({ ...a, balance: a.nature === 'credit' ? a.balance : -a.balance }));
  const inc = incomeStatement(db, null, to);
  const ta = money(assets.reduce((s, a) => s + a.balance, 0));
  const tl = money(liabilities.reduce((s, a) => s + a.balance, 0));
  const te = money(equity.reduce((s, a) => s + a.balance, 0) + inc.net_profit);
  return { to, assets, liabilities, equity, net_profit: inc.net_profit, total_assets: ta, total_liabilities: tl, total_equity: te, balanced: Math.abs(ta - tl - te) < 0.01 };
}

function inventoryCheck(db) {
  const sub = money(Number(db.val('SELECT COALESCE(SUM(s.qty * p.avg_cost),0) FROM stock s JOIN products p ON p.id = s.product_id')) || 0);
  const gl = ledger.balance(db, ACC.INVENTORY).balance;
  const wip = ledger.balance(db, ACC.WIP).balance;
  const openWip = money(Number(db.val(`SELECT COALESCE(SUM(m.total_cost),0) FROM mo_material_moves m JOIN manufacturing_orders mo ON mo.id = m.mo_id JOIN mo_statuses st ON st.code = mo.status WHERE st.stage IN ('open','active')`)) || 0)
    + money(Number(db.val(`SELECT COALESCE(SUM(l.total),0) FROM mo_labor l JOIN manufacturing_orders mo ON mo.id = l.mo_id JOIN mo_statuses st ON st.code = mo.status WHERE l.status='posted' AND st.stage IN ('open','active')`)) || 0)
    + money(Number(db.val(`SELECT COALESCE(SUM(c.amount),0) FROM mo_other_costs c JOIN manufacturing_orders mo ON mo.id = c.mo_id JOIN mo_statuses st ON st.code = mo.status WHERE c.status='posted' AND st.stage IN ('open','active')`)) || 0);
  return { stock_valuation: sub, gl_inventory: gl, inventory_diff: money(gl - sub), gl_wip: wip, open_orders_cost: money(openWip), wip_diff: money(wip - openWip) };
}

module.exports = {
  statement, incomeStatement, balanceSheet, accountTotals, inventoryCheck, CASH_KINDS,

  // ---------------- payments / receipts ----------------
  'payments.list': {
    perm: ['payments.manage', 'cash.view'],
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['d.doc_no', 'd.reference', 'd.notes', 'c.name', 's.name']);
      addDateRange(where, params, 'd.date', a.from, a.to);
      if (a.direction) { where.push('d.direction = ?'); params.push(a.direction); }
      if (a.party_type) { where.push('d.party_type = ?'); params.push(a.party_type); }
      if (a.party_id) { where.push('d.party_id = ?'); params.push(a.party_id); }
      if (a.status) { where.push('d.status = ?'); params.push(a.status); }
      return paged(ctx.db, {
        select: `d.*, CASE d.party_type WHEN 'customer' THEN c.name ELSE s.name END AS party_name`,
        from: "payments d LEFT JOIN customers c ON d.party_type='customer' AND c.id = d.party_id LEFT JOIN suppliers s ON d.party_type='supplier' AND s.id = d.party_id",
        where, params, sortMap: { date: 'd.date', amount: 'd.amount', doc_no: 'd.doc_no' }, defaultSort: 'd.date DESC, d.id', sort: a.sort, dir: a.dir || 'desc', page: a.page, pageSize: a.pageSize, all: a.all,
      });
    },
  },
  'payments.get': {
    perm: ['payments.manage', 'cash.view'],
    fn(ctx, a) {
      const d = ctx.db.get(`SELECT d.*, CASE d.party_type WHEN 'customer' THEN c.name ELSE s.name END AS party_name, u.full_name AS user_name FROM payments d
        LEFT JOIN customers c ON d.party_type='customer' AND c.id = d.party_id LEFT JOIN suppliers s ON d.party_type='supplier' AND s.id = d.party_id LEFT JOIN users u ON u.id = d.created_by WHERE d.id = ?`, a.id);
      if (!d) throw new AppError('السند غير موجود', 'NOT_FOUND');
      d.party_balance = ledger.partyBalance(ctx.db, d.party_type, d.party_id);
      return d;
    },
  },
  'payments.create': {
    perm: 'payments.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const direction = a.direction === 'out' ? 'out' : 'in';
      const partyType = a.party_type === 'supplier' ? 'supplier' : 'customer';
      const partyId = reqId(a.party_id, partyType === 'customer' ? 'العميل' : 'المورد');
      const name = partyName(db, partyType, partyId);
      const amount = money(num(a.amount, 'المبلغ', { required: true, allowZero: false, min: 0 }));
      const method = a.method === 'bank' ? 'bank' : 'cash';
      const date = isoDate(a.date);
      const docNo = ctx.nextNo(direction === 'in' ? 'receipt' : 'payment');
      const id = db.insert('payments', { doc_no: docNo, date, direction, party_type: partyType, party_id: partyId, amount, method,
        reference: str(a.reference, 'المرجع', { max: 100 }), notes: str(a.notes, 'ملاحظات', { max: 1000 }), created_by: ctx.userId(), created_at: nowISO() });
      const pAcc = partyType === 'customer' ? ACC.AR : ACC.AP;
      const cash = ledger.cashAccount(method);
      const party = { account: pAcc, partyType, partyId };
      const lines = direction === 'in' ? [{ account: cash, debit: amount }, { ...party, credit: amount }] : [{ ...party, debit: amount }, { account: cash, credit: amount }];
      ledger.post(ctx, { date, docType: direction === 'in' ? 'receipt' : 'payment', docId: id, docNo,
        description: `${direction === 'in' ? 'تحصيل من' : 'سداد إلى'} ${name}`, lines });
      ctx.audit('create', { entity: 'payments', entityId: id, docNo, newData: { direction, partyType, partyId, amount, method } });
      return { id, doc_no: docNo, warning: direction === 'out' ? cashWarning(db, method) : null };
    },
  },
  'payments.void': {
    perm: 'payments.manage', write: true,
    fn(ctx, a) {
      const reason = docs.voidReason(a);
      const d = ctx.db.get('SELECT * FROM payments WHERE id = ?', a.id);
      if (!d || d.status !== 'posted') throw new AppError('السند غير موجود أو ملغي', 'NOT_FOUND');
      ledger.voidEntries(ctx, d.direction === 'in' ? 'receipt' : 'payment', d.id);
      ctx.db.update('payments', d.id, { status: 'void', voided_at: nowISO(), void_reason: reason });
      ctx.audit('void', { entity: 'payments', entityId: d.id, docNo: d.doc_no, oldData: d, notes: reason });
      return true;
    },
  },

  // ---------------- expenses ----------------
  'expenses.list': {
    perm: ['expenses.manage', 'reports.view'],
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['d.doc_no', 'd.description', 'd.payee', 'd.notes']);
      addDateRange(where, params, 'd.date', a.from, a.to);
      if (a.category_id) { where.push('d.category_id = ?'); params.push(a.category_id); }
      if (a.status) { where.push('d.status = ?'); params.push(a.status); }
      const r = paged(ctx.db, {
        select: 'd.*, c.name AS category_name, u.full_name AS user_name',
        from: 'expenses d JOIN expense_categories c ON c.id = d.category_id LEFT JOIN users u ON u.id = d.created_by',
        where, params, sortMap: { date: 'd.date', amount: 'd.amount', category_name: 'c.name' }, defaultSort: 'd.date DESC, d.id', sort: a.sort, dir: a.dir || 'desc', page: a.page, pageSize: a.pageSize, all: a.all,
      });
      r.sum = ctx.db.get(`SELECT COALESCE(SUM(d.amount),0) AS total FROM expenses d JOIN expense_categories c ON c.id = d.category_id WHERE d.status='posted' ${where.length ? 'AND ' + where.join(' AND ') : ''}`, ...params);
      return r;
    },
  },
  'expenses.create': {
    perm: 'expenses.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const cat = db.get('SELECT * FROM expense_categories WHERE id = ? AND active = 1', reqId(a.category_id, 'تصنيف المصروف'));
      if (!cat) throw new AppError('تصنيف المصروف غير موجود أو موقوف', 'VALIDATION');
      const amount = money(num(a.amount, 'المبلغ', { required: true, allowZero: false, min: 0 }));
      const method = METHOD[a.method] ? a.method : 'cash';
      const date = isoDate(a.date);
      const docNo = ctx.nextNo('expense');
      const description = str(a.description, 'البيان', { required: true, max: 300 });
      const id = db.insert('expenses', { doc_no: docNo, date, category_id: cat.id, amount, method, description, payee: str(a.payee, 'المستفيد', { max: 150 }),
        notes: str(a.notes, 'ملاحظات', { max: 1000 }), created_by: ctx.userId(), created_at: nowISO() });
      const credit = method === 'credit' ? ACC.ACCRUED : ledger.cashAccount(method);
      ledger.post(ctx, { date, docType: 'expense', docId: id, docNo, description: `مصروف ${cat.name}: ${description}`, lines: [{ account: cat.account_code, debit: amount }, { account: credit, credit: amount }] });
      ctx.audit('create', { entity: 'expenses', entityId: id, docNo, newData: { category: cat.name, amount, method, description } });
      return { id, doc_no: docNo, warning: method !== 'credit' ? cashWarning(db, method) : null };
    },
  },
  'expenses.void': {
    perm: 'expenses.manage', write: true,
    fn(ctx, a) {
      const reason = docs.voidReason(a);
      const d = ctx.db.get('SELECT * FROM expenses WHERE id = ?', a.id);
      if (!d || d.status !== 'posted') throw new AppError('المصروف غير موجود أو ملغي', 'NOT_FOUND');
      ledger.voidEntries(ctx, 'expense', d.id);
      ctx.db.update('expenses', d.id, { status: 'void', voided_at: nowISO(), void_reason: reason });
      ctx.audit('void', { entity: 'expenses', entityId: d.id, docNo: d.doc_no, oldData: d, notes: reason });
      return true;
    },
  },

  // ---------------- cash ----------------
  'cash.summary': {
    perm: 'cash.view',
    fn(ctx) {
      const db = ctx.db;
      return { cash: ledger.balance(db, ACC.CASH).balance, bank: ledger.balance(db, ACC.BANK).balance,
        wages_payable: ledger.balance(db, ACC.WAGES_PAYABLE).balance, accrued: ledger.balance(db, ACC.ACCRUED).balance, kinds: Object.entries(CASH_KINDS).map(([k, v]) => ({ value: k, label: v.label })) };
    },
  },
  'cash.ledger': {
    perm: 'cash.view',
    fn(ctx, a = {}) {
      const account = a.account === ACC.BANK ? ACC.BANK : ACC.CASH;
      return module.exports['accounting.ledger'].fn(ctx, { ...a, account });
    },
  },
  'cash.moves': {
    perm: 'cash.view',
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addDateRange(where, params, 'd.date', a.from, a.to);
      const r = paged(ctx.db, { select: 'd.*', from: 'cash_moves d', where, params, defaultSort: 'd.date DESC, d.id', page: a.page, pageSize: a.pageSize, all: a.all });
      r.rows.forEach((x) => { x.kind_label = CASH_KINDS[x.kind].label; });
      return r;
    },
  },
  'cash.createMove': {
    perm: 'cash.manage', write: true,
    fn(ctx, a) {
      const k = CASH_KINDS[a.kind];
      if (!k) throw new AppError('نوع الحركة غير صحيح', 'VALIDATION');
      const amount = money(num(a.amount, 'المبلغ', { required: true, allowZero: false, min: 0 }));
      const method = a.method === 'bank' ? 'bank' : 'cash';
      const date = isoDate(a.date);
      const docNo = ctx.nextNo('cash_move');
      const description = str(a.description, 'البيان', { max: 300 });
      const id = ctx.db.insert('cash_moves', { doc_no: docNo, date, kind: a.kind, amount, method, description, created_by: ctx.userId(), created_at: nowISO() });
      ledger.post(ctx, { date, docType: 'cash_move', docId: id, docNo, description: `${k.label}${description ? ' — ' + description : ''}`, lines: k.lines(amount, ledger.cashAccount(method)) });
      ctx.audit('create', { entity: 'cash_moves', entityId: id, docNo, newData: { kind: a.kind, amount, method } });
      return { id, doc_no: docNo, warning: cashWarning(ctx.db, a.kind === 'withdraw' ? 'bank' : a.kind === 'deposit' ? 'cash' : method) };
    },
  },
  'cash.voidMove': {
    perm: 'cash.manage', write: true,
    fn(ctx, a) {
      const reason = docs.voidReason(a);
      const d = ctx.db.get('SELECT * FROM cash_moves WHERE id = ?', a.id);
      if (!d || d.status !== 'posted') throw new AppError('الحركة غير موجودة أو ملغاة', 'NOT_FOUND');
      ledger.voidEntries(ctx, 'cash_move', d.id);
      ctx.db.update('cash_moves', d.id, { status: 'void', voided_at: nowISO(), void_reason: reason });
      ctx.audit('void', { entity: 'cash_moves', entityId: d.id, docNo: d.doc_no, notes: reason });
      return true;
    },
  },

  // ---------------- opening balances (customers / suppliers / cash / bank) ----------------
  'opening.list': {
    perm: 'accounting.manage',
    fn(ctx) {
      return ctx.db.all(`SELECT o.*, CASE o.kind WHEN 'customer' THEN c.name WHEN 'supplier' THEN s.name WHEN 'cash' THEN 'الصندوق' ELSE 'البنك' END AS party_name
        FROM opening_balances o LEFT JOIN customers c ON o.kind='customer' AND c.id=o.party_id LEFT JOIN suppliers s ON o.kind='supplier' AND s.id=o.party_id ORDER BY o.id DESC`);
    },
  },
  'opening.create': {
    perm: ['accounting.manage', 'customers.manage', 'suppliers.manage'], write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const kind = ['customer', 'supplier', 'cash', 'bank'].includes(a.kind) ? a.kind : null;
      if (!kind) throw new AppError('نوع الرصيد غير صحيح', 'VALIDATION');
      if ((kind === 'cash' || kind === 'bank') && !ctx.can('accounting.manage')) ctx.require('accounting.manage');
      const amount = money(num(a.amount, 'المبلغ', { required: true, allowZero: false }));
      const partyId = kind === 'customer' || kind === 'supplier' ? reqId(a.party_id, kind === 'customer' ? 'العميل' : 'المورد') : null;
      const name = partyId ? partyName(db, kind, partyId) : (kind === 'cash' ? 'الصندوق' : 'البنك');
      const date = isoDate(a.date);
      const docNo = ctx.nextNo('opening');
      const id = db.insert('opening_balances', { doc_no: docNo, date, kind, party_id: partyId, amount, notes: str(a.notes, 'ملاحظات', { max: 500 }), created_by: ctx.userId(), created_at: nowISO() });
      let lines;
      if (kind === 'customer') lines = [{ account: ACC.AR, debit: amount, partyType: 'customer', partyId }, { account: ACC.OPENING, credit: amount }];
      else if (kind === 'supplier') lines = [{ account: ACC.OPENING, debit: amount }, { account: ACC.AP, credit: amount, partyType: 'supplier', partyId }];
      else lines = [{ account: kind === 'cash' ? ACC.CASH : ACC.BANK, debit: amount }, { account: ACC.OPENING, credit: amount }];
      ledger.post(ctx, { date, docType: 'opening', docId: id, docNo, description: `رصيد افتتاحي — ${name}`, lines });
      ctx.audit('opening', { entity: 'opening_balances', entityId: id, docNo, newData: { kind, partyId, amount } });
      return { id, doc_no: docNo };
    },
  },
  'opening.void': {
    perm: 'accounting.manage', write: true,
    fn(ctx, a) {
      const d = ctx.db.get('SELECT * FROM opening_balances WHERE id = ?', a.id);
      if (!d || d.status !== 'posted') throw new AppError('غير موجود أو ملغي', 'NOT_FOUND');
      ledger.voidEntries(ctx, 'opening', d.id);
      ctx.db.update('opening_balances', d.id, { status: 'void', voided_at: nowISO() });
      ctx.audit('void', { entity: 'opening_balances', entityId: d.id, docNo: d.doc_no, oldData: d });
      return true;
    },
  },

  // ---------------- statements ----------------
  'statements.party': {
    perm: ['customers.manage', 'suppliers.manage', 'reports.view'],
    fn(ctx, a) {
      const type = a.party_type === 'supplier' ? 'supplier' : 'customer';
      return statement(ctx.db, type, reqId(a.party_id, type === 'customer' ? 'العميل' : 'المورد'), a.from || null, a.to || null);
    },
  },

  // ---------------- accounting (kept from the original system) ----------------
  'accounting.journal': {
    perm: 'accounting.view',
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['e.doc_no', 'e.description']);
      addDateRange(where, params, 'e.date', a.from, a.to);
      if (a.doc_type) { where.push('e.doc_type = ?'); params.push(a.doc_type); }
      if (!a.includeVoid) where.push("e.status = 'posted'");
      const r = paged(ctx.db, { select: 'e.*, u.full_name AS user_name', from: 'journal_entries e LEFT JOIN users u ON u.id = e.created_by', where, params,
        defaultSort: 'e.date DESC, e.id DESC', page: a.page, pageSize: a.pageSize, all: a.all });
      r.rows.forEach((e) => { e.lines = ctx.db.all('SELECT l.*, ac.name AS account_name FROM journal_lines l JOIN accounts ac ON ac.code = l.account_code WHERE l.entry_id = ? ORDER BY l.debit DESC, l.id', e.id); });
      return r;
    },
  },
  'accounting.ledger': {
    perm: ['accounting.view', 'cash.view'],
    fn(ctx, a = {}) {
      const db = ctx.db;
      const acc = db.get('SELECT * FROM accounts WHERE code = ?', a.account || ACC.CASH);
      if (!acc) throw new AppError('الحساب غير موجود', 'NOT_FOUND');
      const opening = a.from ? ledger.balance(db, acc.code, { to: prevDay(a.from) }).balance : 0;
      const where = ["e.status='posted'", 'l.account_code = ?']; const p = [acc.code];
      addDateRange(where, p, 'e.date', a.from, a.to);
      const rows = db.all(`SELECT e.id AS entry_id, e.date, e.doc_type, e.doc_id, e.doc_no, e.description, l.debit, l.credit, l.memo FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
        WHERE ${where.join(' AND ')} ORDER BY e.date, e.id, l.id`, ...p);
      let run = opening; let td = 0; let tc = 0;
      rows.forEach((r) => { run = money(run + (acc.nature === 'debit' ? r.debit - r.credit : r.credit - r.debit)); r.balance = run; td += r.debit; tc += r.credit; });
      return { account: acc, opening, rows, total_debit: money(td), total_credit: money(tc), closing: run };
    },
  },
  'accounting.trial': {
    perm: 'accounting.view',
    fn(ctx, a = {}) {
      const rows = accountTotals(ctx.db, a.from, a.to).filter((r) => r.debit > 0.004 || r.credit > 0.004);
      const td = money(rows.reduce((s, r) => s + r.debit, 0)); const tc = money(rows.reduce((s, r) => s + r.credit, 0));
      return { rows, total_debit: td, total_credit: tc, balanced: Math.abs(td - tc) < 0.01 };
    },
  },
  'accounting.income': { perm: ['accounting.view', 'reports.view'], fn: (ctx, a = {}) => incomeStatement(ctx.db, a.from || null, a.to || null) },
  'accounting.balanceSheet': { perm: 'accounting.view', fn: (ctx, a = {}) => balanceSheet(ctx.db, a.to || null) },
  'accounting.inventoryCheck': { perm: ['accounting.view', 'inventory.view'], fn: (ctx) => inventoryCheck(ctx.db) },
};
