'use strict';
const { AppError, str, num, money, qtyR, costR, nowISO, idOrNull, reqId, isoDate, EPS, todayISO, fmtQty } = require('../core/util');
const { paged, addSearch, addDateRange } = require('../core/query');
const ledger = require('../core/ledger');
const inv = require('../core/inventory');
const docs = require('../core/docs');

const { ACC } = ledger;
const RATE_TYPES = { hour: 'بالساعة', day: 'باليوم', piece: 'بالقطعة', fixed: 'مبلغ ثابت', manual: 'مبلغ يدوي' };
const PAY = { cash: 'نقدًا (الصندوق)', bank: 'البنك', accrued: 'مستحق (يُسدد لاحقًا)' };

// ============================ BOM ============================
function bomCost(db, bomId) {
  const bom = db.get('SELECT b.*, p.name AS product_name, p.code AS product_code, u.name AS unit_name FROM boms b JOIN products p ON p.id = b.product_id JOIN units u ON u.id = p.unit_id WHERE b.id = ?', bomId);
  if (!bom) throw new AppError('قائمة المواد غير موجودة', 'NOT_FOUND');
  bom.items = db.all(`SELECT bi.*, p.code AS product_code, p.name AS product_name, p.kind, u.name AS unit_name, p.avg_cost, p.last_purchase_price, p.purchase_price,
      (SELECT COALESCE(SUM(qty),0) FROM stock s WHERE s.product_id = p.id) AS stock_qty
    FROM bom_items bi JOIN products p ON p.id = bi.product_id JOIN units u ON u.id = p.unit_id WHERE bi.bom_id = ? ORDER BY bi.id`, bomId);
  let total = 0;
  bom.items.forEach((i) => {
    i.unit_cost = i.avg_cost > 0 ? i.avg_cost : (i.last_purchase_price || i.purchase_price || 0);
    i.gross_qty = qtyR(i.qty * (1 + (i.waste_pct || 0) / 100));
    i.cost = money(i.gross_qty * i.unit_cost);
    total += i.cost;
  });
  bom.total_cost = money(total);
  bom.unit_cost = costR(total / (bom.output_qty || 1));
  return bom;
}

// ============================ MO helpers ============================
function moRow(db, id) {
  const mo = db.get(`SELECT mo.*, st.name AS status_name, st.stage, st.color AS status_color, p.name AS product_name, p.code AS product_code, u.name AS unit_name,
      c.name AS customer_name, w.name AS warehouse_name, ow.name AS output_warehouse_name, b.name AS bom_name, us.full_name AS user_name
    FROM manufacturing_orders mo JOIN mo_statuses st ON st.code = mo.status JOIN products p ON p.id = mo.product_id JOIN units u ON u.id = p.unit_id
    LEFT JOIN customers c ON c.id = mo.customer_id JOIN warehouses w ON w.id = mo.warehouse_id JOIN warehouses ow ON ow.id = mo.output_warehouse_id
    LEFT JOIN boms b ON b.id = mo.bom_id LEFT JOIN users us ON us.id = mo.created_by WHERE mo.id = ?`, id);
  if (!mo) throw new AppError('أمر التصنيع غير موجود', 'NOT_FOUND');
  return mo;
}

function assertEditable(mo) {
  if (mo.stage === 'done') throw new AppError(`أمر التصنيع ${mo.doc_no} مكتمل. أعد فتحه أولًا إذا كنت تريد تعديل التكاليف.`, 'VALIDATION');
  if (mo.stage === 'cancelled') throw new AppError(`أمر التصنيع ${mo.doc_no} ملغي`, 'VALIDATION');
}

function markInProgress(ctx, mo) {
  if (mo.stage === 'open') ctx.db.run("UPDATE manufacturing_orders SET status = 'in_progress', start_date = COALESCE(start_date, ?), updated_at = ? WHERE id = ?", todayISO(), nowISO(), mo.id);
}

/** Actual cost buckets from real movements (never from the BOM). */
function actualCosts(db, moId) {
  const mat = db.get(`SELECT COALESCE(SUM(CASE WHEN p.kind = 'accessory' THEN 0 ELSE m.total_cost END),0) AS material,
      COALESCE(SUM(CASE WHEN p.kind = 'accessory' THEN m.total_cost ELSE 0 END),0) AS accessories
    FROM mo_material_moves m JOIN products p ON p.id = m.product_id WHERE m.mo_id = ?`, moId);
  const labor = Number(db.val("SELECT COALESCE(SUM(total),0) FROM mo_labor WHERE mo_id = ? AND status='posted'", moId)) || 0;
  const other = Number(db.val("SELECT COALESCE(SUM(amount),0) FROM mo_other_costs WHERE mo_id = ? AND status='posted'", moId)) || 0;
  return { material: money(mat.material), accessories: money(mat.accessories), labor: money(labor), other: money(other) };
}

function overheadFor(ctx, mo, c) {
  const base = ctx.settings().manufacturing.overheadBase === 'labor' ? c.labor : c.material + c.accessories + c.labor + c.other;
  if (mo.overhead_type === 'percent') return money(base * (Number(mo.overhead_value) || 0) / 100);
  if (mo.overhead_type === 'amount') return money(Number(mo.overhead_value) || 0);
  return 0;
}

function materialsDetail(db, moId) {
  const rows = db.all(`SELECT x.product_id, p.code AS product_code, p.name AS product_name, p.kind, u.name AS unit_name, p.avg_cost,
      COALESCE(mm.planned_qty,0) AS planned_qty, mm.id AS line_id,
      COALESCE((SELECT SUM(qty) FROM mo_material_moves m WHERE m.mo_id = ? AND m.product_id = x.product_id),0) AS actual_qty,
      COALESCE((SELECT SUM(total_cost) FROM mo_material_moves m WHERE m.mo_id = ? AND m.product_id = x.product_id),0) AS actual_cost,
      (SELECT COALESCE(SUM(qty),0) FROM stock s WHERE s.product_id = x.product_id) AS stock_qty
    FROM (SELECT product_id FROM mo_materials WHERE mo_id = ? UNION SELECT product_id FROM mo_material_moves WHERE mo_id = ?) x
    JOIN products p ON p.id = x.product_id JOIN units u ON u.id = p.unit_id LEFT JOIN mo_materials mm ON mm.mo_id = ? AND mm.product_id = x.product_id
    ORDER BY p.kind = 'accessory', p.name`, moId, moId, moId, moId, moId);
  rows.forEach((r) => {
    r.actual_qty = qtyR(r.actual_qty); r.actual_cost = money(r.actual_cost);
    r.unit_cost = r.actual_qty > EPS ? costR(r.actual_cost / r.actual_qty) : r.avg_cost;
    r.planned_cost = money(r.planned_qty * r.unit_cost);
    r.diff_qty = qtyR(r.actual_qty - r.planned_qty);
    r.waste_qty = r.diff_qty > 0 ? r.diff_qty : 0;
    r.waste_pct = r.planned_qty > EPS ? money((r.diff_qty / r.planned_qty) * 100) : null;
    r.remaining_to_issue = qtyR(Math.max(0, r.planned_qty - r.actual_qty));
  });
  return rows;
}

function profitability(ctx, mo) {
  const db = ctx.db;
  const sold = db.get(`SELECT COALESCE(SUM(si.qty),0) AS qty, COALESCE(SUM(si.net_total),0) AS revenue, COALESCE(SUM(si.cost_total),0) AS cost
    FROM sales_items si JOIN sales_invoices s ON s.id = si.invoice_id WHERE si.mo_id = ? AND s.status='posted'`, mo.id);
  const ret = db.get(`SELECT COALESCE(SUM(ri.qty),0) AS qty, COALESCE(SUM(ri.line_total),0) AS revenue, COALESCE(SUM(ri.cost_total),0) AS cost
    FROM sales_return_items ri JOIN sales_returns r ON r.id = ri.return_id JOIN sales_items si ON si.id = ri.sales_item_id WHERE si.mo_id = ? AND r.status='posted'`, mo.id);
  const c = mo.stage === 'done' ? { material: mo.material_cost, accessories: mo.accessories_cost, labor: mo.labor_cost, other: mo.other_cost, overhead: mo.overhead_cost }
    : (() => { const x = actualCosts(db, mo.id); return { ...x, overhead: overheadFor(ctx, mo, x) }; })();
  const totalCost = money(c.material + c.accessories + c.labor + c.other + c.overhead);
  const soldQty = qtyR(sold.qty - ret.qty);
  const actualRevenue = money(sold.revenue - ret.revenue);
  const qtyBase = mo.produced_qty > EPS ? mo.produced_qty : mo.qty;
  const expectedRevenue = money((mo.agreed_price || 0) * qtyBase);
  const revenue = soldQty > EPS ? actualRevenue : expectedRevenue;
  const basis = soldQty > EPS ? 'actual' : (expectedRevenue > 0 ? 'expected' : 'none');
  // when only part of the job is sold, compare revenue against the cost share of what was sold
  const costBase = soldQty > EPS && qtyBase > EPS ? money(totalCost * Math.min(1, soldQty / qtyBase)) : totalCost;
  const gross = money(revenue - costBase);
  const pr = ctx.settings().pricing;
  const unitCost = qtyBase > EPS ? totalCost / qtyBase : 0;
  const pct = (Number(pr.defaultPct) || 0) / 100;
  const suggestedUnit = pr.method === 'markup' ? unitCost * (1 + pct) : (pct < 1 ? unitCost / (1 - pct) : 0);
  return {
    ...c, total_cost: totalCost, sold_qty: soldQty, actual_revenue: actualRevenue, expected_revenue: expectedRevenue,
    revenue, revenue_basis: basis, cost_basis: costBase, gross_profit: gross, margin_pct: revenue > 0 ? money(gross / revenue * 100) : null,
    markup_pct: costBase > 0 ? money(gross / costBase * 100) : null,
    unit_cost: costR(unitCost), pricing: { method: pr.method, pct: pr.defaultPct, suggested_unit_price: money(suggestedUnit) },
  };
}

function plannedFromBom(db, bomId, qty) {
  const bom = db.get('SELECT * FROM boms WHERE id = ?', bomId);
  if (!bom) throw new AppError('قائمة المواد غير موجودة', 'NOT_FOUND');
  const items = db.all('SELECT * FROM bom_items WHERE bom_id = ?', bomId);
  const map = new Map();
  items.forEach((i) => {
    const q = i.qty * (1 + (i.waste_pct || 0) / 100) * qty / (bom.output_qty || 1);
    map.set(i.product_id, qtyR((map.get(i.product_id) || 0) + q));
  });
  return { bom, map };
}

module.exports = {
  RATE_TYPES,
  // ---------------- BOMs ----------------
  'boms.list': {
    perm: ['manufacturing.view', 'manufacturing.manage'],
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['b.name', 'p.name', 'p.code']);
      if (a.product_id) { where.push('b.product_id = ?'); params.push(a.product_id); }
      if (a.onlyActive) where.push('b.active = 1');
      const rows = ctx.db.all(`SELECT b.id, b.name, b.product_id, p.name AS product_name, p.code AS product_code, b.output_qty, b.is_default, b.active, b.updated_at,
          (SELECT COUNT(*) FROM bom_items bi WHERE bi.bom_id = b.id) AS items_count,
          (SELECT COUNT(*) FROM manufacturing_orders mo WHERE mo.bom_id = b.id) AS mo_count
        FROM boms b JOIN products p ON p.id = b.product_id ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY p.name, b.is_default DESC, b.name`, ...params);
      if (ctx.can('costs.view')) rows.forEach((r) => { const c = bomCost(ctx.db, r.id); r.total_cost = c.total_cost; r.unit_cost = c.unit_cost; });
      return rows;
    },
  },
  'boms.get': {
    perm: ['manufacturing.view', 'manufacturing.manage'],
    fn(ctx, a) {
      const b = bomCost(ctx.db, a.id);
      if (!ctx.can('costs.view')) { b.items.forEach((i) => { delete i.unit_cost; delete i.cost; delete i.avg_cost; }); delete b.total_cost; delete b.unit_cost; }
      return b;
    },
  },
  'boms.save': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const productId = reqId(a.product_id, 'المنتج');
      const product = inv.product(db, productId);
      if (!product.is_stocked) throw new AppError('لا يمكن إنشاء قائمة مواد لخدمة', 'VALIDATION');
      const name = str(a.name, 'اسم قائمة المواد', { max: 100 }) || `قائمة ${product.name}`;
      const outputQty = num(a.output_qty || 1, 'كمية الإنتاج', { allowZero: false, min: 0 });
      const items = (a.items || []).filter((i) => i && i.product_id);
      if (!items.length) throw new AppError('أضف مادة واحدة على الأقل لقائمة المواد', 'VALIDATION');
      const seen = new Set();
      const clean = items.map((i, idx) => {
        const pid = Number(i.product_id);
        if (pid === productId) throw new AppError('لا يمكن أن يكون المنتج مكوّنًا في قائمة مواده', 'VALIDATION');
        if (seen.has(pid)) throw new AppError(`السطر ${idx + 1}: المادة مكررة في القائمة`, 'VALIDATION');
        seen.add(pid);
        const p = inv.product(db, pid);
        if (!p.is_stocked) throw new AppError(`"${p.name}" خدمة. سجّل الخدمات كتكلفة مباشرة على أمر التصنيع بدلًا من قائمة المواد.`, 'VALIDATION');
        return { product_id: pid, qty: qtyR(num(i.qty, `الكمية (السطر ${idx + 1})`, { allowZero: false, min: 0, required: true })), waste_pct: num(i.waste_pct, 'نسبة الهالك', { min: 0 }), notes: str(i.notes, 'ملاحظات', { max: 200 }) };
      });
      let id = a.id;
      const data = { product_id: productId, name, output_qty: outputQty, notes: str(a.notes, 'ملاحظات', { max: 1000 }), updated_at: nowISO() };
      if (id) {
        const old = db.get('SELECT * FROM boms WHERE id = ?', id);
        if (!old) throw new AppError('قائمة المواد غير موجودة', 'NOT_FOUND');
        const oldItems = db.all('SELECT product_id, qty, waste_pct FROM bom_items WHERE bom_id = ?', id);
        db.update('boms', id, data);
        db.run('DELETE FROM bom_items WHERE bom_id = ?', id);
        ctx.audit('update', { entity: 'boms', entityId: id, oldData: { ...old, items: oldItems }, newData: { ...data, items: clean } });
      } else {
        id = db.insert('boms', { ...data, created_at: nowISO() });
        ctx.audit('create', { entity: 'boms', entityId: id, newData: { ...data, items: clean } });
      }
      clean.forEach((i) => db.insert('bom_items', { bom_id: id, ...i }));
      const hasDefault = db.get('SELECT id FROM boms WHERE product_id = ? AND is_default = 1 AND id <> ?', productId, id);
      if (a.is_default || !hasDefault) { db.run('UPDATE boms SET is_default = 0 WHERE product_id = ?', productId); db.run('UPDATE boms SET is_default = 1 WHERE id = ?', id); }
      return id;
    },
  },
  'boms.toggle': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) { const b = ctx.db.get('SELECT * FROM boms WHERE id = ?', a.id); if (!b) throw new AppError('غير موجود', 'NOT_FOUND'); ctx.db.update('boms', b.id, { active: b.active ? 0 : 1 }); ctx.audit(b.active ? 'deactivate' : 'activate', { entity: 'boms', entityId: b.id }); return !b.active; },
  },
  'boms.delete': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const b = ctx.db.get('SELECT * FROM boms WHERE id = ?', a.id);
      if (!b) throw new AppError('غير موجود', 'NOT_FOUND');
      if (Number(ctx.db.val('SELECT COUNT(*) FROM manufacturing_orders WHERE bom_id = ?', b.id)) > 0) throw new AppError('قائمة المواد مستخدمة في أوامر تصنيع، يمكنك إيقافها بدلًا من الحذف', 'IN_USE');
      ctx.db.run('DELETE FROM boms WHERE id = ?', b.id);
      ctx.audit('delete', { entity: 'boms', entityId: b.id, oldData: b });
      return true;
    },
  },

  // ---------------- Manufacturing orders ----------------
  'mo.list': {
    perm: ['manufacturing.view', 'manufacturing.manage'],
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['mo.doc_no', 'p.name', 'c.name', 'mo.specs', 'mo.notes']);
      addDateRange(where, params, 'mo.date', a.from, a.to);
      if (a.status) { where.push('mo.status = ?'); params.push(a.status); }
      if (a.stage) { where.push('st.stage = ?'); params.push(a.stage); }
      if (a.customer_id) { where.push('mo.customer_id = ?'); params.push(a.customer_id); }
      if (a.product_id) { where.push('mo.product_id = ?'); params.push(a.product_id); }
      if (a.overdue) { where.push("mo.due_date IS NOT NULL AND mo.due_date < ? AND st.stage IN ('open','active')"); params.push(todayISO()); }
      const cost = ctx.can('costs.view') ? ', mo.total_cost, mo.unit_cost' : '';
      return paged(ctx.db, {
        select: `mo.id, mo.doc_no, mo.date, mo.due_date, mo.start_date, mo.qty, mo.produced_qty, mo.status, st.name AS status_name, st.color AS status_color, st.stage,
          p.name AS product_name, u.name AS unit_name, c.name AS customer_name, mo.agreed_price ${cost}`,
        from: 'manufacturing_orders mo JOIN mo_statuses st ON st.code = mo.status JOIN products p ON p.id = mo.product_id JOIN units u ON u.id = p.unit_id LEFT JOIN customers c ON c.id = mo.customer_id',
        where, params, sortMap: { date: 'mo.date', doc_no: 'mo.doc_no', due_date: 'mo.due_date', product_name: 'p.name', status_name: 'st.sort' },
        defaultSort: 'mo.date DESC, mo.id', sort: a.sort, dir: a.dir || 'desc', page: a.page, pageSize: a.pageSize, all: a.all,
      });
    },
  },
  'mo.get': {
    perm: ['manufacturing.view', 'manufacturing.manage'],
    fn(ctx, a) {
      const db = ctx.db;
      const mo = moRow(db, a.id);
      mo.materials = materialsDetail(db, mo.id);
      mo.moves = db.all('SELECT m.*, p.name AS product_name, w.name AS warehouse_name, u.full_name AS user_name FROM mo_material_moves m JOIN products p ON p.id = m.product_id JOIN warehouses w ON w.id = m.warehouse_id LEFT JOIN users u ON u.id = m.created_by WHERE m.mo_id = ? ORDER BY m.id', mo.id);
      mo.labor = db.all('SELECT * FROM mo_labor WHERE mo_id = ? ORDER BY id', mo.id).map((l) => ({ ...l, rate_type_label: RATE_TYPES[l.rate_type], pay_label: PAY[l.pay_method] }));
      mo.other_costs = db.all('SELECT * FROM mo_other_costs WHERE mo_id = ? ORDER BY id', mo.id).map((l) => ({ ...l, pay_label: PAY[l.pay_method] }));
      mo.sales = db.all("SELECT s.id, s.doc_no, s.date, si.qty, si.unit_price, si.net_total, s.status FROM sales_items si JOIN sales_invoices s ON s.id = si.invoice_id WHERE si.mo_id = ? ORDER BY s.date", mo.id);
      mo.profit = profitability(ctx, mo);
      if (!ctx.can('costs.view')) {
        ['material_cost', 'accessories_cost', 'labor_cost', 'other_cost', 'overhead_cost', 'total_cost', 'unit_cost'].forEach((k) => delete mo[k]);
        delete mo.profit; mo.materials.forEach((m) => { delete m.actual_cost; delete m.unit_cost; delete m.planned_cost; delete m.avg_cost; });
        mo.moves.forEach((m) => { delete m.unit_cost; delete m.total_cost; });
      }
      return mo;
    },
  },
  'mo.create': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const productId = reqId(a.product_id, 'المنتج');
      const product = inv.product(db, productId);
      if (!product.is_stocked) throw new AppError('المنتج المصنّع يجب أن يكون صنفًا مخزنيًا وليس خدمة', 'VALIDATION');
      const qty = qtyR(num(a.qty, 'الكمية', { required: true, allowZero: false, min: 0 }));
      const warehouseId = reqId(a.warehouse_id, 'مخزن الخامات'); inv.warehouse(db, warehouseId);
      const outWh = idOrNull(a.output_warehouse_id) || warehouseId; inv.warehouse(db, outWh);
      let bomId = idOrNull(a.bom_id);
      if (!bomId && a.bom_id !== 'none') { const def = db.get('SELECT id FROM boms WHERE product_id = ? AND is_default = 1 AND active = 1', productId); bomId = def ? def.id : null; }
      if (bomId) { const b = db.get('SELECT * FROM boms WHERE id = ?', bomId); if (!b || b.product_id !== productId) throw new AppError('قائمة المواد لا تخص هذا المنتج', 'VALIDATION'); }
      const status = a.status && db.get("SELECT code FROM mo_statuses WHERE code = ? AND stage = 'open' AND active = 1", a.status) ? a.status : 'new';
      const st = ctx.settings().manufacturing;
      const overheadType = ['none', 'percent', 'amount'].includes(a.overhead_type) ? a.overhead_type : st.overheadType;
      const docNo = ctx.nextNo('mo');
      const data = {
        doc_no: docNo, date: isoDate(a.date), customer_id: idOrNull(a.customer_id), product_id: productId, bom_id: bomId, qty,
        warehouse_id: warehouseId, output_warehouse_id: outWh, specs: str(a.specs, 'المواصفات', { max: 4000 }), dimensions: str(a.dimensions, 'المقاسات', { max: 2000 }),
        notes: str(a.notes, 'ملاحظات', { max: 4000 }), start_date: a.start_date ? isoDate(a.start_date, 'تاريخ البدء') : null, due_date: a.due_date ? isoDate(a.due_date, 'تاريخ التسليم') : null,
        status, agreed_price: num(a.agreed_price, 'سعر البيع المتفق عليه', { min: 0 }), overhead_type: overheadType,
        overhead_value: overheadType === 'none' ? 0 : num(a.overhead_value === undefined || a.overhead_value === '' ? st.overheadValue : a.overhead_value, 'قيمة المصروفات الصناعية', { min: 0 }),
        created_by: ctx.userId(), created_at: nowISO(),
      };
      if (data.due_date && data.start_date && data.due_date < data.start_date) throw new AppError('تاريخ التسليم قبل تاريخ البدء', 'VALIDATION');
      const id = db.insert('manufacturing_orders', data);
      const planned = new Map();
      if (bomId) plannedFromBom(db, bomId, qty).map.forEach((q, pid) => planned.set(pid, q));
      (a.materials || []).filter((m) => m && m.product_id).forEach((m) => planned.set(Number(m.product_id), qtyR(num(m.planned_qty, 'الكمية المخططة', { min: 0 }))));
      planned.forEach((q, pid) => {
        const p = inv.product(db, pid);
        if (!p.is_stocked) throw new AppError(`"${p.name}" خدمة ولا يمكن صرفها كمادة`, 'VALIDATION');
        db.insert('mo_materials', { mo_id: id, product_id: pid, planned_qty: q });
      });
      ctx.audit('create', { entity: 'manufacturing_orders', entityId: id, docNo, newData: data });
      return { id, doc_no: docNo };
    },
  },
  'mo.update': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const mo = moRow(db, a.id);
      if (mo.stage === 'cancelled') throw new AppError('أمر التصنيع ملغي', 'VALIDATION');
      const data = {
        customer_id: idOrNull(a.customer_id), specs: str(a.specs, 'المواصفات', { max: 4000 }), dimensions: str(a.dimensions, 'المقاسات', { max: 2000 }),
        notes: str(a.notes, 'ملاحظات', { max: 4000 }), start_date: a.start_date ? isoDate(a.start_date, 'تاريخ البدء') : null,
        due_date: a.due_date ? isoDate(a.due_date, 'تاريخ التسليم') : null, agreed_price: num(a.agreed_price, 'السعر المتفق عليه', { min: 0 }), updated_at: nowISO(),
      };
      if (mo.stage !== 'done') {
        const hasMoves = Number(db.val('SELECT COUNT(*) FROM mo_material_moves WHERE mo_id = ?', mo.id)) > 0;
        if (a.qty !== undefined) data.qty = qtyR(num(a.qty, 'الكمية', { allowZero: false, min: 0 }));
        if (a.output_warehouse_id) data.output_warehouse_id = reqId(a.output_warehouse_id, 'مخزن الإنتاج');
        if (a.warehouse_id && !hasMoves) data.warehouse_id = reqId(a.warehouse_id, 'مخزن الخامات');
        if (a.overhead_type) { data.overhead_type = ['none', 'percent', 'amount'].includes(a.overhead_type) ? a.overhead_type : 'none'; data.overhead_value = data.overhead_type === 'none' ? 0 : num(a.overhead_value, 'قيمة المصروفات الصناعية', { min: 0 }); }
        // re-plan when quantity changed and the order follows a BOM
        if (data.qty && Math.abs(data.qty - mo.qty) > EPS && mo.bom_id && a.replan !== false) {
          plannedFromBom(db, mo.bom_id, data.qty).map.forEach((q, pid) => {
            db.run('INSERT INTO mo_materials(mo_id, product_id, planned_qty) VALUES (?,?,?) ON CONFLICT(mo_id, product_id) DO UPDATE SET planned_qty = excluded.planned_qty', mo.id, pid, q);
          });
        }
      }
      db.update('manufacturing_orders', mo.id, data);
      ctx.audit('update', { entity: 'manufacturing_orders', entityId: mo.id, docNo: mo.doc_no, oldData: mo, newData: data });
      return true;
    },
  },
  'mo.setPlanned': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const mo = moRow(db, a.mo_id); assertEditable(mo);
      const pid = reqId(a.product_id, 'المادة');
      const p = inv.product(db, pid);
      if (!p.is_stocked) throw new AppError(`"${p.name}" خدمة ولا يمكن صرفها كمادة`, 'VALIDATION');
      if (pid === mo.product_id) throw new AppError('لا يمكن استخدام المنتج نفسه كمادة خام', 'VALIDATION');
      const q = qtyR(num(a.planned_qty, 'الكمية المخططة', { min: 0 }));
      const moved = Number(db.val('SELECT COUNT(*) FROM mo_material_moves WHERE mo_id = ? AND product_id = ?', mo.id, pid)) > 0;
      if (a.remove) {
        if (moved) throw new AppError('لا يمكن حذف مادة تم صرفها. يمكنك ردها للمخزن أو جعل الكمية المخططة صفرًا.', 'VALIDATION');
        db.run('DELETE FROM mo_materials WHERE mo_id = ? AND product_id = ?', mo.id, pid);
      } else {
        db.run('INSERT INTO mo_materials(mo_id, product_id, planned_qty) VALUES (?,?,?) ON CONFLICT(mo_id, product_id) DO UPDATE SET planned_qty = excluded.planned_qty', mo.id, pid, q);
      }
      ctx.audit('plan_material', { entity: 'manufacturing_orders', entityId: mo.id, docNo: mo.doc_no, newData: { product_id: pid, planned_qty: q, remove: !!a.remove } });
      return true;
    },
  },
  'mo.setStatus': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const mo = moRow(db, a.id);
      const st = db.get('SELECT * FROM mo_statuses WHERE code = ? AND active = 1', a.status);
      if (!st) throw new AppError('الحالة غير موجودة', 'VALIDATION');
      if (st.code === 'completed') throw new AppError('استخدم زر "إكمال التصنيع" لتسجيل الإنتاج وحساب التكلفة', 'VALIDATION');
      if (st.stage === 'cancelled') throw new AppError('استخدم زر "إلغاء الأمر" لإلغاء أمر التصنيع ومعالجة المواد المصروفة', 'VALIDATION');
      if (mo.stage === 'cancelled') throw new AppError('أمر التصنيع ملغي', 'VALIDATION');
      if (mo.stage === 'done' && st.stage !== 'done') throw new AppError('الأمر مكتمل. استخدم "إعادة فتح الأمر" إذا أردت إرجاعه للتشغيل.', 'VALIDATION');
      if (mo.stage !== 'done' && st.stage === 'done') throw new AppError('لا يمكن جعل الأمر جاهزًا للتسليم قبل إكمال التصنيع', 'VALIDATION');
      db.update('manufacturing_orders', mo.id, { status: st.code, updated_at: nowISO(), start_date: st.stage === 'active' && !mo.start_date ? todayISO() : mo.start_date });
      ctx.audit('status', { entity: 'manufacturing_orders', entityId: mo.id, docNo: mo.doc_no, oldData: { status: mo.status }, newData: { status: st.code } });
      return true;
    },
  },
  /** Issue raw materials to the order: stock out → WIP. */
  'mo.issue': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const mo = moRow(db, a.mo_id); assertEditable(mo);
      const date = isoDate(a.date);
      const warehouseId = idOrNull(a.warehouse_id) || mo.warehouse_id;
      const lines = (a.lines || []).filter((l) => l && l.product_id && Number(l.qty) > 0);
      if (!lines.length) throw new AppError('أدخل كمية لمادة واحدة على الأقل', 'VALIDATION');
      const docNo = ctx.nextNo('mo_issue');
      const warnings = [];
      let total = 0; const jlMemo = [];
      for (const l of lines) {
        const pid = Number(l.product_id);
        if (pid === mo.product_id) throw new AppError('لا يمكن صرف المنتج نفسه كمادة خام', 'VALIDATION');
        const qty = qtyR(num(l.qty, 'الكمية', { allowZero: false, min: 0 }));
        const r = inv.issue(ctx, { productId: pid, warehouseId, qty, type: 'mo_issue', docType: 'mo', docId: mo.id, docNo: mo.doc_no, date, notes: `صرف ${docNo}` + (l.notes ? ' — ' + l.notes : '') });
        db.insert('mo_material_moves', { mo_id: mo.id, product_id: pid, warehouse_id: warehouseId, date, qty, unit_cost: r.unitCost, total_cost: r.total, doc_no: docNo, notes: str(l.notes, 'ملاحظات', { max: 300 }), created_by: ctx.userId(), created_at: nowISO() });
        db.run('INSERT INTO mo_materials(mo_id, product_id, planned_qty) VALUES (?,?,0) ON CONFLICT(mo_id, product_id) DO NOTHING', mo.id, pid);
        total += r.total;
        const p = inv.product(db, pid);
        jlMemo.push(`${p.name} × ${fmtQty(qty)}`);
        const planned = Number(db.val('SELECT planned_qty FROM mo_materials WHERE mo_id = ? AND product_id = ?', mo.id, pid)) || 0;
        const actual = Number(db.val('SELECT COALESCE(SUM(qty),0) FROM mo_material_moves WHERE mo_id = ? AND product_id = ?', mo.id, pid)) || 0;
        const tol = Number(ctx.settings().manufacturing.warnOverIssuePct) || 0;
        if (planned > EPS && actual > planned * (1 + tol / 100) + EPS) warnings.push(`تم صرف ${fmtQty(actual)} من "${p.name}" مقابل ${fmtQty(planned)} مخطط (هالك ${money((actual - planned) / planned * 100)}%)`);
      }
      ledger.post(ctx, { date, docType: 'mo_issue', docId: mo.id, docNo, description: `صرف خامات لأمر التصنيع ${mo.doc_no}: ${jlMemo.join('، ')}`, lines: [{ account: ACC.WIP, debit: total }, { account: ACC.INVENTORY, credit: total }] });
      markInProgress(ctx, mo);
      ctx.audit('mo_issue', { entity: 'manufacturing_orders', entityId: mo.id, docNo: mo.doc_no, newData: { issue_no: docNo, lines } });
      return { doc_no: docNo, total: money(total), warnings };
    },
  },
  /** Return unused material from the order back to stock at the order's own issue cost. */
  'mo.returnMaterial': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const mo = moRow(db, a.mo_id); assertEditable(mo);
      const pid = reqId(a.product_id, 'المادة');
      const qty = qtyR(num(a.qty, 'الكمية', { allowZero: false, min: 0, required: true }));
      const agg = db.get('SELECT COALESCE(SUM(qty),0) AS q, COALESCE(SUM(total_cost),0) AS v FROM mo_material_moves WHERE mo_id = ? AND product_id = ?', mo.id, pid);
      if (qty > agg.q + EPS) throw new AppError(`لا يمكن رد ${fmtQty(qty)} لأن صافي المصروف لهذا الأمر هو ${fmtQty(agg.q)} فقط`, 'VALIDATION');
      const unitCost = agg.q > EPS ? agg.v / agg.q : 0;
      const value = Math.abs(qty - agg.q) < EPS ? money(agg.v) : money(qty * unitCost);
      const date = isoDate(a.date);
      const warehouseId = idOrNull(a.warehouse_id) || mo.warehouse_id;
      const docNo = ctx.nextNo('mo_issue');
      const r = inv.receive(ctx, { productId: pid, warehouseId, qty, unitCost: qty > 0 ? value / qty : 0, type: 'mo_return', docType: 'mo', docId: mo.id, docNo: mo.doc_no, date, notes: `رد ${docNo}` });
      db.insert('mo_material_moves', { mo_id: mo.id, product_id: pid, warehouse_id: warehouseId, date, qty: -qty, unit_cost: r.unitCost, total_cost: -r.total, doc_no: docNo, notes: str(a.notes, 'ملاحظات', { max: 300 }) || 'رد للمخزن', created_by: ctx.userId(), created_at: nowISO() });
      ledger.post(ctx, { date, docType: 'mo_issue', docId: mo.id, docNo, description: `رد خامات من أمر التصنيع ${mo.doc_no}`, lines: [{ account: ACC.INVENTORY, debit: r.total }, { account: ACC.WIP, credit: r.total }] });
      ctx.audit('mo_return', { entity: 'manufacturing_orders', entityId: mo.id, docNo: mo.doc_no, newData: { product_id: pid, qty, value: r.total } });
      return { doc_no: docNo, total: r.total };
    },
  },
  'mo.addLabor': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const mo = moRow(db, a.mo_id); assertEditable(mo);
      const workerId = idOrNull(a.worker_id);
      const worker = workerId ? db.get('SELECT * FROM workers WHERE id = ?', workerId) : null;
      if (workerId && !worker) throw new AppError('العامل غير موجود', 'NOT_FOUND');
      const name = worker ? worker.name : str(a.worker_name, 'اسم العامل', { required: true, max: 100 });
      const rateType = RATE_TYPES[a.rate_type] ? a.rate_type : (worker ? worker.rate_type : 'manual');
      let qty; let rate; let total;
      if (rateType === 'fixed' || rateType === 'manual') {
        total = money(num(a.total !== undefined && a.total !== '' ? a.total : a.rate, 'المبلغ', { required: true, allowZero: false, min: 0 }));
        qty = 1; rate = total;
      } else {
        qty = qtyR(num(a.qty, rateType === 'hour' ? 'عدد الساعات' : rateType === 'day' ? 'عدد الأيام' : 'عدد القطع', { required: true, allowZero: false, min: 0 }));
        rate = num(a.rate === '' || a.rate === undefined ? (worker ? worker.rate : '') : a.rate, 'سعر الوحدة', { required: true, allowZero: false, min: 0 });
        total = money(qty * rate);
      }
      const pay = PAY[a.pay_method] ? a.pay_method : 'accrued';
      const date = isoDate(a.date);
      const docNo = ctx.nextNo('labor');
      const id = db.insert('mo_labor', { mo_id: mo.id, worker_id: workerId, worker_name: name, date, rate_type: rateType, qty, rate, total, pay_method: pay, notes: str(a.notes, 'ملاحظات', { max: 500 }), created_by: ctx.userId(), created_at: nowISO() });
      const credit = pay === 'accrued' ? ACC.WAGES_PAYABLE : ledger.cashAccount(pay);
      ledger.post(ctx, { date, docType: 'mo_labor', docId: id, docNo, description: `عمالة ${name} — أمر التصنيع ${mo.doc_no}`, lines: [{ account: ACC.WIP, debit: total }, { account: credit, credit: total }] });
      markInProgress(ctx, mo);
      ctx.audit('mo_labor', { entity: 'manufacturing_orders', entityId: mo.id, docNo: mo.doc_no, newData: { worker: name, rateType, qty, rate, total, pay } });
      return id;
    },
  },
  'mo.voidLabor': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const l = db.get('SELECT * FROM mo_labor WHERE id = ?', a.id);
      if (!l || l.status !== 'posted') throw new AppError('السجل غير موجود أو ملغي', 'NOT_FOUND');
      const mo = moRow(db, l.mo_id); assertEditable(mo);
      ledger.voidEntries(ctx, 'mo_labor', l.id);
      db.update('mo_labor', l.id, { status: 'void' });
      ctx.audit('void', { entity: 'mo_labor', entityId: l.id, docNo: mo.doc_no, oldData: l });
      return true;
    },
  },
  'mo.addCost': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const mo = moRow(db, a.mo_id); assertEditable(mo);
      const amount = money(num(a.amount, 'المبلغ', { required: true, allowZero: false, min: 0 }));
      const pay = PAY[a.pay_method] ? a.pay_method : 'cash';
      const date = isoDate(a.date);
      const desc = str(a.description, 'البيان', { required: true, max: 300 });
      const docNo = ctx.nextNo('mo_cost');
      const id = db.insert('mo_other_costs', { mo_id: mo.id, date, description: desc, amount, pay_method: pay, notes: str(a.notes, 'ملاحظات', { max: 500 }), created_by: ctx.userId(), created_at: nowISO() });
      const credit = pay === 'accrued' ? ACC.ACCRUED : ledger.cashAccount(pay);
      ledger.post(ctx, { date, docType: 'mo_cost', docId: id, docNo, description: `تكلفة مباشرة (${desc}) — أمر التصنيع ${mo.doc_no}`, lines: [{ account: ACC.WIP, debit: amount }, { account: credit, credit: amount }] });
      markInProgress(ctx, mo);
      ctx.audit('mo_cost', { entity: 'manufacturing_orders', entityId: mo.id, docNo: mo.doc_no, newData: { desc, amount, pay } });
      return id;
    },
  },
  'mo.voidCost': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const c = db.get('SELECT * FROM mo_other_costs WHERE id = ?', a.id);
      if (!c || c.status !== 'posted') throw new AppError('السجل غير موجود أو ملغي', 'NOT_FOUND');
      const mo = moRow(db, c.mo_id); assertEditable(mo);
      ledger.voidEntries(ctx, 'mo_cost', c.id);
      db.update('mo_other_costs', c.id, { status: 'void' });
      ctx.audit('void', { entity: 'mo_other_costs', entityId: c.id, docNo: mo.doc_no, oldData: c });
      return true;
    },
  },
  /** Finish the job: apply overhead, move WIP to finished goods at real cost. */
  'mo.complete': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const mo = moRow(db, a.id); assertEditable(mo);
      const producedQty = qtyR(num(a.produced_qty === undefined || a.produced_qty === '' ? mo.qty : a.produced_qty, 'الكمية المنتجة', { allowZero: false, min: 0 }));
      const date = isoDate(a.date);
      const outWh = idOrNull(a.output_warehouse_id) || mo.output_warehouse_id;
      const c = actualCosts(db, mo.id);
      const overhead = overheadFor(ctx, mo, c);
      const total = money(c.material + c.accessories + c.labor + c.other + overhead);
      if (total <= 0 && !a.allowZeroCost) throw new AppError('لا توجد أي تكلفة مسجلة على هذا الأمر (لم تُصرف خامات ولم تُسجل عمالة). سجّل التكاليف أولًا أو أكّد الإكمال بدون تكلفة.', 'ZERO_COST');
      const unitCost = costR(total / producedQty);
      const r = inv.receive(ctx, { productId: mo.product_id, warehouseId: outWh, qty: producedQty, unitCost, type: 'mo_receipt', docType: 'mo', docId: mo.id, docNo: mo.doc_no, date, notes: 'استلام إنتاج' });
      const residual = money(total - r.total);
      const lines = [
        { account: ACC.WIP, debit: overhead, memo: 'تحميل مصروفات صناعية' }, { account: ACC.OVERHEAD_APPLIED, credit: overhead },
        { account: ACC.INVENTORY, debit: r.total, memo: `استلام ${fmtQty(producedQty)} ${mo.unit_name} من ${mo.product_name}` }, { account: ACC.WIP, credit: r.total },
      ];
      if (Math.abs(residual) >= 0.005) lines.push({ account: ACC.INV_DIFF, debit: residual, memo: 'فرق تقريب' }, { account: ACC.WIP, credit: residual });
      ledger.post(ctx, { date, docType: 'mo_complete', docId: mo.id, docNo: mo.doc_no, description: `إكمال أمر التصنيع ${mo.doc_no} — ${mo.product_name}`, lines });
      db.update('manufacturing_orders', mo.id, {
        status: 'completed', produced_qty: producedQty, completed_at: date, output_warehouse_id: outWh,
        material_cost: c.material, accessories_cost: c.accessories, labor_cost: c.labor, other_cost: c.other, overhead_cost: overhead,
        total_cost: total, unit_cost: unitCost, updated_at: nowISO(),
      });
      ctx.audit('mo_complete', { entity: 'manufacturing_orders', entityId: mo.id, docNo: mo.doc_no, newData: { producedQty, ...c, overhead, total, unitCost } });
      return { total_cost: total, unit_cost: unitCost, produced_qty: producedQty };
    },
  },
  /** Undo completion (only while the finished goods are still in stock and unsold). */
  'mo.reopen': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const mo = moRow(db, a.id);
      if (mo.stage !== 'done') throw new AppError('الأمر غير مكتمل', 'VALIDATION');
      if (Number(db.val("SELECT COUNT(*) FROM sales_items si JOIN sales_invoices s ON s.id = si.invoice_id WHERE si.mo_id = ? AND s.status='posted'", mo.id)) > 0) throw new AppError('لا يمكن إعادة فتح أمر تم بيع إنتاجه. ألغِ فاتورة البيع أولًا.', 'IN_USE');
      const avail = inv.whQty(db, mo.product_id, mo.output_warehouse_id);
      if (avail < mo.produced_qty - EPS) throw new AppError(`لا يمكن إعادة الفتح لأن المتاح من "${mo.product_name}" في مخزن الإنتاج هو ${fmtQty(avail)} فقط`, 'INSUFFICIENT_STOCK');
      const booked = money(mo.produced_qty * mo.unit_cost);
      const r = inv.issue(ctx, { productId: mo.product_id, warehouseId: mo.output_warehouse_id, qty: mo.produced_qty, unitCost: mo.unit_cost, type: 'void_reversal', docType: 'mo', docId: mo.id, docNo: mo.doc_no, date: todayISO(), notes: 'إعادة فتح أمر التصنيع', allowNegative: false });
      ledger.voidEntries(ctx, 'mo_complete', mo.id);
      docs.inventoryGLAdjust(ctx, booked - r.total, mo.doc_no, `فرق تقييم عند إعادة فتح ${mo.doc_no}`);
      db.update('manufacturing_orders', mo.id, { status: 'in_progress', produced_qty: 0, completed_at: null, overhead_cost: 0, total_cost: 0, unit_cost: 0, updated_at: nowISO() });
      ctx.audit('mo_reopen', { entity: 'manufacturing_orders', entityId: mo.id, docNo: mo.doc_no, notes: str(a.reason, 'السبب', { max: 300 }) });
      return true;
    },
  },
  /** Cancel: return net issued materials to stock, write off labor/direct costs. */
  'mo.cancel': {
    perm: 'manufacturing.manage', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const reason = docs.voidReason(a);
      const mo = moRow(db, a.id);
      if (mo.stage === 'done') throw new AppError('لا يمكن إلغاء أمر مكتمل. أعد فتحه أولًا.', 'VALIDATION');
      if (mo.stage === 'cancelled') throw new AppError('الأمر ملغي بالفعل', 'VALIDATION');
      const date = todayISO();
      const nets = db.all('SELECT product_id, warehouse_id, SUM(qty) AS q, SUM(total_cost) AS v FROM mo_material_moves WHERE mo_id = ? GROUP BY product_id, warehouse_id HAVING SUM(qty) > 0.00001', mo.id);
      let returned = 0;
      for (const n of nets) {
        const r = inv.receive(ctx, { productId: n.product_id, warehouseId: n.warehouse_id, qty: n.q, unitCost: n.v / n.q, type: 'mo_return', docType: 'mo', docId: mo.id, docNo: mo.doc_no, date, notes: 'رد تلقائي عند إلغاء الأمر' });
        db.insert('mo_material_moves', { mo_id: mo.id, product_id: n.product_id, warehouse_id: n.warehouse_id, date, qty: -n.q, unit_cost: r.unitCost, total_cost: -r.total, doc_no: mo.doc_no, notes: 'رد عند الإلغاء', created_by: ctx.userId(), created_at: nowISO() });
        returned += r.total;
      }
      const c = actualCosts(db, mo.id); // after returns: materials ≈ 0, labor + other remain in WIP
      const writeOff = money(c.material + c.accessories + c.labor + c.other);
      ledger.post(ctx, {
        date, docType: 'mo_cancel', docId: mo.id, docNo: mo.doc_no, description: `إلغاء أمر التصنيع ${mo.doc_no}: ${reason}`,
        lines: [{ account: ACC.INVENTORY, debit: returned, memo: 'رد الخامات للمخزن' }, { account: ACC.MO_LOSS, debit: writeOff, memo: 'تكاليف غير قابلة للاسترداد' }, { account: ACC.WIP, credit: money(returned + writeOff) }],
      });
      db.update('manufacturing_orders', mo.id, { status: 'cancelled', notes: (mo.notes ? mo.notes + '\n' : '') + 'سبب الإلغاء: ' + reason, updated_at: nowISO() });
      ctx.audit('mo_cancel', { entity: 'manufacturing_orders', entityId: mo.id, docNo: mo.doc_no, notes: reason, newData: { returned, writeOff } });
      return { returned: money(returned), write_off: writeOff };
    },
  },
};
module.exports.bomCost = bomCost;
