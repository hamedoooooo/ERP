'use strict';
const fs = require('fs');
const path = require('path');
const { AppError, str, money, nowISO, todayISO } = require('../core/util');
const { LATEST } = require('../db/migrate');

function app(ctx) { if (!ctx.app) throw new AppError('وظيفة غير متاحة', 'NO_APP'); return ctx.app; }

/**
 * Import data from the previous single-file system (localStorage key "acct_system_v1").
 * Master data is recreated; balances are carried over as clearly-labelled opening balances.
 * The complete old data set is archived untouched in legacy_archive.
 */
function importLegacy(ctx, data) {
  const db = ctx.db;
  const s = { accounts: 0, customers: 0, suppliers: 0, products: 0, openings: 0, stockLines: 0, skipped: [] };
  const date = todayISO();
  const oldCoa = Array.isArray(data.coa) ? data.coa : [];
  oldCoa.forEach((a) => {
    if (!a || !a.code || !a.name) return;
    if (db.get('SELECT 1 FROM accounts WHERE code = ?', String(a.code))) return;
    const types = ['asset', 'liability', 'equity', 'revenue', 'cogs', 'expense'];
    if (!types.includes(a.type)) return;
    db.insert('accounts', { code: String(a.code), name: String(a.name), type: a.type, nature: a.nature === 'credit' ? 'credit' : 'debit', is_system: 0, created_at: nowISO() });
    if (a.type === 'expense' && !db.get('SELECT 1 FROM expense_categories WHERE name = ?', String(a.name))) db.insert('expense_categories', { name: String(a.name), account_code: String(a.code), created_at: nowISO() });
    s.accounts++;
  });
  const partyMap = (list, type) => {
    (Array.isArray(list) ? list : []).forEach((p) => {
      if (!p || !p.name) return;
      const id = ctx.api(`${type}s.save`, { name: p.name, phone: p.phone || '', email: p.email || '', address: p.address || '', credit_limit: p.creditLimit || 0, notes: [p.notes || '', 'مستورد من النظام القديم'].filter(Boolean).join(' — ') });
      if (p.archived) db.update(`${type}s`, id, { active: 0 });
      s[`${type}s`]++;
      const bal = money(p.balance || 0);
      if (Math.abs(bal) >= 0.01) { ctx.api('opening.create', { kind: type, party_id: id, amount: bal, date, notes: 'رصيد منقول من النظام القديم' }); s.openings++; }
    });
  };
  partyMap(data.customers, 'customer');
  partyMap(data.suppliers, 'supplier');

  const wh = db.get('SELECT id FROM warehouses WHERE is_default = 1');
  const stockLines = [];
  (Array.isArray(data.items) ? data.items : []).forEach((i) => {
    if (!i || !i.name) return;
    let unit = db.get('SELECT id FROM units WHERE name = ?', (i.unit || 'قطعة').trim());
    if (!unit) unit = { id: db.insert('units', { name: (i.unit || 'قطعة').trim(), symbol: (i.unit || 'قطعة').trim(), created_at: nowISO() }) };
    let cat = null;
    if (i.category && i.category.trim()) {
      cat = db.get('SELECT id FROM categories WHERE name = ?', i.category.trim());
      if (!cat) cat = { id: db.insert('categories', { name: i.category.trim(), created_at: nowISO() }) };
    }
    let barcode = (i.barcode || '').trim();
    if (barcode && db.get('SELECT 1 FROM products WHERE barcode = ?', barcode)) { s.skipped.push(`باركود مكرر: ${i.name}`); barcode = ''; }
    const id = ctx.api('products.save', {
      name: i.name, kind: 'other', unit_id: unit.id, category_id: cat ? cat.id : null, barcode, purchase_price: i.purchasePrice || 0, sale_price: i.salePrice || 0,
      wholesale_price: i.wholesalePrice || 0, min_qty: i.minQty || 0, max_qty: i.maxQty || 0, description: i.description || '', notes: 'مستورد من النظام القديم',
    });
    s.products++;
    const q = Number(i.qty) || 0;
    if (q > 0) stockLines.push({ product_id: id, qty: q, unit_cost: Number(i.avgCost) || Number(i.purchasePrice) || 0 });
    else if (q < 0) s.skipped.push(`رصيد سالب لم يُنقل: ${i.name} (${q})`);
  });
  if (stockLines.length) { ctx.api('inventory.opening', { warehouse_id: wh.id, date, lines: stockLines, notes: 'أرصدة مخزون منقولة من النظام القديم' }); s.stockLines = stockLines.length; }

  // cash and bank from the old journal
  const bal = { '1100': 0, '1200': 0 };
  (Array.isArray(data.transactions) ? data.transactions : []).forEach((t) => (t.journal || []).forEach((l) => { if (l.account in bal) bal[l.account] += (Number(l.debit) || 0) - (Number(l.credit) || 0); }));
  if (Math.abs(bal['1100']) >= 0.01) { ctx.api('opening.create', { kind: 'cash', amount: money(bal['1100']), date, notes: 'رصيد الصندوق من النظام القديم' }); s.openings++; }
  if (Math.abs(bal['1200']) >= 0.01) { ctx.api('opening.create', { kind: 'bank', amount: money(bal['1200']), date, notes: 'رصيد البنك من النظام القديم' }); s.openings++; }
  s.transactionsArchived = Array.isArray(data.transactions) ? data.transactions.length : 0;
  db.insert('legacy_archive', { imported_at: nowISO(), source: 'acct_system_v1', payload: JSON.stringify(data) });
  return s;
}

module.exports = {
  importLegacy,
  'backup.info': {
    perm: ['backup.create', 'backup.restore', 'settings.manage'],
    fn(ctx) {
      const a = app(ctx);
      const loc = a.resolveBackupDir();
      let size = 0; try { size = fs.statSync(a.dbPath).size; } catch (_) { /* ignore */ }
      return {
        settings: ctx.settings().backup, resolvedDir: loc.dir, fallback: loc.fallback ? loc.reason : null, defaultDir: a.defaultBackupDir,
        dataDir: a.dataDir, dbPath: a.dbPath, dbSize: size, appVersion: a.appVersion, schemaVersion: LATEST, driver: ctx.db.driver.name,
        history: ctx.db.all('SELECT * FROM backup_metadata ORDER BY id DESC LIMIT 30').map((h) => ({ ...h, exists: fs.existsSync(h.file_path) })),
        legacyImported: !!ctx.db.get('SELECT 1 FROM legacy_archive'),
      };
    },
  },
  'backup.create': {
    perm: 'backup.create', // not wrapped in a transaction: VACUUM INTO cannot run inside one
    fn(ctx, a = {}) {
      if (a.password) {
        if (String(a.password).length < 6) throw new AppError('كلمة مرور النسخة يجب ألا تقل عن 6 أحرف', 'VALIDATION');
        if (a.password !== a.passwordConfirm) throw new AppError('كلمتا المرور غير متطابقتين', 'VALIDATION');
      }
      return app(ctx).createBackup({ password: a.password || '', kind: 'manual', dir: a.dir || null, filePath: a.filePath || null });
    },
  },
  'backup.inspect': {
    perm: 'backup.restore',
    fn(ctx, a) { return app(ctx).inspectBackup(str(a.path, 'مسار الملف', { required: true, max: 2000 })); },
  },
  'backup.restore': {
    perm: 'backup.restore',
    fn(ctx, a) {
      if (a.confirm !== true) throw new AppError('يجب تأكيد الاستعادة', 'VALIDATION');
      return app(ctx).restoreBackup(str(a.path, 'مسار الملف', { required: true, max: 2000 }), a.password || '');
    },
  },
  /** Browser-preview mode only: receive a file picked in the browser. */
  'backup.stageUpload': {
    perm: 'backup.restore',
    fn(ctx, a) {
      const dir = path.join(app(ctx).dataDir, 'uploads'); fs.mkdirSync(dir, { recursive: true });
      const name = path.basename(String(a.name || 'upload.backup')).replace(/[^\w.\-]/g, '_');
      const target = path.join(dir, `${Date.now()}_${name}`);
      fs.writeFileSync(target, Buffer.from(String(a.base64 || ''), 'base64'));
      return { path: target };
    },
  },
  'backup.runAutoNow': { perm: 'backup.create', fn(ctx) { return app(ctx).runAuto(); } },
  'backup.importLegacy': {
    perm: 'backup.restore',
    fn(ctx, a) {
      let data = a.data;
      if (typeof data === 'string') { try { data = JSON.parse(data); } catch (_) { throw new AppError('الملف أو النص ليس بصيغة JSON صحيحة', 'VALIDATION'); } }
      if (!data || typeof data !== 'object' || (!data.items && !data.customers && !data.suppliers && !data.transactions)) throw new AppError('البيانات لا تطابق صيغة النظام القديم (acct_system_v1)', 'VALIDATION');
      if (ctx.db.get("SELECT 1 FROM legacy_archive WHERE source = 'acct_system_v1'") && !a.force) throw new AppError('تم استيراد بيانات النظام القديم من قبل. الاستيراد مرة أخرى سيكرر البيانات.', 'ALREADY_IMPORTED');
      const safety = app(ctx).createBackup({ kind: 'pre-import' });
      const summary = ctx.db.tx(() => importLegacy(ctx, data));
      ctx.audit('legacy_import', { entity: 'legacy_archive', notes: `نسخة أمان: ${safety.file}`, newData: summary });
      return { ...summary, safetyBackup: safety.path };
    },
  },
  'system.info': {
    fn(ctx) {
      const a = app(ctx);
      return { appVersion: a.appVersion, schemaVersion: LATEST, driver: ctx.db.driver.name, dataDir: a.dataDir, dbPath: a.dbPath, platform: a.platform };
    },
  },
};
