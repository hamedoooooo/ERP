'use strict';
const { AppError, str, num, nowISO, idOrNull, reqId, money } = require('../core/util');
const { paged, addSearch, addDateRange } = require('../core/query');
const { TYPE_LABELS } = require('../core/inventory');

const KINDS = { raw: 'خامة', accessory: 'إكسسوار', part: 'قطعة', supply: 'مستلزم', finished: 'منتج نهائي', service: 'خدمة', other: 'أخرى' };

function lowStockCond(ctx, alias = 'p', qtyExpr = 'qty_total') {
  const def = Number(ctx.settings().inventory.defaultLowStock) || 0;
  return `(${alias}.is_stocked = 1 AND ${alias}.active = 1 AND ((${alias}.min_qty > 0 AND ${qtyExpr} <= ${alias}.min_qty) OR (${alias}.min_qty = 0 AND ${def} > 0 AND ${qtyExpr} <= ${def})))`;
}

const QTY_SUB = '(SELECT COALESCE(SUM(s.qty),0) FROM stock s WHERE s.product_id = p.id)';

function list(ctx, a = {}) {
  const where = []; const params = [];
  addSearch(where, params, a.q, ['p.name', 'p.code', 'p.barcode', 'p.description']);
  if (a.category_id) { where.push('p.category_id = ?'); params.push(a.category_id); }
  if (a.kind) { where.push('p.kind = ?'); params.push(a.kind); }
  if (a.active === 'active' || a.active === undefined) where.push('p.active = 1');
  if (a.active === 'inactive') where.push('p.active = 0');
  if (a.stockable) where.push('p.is_stocked = 1');
  const qtyExpr = QTY_SUB;
  if (a.stock === 'low') where.push(lowStockCond(ctx, 'p', qtyExpr));
  if (a.stock === 'available') where.push(`${qtyExpr} > 0.00001`);
  if (a.stock === 'zero') where.push(`p.is_stocked = 1 AND ABS(${qtyExpr}) < 0.00001`);
  const res = paged(ctx.db, {
    select: `p.id, p.code, p.barcode, p.name, p.kind, p.is_stocked, p.category_id, c.name AS category_name, p.unit_id, u.name AS unit_name,
      p.purchase_price, p.sale_price, p.wholesale_price, p.avg_cost, p.last_purchase_price, p.min_qty, p.max_qty, p.active, p.tax_rate,
      ${qtyExpr} AS qty, ${qtyExpr} * p.avg_cost AS value, CASE WHEN p.image IS NOT NULL AND p.image <> '' THEN 1 ELSE 0 END AS has_image`,
    from: 'products p JOIN units u ON u.id = p.unit_id LEFT JOIN categories c ON c.id = p.category_id',
    where, params,
    sortMap: { name: 'p.name', code: 'p.code', qty: 'qty', value: 'value', avg_cost: 'p.avg_cost', sale_price: 'p.sale_price', category_name: 'c.name' },
    defaultSort: 'p.name', sort: a.sort, dir: a.dir, page: a.page, pageSize: a.pageSize, all: a.all,
  });
  return res;
}

module.exports = {
  KINDS,
  lowStockCond,
  'products.kinds': { fn() { return Object.entries(KINDS).map(([value, label]) => ({ value, label })); } },
  'products.list': {
    perm: ['products.view', 'inventory.view'],
    fn(ctx, a = {}) {
      // warehouse-specific qty uses placeholders in SELECT; build params accordingly
      if (!a.warehouse_id) return list(ctx, a);
      const where = []; const params = [];
      addSearch(where, params, a.q, ['p.name', 'p.code', 'p.barcode']);
      if (a.category_id) { where.push('p.category_id = ?'); params.push(a.category_id); }
      if (a.kind) { where.push('p.kind = ?'); params.push(a.kind); }
      where.push('p.active = 1');
      const w = Number(a.warehouse_id);
      const qtyExpr = `(SELECT COALESCE(SUM(s.qty),0) FROM stock s WHERE s.product_id = p.id AND s.warehouse_id = ${w})`;
      if (a.stock === 'low') where.push(lowStockCond(ctx, 'p', qtyExpr));
      if (a.stock === 'available') where.push(`${qtyExpr} > 0.00001`);
      return paged(ctx.db, {
        select: `p.id, p.code, p.barcode, p.name, p.kind, p.is_stocked, c.name AS category_name, u.name AS unit_name, p.purchase_price, p.sale_price,
          p.avg_cost, p.min_qty, p.active, ${qtyExpr} AS qty, ${qtyExpr} * p.avg_cost AS value`,
        from: 'products p JOIN units u ON u.id = p.unit_id LEFT JOIN categories c ON c.id = p.category_id', where, params,
        sortMap: { name: 'p.name', code: 'p.code', qty: 'qty', value: 'value' }, defaultSort: 'p.name', sort: a.sort, dir: a.dir, page: a.page, pageSize: a.pageSize, all: a.all,
      });
    },
  },
  /** Light list for pickers (lines of invoices, BOMs, counts). */
  'products.options': {
    fn(ctx, a = {}) {
      const where = ['p.active = 1']; const params = [];
      if (a.stockable) where.push('p.is_stocked = 1');
      if (a.kinds && a.kinds.length) { where.push(`p.kind IN (${a.kinds.map(() => '?').join(',')})`); params.push(...a.kinds); }
      if (a.excludeKinds && a.excludeKinds.length) { where.push(`p.kind NOT IN (${a.excludeKinds.map(() => '?').join(',')})`); params.push(...a.excludeKinds); }
      const wh = idOrNull(a.warehouse_id);
      return ctx.db.all(`SELECT p.id, p.code, p.barcode, p.name, p.kind, p.is_stocked, u.name AS unit_name, p.purchase_price, p.sale_price, p.avg_cost,
        p.last_purchase_price, p.tax_rate, ${QTY_SUB} AS qty ${wh ? `, (SELECT COALESCE(SUM(s.qty),0) FROM stock s WHERE s.product_id = p.id AND s.warehouse_id = ${wh}) AS wh_qty` : ''}
        FROM products p JOIN units u ON u.id = p.unit_id WHERE ${where.join(' AND ')} ORDER BY p.name`, ...params);
    },
  },
  'products.get': {
    perm: ['products.view', 'inventory.view'],
    fn(ctx, a) {
      const p = ctx.db.get(`SELECT p.*, u.name AS unit_name, c.name AS category_name, s.name AS supplier_name FROM products p
        JOIN units u ON u.id = p.unit_id LEFT JOIN categories c ON c.id = p.category_id LEFT JOIN suppliers s ON s.id = p.default_supplier_id WHERE p.id = ?`, a.id);
      if (!p) throw new AppError('الصنف غير موجود', 'NOT_FOUND');
      p.stock = ctx.db.all('SELECT w.id AS warehouse_id, w.name AS warehouse_name, COALESCE(s.qty,0) AS qty FROM warehouses w LEFT JOIN stock s ON s.warehouse_id = w.id AND s.product_id = ? WHERE w.active = 1 OR COALESCE(s.qty,0) <> 0 ORDER BY w.is_default DESC, w.name', p.id);
      p.qty = p.stock.reduce((s, r) => s + r.qty, 0);
      p.has_movements = Number(ctx.db.val('SELECT COUNT(*) FROM inventory_transactions WHERE product_id = ?', p.id)) > 0;
      return p;
    },
  },
  'products.save': {
    perm: 'products.edit', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      if (!KINDS[a.kind]) throw new AppError('من فضلك اختر نوع الصنف', 'VALIDATION');
      const data = {
        name: str(a.name, 'اسم الصنف', { required: true, max: 200 }),
        barcode: str(a.barcode, 'الباركود', { max: 60 }) || null,
        category_id: idOrNull(a.category_id), unit_id: reqId(a.unit_id, 'الوحدة'), kind: a.kind,
        is_stocked: a.kind === 'service' ? 0 : 1,
        purchase_price: num(a.purchase_price, 'سعر الشراء', { min: 0 }), sale_price: num(a.sale_price, 'سعر البيع', { min: 0 }),
        wholesale_price: num(a.wholesale_price, 'سعر الجملة', { min: 0 }),
        min_qty: num(a.min_qty, 'الحد الأدنى', { min: 0 }), max_qty: num(a.max_qty, 'الحد الأقصى', { min: 0 }),
        default_supplier_id: idOrNull(a.default_supplier_id),
        tax_rate: a.tax_rate === '' || a.tax_rate === null || a.tax_rate === undefined ? null : num(a.tax_rate, 'نسبة الضريبة', { min: 0 }),
        pricing_margin: a.pricing_margin === '' || a.pricing_margin === null || a.pricing_margin === undefined ? null : num(a.pricing_margin, 'هامش الربح', { min: 0 }),
        description: str(a.description, 'الوصف', { max: 2000 }), notes: str(a.notes, 'ملاحظات', { max: 2000 }),
        updated_at: nowISO(),
      };
      if (a.image !== undefined) {
        const img = a.image || null;
        if (img && (!/^data:image\/(png|jpe?g|webp|gif);base64,/.test(img) || img.length > 2_000_000)) throw new AppError('الصورة غير مدعومة أو حجمها كبير (الحد 1.5 ميجا)', 'VALIDATION');
        data.image = img;
      }
      if (data.max_qty > 0 && data.min_qty > data.max_qty) throw new AppError('الحد الأدنى أكبر من الحد الأقصى', 'VALIDATION');
      if (data.barcode && db.get('SELECT id FROM products WHERE barcode = ? AND id <> ?', data.barcode, a.id || 0)) throw new AppError('الباركود مستخدم لصنف آخر', 'VALIDATION');
      if (a.id) {
        const old = db.get('SELECT * FROM products WHERE id = ?', a.id);
        if (!old) throw new AppError('الصنف غير موجود', 'NOT_FOUND');
        const moved = Number(db.val('SELECT COUNT(*) FROM inventory_transactions WHERE product_id = ?', a.id)) > 0;
        if (moved && old.unit_id !== data.unit_id) throw new AppError('لا يمكن تغيير وحدة صنف له حركات مخزون، لأن ذلك يغيّر معنى الكميات المسجلة.', 'VALIDATION');
        if (moved && old.is_stocked !== data.is_stocked) throw new AppError('لا يمكن تحويل صنف له حركات مخزون إلى خدمة أو العكس.', 'VALIDATION');
        if (a.code && a.code.trim() !== old.code) {
          if (db.get('SELECT id FROM products WHERE code = ? AND id <> ?', a.code.trim(), a.id)) throw new AppError('كود الصنف مستخدم بالفعل', 'VALIDATION');
          data.code = a.code.trim();
        }
        db.update('products', a.id, data);
        const priceFields = ['purchase_price', 'sale_price', 'wholesale_price'];
        ctx.audit(priceFields.some((f) => Number(old[f]) !== Number(data[f])) ? 'update_price' : 'update', { entity: 'products', entityId: a.id, docNo: old.code, oldData: old, newData: data });
        return a.id;
      }
      data.code = ctx.code('products', 'product', a.code);
      if (db.get('SELECT id FROM products WHERE code = ?', data.code)) throw new AppError('كود الصنف مستخدم بالفعل', 'VALIDATION');
      data.avg_cost = data.purchase_price;
      data.created_at = nowISO();
      const id = db.insert('products', data);
      ctx.audit('create', { entity: 'products', entityId: id, docNo: data.code, newData: data });
      return id;
    },
  },
  'products.toggle': {
    perm: 'products.edit', write: true,
    fn(ctx, a) {
      const p = ctx.db.get('SELECT * FROM products WHERE id = ?', a.id);
      if (!p) throw new AppError('الصنف غير موجود', 'NOT_FOUND');
      ctx.db.update('products', p.id, { active: p.active ? 0 : 1, updated_at: nowISO() });
      ctx.audit(p.active ? 'deactivate' : 'activate', { entity: 'products', entityId: p.id, docNo: p.code });
      return !p.active;
    },
  },
  'products.delete': {
    perm: 'data.delete', write: true,
    fn(ctx, a) {
      const db = ctx.db;
      const p = db.get('SELECT * FROM products WHERE id = ?', a.id);
      if (!p) throw new AppError('الصنف غير موجود', 'NOT_FOUND');
      const refs = [
        ['SELECT COUNT(*) FROM inventory_transactions WHERE product_id = ?', 'حركات مخزون'],
        ['SELECT COUNT(*) FROM purchase_items WHERE product_id = ?', 'فواتير شراء'],
        ['SELECT COUNT(*) FROM sales_items WHERE product_id = ?', 'فواتير بيع'],
        ['SELECT COUNT(*) FROM bom_items WHERE product_id = ?', 'قوائم مواد'],
        ['SELECT COUNT(*) FROM boms WHERE product_id = ?', 'قوائم مواد'],
        ['SELECT COUNT(*) FROM manufacturing_orders WHERE product_id = ?', 'أوامر تصنيع'],
        ['SELECT COUNT(*) FROM stock_count_items WHERE product_id = ?', 'جرد'],
      ];
      for (const [sql, what] of refs) if (Number(db.val(sql, p.id)) > 0) throw new AppError(`لا يمكن حذف "${p.name}" لأنه مستخدم في ${what}. يمكنك إيقافه بدلًا من الحذف.`, 'IN_USE');
      db.run('DELETE FROM stock WHERE product_id = ?', p.id);
      db.run('DELETE FROM products WHERE id = ?', p.id);
      ctx.audit('delete', { entity: 'products', entityId: p.id, docNo: p.code, oldData: p });
      return true;
    },
  },

  /** Item card: summary + movement ledger with running balance. */
  'products.card': {
    perm: ['products.view', 'inventory.view'],
    fn(ctx, a) {
      const db = ctx.db;
      const p = db.get('SELECT p.*, u.name AS unit_name, c.name AS category_name FROM products p JOIN units u ON u.id = p.unit_id LEFT JOIN categories c ON c.id = p.category_id WHERE p.id = ?', a.id);
      if (!p) throw new AppError('الصنف غير موجود', 'NOT_FOUND');
      const wh = idOrNull(a.warehouse_id);
      const qty = Number(db.val(`SELECT COALESCE(SUM(qty),0) FROM stock WHERE product_id = ? ${wh ? 'AND warehouse_id = ' + wh : ''}`, p.id)) || 0;
      const agg = db.get(`SELECT COALESCE(SUM(qty_in),0) AS tin, COALESCE(SUM(qty_out),0) AS tout, MAX(date) AS last_date FROM inventory_transactions WHERE product_id = ? ${wh ? 'AND warehouse_id = ' + wh : ''}`, p.id);
      const lastPurchase = db.get("SELECT pi.date, pi.doc_no, it.qty, it.unit_cost FROM purchase_items it JOIN purchase_invoices pi ON pi.id = it.invoice_id WHERE it.product_id = ? AND pi.status='posted' ORDER BY pi.date DESC, pi.id DESC LIMIT 1", p.id);
      const lastSale = db.get("SELECT si.date, si.doc_no, it.qty, it.unit_price FROM sales_items it JOIN sales_invoices si ON si.id = it.invoice_id WHERE it.product_id = ? AND si.status='posted' ORDER BY si.date DESC, si.id DESC LIMIT 1", p.id);
      const lastMove = db.get(`SELECT date, type, doc_no FROM inventory_transactions WHERE product_id = ? ${wh ? 'AND warehouse_id = ' + wh : ''} ORDER BY id DESC LIMIT 1`, p.id);

      const where = ['t.product_id = ?']; const params = [p.id];
      if (wh) { where.push('t.warehouse_id = ?'); params.push(wh); }
      // opening balance before date range
      let opening = 0;
      if (a.from) {
        opening = Number(db.val(`SELECT COALESCE(SUM(qty_in - qty_out),0) FROM inventory_transactions t WHERE ${where.join(' AND ')} AND t.date < ?`, ...params, a.from)) || 0;
      }
      addDateRange(where, params, 't.date', a.from, a.to);
      const rows = db.all(`SELECT t.id, t.date, t.type, t.doc_type, t.doc_id, t.doc_no, t.qty_in, t.qty_out, t.unit_cost, t.total_cost, t.avg_cost_after, t.notes, w.name AS warehouse_name
        FROM inventory_transactions t JOIN warehouses w ON w.id = t.warehouse_id WHERE ${where.join(' AND ')} ORDER BY t.date, t.id`, ...params);
      let running = opening;
      rows.forEach((r) => { running += r.qty_in - r.qty_out; r.balance = running; r.type_label = TYPE_LABELS[r.type] || r.type; });
      return {
        product: { ...p, image: undefined, kind_label: KINDS[p.kind] },
        summary: {
          qty, value: money(qty * p.avg_cost), avg_cost: p.avg_cost, total_in: agg.tin, total_out: agg.tout,
          last_purchase: lastPurchase, last_sale: lastSale, last_move: lastMove ? { ...lastMove, type_label: TYPE_LABELS[lastMove.type] } : null,
        },
        opening, rows,
      };
    },
  },
};
