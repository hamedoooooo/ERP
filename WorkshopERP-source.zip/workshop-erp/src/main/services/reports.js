'use strict';
const { AppError, money, qtyR, todayISO, idOrNull, EPS } = require('../core/util');
const { paged, addSearch, addDateRange } = require('../core/query');
const ledger = require('../core/ledger');
const finance = require('./finance');
const products = require('./products');
const inv = require('../core/inventory');

const { ACC } = ledger;
const MAX_ROWS = 20000;

const C = (key, label, type = 'text', extra = {}) => ({ key, label, type, ...extra });
const dr = (w, p, col, a) => addDateRange(w, p, col, a.from, a.to);
const W = (w) => (w.length ? 'WHERE ' + w.join(' AND ') : '');
const sumCols = (rows, keys) => { const t = {}; keys.forEach((k) => { t[k] = money(rows.reduce((s, r) => s + (Number(r[k]) || 0), 0)); }); return t; };

const STATUS = { posted: 'معتمد', void: 'ملغي', draft: 'مسودة', approved: 'معتمد', cancelled: 'ملغي' };
const SETTLE = { account: 'على الحساب', cash: 'نقدًا', bank: 'البنك' };

const REPORTS = {
  stock: {
    title: 'تقرير المخزون', group: 'المخزون', perm: 'inventory.view', filters: ['warehouse', 'category', 'kind', 'q'],
    run(ctx, a) {
      const w = ['p.is_stocked = 1', 'p.active = 1']; const p = [];
      if (a.category_id) { w.push('p.category_id = ?'); p.push(a.category_id); }
      if (a.kind) { w.push('p.kind = ?'); p.push(a.kind); }
      addSearch(w, p, a.q, ['p.name', 'p.code', 'p.barcode']);
      const wh = idOrNull(a.warehouse_id);
      const q = `(SELECT COALESCE(SUM(s.qty),0) FROM stock s WHERE s.product_id = p.id ${wh ? 'AND s.warehouse_id = ' + wh : ''})`;
      const rows = ctx.db.all(`SELECT p.code, p.name, c.name AS category, u.name AS unit, ${q} AS qty, p.avg_cost, ${q} * p.avg_cost AS value, p.min_qty,
          CASE WHEN ${products.lowStockCond(ctx, 'p', q)} THEN 'منخفض' ELSE '' END AS flag
        FROM products p JOIN units u ON u.id = p.unit_id LEFT JOIN categories c ON c.id = p.category_id ${W(w)} ORDER BY p.name`, ...p);
      return { columns: [C('code', 'الكود'), C('name', 'الصنف'), C('category', 'التصنيف'), C('unit', 'الوحدة'), C('qty', 'الرصيد', 'qty'), C('avg_cost', 'متوسط التكلفة', 'money'), C('value', 'القيمة', 'money'), C('min_qty', 'الحد الأدنى', 'qty'), C('flag', 'تنبيه', 'badge')],
        rows, totals: sumCols(rows, ['value']) };
    },
  },
  item_card: {
    title: 'كارت الصنف', group: 'المخزون', perm: 'inventory.view', filters: ['product*', 'warehouse', 'date'],
    run(ctx, a) {
      if (!a.product_id) throw new AppError('اختر الصنف لعرض الكارت', 'VALIDATION');
      const card = products['products.card'].fn(ctx, { id: a.product_id, warehouse_id: a.warehouse_id, from: a.from, to: a.to });
      const s = card.summary;
      return {
        subtitle: `${card.product.code} — ${card.product.name} (${card.product.unit_name})`,
        summary: [
          { label: 'الرصيد الحالي', value: s.qty, type: 'qty' }, { label: 'قيمة المخزون', value: s.value, type: 'money' }, { label: 'متوسط التكلفة', value: s.avg_cost, type: 'money' },
          { label: 'إجمالي الوارد', value: s.total_in, type: 'qty' }, { label: 'إجمالي المنصرف', value: s.total_out, type: 'qty' },
          { label: 'آخر شراء', value: s.last_purchase ? `${s.last_purchase.date} (${s.last_purchase.doc_no})` : '—' },
          { label: 'آخر بيع', value: s.last_sale ? `${s.last_sale.date} (${s.last_sale.doc_no})` : '—' },
          { label: 'آخر حركة', value: s.last_move ? `${s.last_move.date} — ${s.last_move.type_label}` : '—' },
        ],
        columns: [C('date', 'التاريخ', 'date'), C('type_label', 'الحركة'), C('doc_no', 'المستند'), C('warehouse_name', 'المخزن'), C('qty_in', 'وارد', 'qty'), C('qty_out', 'منصرف', 'qty'), C('balance', 'الرصيد', 'qty'), C('unit_cost', 'التكلفة', 'money'), C('total_cost', 'القيمة', 'money')],
        rows: card.opening ? [{ date: a.from, type_label: 'رصيد أول المدة', balance: card.opening }, ...card.rows] : card.rows,
        totals: sumCols(card.rows, ['qty_in', 'qty_out']),
      };
    },
  },
  movements: {
    title: 'حركة المخزون', group: 'المخزون', perm: 'inventory.view', filters: ['date', 'warehouse', 'product', 'movetype', 'q'],
    run(ctx, a) {
      const w = []; const p = [];
      dr(w, p, 't.date', a);
      if (a.warehouse_id) { w.push('t.warehouse_id = ?'); p.push(a.warehouse_id); }
      if (a.product_id) { w.push('t.product_id = ?'); p.push(a.product_id); }
      if (a.type) { w.push('t.type = ?'); p.push(a.type); }
      addSearch(w, p, a.q, ['pr.name', 't.doc_no']);
      const rows = ctx.db.all(`SELECT t.date, t.type, t.doc_no, pr.code, pr.name, wh.name AS warehouse, t.qty_in, t.qty_out, t.unit_cost, t.total_cost, u.full_name AS user_name
        FROM inventory_transactions t JOIN products pr ON pr.id = t.product_id JOIN warehouses wh ON wh.id = t.warehouse_id LEFT JOIN users u ON u.id = t.user_id ${W(w)} ORDER BY t.date, t.id LIMIT ${MAX_ROWS}`, ...p);
      rows.forEach((r) => { r.type_label = inv.TYPE_LABELS[r.type] || r.type; });
      return { columns: [C('date', 'التاريخ', 'date'), C('type_label', 'الحركة'), C('doc_no', 'المستند'), C('code', 'الكود'), C('name', 'الصنف'), C('warehouse', 'المخزن'), C('qty_in', 'وارد', 'qty'), C('qty_out', 'منصرف', 'qty'), C('unit_cost', 'تكلفة الوحدة', 'money'), C('total_cost', 'القيمة', 'money'), C('user_name', 'المستخدم')],
        rows, totals: sumCols(rows, ['qty_in', 'qty_out']), truncated: rows.length >= MAX_ROWS };
    },
  },
  purchases: {
    title: 'المشتريات', group: 'المشتريات والمبيعات', perm: 'purchases.view', filters: ['date', 'supplier', 'status', 'q'],
    run(ctx, a) {
      const w = []; const p = [];
      dr(w, p, 'd.date', a);
      if (a.supplier_id) { w.push('d.supplier_id = ?'); p.push(a.supplier_id); }
      w.push('d.status = ?'); p.push(a.status || 'posted');
      addSearch(w, p, a.q, ['d.doc_no', 's.name']);
      const rows = ctx.db.all(`SELECT d.date, d.doc_no, COALESCE(s.name,'نقدي') AS party, d.subtotal, d.discount, d.tax, d.total, d.paid, d.total - d.paid AS remaining, d.status
        FROM purchase_invoices d LEFT JOIN suppliers s ON s.id = d.supplier_id ${W(w)} ORDER BY d.date, d.id`, ...p);
      rows.forEach((r) => { r.status = STATUS[r.status]; });
      return { columns: [C('date', 'التاريخ', 'date'), C('doc_no', 'رقم الفاتورة'), C('party', 'المورد'), C('subtotal', 'الإجمالي', 'money'), C('discount', 'الخصم', 'money'), C('tax', 'الضريبة', 'money'), C('total', 'الصافي', 'money'), C('paid', 'المدفوع', 'money'), C('remaining', 'المتبقي', 'money'), C('status', 'الحالة', 'badge')],
        rows, totals: sumCols(rows, ['subtotal', 'discount', 'tax', 'total', 'paid', 'remaining']) };
    },
  },
  sales: {
    title: 'المبيعات', group: 'المشتريات والمبيعات', perm: 'sales.view', filters: ['date', 'customer', 'status', 'q'],
    run(ctx, a) {
      const w = []; const p = [];
      dr(w, p, 'd.date', a);
      if (a.customer_id) { w.push('d.customer_id = ?'); p.push(a.customer_id); }
      w.push('d.status = ?'); p.push(a.status || 'posted');
      addSearch(w, p, a.q, ['d.doc_no', 'c.name']);
      const cost = ctx.can('costs.view');
      const rows = ctx.db.all(`SELECT d.date, d.doc_no, COALESCE(c.name,'نقدي') AS party, d.subtotal, d.discount, d.tax, d.total, d.paid, d.total - d.paid AS remaining,
          d.cost_total, d.subtotal - d.discount - d.cost_total AS profit, d.status
        FROM sales_invoices d LEFT JOIN customers c ON c.id = d.customer_id ${W(w)} ORDER BY d.date, d.id`, ...p);
      rows.forEach((r) => { r.status = STATUS[r.status]; if (!cost) { delete r.cost_total; delete r.profit; } });
      const cols = [C('date', 'التاريخ', 'date'), C('doc_no', 'رقم الفاتورة'), C('party', 'العميل'), C('subtotal', 'الإجمالي', 'money'), C('discount', 'الخصم', 'money'), C('tax', 'الضريبة', 'money'), C('total', 'الصافي', 'money'), C('paid', 'المدفوع', 'money'), C('remaining', 'المتبقي', 'money')];
      if (cost) cols.push(C('cost_total', 'تكلفة المبيعات', 'money'), C('profit', 'مجمل الربح', 'money'));
      cols.push(C('status', 'الحالة', 'badge'));
      return { columns: cols, rows, totals: sumCols(rows, ['subtotal', 'discount', 'tax', 'total', 'paid', 'remaining', 'cost_total', 'profit']) };
    },
  },
  sales_returns: {
    title: 'مرتجعات المبيعات', group: 'المشتريات والمبيعات', perm: 'sales.view', filters: ['date', 'customer'],
    run(ctx, a) {
      const w = ["d.status='posted'"]; const p = [];
      dr(w, p, 'd.date', a);
      if (a.customer_id) { w.push('d.customer_id = ?'); p.push(a.customer_id); }
      const rows = ctx.db.all(`SELECT d.date, d.doc_no, COALESCE(c.name,'نقدي') AS party, si.doc_no AS invoice_no, d.subtotal, d.tax, d.total, d.cost_total, d.settle
        FROM sales_returns d LEFT JOIN customers c ON c.id = d.customer_id LEFT JOIN sales_invoices si ON si.id = d.invoice_id ${W(w)} ORDER BY d.date, d.id`, ...p);
      rows.forEach((r) => { r.settle = SETTLE[r.settle]; });
      return { columns: [C('date', 'التاريخ', 'date'), C('doc_no', 'رقم المرتجع'), C('party', 'العميل'), C('invoice_no', 'الفاتورة الأصلية'), C('subtotal', 'القيمة', 'money'), C('tax', 'الضريبة', 'money'), C('total', 'الإجمالي', 'money'), C('cost_total', 'التكلفة المستردة', 'money'), C('settle', 'التسوية')],
        rows, totals: sumCols(rows, ['subtotal', 'tax', 'total', 'cost_total']) };
    },
  },
  purchase_returns: {
    title: 'مرتجعات المشتريات', group: 'المشتريات والمبيعات', perm: 'purchases.view', filters: ['date', 'supplier'],
    run(ctx, a) {
      const w = ["d.status='posted'"]; const p = [];
      dr(w, p, 'd.date', a);
      if (a.supplier_id) { w.push('d.supplier_id = ?'); p.push(a.supplier_id); }
      const rows = ctx.db.all(`SELECT d.date, d.doc_no, COALESCE(s.name,'نقدي') AS party, pi.doc_no AS invoice_no, d.subtotal, d.tax, d.total, d.cost_total, d.settle
        FROM purchase_returns d LEFT JOIN suppliers s ON s.id = d.supplier_id LEFT JOIN purchase_invoices pi ON pi.id = d.invoice_id ${W(w)} ORDER BY d.date, d.id`, ...p);
      rows.forEach((r) => { r.settle = SETTLE[r.settle]; });
      return { columns: [C('date', 'التاريخ', 'date'), C('doc_no', 'رقم المرتجع'), C('party', 'المورد'), C('invoice_no', 'الفاتورة الأصلية'), C('subtotal', 'القيمة', 'money'), C('tax', 'الضريبة', 'money'), C('total', 'الإجمالي', 'money'), C('cost_total', 'تكلفة المخزون', 'money'), C('settle', 'التسوية')],
        rows, totals: sumCols(rows, ['subtotal', 'tax', 'total', 'cost_total']) };
    },
  },
  customers: {
    title: 'العملاء وأرصدتهم', group: 'العملاء والموردون', perm: 'customers.manage', filters: ['q', 'due'],
    run(ctx, a) {
      const r = ctx.api('customers.list', { q: a.q, balance: a.due ? 'due' : '', all: true, active: 'all' });
      const rows = r.rows.map((x) => ({ code: x.code, name: x.name, phone: x.phone, invoices_total: x.invoices_total, returns_total: x.returns_total, paid: x.paid, balance: x.balance, credit_limit: x.credit_limit }));
      return { columns: [C('code', 'الكود'), C('name', 'العميل'), C('phone', 'الهاتف'), C('invoices_total', 'إجمالي المبيعات', 'money'), C('returns_total', 'المرتجعات', 'money'), C('paid', 'المدفوع', 'money'), C('balance', 'المتبقي (الرصيد)', 'money'), C('credit_limit', 'حد الائتمان', 'money')],
        rows, totals: sumCols(rows, ['invoices_total', 'returns_total', 'paid', 'balance']) };
    },
  },
  suppliers: {
    title: 'الموردون وأرصدتهم', group: 'العملاء والموردون', perm: 'suppliers.manage', filters: ['q', 'due'],
    run(ctx, a) {
      const r = ctx.api('suppliers.list', { q: a.q, balance: a.due ? 'due' : '', all: true, active: 'all' });
      const rows = r.rows.map((x) => ({ code: x.code, name: x.name, phone: x.phone, invoices_total: x.invoices_total, returns_total: x.returns_total, paid: x.paid, balance: x.balance }));
      return { columns: [C('code', 'الكود'), C('name', 'المورد'), C('phone', 'الهاتف'), C('invoices_total', 'إجمالي المشتريات', 'money'), C('returns_total', 'المرتجعات', 'money'), C('paid', 'المدفوع', 'money'), C('balance', 'المتبقي (الرصيد)', 'money')],
        rows, totals: sumCols(rows, ['invoices_total', 'returns_total', 'paid', 'balance']) };
    },
  },
  customer_statement: {
    title: 'كشف حساب عميل', group: 'العملاء والموردون', perm: 'customers.manage', filters: ['customer*', 'date'],
    run(ctx, a) {
      if (!a.customer_id) throw new AppError('اختر العميل', 'VALIDATION');
      return stmtReport(finance.statement(ctx.db, 'customer', Number(a.customer_id), a.from, a.to));
    },
  },
  supplier_statement: {
    title: 'كشف حساب مورد', group: 'العملاء والموردون', perm: 'suppliers.manage', filters: ['supplier*', 'date'],
    run(ctx, a) {
      if (!a.supplier_id) throw new AppError('اختر المورد', 'VALIDATION');
      return stmtReport(finance.statement(ctx.db, 'supplier', Number(a.supplier_id), a.from, a.to));
    },
  },
  expenses: {
    title: 'المصروفات', group: 'المالية', perm: 'expenses.manage', filters: ['date', 'expcat', 'q'],
    run(ctx, a) {
      const w = ["d.status='posted'"]; const p = [];
      dr(w, p, 'd.date', a);
      if (a.category_id) { w.push('d.category_id = ?'); p.push(a.category_id); }
      addSearch(w, p, a.q, ['d.description', 'd.payee', 'd.doc_no']);
      const rows = ctx.db.all(`SELECT d.date, d.doc_no, c.name AS category, d.description, d.payee, d.method, d.amount, u.full_name AS user_name FROM expenses d JOIN expense_categories c ON c.id = d.category_id LEFT JOIN users u ON u.id = d.created_by ${W(w)} ORDER BY d.date, d.id`, ...p);
      const M = { cash: 'الصندوق', bank: 'البنك', credit: 'آجل' };
      rows.forEach((r) => { r.method = M[r.method]; });
      const byCat = {};
      rows.forEach((r) => { byCat[r.category] = money((byCat[r.category] || 0) + r.amount); });
      return { columns: [C('date', 'التاريخ', 'date'), C('doc_no', 'الرقم'), C('category', 'التصنيف'), C('description', 'البيان'), C('payee', 'المستفيد'), C('method', 'طريقة الدفع'), C('amount', 'المبلغ', 'money'), C('user_name', 'المستخدم')],
        rows, totals: sumCols(rows, ['amount']), summary: Object.entries(byCat).map(([label, value]) => ({ label, value, type: 'money' })) };
    },
  },
  mo_list: {
    title: 'أوامر التصنيع', group: 'التصنيع', perm: 'manufacturing.view', filters: ['date', 'mostatus', 'customer', 'q'],
    run(ctx, a) {
      const w = []; const p = [];
      dr(w, p, 'mo.date', a);
      if (a.status) { w.push('mo.status = ?'); p.push(a.status); }
      if (a.customer_id) { w.push('mo.customer_id = ?'); p.push(a.customer_id); }
      addSearch(w, p, a.q, ['mo.doc_no', 'pr.name']);
      const rows = ctx.db.all(`SELECT mo.doc_no, mo.date, pr.name AS product, c.name AS customer, mo.qty, mo.produced_qty, st.name AS status, mo.start_date, mo.due_date, mo.completed_at,
          CASE WHEN mo.due_date IS NOT NULL AND st.stage IN ('open','active') AND mo.due_date < '${todayISO()}' THEN 'متأخر' ELSE '' END AS late
        FROM manufacturing_orders mo JOIN products pr ON pr.id = mo.product_id JOIN mo_statuses st ON st.code = mo.status LEFT JOIN customers c ON c.id = mo.customer_id ${W(w)} ORDER BY mo.date, mo.id`, ...p);
      return { columns: [C('doc_no', 'رقم الأمر'), C('date', 'التاريخ', 'date'), C('product', 'المنتج'), C('customer', 'العميل'), C('qty', 'الكمية', 'qty'), C('produced_qty', 'المنتج فعلًا', 'qty'), C('status', 'الحالة', 'badge'), C('start_date', 'البدء', 'date'), C('due_date', 'التسليم', 'date'), C('completed_at', 'الإكمال', 'date'), C('late', 'تنبيه', 'badge')], rows };
    },
  },
  mo_cost: {
    title: 'تكلفة التصنيع', group: 'التصنيع', perm: 'costs.view', filters: ['date', 'product'],
    run(ctx, a) {
      const w = ["st.stage = 'done'"]; const p = [];
      addDateRange(w, p, 'mo.completed_at', a.from, a.to);
      if (a.product_id) { w.push('mo.product_id = ?'); p.push(a.product_id); }
      const rows = ctx.db.all(`SELECT mo.doc_no, mo.completed_at, pr.name AS product, mo.produced_qty, mo.material_cost, mo.accessories_cost, mo.labor_cost, mo.other_cost, mo.overhead_cost, mo.total_cost, mo.unit_cost
        FROM manufacturing_orders mo JOIN products pr ON pr.id = mo.product_id JOIN mo_statuses st ON st.code = mo.status ${W(w)} ORDER BY mo.completed_at, mo.id`, ...p);
      return { columns: [C('doc_no', 'رقم الأمر'), C('completed_at', 'تاريخ الإكمال', 'date'), C('product', 'المنتج'), C('produced_qty', 'الكمية', 'qty'), C('material_cost', 'الخامات', 'money'), C('accessories_cost', 'الإكسسوارات', 'money'), C('labor_cost', 'العمالة', 'money'), C('other_cost', 'تكاليف مباشرة', 'money'), C('overhead_cost', 'مصروفات صناعية', 'money'), C('total_cost', 'الإجمالي', 'money'), C('unit_cost', 'تكلفة الوحدة', 'money')],
        rows, totals: sumCols(rows, ['material_cost', 'accessories_cost', 'labor_cost', 'other_cost', 'overhead_cost', 'total_cost']) };
    },
  },
  consumption: {
    title: 'استهلاك الخامات', group: 'التصنيع', perm: 'manufacturing.view', filters: ['date', 'product', 'category'],
    run(ctx, a) {
      const w = []; const p = [];
      dr(w, p, 'm.date', a);
      if (a.product_id) { w.push('m.product_id = ?'); p.push(a.product_id); }
      if (a.category_id) { w.push('pr.category_id = ?'); p.push(a.category_id); }
      const rows = ctx.db.all(`SELECT pr.code, pr.name, u.name AS unit, COUNT(DISTINCT m.mo_id) AS orders, SUM(m.qty) AS qty, SUM(m.total_cost) AS cost
        FROM mo_material_moves m JOIN products pr ON pr.id = m.product_id JOIN units u ON u.id = pr.unit_id ${W(w)} GROUP BY m.product_id HAVING ABS(SUM(m.qty)) > 0.00001 ORDER BY cost DESC`, ...p);
      if (!ctx.can('costs.view')) rows.forEach((r) => delete r.cost);
      return { columns: [C('code', 'الكود'), C('name', 'المادة'), C('unit', 'الوحدة'), C('orders', 'عدد الأوامر', 'qty'), C('qty', 'الكمية المستهلكة', 'qty'), ...(ctx.can('costs.view') ? [C('cost', 'التكلفة', 'money')] : [])], rows, totals: sumCols(rows, ['cost']) };
    },
  },
  waste: {
    title: 'الهالك (المخطط مقابل الفعلي)', group: 'التصنيع', perm: 'manufacturing.view', filters: ['date', 'product'],
    run(ctx, a) {
      const w = []; const p = [];
      dr(w, p, 'mo.date', a);
      if (a.product_id) { w.push('x.product_id = ?'); p.push(a.product_id); }
      const rows = ctx.db.all(`SELECT mo.doc_no, pr.name AS material, u.name AS unit, x.planned_qty,
          COALESCE((SELECT SUM(qty) FROM mo_material_moves m WHERE m.mo_id = x.mo_id AND m.product_id = x.product_id),0) AS actual_qty,
          COALESCE((SELECT SUM(total_cost) FROM mo_material_moves m WHERE m.mo_id = x.mo_id AND m.product_id = x.product_id),0) AS actual_cost
        FROM mo_materials x JOIN manufacturing_orders mo ON mo.id = x.mo_id JOIN products pr ON pr.id = x.product_id JOIN units u ON u.id = pr.unit_id JOIN mo_statuses st ON st.code = mo.status
        ${W([...w, "st.stage <> 'cancelled'"])} ORDER BY mo.id, pr.name`, ...p)
        .map((r) => {
          const diff = qtyR(r.actual_qty - r.planned_qty);
          const unit = r.actual_qty > EPS ? r.actual_cost / r.actual_qty : 0;
          return { ...r, diff, waste_pct: r.planned_qty > EPS ? money(diff / r.planned_qty * 100) : null, waste_value: diff > 0 ? money(diff * unit) : 0 };
        }).filter((r) => r.actual_qty > EPS);
      return { columns: [C('doc_no', 'أمر التصنيع'), C('material', 'المادة'), C('unit', 'الوحدة'), C('planned_qty', 'المخطط', 'qty'), C('actual_qty', 'الفعلي', 'qty'), C('diff', 'الفرق', 'qty'), C('waste_pct', 'نسبة الهالك', 'pct'), ...(ctx.can('costs.view') ? [C('waste_value', 'قيمة الهالك', 'money')] : [])],
        rows, totals: sumCols(rows, ['waste_value']) };
    },
  },
  product_profit: {
    title: 'ربحية المنتجات', group: 'الأرباح', perm: 'costs.view', filters: ['date', 'category'],
    run(ctx, a) {
      const w = ["s.status='posted'"]; const p = [];
      dr(w, p, 's.date', a);
      if (a.category_id) { w.push('pr.category_id = ?'); p.push(a.category_id); }
      const sales = ctx.db.all(`SELECT si.product_id, pr.code, pr.name, SUM(si.qty) AS qty, SUM(si.net_total) AS revenue, SUM(si.cost_total) AS cost
        FROM sales_items si JOIN sales_invoices s ON s.id = si.invoice_id JOIN products pr ON pr.id = si.product_id ${W(w)} GROUP BY si.product_id`, ...p);
      const w2 = ["r.status='posted'"]; const p2 = [];
      dr(w2, p2, 'r.date', a);
      const rets = ctx.db.all(`SELECT ri.product_id, SUM(ri.qty) AS qty, SUM(ri.line_total) AS revenue, SUM(ri.cost_total) AS cost FROM sales_return_items ri JOIN sales_returns r ON r.id = ri.return_id ${W(w2)} GROUP BY ri.product_id`, ...p2);
      const rm = new Map(rets.map((r) => [r.product_id, r]));
      const rows = sales.map((s) => {
        const r = rm.get(s.product_id) || { qty: 0, revenue: 0, cost: 0 };
        const revenue = money(s.revenue - r.revenue); const cost = money(s.cost - r.cost); const profit = money(revenue - cost);
        return { code: s.code, name: s.name, qty: qtyR(s.qty - r.qty), revenue, cost, profit, margin: revenue ? money(profit / revenue * 100) : null };
      }).sort((x, y) => y.profit - x.profit);
      const t = sumCols(rows, ['revenue', 'cost', 'profit']);
      t.margin = t.revenue ? money(t.profit / t.revenue * 100) : null;
      return { columns: [C('code', 'الكود'), C('name', 'المنتج'), C('qty', 'الكمية المباعة', 'qty'), C('revenue', 'صافي الإيراد', 'money'), C('cost', 'التكلفة', 'money'), C('profit', 'مجمل الربح', 'money'), C('margin', 'هامش الربح', 'pct')], rows, totals: t };
    },
  },
  mo_profit: {
    title: 'ربحية أوامر التصنيع', group: 'الأرباح', perm: 'costs.view', filters: ['date', 'customer'],
    run(ctx, a) {
      const w = ["st.stage <> 'cancelled'"]; const p = [];
      dr(w, p, 'mo.date', a);
      if (a.customer_id) { w.push('mo.customer_id = ?'); p.push(a.customer_id); }
      const ids = ctx.db.all(`SELECT mo.id FROM manufacturing_orders mo JOIN mo_statuses st ON st.code = mo.status ${W(w)} ORDER BY mo.date, mo.id`, ...p);
      const BASIS = { actual: 'فعلي (مبيعات)', expected: 'متوقع (سعر متفق)', none: '—' };
      const rows = ids.map(({ id }) => {
        const mo = ctx.api('mo.get', { id });
        const pr = mo.profit;
        return { doc_no: mo.doc_no, product: mo.product_name, customer: mo.customer_name, status: mo.status_name, revenue: pr.revenue, basis: BASIS[pr.revenue_basis],
          material: money(pr.material + pr.accessories), labor: pr.labor, other: money(pr.other + pr.overhead), total_cost: pr.cost_basis, profit: pr.gross_profit, margin: pr.margin_pct };
      });
      const t = sumCols(rows, ['revenue', 'material', 'labor', 'other', 'total_cost', 'profit']);
      t.margin = t.revenue ? money(t.profit / t.revenue * 100) : null;
      return { columns: [C('doc_no', 'رقم الأمر'), C('product', 'المنتج'), C('customer', 'العميل'), C('status', 'الحالة', 'badge'), C('revenue', 'الإيراد', 'money'), C('basis', 'أساس الإيراد'), C('material', 'خامات وإكسسوارات', 'money'), C('labor', 'عمالة', 'money'), C('other', 'أخرى وصناعية', 'money'), C('total_cost', 'التكلفة', 'money'), C('profit', 'الربح', 'money'), C('margin', 'الهامش', 'pct')], rows, totals: t };
    },
  },
  income: {
    title: 'قائمة الدخل', group: 'الأرباح', perm: 'reports.view', filters: ['date'],
    run(ctx, a) {
      if (!ctx.can('costs.view')) throw new AppError('ليست لديك صلاحية: رؤية التكاليف والأرباح', 'FORBIDDEN');
      const i = finance.incomeStatement(ctx.db, a.from, a.to);
      const rows = [
        { label: 'إجمالي المبيعات', amount: i.sales, level: 0 }, { label: '(-) مردودات المبيعات', amount: -i.returns, level: 1 },
        { label: 'صافي المبيعات', amount: i.net_sales, level: 0, strong: true },
        ...i.cogs_rows.map((r) => ({ label: '(-) ' + r.name, amount: -r.balance, level: 1 })),
        { label: 'تكلفة المبيعات', amount: -i.cogs, level: 0 },
        { label: 'مجمل الربح', amount: i.gross_profit, level: 0, strong: true },
        ...i.opex_rows.map((r) => ({ label: '(-) ' + r.name, amount: -r.balance, level: 1 })),
        { label: 'إجمالي المصروفات التشغيلية', amount: -i.opex, level: 0 },
        ...(Math.abs(i.other_income) > 0.004 ? [{ label: '(+) إيرادات أخرى', amount: i.other_income, level: 1 }] : []),
        { label: 'صافي الربح', amount: i.net_profit, level: 0, strong: true },
      ];
      return { layout: 'statement', columns: [C('label', 'البند'), C('amount', 'المبلغ', 'money')], rows,
        summary: [{ label: 'هامش مجمل الربح', value: i.gross_margin, type: 'pct' }, { label: 'هامش صافي الربح', value: i.net_margin, type: 'pct' }] };
    },
  },
  stock_counts: {
    title: 'جرد المخزون', group: 'المخزون', perm: 'inventory.view', filters: ['date', 'warehouse'],
    run(ctx, a) {
      const w = ["c.status = 'approved'", 'i.actual_qty IS NOT NULL']; const p = [];
      dr(w, p, 'c.date', a);
      if (a.warehouse_id) { w.push('c.warehouse_id = ?'); p.push(a.warehouse_id); }
      const rows = ctx.db.all(`SELECT c.doc_no, c.date, wh.name AS warehouse, pr.name AS product, i.system_qty, i.actual_qty, i.actual_qty - i.system_qty AS diff, (i.actual_qty - i.system_qty) * i.unit_cost AS diff_value, i.reason, u.full_name AS approver
        FROM stock_count_items i JOIN stock_counts c ON c.id = i.count_id JOIN warehouses wh ON wh.id = c.warehouse_id JOIN products pr ON pr.id = i.product_id LEFT JOIN users u ON u.id = c.approved_by ${W(w)} ORDER BY c.date, c.id, pr.name`, ...p);
      return { columns: [C('doc_no', 'رقم الجرد'), C('date', 'التاريخ', 'date'), C('warehouse', 'المخزن'), C('product', 'الصنف'), C('system_qty', 'كمية النظام', 'qty'), C('actual_qty', 'الفعلية', 'qty'), C('diff', 'الفرق', 'qty'), C('diff_value', 'قيمة الفرق', 'money'), C('reason', 'السبب'), C('approver', 'المعتمِد')],
        rows, totals: sumCols(rows, ['diff_value']) };
    },
  },
  low_stock: {
    title: 'الأصناف منخفضة المخزون', group: 'المخزون', perm: 'inventory.view', filters: ['category'],
    run(ctx, a) {
      const w = []; const p = [];
      const q = '(SELECT COALESCE(SUM(s.qty),0) FROM stock s WHERE s.product_id = p.id)';
      w.push(products.lowStockCond(ctx, 'p', q));
      if (a.category_id) { w.push('p.category_id = ?'); p.push(a.category_id); }
      const rows = ctx.db.all(`SELECT p.code, p.name, u.name AS unit, ${q} AS qty, p.min_qty, p.max_qty, CASE WHEN p.max_qty > 0 THEN p.max_qty - ${q} ELSE p.min_qty * 2 - ${q} END AS suggested, s.name AS supplier, p.last_purchase_price
        FROM products p JOIN units u ON u.id = p.unit_id LEFT JOIN suppliers s ON s.id = p.default_supplier_id ${W(w)} ORDER BY ${q} - p.min_qty`, ...p);
      return { columns: [C('code', 'الكود'), C('name', 'الصنف'), C('unit', 'الوحدة'), C('qty', 'المتاح', 'qty'), C('min_qty', 'الحد الأدنى', 'qty'), C('suggested', 'كمية مقترحة للشراء', 'qty'), C('supplier', 'المورد الافتراضي'), C('last_purchase_price', 'آخر سعر شراء', 'money')], rows };
    },
  },
  cash_movement: {
    title: 'حركة الصندوق والبنك', group: 'المالية', perm: 'cash.view', filters: ['date', 'cashacct'],
    run(ctx, a) {
      const l = finance['accounting.ledger'].fn(ctx, { account: a.account === ACC.BANK ? ACC.BANK : ACC.CASH, from: a.from, to: a.to });
      return {
        subtitle: l.account.name,
        columns: [C('date', 'التاريخ', 'date'), C('doc_no', 'المستند'), C('description', 'البيان'), C('debit', 'مقبوضات', 'money'), C('credit', 'مدفوعات', 'money'), C('balance', 'الرصيد', 'money')],
        rows: [...(a.from ? [{ date: a.from, description: 'رصيد أول المدة', balance: l.opening }] : []), ...l.rows],
        totals: { debit: l.total_debit, credit: l.total_credit, balance: l.closing },
      };
    },
  },
};

function stmtReport(s) {
  return {
    subtitle: s.party.name,
    summary: [{ label: 'رصيد أول المدة', value: s.opening, type: 'money' }, { label: 'إجمالي المدين', value: s.total_debit, type: 'money' }, { label: 'إجمالي الدائن', value: s.total_credit, type: 'money' }, { label: 'الرصيد الختامي', value: s.closing, type: 'money' }],
    columns: [C('date', 'التاريخ', 'date'), C('doc_no', 'المستند'), C('description', 'البيان'), C('debit', 'مدين', 'money'), C('credit', 'دائن', 'money'), C('balance', 'الرصيد', 'money')],
    rows: [{ date: s.from || '', description: 'رصيد أول المدة', balance: s.opening }, ...s.rows],
    totals: { debit: s.total_debit, credit: s.total_credit, balance: s.closing },
  };
}

function monthRange(offset) {
  const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - offset);
  const y = d.getFullYear(); const m = d.getMonth();
  const p = (x) => String(x).padStart(2, '0');
  const last = new Date(y, m + 1, 0).getDate();
  return { from: `${y}-${p(m + 1)}-01`, to: `${y}-${p(m + 1)}-${p(last)}`, label: `${p(m + 1)}/${String(y).slice(2)}` };
}

module.exports = {
  REPORTS,
  'reports.catalog': {
    perm: 'reports.view',
    fn(ctx) { return Object.entries(REPORTS).filter(([, r]) => ctx.can(r.perm)).map(([id, r]) => ({ id, title: r.title, group: r.group, filters: r.filters })); },
  },
  'reports.run': {
    perm: 'reports.view',
    fn(ctx, a) {
      const r = REPORTS[a.id];
      if (!r) throw new AppError('التقرير غير موجود', 'NOT_FOUND');
      ctx.require(r.perm);
      const out = r.run(ctx, a.params || {});
      return { id: a.id, title: r.title, params: a.params || {}, generated_at: new Date().toISOString(), ...out };
    },
  },

  'dashboard.get': {
    perm: 'dashboard.view',
    fn(ctx, a = {}) {
      const db = ctx.db;
      const cur = monthRange(0);
      const from = a.from || cur.from; const to = a.to || todayISO();
      const costs = ctx.can('costs.view');
      const inc = finance.incomeStatement(db, from, to);
      const purchases = Number(db.val("SELECT COALESCE(SUM(total),0) FROM purchase_invoices WHERE status='posted' AND date BETWEEN ? AND ?", from, to)) || 0;
      const expenses = Number(db.val("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE status='posted' AND date BETWEEN ? AND ?", from, to)) || 0;
      const invValue = Number(db.val('SELECT COALESCE(SUM(s.qty * p.avg_cost),0) FROM stock s JOIN products p ON p.id = s.product_id')) || 0;
      const moStages = db.all('SELECT st.stage, COUNT(*) AS n FROM manufacturing_orders mo JOIN mo_statuses st ON st.code = mo.status GROUP BY st.stage');
      const stage = (s) => (moStages.find((x) => x.stage === s) || { n: 0 }).n;
      const completedPeriod = Number(db.val("SELECT COUNT(*) FROM manufacturing_orders WHERE completed_at BETWEEN ? AND ?", from, to)) || 0;
      const lowQ = '(SELECT COALESCE(SUM(s.qty),0) FROM stock s WHERE s.product_id = p.id)';
      const low = db.all(`SELECT p.id, p.name, p.min_qty, u.name AS unit, ${lowQ} AS qty FROM products p JOIN units u ON u.id = p.unit_id WHERE ${products.lowStockCond(ctx, 'p', lowQ)} ORDER BY ${lowQ} - p.min_qty LIMIT 12`);
      const lowCount = Number(db.val(`SELECT COUNT(*) FROM products p WHERE ${products.lowStockCond(ctx, 'p', lowQ)}`)) || 0;
      const ar = ledger.balance(db, ACC.AR).balance; const ap = ledger.balance(db, ACC.AP).balance;
      const months = [];
      for (let i = 11; i >= 0; i--) {
        const m = monthRange(i);
        const x = finance.incomeStatement(db, m.from, m.to);
        months.push({
          label: m.label, sales: x.net_sales,
          purchases: Number(db.val("SELECT COALESCE(SUM(total),0) FROM purchase_invoices WHERE status='posted' AND date BETWEEN ? AND ?", m.from, m.to)) || 0,
          expenses: x.opex, net_profit: costs ? x.net_profit : null,
        });
      }
      const expByCat = db.all("SELECT c.name AS label, SUM(e.amount) AS value FROM expenses e JOIN expense_categories c ON c.id = e.category_id WHERE e.status='posted' AND e.date BETWEEN ? AND ? GROUP BY c.id ORDER BY value DESC", from, to);
      const moByStatus = db.all(`SELECT st.name AS label, st.color, COUNT(mo.id) AS value FROM mo_statuses st LEFT JOIN manufacturing_orders mo ON mo.status = st.code WHERE st.active = 1 GROUP BY st.code ORDER BY st.sort`);
      const overdue = db.all(`SELECT mo.id, mo.doc_no, mo.due_date, p.name AS product_name, c.name AS customer_name, st.name AS status_name, st.color FROM manufacturing_orders mo JOIN mo_statuses st ON st.code = mo.status JOIN products p ON p.id = mo.product_id LEFT JOIN customers c ON c.id = mo.customer_id
        WHERE st.stage IN ('open','active') AND mo.due_date IS NOT NULL AND mo.due_date <= date(?, '+3 day') ORDER BY mo.due_date LIMIT 8`, todayISO());
      const recent = db.all(`SELECT * FROM (
          SELECT 'sale' AS kind, id, doc_no, date, total AS amount, status FROM sales_invoices
          UNION ALL SELECT 'purchase', id, doc_no, date, total, status FROM purchase_invoices
          UNION ALL SELECT 'receipt', id, doc_no, date, amount, status FROM payments WHERE direction='in'
          UNION ALL SELECT 'expense', id, doc_no, date, amount, status FROM expenses) ORDER BY date DESC, id DESC LIMIT 8`);
      return {
        from, to,
        kpis: {
          sales: inc.net_sales, purchases: money(purchases), inventory_value: costs ? money(invValue) : null, expenses: money(expenses),
          gross_profit: costs ? inc.gross_profit : null, net_profit: costs ? inc.net_profit : null,
          customers: Number(db.val('SELECT COUNT(*) FROM customers WHERE active = 1')) || 0, suppliers: Number(db.val('SELECT COUNT(*) FROM suppliers WHERE active = 1')) || 0,
          mo_open: stage('open'), mo_active: stage('active'), mo_done_period: completedPeriod, ar, ap, low_stock: lowCount,
          cash: ctx.can('cash.view') ? ledger.balance(db, ACC.CASH).balance : null, bank: ctx.can('cash.view') ? ledger.balance(db, ACC.BANK).balance : null,
        },
        months, exp_by_cat: expByCat, mo_by_status: moByStatus, low_stock: low, overdue, recent,
      };
    },
  },

  'search.global': {
    fn(ctx, a) {
      const q = String(a.q || '').trim();
      if (q.length < 1) return [];
      const like = `%${q}%`; const db = ctx.db; const out = [];
      const add = (group, route, rows) => rows.forEach((r) => out.push({ group, route, ...r }));
      if (ctx.can('products.view')) add('الأصناف', 'product', db.all('SELECT id, name AS title, code || COALESCE(\' — \' || barcode, \'\') AS sub FROM products WHERE name LIKE ? OR code LIKE ? OR barcode LIKE ? LIMIT 8', like, like, like));
      if (ctx.can('customers.manage')) add('العملاء', 'customer', db.all('SELECT id, name AS title, code || \' — \' || COALESCE(phone,\'\') AS sub FROM customers WHERE name LIKE ? OR code LIKE ? OR phone LIKE ? LIMIT 6', like, like, like));
      if (ctx.can('suppliers.manage')) add('الموردون', 'supplier', db.all('SELECT id, name AS title, code || \' — \' || COALESCE(phone,\'\') AS sub FROM suppliers WHERE name LIKE ? OR code LIKE ? OR phone LIKE ? LIMIT 6', like, like, like));
      if (ctx.can('sales.view')) add('فواتير البيع', 'sale', db.all('SELECT d.id, d.doc_no AS title, d.date || \' — \' || COALESCE(c.name,\'نقدي\') AS sub FROM sales_invoices d LEFT JOIN customers c ON c.id = d.customer_id WHERE d.doc_no LIKE ? OR c.name LIKE ? ORDER BY d.id DESC LIMIT 6', like, like));
      if (ctx.can('purchases.view')) add('فواتير الشراء', 'purchase', db.all('SELECT d.id, d.doc_no AS title, d.date || \' — \' || COALESCE(s.name,\'نقدي\') AS sub FROM purchase_invoices d LEFT JOIN suppliers s ON s.id = d.supplier_id WHERE d.doc_no LIKE ? OR s.name LIKE ? OR d.supplier_ref LIKE ? ORDER BY d.id DESC LIMIT 6', like, like, like));
      if (ctx.can('manufacturing.view')) add('أوامر التصنيع', 'mo', db.all('SELECT mo.id, mo.doc_no AS title, p.name || \' — \' || st.name AS sub FROM manufacturing_orders mo JOIN products p ON p.id = mo.product_id JOIN mo_statuses st ON st.code = mo.status WHERE mo.doc_no LIKE ? OR p.name LIKE ? OR mo.specs LIKE ? ORDER BY mo.id DESC LIMIT 6', like, like, like));
      if (ctx.can('payments.manage')) add('سندات القبض والصرف', 'payment', db.all('SELECT id, doc_no AS title, date || \' — \' || amount AS sub FROM payments WHERE doc_no LIKE ? OR reference LIKE ? ORDER BY id DESC LIMIT 5', like, like));
      if (ctx.can('expenses.manage')) add('المصروفات', 'expense', db.all('SELECT id, doc_no AS title, description AS sub FROM expenses WHERE doc_no LIKE ? OR description LIKE ? ORDER BY id DESC LIMIT 5', like, like));
      if (ctx.can('reports.view')) Object.entries(REPORTS).filter(([, r]) => r.title.includes(q) && ctx.can(r.perm)).slice(0, 5).forEach(([id, r]) => out.push({ group: 'التقارير', route: 'report', id, title: r.title, sub: r.group }));
      return out;
    },
  },

  'audit.list': {
    perm: 'audit.view',
    fn(ctx, a = {}) {
      const where = []; const params = [];
      addSearch(where, params, a.q, ['a.username', 'a.action', 'a.entity', 'a.doc_no', 'a.notes']);
      if (a.from) { where.push('a.ts >= ?'); params.push(a.from); }
      if (a.to) { where.push('a.ts <= ?'); params.push(a.to + 'T23:59:59'); }
      if (a.action) { where.push('a.action = ?'); params.push(a.action); }
      return paged(ctx.db, { select: 'a.*', from: 'audit_logs a', where, params, defaultSort: 'a.id DESC', page: a.page, pageSize: a.pageSize });
    },
  },
};
