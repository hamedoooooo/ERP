'use strict';
/* Migration v2 — reference data. Generic: nothing here assumes a specific trade. */
const PERMISSIONS = [
  ['dashboard.view', 'عرض لوحة التحكم', 'عام'],
  ['products.view', 'عرض الأصناف', 'الأصناف والمخزون'],
  ['products.edit', 'إضافة وتعديل الأصناف والتصنيفات والوحدات', 'الأصناف والمخزون'],
  ['inventory.view', 'عرض المخزون وحركاته', 'الأصناف والمخزون'],
  ['inventory.adjust', 'تسويات وتحويلات وأرصدة افتتاحية للمخزون', 'الأصناف والمخزون'],
  ['stockcount.manage', 'الجرد (إنشاء واعتماد)', 'الأصناف والمخزون'],
  ['purchases.view', 'عرض المشتريات', 'المشتريات'],
  ['purchases.create', 'إنشاء فواتير ومرتجعات الشراء', 'المشتريات'],
  ['purchases.void', 'إلغاء مستندات الشراء', 'المشتريات'],
  ['suppliers.manage', 'إدارة الموردين', 'المشتريات'],
  ['sales.view', 'عرض المبيعات', 'المبيعات'],
  ['sales.create', 'إنشاء فواتير ومرتجعات البيع', 'المبيعات'],
  ['sales.void', 'إلغاء مستندات البيع', 'المبيعات'],
  ['customers.manage', 'إدارة العملاء', 'المبيعات'],
  ['manufacturing.view', 'عرض أوامر التصنيع', 'التصنيع'],
  ['manufacturing.manage', 'إدارة أوامر التصنيع وقوائم المواد والعمالة', 'التصنيع'],
  ['costs.view', 'رؤية التكاليف والأرباح', 'التصنيع'],
  ['expenses.manage', 'تسجيل المصروفات', 'المالية'],
  ['payments.manage', 'التحصيل والسداد', 'المالية'],
  ['cash.view', 'عرض الصندوق والبنك', 'المالية'],
  ['cash.manage', 'حركات الصندوق (إيداع/سحب/رأس مال)', 'المالية'],
  ['accounting.view', 'القيود ودفتر الأستاذ والقوائم المالية', 'المالية'],
  ['accounting.manage', 'إدارة دليل الحسابات والأرصدة الافتتاحية', 'المالية'],
  ['reports.view', 'عرض التقارير', 'التقارير'],
  ['users.manage', 'إدارة المستخدمين والأدوار', 'النظام'],
  ['settings.manage', 'تعديل الإعدادات', 'النظام'],
  ['backup.create', 'إنشاء نسخة احتياطية', 'النظام'],
  ['backup.restore', 'استعادة نسخة احتياطية', 'النظام'],
  ['audit.view', 'عرض سجل التدقيق', 'النظام'],
  ['data.delete', 'حذف البيانات الأساسية غير المستخدمة', 'النظام'],
];

const MANAGER_DENY = new Set(['users.manage', 'backup.restore', 'data.delete']);
const EMPLOYEE_ALLOW = new Set([
  'dashboard.view', 'products.view', 'inventory.view', 'purchases.view', 'purchases.create', 'sales.view', 'sales.create',
  'customers.manage', 'suppliers.manage', 'manufacturing.view', 'manufacturing.manage', 'expenses.manage', 'payments.manage',
  'stockcount.manage', 'backup.create',
]);

// Chart of accounts: the original 18 accounts kept with identical codes, plus the ones manufacturing needs.
const COA = [
  ['1100', 'الصندوق', 'asset', 'debit'],
  ['1200', 'البنك', 'asset', 'debit'],
  ['1300', 'عملاء (مدينون)', 'asset', 'debit'],
  ['1400', 'المخزون', 'asset', 'debit'],
  ['1450', 'إنتاج تحت التشغيل', 'asset', 'debit'],
  ['1500', 'أصول ثابتة', 'asset', 'debit'],
  ['1600', 'ضريبة مشتريات قابلة للخصم', 'asset', 'debit'],
  ['2100', 'موردون (دائنون)', 'liability', 'credit'],
  ['2200', 'مصروفات مستحقة', 'liability', 'credit'],
  ['2300', 'ضريبة مبيعات مستحقة', 'liability', 'credit'],
  ['2400', 'أجور مستحقة', 'liability', 'credit'],
  ['3100', 'رأس المال', 'equity', 'credit'],
  ['3200', 'أرباح مرحّلة', 'equity', 'credit'],
  ['3300', 'أرصدة افتتاحية', 'equity', 'credit'],
  ['3400', 'مسحوبات شخصية', 'equity', 'debit'],
  ['4100', 'المبيعات', 'revenue', 'credit'],
  ['4200', 'مردودات ومسموحات المبيعات', 'revenue', 'debit'],
  ['4300', 'إيرادات أخرى', 'revenue', 'credit'],
  ['5100', 'تكلفة البضاعة المباعة', 'cogs', 'debit'],
  ['5200', 'فروقات وتسويات المخزون', 'cogs', 'debit'],
  ['5300', 'خسائر أوامر تصنيع ملغاة', 'cogs', 'debit'],
  ['5400', 'مصروفات صناعية محمّلة على الإنتاج', 'cogs', 'debit'],
  ['6100', 'إيجار', 'expense', 'debit'],
  ['6200', 'أجور ورواتب', 'expense', 'debit'],
  ['6300', 'كهرباء ومياه', 'expense', 'debit'],
  ['6400', 'مصروفات أخرى', 'expense', 'debit'],
  ['6500', 'نقل ومواصلات', 'expense', 'debit'],
  ['6600', 'صيانة', 'expense', 'debit'],
  ['6700', 'مصروفات إدارية', 'expense', 'debit'],
];

const EXPENSE_CATS = [
  ['أجور ورواتب', '6200'], ['إيجار', '6100'], ['كهرباء ومياه', '6300'], ['نقل ومواصلات', '6500'],
  ['صيانة', '6600'], ['مصروفات إدارية', '6700'], ['مصروفات أخرى', '6400'],
];

const UNITS = [
  ['قطعة', 'قطعة', 0], ['متر', 'م', 1], ['متر مربع', 'م²', 1], ['متر مكعب', 'م³', 1], ['كيلو', 'كجم', 1],
  ['جرام', 'جم', 1], ['لتر', 'لتر', 1], ['ساعة', 'ساعة', 1], ['يوم', 'يوم', 1], ['وحدة', 'وحدة', 1],
];

const MO_STATUSES = [
  ['new', 'جديد', '#6b6455', 'open', 1], ['planned', 'مخطط', '#3d5a80', 'open', 2],
  ['in_progress', 'جاري التصنيع', '#A8823C', 'active', 3], ['on_hold', 'متوقف', '#8B3A3A', 'active', 4],
  ['completed', 'مكتمل', '#1F4B3F', 'done', 5], ['ready', 'جاهز للتسليم', '#2e7d5b', 'done', 6],
  ['cancelled', 'ملغي', '#8a8368', 'cancelled', 7],
];

const SEQUENCES = [
  ['purchase', 'PI-'], ['purchase_return', 'PR-'], ['sale', 'SI-'], ['sale_return', 'SR-'], ['mo', 'MO-'],
  ['mo_issue', 'MI-'], ['expense', 'EX-'], ['receipt', 'RC-'], ['payment', 'PY-'], ['stock_count', 'SC-'],
  ['adjustment', 'AD-'], ['transfer', 'TR-'], ['opening', 'OB-'], ['cash_move', 'CM-'], ['labor', 'LB-'], ['mo_cost', 'DC-'],
  ['product', 'P'], ['customer', 'C'], ['supplier', 'S'], ['worker', 'W'], ['warehouse', 'WH'],
];

module.exports = {
  version: 2,
  name: 'reference data',
  PERMISSIONS,
  COA,
  up(db) {
    const now = new Date().toISOString();
    PERMISSIONS.forEach(([code, name, group], i) => db.run('INSERT OR IGNORE INTO permissions(code,name,group_name,sort) VALUES (?,?,?,?)', code, name, group, i));
    const roles = [['مدير النظام', 'كل الصلاحيات', () => true], ['مدير', 'كل العمليات عدا المستخدمين والاستعادة والحذف', (c) => !MANAGER_DENY.has(c)], ['موظف', 'العمليات اليومية', (c) => EMPLOYEE_ALLOW.has(c)]];
    roles.forEach(([name, desc, allow]) => {
      const id = db.insert('roles', { name, description: desc, is_system: 1, created_at: now });
      PERMISSIONS.forEach(([code]) => { if (allow(code)) db.run('INSERT INTO role_permissions(role_id, perm_code) VALUES (?,?)', id, code); });
    });
    COA.forEach(([code, name, type, nature]) => db.run('INSERT INTO accounts(code,name,type,nature,is_system,created_at) VALUES (?,?,?,?,1,?)', code, name, type, nature, now));
    EXPENSE_CATS.forEach(([name, acct]) => db.run('INSERT INTO expense_categories(name, account_code, created_at) VALUES (?,?,?)', name, acct, now));
    UNITS.forEach(([name, sym, frac]) => db.run('INSERT INTO units(name,symbol,allow_fraction,created_at) VALUES (?,?,?,?)', name, sym, frac, now));
    db.run("INSERT INTO warehouses(code,name,is_default,created_at) VALUES ('WH1','المخزن الرئيسي',1,?)", now);
    MO_STATUSES.forEach(([code, name, color, stage, sort]) => db.run('INSERT INTO mo_statuses(code,name,color,stage,sort,is_system) VALUES (?,?,?,?,?,1)', code, name, color, stage, sort));
    SEQUENCES.forEach(([t, p]) => db.run('INSERT INTO doc_sequences(doc_type,prefix,next_no,pad) VALUES (?,?,1,?)', t, p, p.endsWith('-') ? 5 : 4));
  },
};
