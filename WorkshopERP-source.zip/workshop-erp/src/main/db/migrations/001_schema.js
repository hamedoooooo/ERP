'use strict';
/* Migration v1 — core relational schema. Never edit after release; add a new migration instead. */
module.exports = {
  version: 1,
  name: 'initial schema',
  up(db) {
    db.exec(`
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT);

-- ============ Security ============
CREATE TABLE roles (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, description TEXT DEFAULT '',
  is_system INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
);
CREATE TABLE permissions (code TEXT PRIMARY KEY, name TEXT NOT NULL, group_name TEXT NOT NULL, sort INTEGER DEFAULT 0);
CREATE TABLE role_permissions (
  role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  perm_code TEXT NOT NULL REFERENCES permissions(code) ON DELETE CASCADE,
  PRIMARY KEY (role_id, perm_code)
);
CREATE TABLE users (
  id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, full_name TEXT NOT NULL,
  password_hash TEXT NOT NULL, password_salt TEXT NOT NULL,
  role_id INTEGER NOT NULL REFERENCES roles(id), active INTEGER NOT NULL DEFAULT 1,
  failed_attempts INTEGER NOT NULL DEFAULT 0, locked_until TEXT,
  last_login_at TEXT, created_at TEXT NOT NULL, updated_at TEXT
);

-- ============ Master data ============
CREATE TABLE categories (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, parent_id INTEGER REFERENCES categories(id),
  notes TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE TABLE units (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, symbol TEXT DEFAULT '', allow_fraction INTEGER NOT NULL DEFAULT 1,
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE TABLE warehouses (
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL UNIQUE, notes TEXT DEFAULT '',
  is_default INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE TABLE suppliers (
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, phone TEXT DEFAULT '', email TEXT DEFAULT '',
  address TEXT DEFAULT '', contact_person TEXT DEFAULT '', tax_no TEXT DEFAULT '', notes TEXT DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT
);
CREATE TABLE customers (
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, phone TEXT DEFAULT '', email TEXT DEFAULT '',
  address TEXT DEFAULT '', contact_person TEXT DEFAULT '', tax_no TEXT DEFAULT '', credit_limit REAL NOT NULL DEFAULT 0,
  notes TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT
);
CREATE TABLE products (
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, barcode TEXT, name TEXT NOT NULL,
  category_id INTEGER REFERENCES categories(id), unit_id INTEGER NOT NULL REFERENCES units(id),
  kind TEXT NOT NULL CHECK (kind IN ('raw','accessory','part','supply','finished','service','other')),
  is_stocked INTEGER NOT NULL DEFAULT 1,
  purchase_price REAL NOT NULL DEFAULT 0, sale_price REAL NOT NULL DEFAULT 0, wholesale_price REAL NOT NULL DEFAULT 0,
  avg_cost REAL NOT NULL DEFAULT 0, last_purchase_price REAL NOT NULL DEFAULT 0, last_purchase_date TEXT,
  min_qty REAL NOT NULL DEFAULT 0, max_qty REAL NOT NULL DEFAULT 0,
  default_supplier_id INTEGER REFERENCES suppliers(id), tax_rate REAL,
  costing_method TEXT NOT NULL DEFAULT 'wac', pricing_margin REAL,
  image TEXT, description TEXT DEFAULT '', notes TEXT DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT
);
CREATE UNIQUE INDEX ux_products_barcode ON products(barcode) WHERE barcode IS NOT NULL AND barcode <> '';
CREATE INDEX ix_products_name ON products(name);
CREATE INDEX ix_products_cat ON products(category_id);

CREATE TABLE stock (
  product_id INTEGER NOT NULL REFERENCES products(id),
  warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
  qty REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (product_id, warehouse_id)
);

-- ============ Accounting (double entry, kept from the original system) ============
CREATE TABLE accounts (
  code TEXT PRIMARY KEY, name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('asset','liability','equity','revenue','cogs','expense')),
  nature TEXT NOT NULL CHECK (nature IN ('debit','credit')),
  is_system INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE TABLE journal_entries (
  id INTEGER PRIMARY KEY, date TEXT NOT NULL, doc_type TEXT NOT NULL, doc_id INTEGER, doc_no TEXT,
  description TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, voided_at TEXT, voided_by INTEGER REFERENCES users(id)
);
CREATE INDEX ix_je_doc ON journal_entries(doc_type, doc_id);
CREATE INDEX ix_je_date ON journal_entries(date);
CREATE TABLE journal_lines (
  id INTEGER PRIMARY KEY, entry_id INTEGER NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE,
  account_code TEXT NOT NULL REFERENCES accounts(code),
  debit REAL NOT NULL DEFAULT 0 CHECK (debit >= 0), credit REAL NOT NULL DEFAULT 0 CHECK (credit >= 0),
  party_type TEXT CHECK (party_type IN ('customer','supplier') OR party_type IS NULL), party_id INTEGER,
  memo TEXT DEFAULT ''
);
CREATE INDEX ix_jl_entry ON journal_lines(entry_id);
CREATE INDEX ix_jl_acct ON journal_lines(account_code);
CREATE INDEX ix_jl_party ON journal_lines(party_type, party_id);

CREATE TABLE doc_sequences (doc_type TEXT PRIMARY KEY, prefix TEXT NOT NULL, next_no INTEGER NOT NULL DEFAULT 1, pad INTEGER NOT NULL DEFAULT 5);

-- ============ Inventory ledger ============
CREATE TABLE inventory_transactions (
  id INTEGER PRIMARY KEY, date TEXT NOT NULL,
  product_id INTEGER NOT NULL REFERENCES products(id), warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
  type TEXT NOT NULL, qty_in REAL NOT NULL DEFAULT 0, qty_out REAL NOT NULL DEFAULT 0,
  unit_cost REAL NOT NULL DEFAULT 0, total_cost REAL NOT NULL DEFAULT 0,
  wh_balance_after REAL NOT NULL DEFAULT 0, total_balance_after REAL NOT NULL DEFAULT 0, avg_cost_after REAL NOT NULL DEFAULT 0,
  doc_type TEXT NOT NULL, doc_id INTEGER, doc_no TEXT, user_id INTEGER REFERENCES users(id),
  notes TEXT DEFAULT '', created_at TEXT NOT NULL
);
CREATE INDEX ix_it_product ON inventory_transactions(product_id, id);
CREATE INDEX ix_it_doc ON inventory_transactions(doc_type, doc_id);
CREATE INDEX ix_it_date ON inventory_transactions(date);

-- ============ Purchasing ============
CREATE TABLE purchase_invoices (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL, supplier_id INTEGER REFERENCES suppliers(id),
  warehouse_id INTEGER NOT NULL REFERENCES warehouses(id), supplier_ref TEXT DEFAULT '',
  subtotal REAL NOT NULL, discount REAL NOT NULL DEFAULT 0, tax_rate REAL NOT NULL DEFAULT 0, tax REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL, paid REAL NOT NULL DEFAULT 0, pay_method TEXT NOT NULL DEFAULT 'cash' CHECK (pay_method IN ('cash','bank')),
  notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, voided_at TEXT, void_reason TEXT
);
CREATE TABLE purchase_items (
  id INTEGER PRIMARY KEY, invoice_id INTEGER NOT NULL REFERENCES purchase_invoices(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id), qty REAL NOT NULL CHECK (qty > 0), unit_price REAL NOT NULL CHECK (unit_price >= 0),
  line_total REAL NOT NULL, unit_cost REAL NOT NULL, notes TEXT DEFAULT ''
);
CREATE INDEX ix_pi_items ON purchase_items(invoice_id);
CREATE TABLE purchase_returns (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL, supplier_id INTEGER REFERENCES suppliers(id),
  invoice_id INTEGER REFERENCES purchase_invoices(id), warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
  subtotal REAL NOT NULL, tax_rate REAL NOT NULL DEFAULT 0, tax REAL NOT NULL DEFAULT 0, total REAL NOT NULL, cost_total REAL NOT NULL DEFAULT 0,
  settle TEXT NOT NULL DEFAULT 'account' CHECK (settle IN ('account','cash','bank')),
  notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, voided_at TEXT, void_reason TEXT
);
CREATE TABLE purchase_return_items (
  id INTEGER PRIMARY KEY, return_id INTEGER NOT NULL REFERENCES purchase_returns(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id), qty REAL NOT NULL CHECK (qty > 0), unit_price REAL NOT NULL,
  line_total REAL NOT NULL, unit_cost REAL NOT NULL, cost_total REAL NOT NULL
);

-- ============ Manufacturing ============
CREATE TABLE workers (
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, phone TEXT DEFAULT '', job TEXT DEFAULT '',
  rate_type TEXT NOT NULL DEFAULT 'day' CHECK (rate_type IN ('hour','day','piece','fixed','manual')),
  rate REAL NOT NULL DEFAULT 0, notes TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE TABLE boms (
  id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id), name TEXT NOT NULL,
  output_qty REAL NOT NULL DEFAULT 1 CHECK (output_qty > 0), is_default INTEGER NOT NULL DEFAULT 0,
  notes TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT
);
CREATE TABLE bom_items (
  id INTEGER PRIMARY KEY, bom_id INTEGER NOT NULL REFERENCES boms(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id), qty REAL NOT NULL CHECK (qty > 0),
  waste_pct REAL NOT NULL DEFAULT 0, notes TEXT DEFAULT ''
);
CREATE TABLE mo_statuses (
  code TEXT PRIMARY KEY, name TEXT NOT NULL, color TEXT NOT NULL DEFAULT '#6b6455',
  stage TEXT NOT NULL CHECK (stage IN ('open','active','done','cancelled')),
  sort INTEGER NOT NULL DEFAULT 0, is_system INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE manufacturing_orders (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL,
  customer_id INTEGER REFERENCES customers(id), product_id INTEGER NOT NULL REFERENCES products(id),
  bom_id INTEGER REFERENCES boms(id), qty REAL NOT NULL CHECK (qty > 0),
  warehouse_id INTEGER NOT NULL REFERENCES warehouses(id), output_warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
  specs TEXT DEFAULT '', dimensions TEXT DEFAULT '', notes TEXT DEFAULT '',
  start_date TEXT, due_date TEXT, status TEXT NOT NULL REFERENCES mo_statuses(code),
  agreed_price REAL NOT NULL DEFAULT 0,
  overhead_type TEXT NOT NULL DEFAULT 'none' CHECK (overhead_type IN ('none','percent','amount')), overhead_value REAL NOT NULL DEFAULT 0,
  produced_qty REAL NOT NULL DEFAULT 0, completed_at TEXT,
  material_cost REAL NOT NULL DEFAULT 0, accessories_cost REAL NOT NULL DEFAULT 0, labor_cost REAL NOT NULL DEFAULT 0,
  other_cost REAL NOT NULL DEFAULT 0, overhead_cost REAL NOT NULL DEFAULT 0, total_cost REAL NOT NULL DEFAULT 0, unit_cost REAL NOT NULL DEFAULT 0,
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, updated_at TEXT
);
CREATE INDEX ix_mo_status ON manufacturing_orders(status);
CREATE TABLE mo_materials (
  id INTEGER PRIMARY KEY, mo_id INTEGER NOT NULL REFERENCES manufacturing_orders(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id), planned_qty REAL NOT NULL DEFAULT 0,
  notes TEXT DEFAULT '', UNIQUE (mo_id, product_id)
);
CREATE TABLE mo_material_moves (
  id INTEGER PRIMARY KEY, mo_id INTEGER NOT NULL REFERENCES manufacturing_orders(id),
  product_id INTEGER NOT NULL REFERENCES products(id), warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
  date TEXT NOT NULL, qty REAL NOT NULL, unit_cost REAL NOT NULL, total_cost REAL NOT NULL,
  doc_no TEXT, notes TEXT DEFAULT '', created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE INDEX ix_mom_mo ON mo_material_moves(mo_id);
CREATE TABLE mo_labor (
  id INTEGER PRIMARY KEY, mo_id INTEGER NOT NULL REFERENCES manufacturing_orders(id),
  worker_id INTEGER REFERENCES workers(id), worker_name TEXT NOT NULL, date TEXT NOT NULL,
  rate_type TEXT NOT NULL CHECK (rate_type IN ('hour','day','piece','fixed','manual')),
  qty REAL NOT NULL DEFAULT 1, rate REAL NOT NULL DEFAULT 0, total REAL NOT NULL,
  pay_method TEXT NOT NULL DEFAULT 'accrued' CHECK (pay_method IN ('cash','bank','accrued')),
  notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE TABLE mo_other_costs (
  id INTEGER PRIMARY KEY, mo_id INTEGER NOT NULL REFERENCES manufacturing_orders(id),
  date TEXT NOT NULL, description TEXT NOT NULL, amount REAL NOT NULL CHECK (amount > 0),
  pay_method TEXT NOT NULL DEFAULT 'cash' CHECK (pay_method IN ('cash','bank','accrued')),
  notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
);

-- ============ Sales ============
CREATE TABLE sales_invoices (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL, customer_id INTEGER REFERENCES customers(id),
  warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
  subtotal REAL NOT NULL, discount REAL NOT NULL DEFAULT 0, tax_rate REAL NOT NULL DEFAULT 0, tax REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL, paid REAL NOT NULL DEFAULT 0, pay_method TEXT NOT NULL DEFAULT 'cash' CHECK (pay_method IN ('cash','bank')),
  cost_total REAL NOT NULL DEFAULT 0,
  notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, voided_at TEXT, void_reason TEXT
);
CREATE TABLE sales_items (
  id INTEGER PRIMARY KEY, invoice_id INTEGER NOT NULL REFERENCES sales_invoices(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id), mo_id INTEGER REFERENCES manufacturing_orders(id),
  qty REAL NOT NULL CHECK (qty > 0), unit_price REAL NOT NULL CHECK (unit_price >= 0), line_total REAL NOT NULL,
  net_total REAL NOT NULL, unit_cost REAL NOT NULL DEFAULT 0, cost_total REAL NOT NULL DEFAULT 0, notes TEXT DEFAULT ''
);
CREATE INDEX ix_si_items ON sales_items(invoice_id);
CREATE INDEX ix_si_mo ON sales_items(mo_id);
CREATE TABLE sales_returns (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL, customer_id INTEGER REFERENCES customers(id),
  invoice_id INTEGER REFERENCES sales_invoices(id), warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
  subtotal REAL NOT NULL, tax_rate REAL NOT NULL DEFAULT 0, tax REAL NOT NULL DEFAULT 0, total REAL NOT NULL, cost_total REAL NOT NULL DEFAULT 0,
  settle TEXT NOT NULL DEFAULT 'account' CHECK (settle IN ('account','cash','bank')),
  notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, voided_at TEXT, void_reason TEXT
);
CREATE TABLE sales_return_items (
  id INTEGER PRIMARY KEY, return_id INTEGER NOT NULL REFERENCES sales_returns(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id), sales_item_id INTEGER REFERENCES sales_items(id),
  qty REAL NOT NULL CHECK (qty > 0), unit_price REAL NOT NULL, line_total REAL NOT NULL,
  unit_cost REAL NOT NULL, cost_total REAL NOT NULL
);

-- ============ Money ============
CREATE TABLE payments (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('in','out')),
  party_type TEXT NOT NULL CHECK (party_type IN ('customer','supplier')), party_id INTEGER NOT NULL,
  amount REAL NOT NULL CHECK (amount > 0), method TEXT NOT NULL CHECK (method IN ('cash','bank')),
  reference TEXT DEFAULT '', notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, voided_at TEXT, void_reason TEXT
);
CREATE TABLE expense_categories (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, account_code TEXT NOT NULL REFERENCES accounts(code),
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE TABLE expenses (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL,
  category_id INTEGER NOT NULL REFERENCES expense_categories(id), amount REAL NOT NULL CHECK (amount > 0),
  method TEXT NOT NULL CHECK (method IN ('cash','bank','credit')), description TEXT NOT NULL, payee TEXT DEFAULT '',
  notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, voided_at TEXT, void_reason TEXT
);
CREATE TABLE cash_moves (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('deposit','withdraw','capital_in','owner_draw','pay_wages','pay_accrued','other_in','other_out')),
  amount REAL NOT NULL CHECK (amount > 0), method TEXT NOT NULL DEFAULT 'cash' CHECK (method IN ('cash','bank')),
  description TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, voided_at TEXT, void_reason TEXT
);
CREATE TABLE opening_balances (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('customer','supplier','cash','bank')), party_id INTEGER,
  amount REAL NOT NULL, notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, voided_at TEXT
);

-- ============ Stock control ============
CREATE TABLE stock_counts (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL, warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','approved','cancelled')), notes TEXT DEFAULT '',
  adjustment_id INTEGER, created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL,
  approved_by INTEGER REFERENCES users(id), approved_at TEXT
);
CREATE TABLE stock_count_items (
  id INTEGER PRIMARY KEY, count_id INTEGER NOT NULL REFERENCES stock_counts(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id), system_qty REAL NOT NULL DEFAULT 0, actual_qty REAL,
  unit_cost REAL NOT NULL DEFAULT 0, reason TEXT DEFAULT '', UNIQUE(count_id, product_id)
);
CREATE TABLE inventory_adjustments (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL, warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
  source TEXT NOT NULL CHECK (source IN ('manual','count','opening')), count_id INTEGER REFERENCES stock_counts(id),
  reason TEXT DEFAULT '', total_value REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, voided_at TEXT, void_reason TEXT
);
CREATE TABLE inventory_adjustment_items (
  id INTEGER PRIMARY KEY, adjustment_id INTEGER NOT NULL REFERENCES inventory_adjustments(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id), qty_diff REAL NOT NULL, unit_cost REAL NOT NULL, value REAL NOT NULL, reason TEXT DEFAULT ''
);
CREATE TABLE stock_transfers (
  id INTEGER PRIMARY KEY, doc_no TEXT NOT NULL UNIQUE, date TEXT NOT NULL,
  from_warehouse_id INTEGER NOT NULL REFERENCES warehouses(id), to_warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
  notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted','void')),
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, voided_at TEXT,
  CHECK (from_warehouse_id <> to_warehouse_id)
);
CREATE TABLE stock_transfer_items (
  id INTEGER PRIMARY KEY, transfer_id INTEGER NOT NULL REFERENCES stock_transfers(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id), qty REAL NOT NULL CHECK (qty > 0)
);

-- ============ System ============
CREATE TABLE audit_logs (
  id INTEGER PRIMARY KEY, ts TEXT NOT NULL, user_id INTEGER, username TEXT, action TEXT NOT NULL,
  entity TEXT, entity_id TEXT, doc_no TEXT, old_data TEXT, new_data TEXT, notes TEXT DEFAULT ''
);
CREATE INDEX ix_audit_ts ON audit_logs(ts);
CREATE TABLE backup_metadata (
  id INTEGER PRIMARY KEY, created_at TEXT NOT NULL, file_name TEXT NOT NULL, file_path TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('manual','auto','pre-restore','pre-import','pre-migration')),
  size_bytes INTEGER, encrypted INTEGER NOT NULL DEFAULT 0, app_version TEXT, schema_version INTEGER, sha256 TEXT,
  created_by INTEGER, notes TEXT DEFAULT ''
);
CREATE TABLE legacy_archive (id INTEGER PRIMARY KEY, imported_at TEXT NOT NULL, source TEXT NOT NULL, payload TEXT NOT NULL);
`);
  },
};
