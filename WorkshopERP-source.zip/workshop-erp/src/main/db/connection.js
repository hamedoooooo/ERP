'use strict';
/**
 * Thin adapter over SQLite.
 *  - Production (Electron): better-sqlite3 (native, rebuilt for Electron by electron-builder).
 *  - Fallback / tests: Node's built-in node:sqlite (Node >= 22.13).
 * Both expose the same synchronous API through this wrapper, so services never
 * care which driver is running. Only positional "?" parameters are used.
 */
const fs = require('fs');
const path = require('path');

function loadDriver(preferred) {
  const order = preferred === 'node' ? ['node', 'better'] : ['better', 'node'];
  const errors = [];
  for (const d of order) {
    try {
      if (d === 'better') {
        const Better = require('better-sqlite3');
        return { name: 'better-sqlite3', open: (f, ro) => new Better(f, { readonly: !!ro, fileMustExist: !!ro }) };
      }
      // eslint-disable-next-line global-require
      const { DatabaseSync } = require('node:sqlite');
      return { name: 'node:sqlite', open: (f, ro) => new DatabaseSync(f, ro ? { readOnly: true } : {}) };
    } catch (e) { errors.push(`${d}: ${e.message}`); }
  }
  throw new Error('No SQLite driver available: ' + errors.join(' | '));
}

function normParams(params) {
  return params.map((p) => {
    if (p === undefined) return null;
    if (typeof p === 'boolean') return p ? 1 : 0;
    if (p !== null && typeof p === 'object' && !(p instanceof Uint8Array)) return JSON.stringify(p);
    return p;
  });
}

class Database {
  constructor(file, { readonly = false, driver = process.env.WERP_SQLITE_DRIVER } = {}) {
    this.file = file;
    if (!readonly) fs.mkdirSync(path.dirname(file), { recursive: true });
    this.driver = loadDriver(driver);
    this.raw = this.driver.open(file, readonly);
    this.cache = new Map();
    this.depth = 0;
    this.readonly = readonly;
    if (!readonly) {
      this.exec('PRAGMA journal_mode = WAL');
      this.exec('PRAGMA synchronous = FULL'); // survive power cuts at the cost of a little speed
    }
    this.exec('PRAGMA foreign_keys = ON');
    this.exec('PRAGMA busy_timeout = 5000');
  }

  stmt(sql) {
    let s = this.cache.get(sql);
    if (!s) {
      s = this.raw.prepare(sql);
      if (this.cache.size > 400) this.cache.clear();
      this.cache.set(sql, s);
    }
    return s;
  }

  exec(sql) { this.raw.exec(sql); }

  run(sql, ...params) {
    const r = this.stmt(sql).run(...normParams(params));
    return { changes: Number(r.changes), lastInsertRowid: Number(r.lastInsertRowid) };
  }

  get(sql, ...params) { return this.stmt(sql).get(...normParams(params)) || null; }

  all(sql, ...params) { return this.stmt(sql).all(...normParams(params)); }

  /** Scalar helper: first column of first row. */
  val(sql, ...params) {
    const r = this.get(sql, ...params);
    if (!r) return null;
    return r[Object.keys(r)[0]];
  }

  insert(table, obj) {
    const keys = Object.keys(obj);
    const sql = `INSERT INTO ${table} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`;
    return this.run(sql, ...keys.map((k) => obj[k])).lastInsertRowid;
  }

  update(table, id, obj, idCol = 'id') {
    const keys = Object.keys(obj);
    if (!keys.length) return 0;
    const sql = `UPDATE ${table} SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE ${idCol} = ?`;
    return this.run(sql, ...keys.map((k) => obj[k]), id).changes;
  }

  /** Atomic unit of work. Nested calls become savepoints. Any throw rolls back. */
  tx(fn) {
    const sp = `sp_${this.depth}`;
    if (this.depth === 0) this.exec('BEGIN IMMEDIATE'); else this.exec(`SAVEPOINT ${sp}`);
    this.depth++;
    try {
      const out = fn();
      this.depth--;
      if (this.depth === 0) this.exec('COMMIT'); else this.exec(`RELEASE ${sp}`);
      return out;
    } catch (e) {
      this.depth--;
      try {
        if (this.depth === 0) this.exec('ROLLBACK'); else { this.exec(`ROLLBACK TO ${sp}`); this.exec(`RELEASE ${sp}`); }
      } catch (_) { /* ignore secondary failure */ }
      throw e;
    }
  }

  /** Consistent single-file snapshot (works while the app is running). */
  snapshotTo(target) {
    if (fs.existsSync(target)) fs.unlinkSync(target);
    this.run('VACUUM INTO ?', target);
  }

  checkpoint() { try { this.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (_) { /* ignore */ } }

  close() {
    try { if (!this.readonly) this.checkpoint(); } catch (_) { /* ignore */ }
    this.cache.clear();
    try { this.raw.close(); } catch (_) { /* ignore */ }
  }
}

module.exports = { Database };
