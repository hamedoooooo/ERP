'use strict';
/**
 * Versioned migration system: v1 -> v2 -> v3 ...
 * Each migration runs in its own transaction and is recorded in schema_migrations.
 * To change the schema in a future release: add src/main/db/migrations/00N_name.js
 * exporting { version: N, name, up(db) } and append it to MIGRATIONS below.
 */
const MIGRATIONS = [
  require('./migrations/001_schema'),
  require('./migrations/002_seed'),
];

const LATEST = MIGRATIONS[MIGRATIONS.length - 1].version;

function currentVersion(db) {
  db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, name TEXT, applied_at TEXT NOT NULL)');
  return Number(db.val('SELECT COALESCE(MAX(version),0) AS v FROM schema_migrations')) || 0;
}

function pending(db) {
  const v = currentVersion(db);
  return MIGRATIONS.filter((m) => m.version > v);
}

/**
 * @param {Database} db
 * @param {{beforeMigrate?: (fromVersion:number, list:object[]) => void}} opts
 */
function migrate(db, opts = {}) {
  const from = currentVersion(db);
  if (from > LATEST) {
    const e = new Error(`قاعدة البيانات من إصدار أحدث (${from}) من هذا البرنامج (${LATEST}). من فضلك ثبّت الإصدار الأحدث من البرنامج.`);
    e.userFacing = true;
    throw e;
  }
  const list = pending(db);
  if (!list.length) return { from, to: from, applied: [] };
  if (from > 0 && opts.beforeMigrate) opts.beforeMigrate(from, list);
  const applied = [];
  for (const m of list) {
    db.tx(() => {
      m.up(db);
      db.run('INSERT INTO schema_migrations(version,name,applied_at) VALUES (?,?,?)', m.version, m.name, new Date().toISOString());
      db.run("INSERT INTO meta(key,value) VALUES ('schema_version',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", String(m.version));
    });
    applied.push(m.version);
  }
  return { from, to: LATEST, applied };
}

module.exports = { migrate, currentVersion, pending, LATEST, MIGRATIONS };
