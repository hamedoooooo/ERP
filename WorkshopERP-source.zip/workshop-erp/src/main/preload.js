'use strict';
// The only bridge between the web page and the operating system. Everything goes
// through named IPC channels; the page never gets Node.js or file-system access.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('erp', {
  invoke: (method, args) => ipcRenderer.invoke('erp:invoke', method, args),
  saveText: (o) => ipcRenderer.invoke('erp:saveText', o),
  openFile: (o) => ipcRenderer.invoke('erp:openFile', o),
  chooseFolder: (o) => ipcRenderer.invoke('erp:chooseFolder', o),
  saveFile: (o) => ipcRenderer.invoke('erp:saveFile', o),
  showInFolder: (p) => ipcRenderer.invoke('erp:showInFolder', p),
  print: () => ipcRenderer.invoke('erp:print'),
  printToPDF: (o) => ipcRenderer.invoke('erp:printToPDF', o),
  setTitle: (t) => ipcRenderer.invoke('erp:setTitle', t),
  onAppEvent: (fn) => { ipcRenderer.on('erp:event', (_e, ev) => fn(ev)); },
});
