'use strict';
/**
 * Electron main process.
 *  - Serves the renderer from a private app:// protocol (no web server, no internet).
 *  - Blocks every http/https/ws request: the program is 100% offline by design.
 *  - Owns the single SQLite database through App (src/main/core/app.js).
 *  - Exposes a narrow IPC surface to the renderer via preload.js.
 */
const { app, BrowserWindow, ipcMain, dialog, protocol, session, shell, Menu } = require('electron');
const fs = require('fs');
const path = require('path');
const { App } = require('./core/app');

const DEV = process.argv.includes('--dev');
const RENDERER = path.join(__dirname, '..', 'renderer');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.woff2': 'font/woff2', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };

protocol.registerSchemesAsPrivileged([{ scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, codeCache: true } }]);

// ------------------------------------------------------------------ data location
// Default: %APPDATA%\Workshop ERP\data  (survives updates and uninstall).
// Override with the WERP_DATA_DIR environment variable (e.g. for a portable setup).
const dataDir = process.env.WERP_DATA_DIR ? path.resolve(process.env.WERP_DATA_DIR) : path.join(app.getPath('userData'), 'data');
const logDir = path.join(dataDir, 'logs');
fs.mkdirSync(logDir, { recursive: true });
function writeLog(level, args) {
  const line = `[${new Date().toISOString()}] ${level.toUpperCase()} ${args.map((a) => (a instanceof Error ? a.stack : typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ')}\n`;
  try { fs.appendFileSync(path.join(logDir, 'app.log'), line); } catch (_) { /* ignore */ }
  if (DEV) process.stdout.write(line);
}
const logger = { log: (...a) => writeLog('info', a), info: (...a) => writeLog('info', a), warn: (...a) => writeLog('warn', a), error: (...a) => writeLog('error', a) };

let core = null;
let win = null;
let quitting = false;

if (!app.requestSingleInstanceLock()) {
  // Two instances writing the same database is never allowed.
  app.quit();
} else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(start);
}

function openCore() {
  core = new App({ dataDir, appVersion: app.getVersion(), logger, platform: process.platform });
  core.open();
  logger.info('Database opened', core.dbPath, 'driver', core.db.driver.name);
}

function start() {
  Menu.setApplicationMenu(null);
  // ---- offline guarantee: refuse every network request and permission
  const ses = session.defaultSession;
  ses.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*', 'ws://*/*', 'wss://*/*', 'ftp://*/*'] }, (details, cb) => { logger.warn('Blocked network request', details.url); cb({ cancel: true }); });
  ses.setPermissionRequestHandler((_wc, _perm, cb) => cb(false));
  ses.setPermissionCheckHandler(() => false);

  protocol.handle('app', (request) => {
    const url = new URL(request.url);
    let rel = decodeURIComponent(url.pathname);
    if (rel === '/' || rel === '') rel = '/index.html';
    const file = path.normalize(path.join(RENDERER, rel));
    if (!file.startsWith(RENDERER)) return new Response('Forbidden', { status: 403 });
    try {
      const data = fs.readFileSync(file);
      return new Response(data, { headers: { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' } });
    } catch (_) { return new Response('Not found', { status: 404 }); }
  });

  try { openCore(); } catch (e) {
    logger.error('Failed to open database', e);
    dialog.showErrorBox('تعذر فتح قاعدة البيانات', `${e.message}\n\nمجلد البيانات: ${dataDir}\nإذا تكرر الخطأ، استعد آخر نسخة احتياطية سليمة أو راجع ملف السجل في: ${logDir}`);
    app.quit();
    return;
  }

  registerIpc();
  createWindow();
  scheduleAutoBackups();
}

function createWindow() {
  win = new BrowserWindow({
    width: 1360, height: 860, minWidth: 980, minHeight: 640, show: false, backgroundColor: '#FAF7F0',
    title: 'Workshop ERP', icon: path.join(RENDERER, 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false, spellcheck: false, devTools: DEV },
  });
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('app://')) e.preventDefault(); });
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F5') { win.webContents.reload(); e.preventDefault(); }
    if (DEV && input.type === 'keyDown' && input.key === 'F12') win.webContents.toggleDevTools();
  });
  win.on('page-title-updated', (e) => e.preventDefault());
  win.on('close', (e) => {
    if (quitting) return;
    e.preventDefault();
    quitting = true;
    shutdown().finally(() => { win.destroy(); app.quit(); });
  });
  win.loadURL('app://erp/index.html');
}

// ------------------------------------------------------------------ backups
function notify(message, kind = 'ok') { if (win && !win.isDestroyed()) win.webContents.send('erp:event', { type: 'toast', message, kind }); }

function scheduleAutoBackups() {
  const tick = () => {
    try {
      const r = core && core.ctx ? core.autoBackupIfDue() : null;
      if (r && r.error) notify(`فشل النسخ الاحتياطي التلقائي: ${r.error}`, 'bad');
      else if (r) { logger.info('Auto backup', r.path); if (r.warning) notify(r.warning, 'warn'); }
    } catch (e) { logger.error('auto backup', e); }
  };
  setTimeout(tick, 15e3);
  setInterval(tick, 30 * 60e3);
}

async function shutdown() {
  try {
    if (core && core.ctx && core.ctx.settings().backup.autoOnClose) {
      const r = core.runAuto();
      logger.info('Backup on close', r && (r.path || r.error));
    }
  } catch (e) { logger.error('backup on close', e); }
  try { if (core) core.close(); } catch (e) { logger.error('close db', e); }
}
app.on('window-all-closed', () => app.quit());

// ------------------------------------------------------------------ IPC
function registerIpc() {
  const fromWin = (e) => BrowserWindow.fromWebContents(e.sender);
  ipcMain.handle('erp:invoke', (_e, method, args) => {
    if (typeof method !== 'string') return { ok: false, error: { message: 'طلب غير صالح', code: 'BAD_REQUEST' } };
    if (method === 'backup.stageUpload') return { ok: false, error: { message: 'غير متاح في تطبيق سطح المكتب', code: 'FORBIDDEN' } };
    return core.invoke(method, args || {});
  });
  ipcMain.handle('erp:saveText', async (e, { defaultName, content, filters }) => {
    const r = await dialog.showSaveDialog(fromWin(e), { defaultPath: path.join(app.getPath('documents'), String(defaultName || 'export.csv')), filters: filters || [] });
    if (r.canceled || !r.filePath) return null;
    fs.writeFileSync(r.filePath, String(content), 'utf8');
    return { path: r.filePath };
  });
  ipcMain.handle('erp:openFile', async (e, { title, filters }) => {
    const r = await dialog.showOpenDialog(fromWin(e), { title, filters: filters || [], properties: ['openFile'] });
    return r.canceled || !r.filePaths.length ? null : r.filePaths[0];
  });
  ipcMain.handle('erp:chooseFolder', async (e, { title }) => {
    const r = await dialog.showOpenDialog(fromWin(e), { title, properties: ['openDirectory', 'createDirectory'] });
    return r.canceled || !r.filePaths.length ? null : r.filePaths[0];
  });
  ipcMain.handle('erp:saveFile', async (e, { defaultName, filters }) => {
    const r = await dialog.showSaveDialog(fromWin(e), { defaultPath: String(defaultName || ''), filters: filters || [] });
    return r.canceled || !r.filePath ? null : r.filePath;
  });
  ipcMain.handle('erp:showInFolder', (_e, p) => { if (p && fs.existsSync(p)) shell.showItemInFolder(p); return true; });
  ipcMain.handle('erp:print', (e) => new Promise((resolve) => {
    e.sender.print({ silent: false, printBackground: true }, (ok, reason) => { if (!ok && reason && reason !== 'cancelled') logger.warn('print', reason); resolve(ok); });
  }));
  ipcMain.handle('erp:printToPDF', async (e, { defaultName }) => {
    const r = await dialog.showSaveDialog(fromWin(e), { defaultPath: path.join(app.getPath('documents'), String(defaultName || 'document.pdf')), filters: [{ name: 'PDF', extensions: ['pdf'] }] });
    if (r.canceled || !r.filePath) return null;
    const pdf = await e.sender.printToPDF({ printBackground: true, pageSize: 'A4' });
    fs.writeFileSync(r.filePath, pdf);
    return { path: r.filePath };
  });
  ipcMain.handle('erp:setTitle', (e, t) => { const w = fromWin(e); if (w) w.setTitle(String(t || 'Workshop ERP')); return true; });
}

process.on('uncaughtException', (e) => logger.error('uncaught', e));
process.on('unhandledRejection', (e) => logger.error('unhandled rejection', e));
