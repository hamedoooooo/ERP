'use strict';
const { AppError } = require('./util');

const MODULES = ['auth', 'masterdata', 'products', 'purchases', 'sales', 'manufacturing', 'finance', 'inventory', 'reports', 'backup'];

function buildRegistry() {
  const reg = new Map();
  for (const m of MODULES) {
    // eslint-disable-next-line global-require, import/no-dynamic-require
    const mod = require(`../services/${m}`);
    for (const [name, h] of Object.entries(mod)) {
      if (h && typeof h === 'object' && typeof h.fn === 'function' && name.includes('.')) {
        if (reg.has(name)) throw new Error('Duplicate handler ' + name);
        reg.set(name, h);
      }
    }
  }
  return reg;
}

/** Translate low-level database errors into messages the user can act on. */
function translate(e) {
  const msg = String(e && e.message || e);
  if (/UNIQUE constraint failed/i.test(msg)) return new AppError('القيمة المدخلة مستخدمة بالفعل (مكررة). غيّر الكود أو الاسم وحاول مرة أخرى.', 'DUPLICATE');
  if (/FOREIGN KEY constraint failed/i.test(msg)) return new AppError('لا يمكن تنفيذ العملية لأن السجل مرتبط ببيانات أخرى.', 'IN_USE');
  if (/CHECK constraint failed/i.test(msg)) return new AppError('بعض القيم المدخلة غير مقبولة (مثل كمية سالبة أو صفرية).', 'VALIDATION');
  if (/NOT NULL constraint failed/i.test(msg)) return new AppError('بعض الحقول المطلوبة فارغة.', 'VALIDATION');
  if (/database is locked|SQLITE_BUSY/i.test(msg)) return new AppError('قاعدة البيانات مشغولة حاليًا. حاول مرة أخرى بعد لحظات.', 'BUSY');
  if (/disk I\/O|SQLITE_FULL|database or disk is full/i.test(msg)) return new AppError('تعذر الكتابة على القرص. تأكد من وجود مساحة كافية.', 'DISK');
  if (/malformed|SQLITE_CORRUPT/i.test(msg)) return new AppError('قاعدة البيانات تالفة. استعد آخر نسخة احتياطية سليمة.', 'CORRUPT');
  return null;
}

class Router {
  constructor(app) {
    this.app = app;
    this.registry = buildRegistry();
  }

  has(method) { return this.registry.has(method); }

  /** Internal call (used by services composing other services). Throws on error. */
  call(ctx, method, args) {
    const h = this.registry.get(method);
    if (!h) throw new AppError('عملية غير معروفة: ' + method, 'UNKNOWN_METHOD');
    if (!h.public) ctx.requireUser();
    if (h.perm) ctx.require(h.perm);
    const run = () => h.fn(ctx, args || {});
    return h.write ? ctx.db.tx(run) : run();
  }

  /** External call from the UI. Never throws; returns {ok, data} or {ok:false, error}. */
  invoke(method, args) {
    const ctx = this.app.ctx;
    if (!ctx) return { ok: false, error: { message: 'قاعدة البيانات غير مفتوحة', code: 'NO_DB' } };
    ctx.api = (m, a) => this.call(ctx, m, a);
    try {
      const data = this.call(ctx, method, args);
      return { ok: true, data: data === undefined ? null : data };
    } catch (e) {
      if (e && e.userFacing) return { ok: false, error: { message: e.message, code: e.code || 'APP_ERROR', details: e.details || null } };
      const t = translate(e);
      if (t) return { ok: false, error: { message: t.message, code: t.code } };
      this.app.log('error', `[${method}]`, e && e.stack ? e.stack : e);
      return { ok: false, error: { message: 'حدث خطأ غير متوقع أثناء تنفيذ العملية ولم يتم حفظ أي تغيير. إن تكرر الخطأ، أنشئ نسخة احتياطية وتواصل مع الدعم.', code: 'INTERNAL', technical: String(e && e.message || e) } };
    }
  }
}

module.exports = { Router, translate, MODULES };
