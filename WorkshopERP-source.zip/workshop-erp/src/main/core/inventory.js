'use strict';
/**
 * Perpetual inventory engine — Weighted Average Cost (one average per product,
 * quantities tracked per warehouse). Every movement writes an
 * inventory_transactions row and updates the cached stock table in the same
 * database transaction, so the item card, stock report and GL always agree.
 *
 * Invariant kept by receive()/issue():  Σ(stock qty) × avg_cost == Σ(movement values)
 */
const { AppError, EPS, qtyR, costR, money, nowISO, fmtQty } = require('./util');

const TYPE_LABELS = {
  purchase: 'شراء', sale: 'بيع', mo_issue: 'صرف للتصنيع', mo_return: 'رد من التصنيع', mo_receipt: 'استلام إنتاج',
  purchase_return: 'مرتجع شراء', sale_return: 'مرتجع بيع', adjustment_in: 'تسوية بالزيادة', adjustment_out: 'تسوية بالعجز',
  count_in: 'جرد (زيادة)', count_out: 'جرد (عجز)', transfer_in: 'تحويل وارد', transfer_out: 'تحويل صادر',
  opening_in: 'رصيد افتتاحي', opening_out: 'خصم افتتاحي', void_reversal: 'عكس مستند ملغي',
};

function product(db, id) {
  const p = db.get('SELECT p.*, u.name AS unit_name FROM products p JOIN units u ON u.id = p.unit_id WHERE p.id = ?', id);
  if (!p) throw new AppError('الصنف غير موجود', 'NOT_FOUND');
  return p;
}

function warehouse(db, id) {
  const w = db.get('SELECT * FROM warehouses WHERE id = ?', id);
  if (!w) throw new AppError('المخزن غير موجود', 'NOT_FOUND');
  return w;
}

const totalQty = (db, pid) => Number(db.val('SELECT COALESCE(SUM(qty),0) AS q FROM stock WHERE product_id = ?', pid)) || 0;
const whQty = (db, pid, wid) => Number(db.val('SELECT qty FROM stock WHERE product_id = ? AND warehouse_id = ?', pid, wid)) || 0;

function setWhQty(db, pid, wid, qty) {
  db.run('INSERT INTO stock(product_id, warehouse_id, qty) VALUES (?,?,?) ON CONFLICT(product_id, warehouse_id) DO UPDATE SET qty = excluded.qty', pid, wid, qtyR(qty));
}

function writeTx(ctx, m) {
  return ctx.db.insert('inventory_transactions', {
    date: m.date, product_id: m.productId, warehouse_id: m.warehouseId, type: m.type,
    qty_in: m.qtyIn || 0, qty_out: m.qtyOut || 0, unit_cost: costR(m.unitCost), total_cost: money(m.total),
    wh_balance_after: qtyR(m.whAfter), total_balance_after: qtyR(m.totalAfter), avg_cost_after: costR(m.avgAfter),
    doc_type: m.docType, doc_id: m.docId || null, doc_no: m.docNo || null, user_id: ctx.userId(),
    notes: m.notes || '', created_at: nowISO(),
  });
}

/** Stock in. Returns {unitCost, total}. */
function receive(ctx, m) {
  const db = ctx.db;
  const p = product(db, m.productId);
  warehouse(db, m.warehouseId);
  const qty = qtyR(m.qty);
  if (!(qty > 0)) throw new AppError('الكمية يجب أن تكون أكبر من صفر', 'VALIDATION');
  const unitCost = Math.max(0, Number(m.unitCost) || 0);
  if (!p.is_stocked) return { unitCost, total: money(qty * unitCost), skipped: true };
  const Q = totalQty(db, p.id);
  const A = Number(p.avg_cost) || 0;
  const newQ = Q + qty;
  const newAvg = Q > EPS ? (Q * A + qty * unitCost) / newQ : unitCost;
  const upd = { avg_cost: costR(newAvg), updated_at: nowISO() };
  if (m.isPurchase) { upd.last_purchase_price = costR(unitCost); upd.last_purchase_date = m.date; }
  db.update('products', p.id, upd);
  const wq = whQty(db, p.id, m.warehouseId) + qty;
  setWhQty(db, p.id, m.warehouseId, wq);
  writeTx(ctx, { ...m, qtyIn: qty, unitCost, total: qty * unitCost, whAfter: wq, totalAfter: newQ, avgAfter: newAvg });
  return { unitCost: costR(unitCost), total: money(qty * unitCost) };
}

/**
 * Stock out. Uses current average cost unless unitCost is given (specific cost,
 * used for make-to-order sales and document reversals). Returns {unitCost, total}.
 */
function issue(ctx, m) {
  const db = ctx.db;
  const p = product(db, m.productId);
  const w = warehouse(db, m.warehouseId);
  const qty = qtyR(m.qty);
  if (!(qty > 0)) throw new AppError('الكمية يجب أن تكون أكبر من صفر', 'VALIDATION');
  if (!p.is_stocked) return { unitCost: 0, total: 0, skipped: true };
  const available = whQty(db, p.id, w.id);
  const allowNeg = m.allowNegative !== undefined ? m.allowNegative : !!ctx.settings().inventory.allowNegative;
  if (!allowNeg && available < qty - EPS) {
    throw new AppError(`لا يمكن صرف الكمية المطلوبة من "${p.name}" (${fmtQty(qty)} ${p.unit_name}) لأن المخزون المتاح في "${w.name}" هو ${fmtQty(available)} فقط.`, 'INSUFFICIENT_STOCK',
      { productId: p.id, available, requested: qty });
  }
  const Q = totalQty(db, p.id);
  const A = Number(p.avg_cost) || 0;
  let cost = A;
  let newAvg = A;
  const hasOverride = m.unitCost !== undefined && m.unitCost !== null;
  if (hasOverride) {
    const c = Math.max(0, Number(m.unitCost) || 0);
    if (Q - qty > EPS) {
      const candidate = (Q * A - qty * c) / (Q - qty);
      if (candidate >= -EPS) { cost = c; newAvg = Math.max(0, candidate); }
    } else if (Q <= EPS) {
      cost = c; // stock already at/below zero (negative stock allowed): nothing to keep consistent
    }
  }
  if (Math.abs(newAvg - A) > 1e-9) db.update('products', p.id, { avg_cost: costR(newAvg), updated_at: nowISO() });
  const wq = available - qty;
  setWhQty(db, p.id, w.id, wq);
  writeTx(ctx, { ...m, qtyOut: qty, unitCost: cost, total: qty * cost, whAfter: wq, totalAfter: Q - qty, avgAfter: newAvg });
  return { unitCost: costR(cost), total: money(qty * cost) };
}

/** Move between warehouses; cost/avg unchanged. */
function transfer(ctx, m) {
  const db = ctx.db;
  const p = product(db, m.productId);
  if (!p.is_stocked) throw new AppError(`الصنف "${p.name}" خدمة ولا يُخزَّن`, 'VALIDATION');
  const from = warehouse(db, m.fromId); const to = warehouse(db, m.toId);
  const qty = qtyR(m.qty);
  const available = whQty(db, p.id, from.id);
  if (available < qty - EPS && !ctx.settings().inventory.allowNegative) {
    throw new AppError(`لا يمكن تحويل ${fmtQty(qty)} من "${p.name}" لأن المتاح في "${from.name}" هو ${fmtQty(available)} فقط.`, 'INSUFFICIENT_STOCK');
  }
  const A = Number(p.avg_cost) || 0; const Q = totalQty(db, p.id);
  setWhQty(db, p.id, from.id, available - qty);
  writeTx(ctx, { ...m, warehouseId: from.id, type: 'transfer_out', qtyOut: qty, unitCost: A, total: qty * A, whAfter: available - qty, totalAfter: Q, avgAfter: A });
  const toQ = whQty(db, p.id, to.id) + qty;
  setWhQty(db, p.id, to.id, toQ);
  writeTx(ctx, { ...m, warehouseId: to.id, type: 'transfer_in', qtyIn: qty, unitCost: A, total: qty * A, whAfter: toQ, totalAfter: Q, avgAfter: A });
}

module.exports = { receive, issue, transfer, product, warehouse, totalQty, whQty, TYPE_LABELS };
