'use strict';
/**
 * Application core, shared by the Electron main process, the browser preview
 * server and the automated tests. Owns the database file lifecycle.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const { Database } = require('../db/connection');
const { migrate, currentVersion, pending, LATEST } = require('../db/migrate');
const { Context } = require('./context');
const { Router } = require('./router');
const bf = require('./backupfile');
const { AppError, stamp, nowISO } = require('./util');
const { loadSessionUser } = require('../services/auth');

class App {
  constructor({ dataDir, appVersion = '1.0.0', logger = console, platform = process.platform }) {
    this.dataDir = dataDir;
    this.appVersion = appVersion;
    this.logger = logger;
    this.platform = platform;
    this.db = null;
    this.ctx = null;
    this.router = null;
    fs.mkdirSync(this.dataDir, { recursive: true });
  }

  get dbPath() { return path.join(this.dataDir, 'workshop.db'); }
  get defaultBackupDir() { return path.join(this.dataDir, 'backups'); }

  log(level, ...args) { try { (this.logger[level] || this.logger.log).call(this.logger, ...args); } catch (_) { /* ignore */ } }

  open() {
    const existed = fs.existsSync(this.dbPath);
    this.db = new Database(this.dbPath);
    const integrity = this.db.val('PRAGMA quick_check');
    if (integrity !== 'ok') this.log('error', 'Database integrity check failed:', integrity);
    migrate(this.db, {
      beforeMigrate: (from, list) => {
        // Safety net before any schema change on an existing database.
        if (!existed) return;
        const dir = this.defaultBackupDir; fs.mkdirSync(dir, { recursive: true });
        const tmp = path.join(os.tmpdir(), `werp-premig-${Date.now()}.db`);
        this.db.snapshotTo(tmp);
        const raw = fs.readFileSync(tmp); fs.unlinkSync(tmp);
        const { buffer } = bf.encode(raw, { appName: 'Workshop ERP', appVersion: this.appVersion, schemaVersion: from, createdAt: nowISO(), kind: 'pre-migration', note: `قبل الترقية إلى ${list.map((m) => m.version).join(',')}` });
        fs.writeFileSync(path.join(dir, `Workshop_Backup_${stamp()}_pre-migration.backup`), buffer);
      },
    });
    this.ctx = new Context(this.db, { appVersion: this.appVersion, paths: { data: this.dataDir } });
    this.ctx.app = this;
    this.router = this.router || new Router(this);
    return this;
  }

  close() {
    if (this.db) { this.db.close(); this.db = null; }
    this.ctx = null;
  }

  invoke(method, args) { return this.router.invoke(method, args); }

  // ------------------------------------------------------------------ backups
  /** Resolve the backup folder; falls back safely if the configured drive is missing. */
  resolveBackupDir(preferred) {
    const configured = preferred || this.ctx.settings().backup.location;
    if (configured) {
      const root = path.parse(path.resolve(configured)).root;
      try {
        if (!fs.existsSync(root)) throw new Error('drive missing');
        fs.mkdirSync(configured, { recursive: true });
        fs.accessSync(configured, fs.constants.W_OK);
        return { dir: configured, fallback: false };
      } catch (e) {
        fs.mkdirSync(this.defaultBackupDir, { recursive: true });
        return { dir: this.defaultBackupDir, fallback: true, reason: `تعذر الوصول إلى "${configured}" (قد يكون القرص أو الفلاشة غير متصل). تم الحفظ في المجلد الافتراضي بدلًا من ذلك.` };
      }
    }
    fs.mkdirSync(this.defaultBackupDir, { recursive: true });
    return { dir: this.defaultBackupDir, fallback: false };
  }

  counts() {
    const n = (t) => Number(this.db.val(`SELECT COUNT(*) FROM ${t}`)) || 0;
    return { products: n('products'), customers: n('customers'), suppliers: n('suppliers'), sales_invoices: n('sales_invoices'), purchase_invoices: n('purchase_invoices'), manufacturing_orders: n('manufacturing_orders'), journal_entries: n('journal_entries') };
  }

  createBackup({ password = '', kind = 'manual', dir = null, filePath = null } = {}) {
    const loc = filePath ? { dir: path.dirname(filePath), fallback: false } : this.resolveBackupDir(dir);
    const suffix = kind === 'manual' ? '' : `_${kind}`;
    const target = filePath || path.join(loc.dir, `Workshop_Backup_${stamp()}${suffix}.backup`);
    const tmp = path.join(os.tmpdir(), `werp-snap-${process.pid}-${Date.now()}.db`);
    try {
      this.db.snapshotTo(tmp);
      const raw = fs.readFileSync(tmp);
      const s = this.ctx.settings();
      const { buffer, header } = bf.encode(raw, {
        appName: s.company.appName, companyName: s.company.companyName, appVersion: this.appVersion, schemaVersion: currentVersion(this.db),
        createdAt: nowISO(), createdBy: this.ctx.user ? this.ctx.user.username : 'system', kind, machine: os.hostname(), counts: this.counts(),
      }, password);
      const part = target + '.part';
      fs.writeFileSync(part, buffer);
      fs.renameSync(part, target); // atomic: never leave a half-written backup behind
      this.db.insert('backup_metadata', { created_at: header.createdAt, file_name: path.basename(target), file_path: target, kind, size_bytes: buffer.length, encrypted: password ? 1 : 0, app_version: this.appVersion, schema_version: header.schemaVersion, sha256: header.sha256, created_by: this.ctx.userId() });
      this.ctx.audit('backup', { entity: 'backup', docNo: path.basename(target), notes: `${kind}${password ? ' (مشفرة)' : ''}` });
      if (kind === 'auto') this.pruneAuto(loc.dir);
      return { path: target, file: path.basename(target), size: buffer.length, encrypted: !!password, warning: loc.fallback ? loc.reason : null };
    } finally {
      try { if (fs.existsSync(tmp)) fs.unlinkSync(tmp); } catch (_) { /* ignore */ }
    }
  }

  pruneAuto(dir) {
    const keep = Math.max(1, Number(this.ctx.settings().backup.keepLast) || 10);
    const files = fs.readdirSync(dir).filter((f) => /^Workshop_Backup_.*_auto\.backup$/.test(f)).sort();
    const remove = files.slice(0, Math.max(0, files.length - keep));
    remove.forEach((f) => { try { fs.unlinkSync(path.join(dir, f)); } catch (_) { /* ignore */ } });
    return remove.length;
  }

  inspectBackup(file) {
    const h = bf.inspectFile(file);
    return { ...h, compatible: (h.schemaVersion || 0) <= LATEST, currentSchema: LATEST, currentAppVersion: this.appVersion };
  }

  /**
   * Restore: verify → validate the database inside → safety backup of current data →
   * swap files → reopen → migrate (older backups are upgraded automatically).
   */
  restoreBackup(file, password) {
    const { raw, header } = bf.decodeFile(file, password);
    if ((header.schemaVersion || 0) > LATEST) throw new AppError(`هذه النسخة من إصدار أحدث من البرنامج (قاعدة بيانات v${header.schemaVersion}). ثبّت الإصدار الأحدث ثم أعد المحاولة.`, 'INCOMPATIBLE');
    const staged = path.join(this.dataDir, `restore-staged-${Date.now()}.db`);
    fs.writeFileSync(staged, raw);
    try {
      const probe = new Database(staged, { readonly: true });
      try {
        const ok = probe.val('PRAGMA integrity_check');
        if (ok !== 'ok') throw new AppError('قاعدة البيانات داخل النسخة غير سليمة: ' + ok, 'BAD_BACKUP');
        if (!probe.get("SELECT name FROM sqlite_master WHERE type='table' AND name='schema_migrations'")) throw new AppError('النسخة لا تحتوي على بيانات هذا البرنامج', 'BAD_BACKUP');
      } finally { probe.close(); }
      const who = this.ctx.user ? this.ctx.user.id : null;
      const safety = this.createBackup({ kind: 'pre-restore' });
      this.ctx.audit('restore_start', { entity: 'backup', docNo: path.basename(file), notes: `نسخة أمان قبل الاستعادة: ${safety.file}` });
      this.close();
      const keepAside = this.dbPath + '.before-restore';
      try { if (fs.existsSync(keepAside)) fs.unlinkSync(keepAside); } catch (_) { /* ignore */ }
      fs.renameSync(this.dbPath, keepAside);
      ['-wal', '-shm'].forEach((s) => { try { if (fs.existsSync(this.dbPath + s)) fs.unlinkSync(this.dbPath + s); } catch (_) { /* ignore */ } });
      try {
        fs.renameSync(staged, this.dbPath);
        this.open();
      } catch (e) {
        // roll back to the previous database if anything goes wrong
        try { this.close(); } catch (_) { /* ignore */ }
        if (fs.existsSync(this.dbPath)) fs.unlinkSync(this.dbPath);
        fs.renameSync(keepAside, this.dbPath);
        this.open();
        throw e;
      }
      try { fs.unlinkSync(keepAside); } catch (_) { /* ignore */ }
      // keep the operator logged in if their account exists in the restored data
      if (who) { const u = loadSessionUser(this.db, who); if (u && u.active) this.ctx.user = u; }
      this.ctx.audit('restore', { entity: 'backup', docNo: path.basename(file), notes: `تاريخ النسخة ${header.createdAt} — إصدار ${header.appVersion}`, newData: header.counts || null });
      return { restored: true, header: { createdAt: header.createdAt, appVersion: header.appVersion, schemaVersion: header.schemaVersion, counts: header.counts }, safetyBackup: safety.path, sessionKept: !!this.ctx.user };
    } finally {
      try { if (fs.existsSync(staged)) fs.unlinkSync(staged); } catch (_) { /* ignore */ }
    }
  }

  /** Scheduled local backups (daily / weekly). Returns the backup made, if any. */
  autoBackupIfDue() {
    const b = this.ctx.settings().backup;
    if (!b.schedule || b.schedule === 'off') return null;
    const span = b.schedule === 'weekly' ? 7 * 864e5 : 864e5;
    const last = b.lastAutoAt ? Date.parse(b.lastAutoAt) : 0;
    if (Date.now() - last < span) return null;
    return this.runAuto();
  }

  runAuto() {
    try {
      const r = this.createBackup({ kind: 'auto' });
      this.ctx.setSetting('backup', { lastAutoAt: nowISO() });
      return r;
    } catch (e) {
      this.log('error', 'auto backup failed', e);
      return { error: e.message };
    }
  }

  pendingMigrations() { return pending(this.db).map((m) => m.version); }
}

module.exports = { App };
