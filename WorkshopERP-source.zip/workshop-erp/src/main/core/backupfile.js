'use strict';
/**
 * Single-file local backup format (.backup)
 *
 *   bytes 0..7   magic "WSERPBK1"
 *   bytes 8..11  header length (uint32 LE)
 *   header       UTF-8 JSON (metadata, never encrypted so the file can be inspected)
 *   payload      gzip(SQLite database)            — plain backups
 *                AES-256-GCM(gzip(SQLite db))     — encrypted backups (key = scrypt(password, salt))
 *
 * The header stores the SHA-256 of the raw database bytes, so any corruption or a
 * wrong password is detected before anything is restored.
 */
const fs = require('fs');
const zlib = require('zlib');
const crypto = require('crypto');
const { AppError } = require('./util');

const MAGIC = Buffer.from('WSERPBK1', 'ascii');
const KDF = { N: 32768, r: 8, p: 1, keyLen: 32 };

function deriveKey(password, salt, kdf = KDF) {
  return crypto.scryptSync(String(password), salt, kdf.keyLen || 32, { N: kdf.N, r: kdf.r, p: kdf.p, maxmem: 128 * kdf.N * kdf.r * 2 });
}

function encode(rawDb, meta, password) {
  const sha256 = crypto.createHash('sha256').update(rawDb).digest('hex');
  let payload = zlib.gzipSync(rawDb, { level: 9 });
  const header = { format: 'WSERP-BACKUP', formatVersion: 1, ...meta, sha256, rawSize: rawDb.length, encrypted: false };
  if (password) {
    const salt = crypto.randomBytes(16); const iv = crypto.randomBytes(12);
    const key = deriveKey(password, salt);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    cipher.setAAD(Buffer.from(sha256, 'utf8'));
    payload = Buffer.concat([cipher.update(payload), cipher.final()]);
    Object.assign(header, { encrypted: true, cipher: 'aes-256-gcm', kdf: { name: 'scrypt', ...KDF, salt: salt.toString('base64') }, iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64') });
  }
  const h = Buffer.from(JSON.stringify(header), 'utf8');
  const len = Buffer.alloc(4); len.writeUInt32LE(h.length, 0);
  return { buffer: Buffer.concat([MAGIC, len, h, payload]), header };
}

function readHeader(buf) {
  if (buf.length < 12 || !buf.subarray(0, 8).equals(MAGIC)) throw new AppError('الملف المختار ليس نسخة احتياطية من هذا البرنامج أو أنه تالف.', 'BAD_BACKUP');
  const hl = buf.readUInt32LE(8);
  if (hl <= 0 || hl > 1_000_000 || 12 + hl > buf.length) throw new AppError('ملف النسخة الاحتياطية تالف (رأس الملف غير صالح).', 'BAD_BACKUP');
  let header;
  try { header = JSON.parse(buf.subarray(12, 12 + hl).toString('utf8')); } catch (_) { throw new AppError('ملف النسخة الاحتياطية تالف (بيانات الرأس غير مقروءة).', 'BAD_BACKUP'); }
  if (header.format !== 'WSERP-BACKUP') throw new AppError('الملف ليس نسخة احتياطية صالحة.', 'BAD_BACKUP');
  if (header.formatVersion > 1) throw new AppError('هذه النسخة أُنشئت بإصدار أحدث من البرنامج. حدّث البرنامج أولًا.', 'BAD_BACKUP');
  return { header, payload: buf.subarray(12 + hl) };
}

function inspectFile(file) {
  if (!fs.existsSync(file)) throw new AppError('ملف النسخة الاحتياطية غير موجود', 'NOT_FOUND');
  const buf = fs.readFileSync(file);
  const { header, payload } = readHeader(buf);
  return { ...header, fileSize: buf.length, payloadSize: payload.length };
}

/** Returns the raw SQLite bytes after verifying integrity. */
function decodeFile(file, password) {
  const buf = fs.readFileSync(file);
  const { header, payload } = readHeader(buf);
  let data = payload;
  if (header.encrypted) {
    if (!password) throw new AppError('هذه النسخة محمية بكلمة مرور. أدخل كلمة المرور.', 'PASSWORD_REQUIRED');
    try {
      const key = deriveKey(password, Buffer.from(header.kdf.salt, 'base64'), header.kdf);
      const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(header.iv, 'base64'));
      d.setAAD(Buffer.from(header.sha256, 'utf8'));
      d.setAuthTag(Buffer.from(header.tag, 'base64'));
      data = Buffer.concat([d.update(payload), d.final()]);
    } catch (_) {
      throw new AppError('كلمة المرور غير صحيحة أو أن الملف تم تعديله.', 'BAD_PASSWORD');
    }
  }
  let raw;
  try { raw = zlib.gunzipSync(data); } catch (_) { throw new AppError('تعذر فك ضغط النسخة الاحتياطية. الملف تالف.', 'BAD_BACKUP'); }
  const sha = crypto.createHash('sha256').update(raw).digest('hex');
  if (sha !== header.sha256) throw new AppError('فشل التحقق من سلامة النسخة (البصمة غير مطابقة). الملف تالف.', 'BAD_BACKUP');
  if (!raw.subarray(0, 16).toString('latin1').startsWith('SQLite format 3')) throw new AppError('محتوى النسخة ليس قاعدة بيانات صالحة.', 'BAD_BACKUP');
  return { raw, header };
}

module.exports = { encode, inspectFile, decodeFile, readHeader, MAGIC };
