'use strict';
const { AppError, num, money, qtyR, costR, EPS, todayISO } = require('./util');
const ledger = require('./ledger');

/** Validate & normalise document lines. */
function parseLines(ctx, lines, { priceLabel = 'السعر', stockedOnly = false, allowServices = true } = {}) {
  if (!Array.isArray(lines) || !lines.length) throw new AppError('أضف سطرًا واحدًا على الأقل', 'VALIDATION');
  const out = [];
  lines.forEach((l, i) => {
    if (!l || !l.product_id) return; // ignore empty rows from the UI
    const p = ctx.db.get('SELECT p.*, u.name AS unit_name, u.allow_fraction FROM products p JOIN units u ON u.id = p.unit_id WHERE p.id = ?', l.product_id);
    if (!p) throw new AppError(`السطر ${i + 1}: الصنف غير موجود`, 'VALIDATION');
    if (!p.active) throw new AppError(`السطر ${i + 1}: الصنف "${p.name}" موقوف`, 'VALIDATION');
    if (stockedOnly && !p.is_stocked) throw new AppError(`السطر ${i + 1}: "${p.name}" خدمة ولا يمكن استخدامها هنا`, 'VALIDATION');
    if (!allowServices && !p.is_stocked) throw new AppError(`السطر ${i + 1}: "${p.name}" خدمة ولا يمكن استخدامها هنا`, 'VALIDATION');
    const qty = qtyR(num(l.qty, `الكمية (السطر ${i + 1})`, { required: true, allowZero: false, min: 0 }));
    if (!p.allow_fraction && Math.abs(qty - Math.round(qty)) > EPS) throw new AppError(`السطر ${i + 1}: وحدة "${p.unit_name}" لا تقبل كسورًا`, 'VALIDATION');
    const price = num(l.unit_price, `${priceLabel} (السطر ${i + 1})`, { min: 0 });
    out.push({ ...l, product: p, product_id: p.id, qty, unit_price: costR(price), line_total: money(qty * price) });
  });
  if (!out.length) throw new AppError('أضف سطرًا واحدًا على الأقل باختيار صنف', 'VALIDATION');
  return out;
}

function taxRate(ctx, requested) {
  const t = ctx.settings().tax;
  if (!t.enabled) return 0;
  if (requested === '' || requested === null || requested === undefined) return Number(t.defaultRate) || 0;
  return num(requested, 'نسبة الضريبة', { min: 0 });
}

/** Header totals with discount allocated proportionally to lines (net_total per line). */
function totals(lines, discountIn, rate) {
  const subtotal = money(lines.reduce((s, l) => s + l.line_total, 0));
  const discount = money(num(discountIn, 'الخصم', { min: 0 }));
  if (discount > subtotal + EPS) throw new AppError('الخصم أكبر من إجمالي الفاتورة', 'VALIDATION');
  const net = money(subtotal - discount);
  const factor = subtotal > 0 ? net / subtotal : 1;
  let allocated = 0;
  lines.forEach((l, i) => {
    l.net_total = i === lines.length - 1 ? money(net - allocated) : money(l.line_total * factor);
    allocated = money(allocated + l.net_total);
    l.net_unit = l.qty > 0 ? costR(l.net_total / l.qty) : 0;
  });
  const tax = money(net * rate / 100);
  return { subtotal, discount, net, tax_rate: rate, tax, total: money(net + tax) };
}

function paidAmount(value, total, hasParty) {
  if (!hasParty) return total; // walk-in documents are settled immediately
  const paid = money(num(value, 'المبلغ المدفوع', { min: 0 }));
  if (paid > total + EPS) throw new AppError('المبلغ المدفوع أكبر من إجمالي الفاتورة', 'VALIDATION');
  return paid;
}

/**
 * When a void reverses an outflow of stock at a value different from what the
 * original document booked (because the average moved in between), post the
 * difference so the inventory account keeps matching the stock valuation.
 * delta > 0 → inventory account must increase.
 */
function inventoryGLAdjust(ctx, delta, docNo, reason) {
  const d = money(delta);
  if (Math.abs(d) < 0.005) return;
  ledger.post(ctx, {
    date: todayISO(), docType: 'void_adjust', docNo, description: reason || `فرق تقييم مخزون عند إلغاء ${docNo}`,
    lines: d > 0
      ? [{ account: ledger.ACC.INVENTORY, debit: d }, { account: ledger.ACC.INV_DIFF, credit: d }]
      : [{ account: ledger.ACC.INV_DIFF, debit: -d }, { account: ledger.ACC.INVENTORY, credit: -d }],
  });
}

function voidReason(a) {
  const r = String((a && a.reason) || '').trim();
  if (!r) throw new AppError('من فضلك اكتب سبب الإلغاء', 'VALIDATION');
  return r.slice(0, 500);
}

module.exports = { parseLines, taxRate, totals, paidAmount, inventoryGLAdjust, voidReason };
