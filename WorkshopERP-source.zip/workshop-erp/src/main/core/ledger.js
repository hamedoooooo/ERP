'use strict';
/**
 * Double-entry posting engine (evolved from the original system's journal).
 * Every financial document posts one balanced journal entry; voiding a document
 * marks its entries void so they disappear from every balance and report while
 * remaining visible for audit.
 */
const { AppError, money, nowISO } = require('./util');

const ACC = {
  CASH: '1100', BANK: '1200', AR: '1300', INVENTORY: '1400', WIP: '1450', VAT_IN: '1600',
  AP: '2100', ACCRUED: '2200', VAT_OUT: '2300', WAGES_PAYABLE: '2400',
  CAPITAL: '3100', RETAINED: '3200', OPENING: '3300', DRAWINGS: '3400',
  SALES: '4100', SALES_RETURNS: '4200', OTHER_INCOME: '4300',
  COGS: '5100', INV_DIFF: '5200', MO_LOSS: '5300', OVERHEAD_APPLIED: '5400',
  OTHER_EXP: '6400',
};

const cashAccount = (method) => (method === 'bank' ? ACC.BANK : ACC.CASH);

/**
 * @param ctx Context
 * @param {{date, docType, docId, docNo, description, lines:[{account, debit, credit, partyType, partyId, memo}]}} e
 */
function post(ctx, e) {
  const db = ctx.db;
  const lines = (e.lines || [])
    .map((l) => ({ ...l, debit: money(l.debit || 0), credit: money(l.credit || 0) }))
    .map((l) => {
      // normalise negatives into the opposite column
      if (l.debit < 0) { l.credit = money(l.credit - l.debit); l.debit = 0; }
      if (l.credit < 0) { l.debit = money(l.debit - l.credit); l.credit = 0; }
      return l;
    })
    .filter((l) => l.debit > 0 || l.credit > 0);
  if (!lines.length) return null;
  let dr = money(lines.reduce((s, l) => s + l.debit, 0));
  let cr = money(lines.reduce((s, l) => s + l.credit, 0));
  const diff = money(dr - cr);
  if (Math.abs(diff) >= 0.005) {
    if (Math.abs(diff) <= 0.05) {
      // absorb sub-piaster rounding into the largest line on the lighter side
      const side = diff > 0 ? 'credit' : 'debit';
      const target = lines.filter((l) => l[side] > 0).sort((a, b) => b[side] - a[side])[0];
      target[side] = money(target[side] + Math.abs(diff));
    } else {
      throw new AppError(`القيد غير متوازن (مدين ${dr} / دائن ${cr}). لم يتم الحفظ.`, 'UNBALANCED');
    }
  }
  for (const l of lines) {
    const acc = db.get('SELECT code, active FROM accounts WHERE code = ?', l.account);
    if (!acc) throw new AppError(`الحساب ${l.account} غير موجود في دليل الحسابات`, 'ACCOUNT');
  }
  const id = db.insert('journal_entries', {
    date: e.date, doc_type: e.docType, doc_id: e.docId || null, doc_no: e.docNo || null,
    description: e.description || '', status: 'posted', created_by: ctx.userId(), created_at: nowISO(),
  });
  for (const l of lines) {
    db.insert('journal_lines', {
      entry_id: id, account_code: l.account, debit: l.debit, credit: l.credit,
      party_type: l.partyType || null, party_id: l.partyId || null, memo: l.memo || '',
    });
  }
  return id;
}

function voidEntries(ctx, docType, docId) {
  return ctx.db.run("UPDATE journal_entries SET status='void', voided_at=?, voided_by=? WHERE doc_type=? AND doc_id=? AND status='posted'",
    nowISO(), ctx.userId(), docType, docId).changes;
}

/** Balance of an account in its natural direction. Options: from/to dates, party. */
function balance(db, code, { from = null, to = null, partyType = null, partyId = null } = {}) {
  const acc = db.get('SELECT nature FROM accounts WHERE code = ?', code);
  const where = ["e.status='posted'", 'l.account_code = ?'];
  const p = [code];
  if (from) { where.push('e.date >= ?'); p.push(from); }
  if (to) { where.push('e.date <= ?'); p.push(to); }
  if (partyType) { where.push('l.party_type = ? AND l.party_id = ?'); p.push(partyType, partyId); }
  const r = db.get(`SELECT COALESCE(SUM(l.debit),0) AS d, COALESCE(SUM(l.credit),0) AS c
    FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE ${where.join(' AND ')}`, ...p);
  const d = Number(r.d) || 0; const c = Number(r.c) || 0;
  return { debit: money(d), credit: money(c), balance: money(acc && acc.nature === 'credit' ? c - d : d - c) };
}

function partyBalance(db, partyType, partyId, opts = {}) {
  return balance(db, partyType === 'customer' ? ACC.AR : ACC.AP, { ...opts, partyType, partyId }).balance;
}

module.exports = { ACC, post, voidEntries, balance, partyBalance, cashAccount };
