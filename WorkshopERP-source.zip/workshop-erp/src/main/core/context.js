'use strict';
const { AppError, nowISO } = require('./util');

const DEFAULT_SETTINGS = {
  company: { appName: 'ورشتي — نظام إدارة التصنيع', companyName: '', phone: '', address: '', taxNo: '', logo: '', invoiceFooter: 'شكرًا لتعاملكم معنا' },
  currency: { code: 'EGP', symbol: 'ج.م', decimals: 2 },
  tax: { enabled: false, defaultRate: 14, label: 'ضريبة القيمة المضافة' },
  inventory: { allowNegative: false, defaultLowStock: 0 },
  manufacturing: { overheadType: 'none', overheadValue: 0, overheadBase: 'direct', warnOverIssuePct: 10 },
  pricing: { method: 'margin', defaultPct: 25 },
  backup: { location: '', autoOnClose: false, schedule: 'off', keepLast: 10, lastAutoAt: null },
  security: { minPasswordLength: 6, lockAfterFailures: 5, lockMinutes: 5 },
  ui: { pageSize: 25 },
};

function deepMerge(base, over) {
  if (!over || typeof over !== 'object' || Array.isArray(over)) return over === undefined ? base : over;
  const out = { ...(base || {}) };
  for (const k of Object.keys(over)) {
    out[k] = (base && typeof base[k] === 'object' && !Array.isArray(base[k]) && base[k] !== null)
      ? deepMerge(base[k], over[k]) : over[k];
  }
  return out;
}

class Context {
  constructor(db, { appVersion = '0.0.0', paths = {} } = {}) {
    this.db = db;
    this.appVersion = appVersion;
    this.paths = paths;
    this.user = null; // {id, username, full_name, role_id, perms:Set}
    this._settings = null;
  }

  // ---------- settings ----------
  settings() {
    if (!this._settings) {
      const rows = this.db.all('SELECT key, value FROM settings');
      const stored = {};
      rows.forEach((r) => { try { stored[r.key] = JSON.parse(r.value); } catch (_) { /* ignore corrupt */ } });
      this._settings = deepMerge(DEFAULT_SETTINGS, stored);
    }
    return this._settings;
  }

  setSetting(section, value) {
    if (!(section in DEFAULT_SETTINGS)) throw new AppError('قسم إعدادات غير معروف', 'VALIDATION');
    const merged = deepMerge(this.settings()[section], value);
    this.db.run('INSERT INTO settings(key,value,updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at',
      section, JSON.stringify(merged), nowISO());
    this._settings = null;
    return merged;
  }

  invalidate() { this._settings = null; }

  // ---------- security ----------
  requireUser() {
    if (!this.user) throw new AppError('انتهت الجلسة. من فضلك سجّل الدخول مرة أخرى.', 'AUTH');
    return this.user;
  }

  can(perm) { return !!(this.user && this.user.perms && this.user.perms.has(perm)); }

  require(perm) {
    this.requireUser();
    if (!perm) return;
    const list = Array.isArray(perm) ? perm : [perm];
    if (!list.some((p) => this.can(p))) {
      const row = this.db.get('SELECT name FROM permissions WHERE code = ?', list[0]);
      throw new AppError(`ليست لديك صلاحية: ${row ? row.name : list[0]}`, 'FORBIDDEN');
    }
  }

  userId() { return this.user ? this.user.id : null; }

  // ---------- audit ----------
  audit(action, { entity = null, entityId = null, docNo = null, oldData = null, newData = null, notes = '' } = {}) {
    const clip = (o) => {
      if (o === null || o === undefined) return null;
      const s = typeof o === 'string' ? o : JSON.stringify(o, (k, v) => (k === 'image' || k === 'logo' || k === 'password_hash' || k === 'password_salt') ? undefined : v);
      return s.length > 20000 ? s.slice(0, 20000) + '…' : s;
    };
    this.db.run('INSERT INTO audit_logs(ts,user_id,username,action,entity,entity_id,doc_no,old_data,new_data,notes) VALUES (?,?,?,?,?,?,?,?,?,?)',
      nowISO(), this.userId(), this.user ? this.user.username : 'system', action, entity, entityId === null ? null : String(entityId), docNo, clip(oldData), clip(newData), notes || '');
  }

  // ---------- numbering ----------
  nextNo(type) {
    const row = this.db.get('SELECT prefix, next_no, pad FROM doc_sequences WHERE doc_type = ?', type);
    if (!row) throw new Error('Unknown sequence ' + type);
    this.db.run('UPDATE doc_sequences SET next_no = next_no + 1 WHERE doc_type = ?', type);
    return row.prefix + String(row.next_no).padStart(row.pad, '0');
  }

  /** Code for master data: user-provided or generated; must be unique in table. */
  code(table, type, provided) {
    let c = (provided || '').trim();
    if (!c) {
      do { c = this.nextNo(type); } while (this.db.get(`SELECT 1 FROM ${table} WHERE code = ?`, c));
    }
    return c;
  }
}

module.exports = { Context, DEFAULT_SETTINGS, deepMerge };
