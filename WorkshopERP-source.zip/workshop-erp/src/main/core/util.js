'use strict';
/**
 * Shared helpers for the main process. No Electron imports here so that
 * every service can be exercised headlessly by the test-suite.
 */

/** Error whose message is safe to show to the user (Arabic, non-technical). */
class AppError extends Error {
  constructor(message, code = 'APP_ERROR', details = null) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.details = details;
    this.userFacing = true;
  }
}

const EPS = 0.00001;

function round(n, d = 2) {
  const v = Number(n) || 0;
  const f = Math.pow(10, d);
  return Math.round((v + Math.sign(v) * Number.EPSILON) * f) / f;
}
const money = (n) => round(n, 2);
const qtyR = (n) => round(n, 4);
const costR = (n) => round(n, 6);

function num(v, label, { min = null, allowZero = true, required = false } = {}) {
  if (v === '' || v === null || v === undefined) {
    if (required) throw new AppError(`من فضلك أدخل قيمة "${label}"`, 'VALIDATION');
    return 0;
  }
  const n = Number(v);
  if (!Number.isFinite(n)) throw new AppError(`قيمة "${label}" غير صحيحة`, 'VALIDATION');
  if (!allowZero && Math.abs(n) < EPS) throw new AppError(`قيمة "${label}" يجب أن تكون أكبر من صفر`, 'VALIDATION');
  if (min !== null && n < min - EPS) throw new AppError(`قيمة "${label}" يجب ألا تقل عن ${min}`, 'VALIDATION');
  return n;
}

function str(v, label, { required = false, max = 500 } = {}) {
  const s = (v === null || v === undefined) ? '' : String(v).trim();
  if (required && !s) throw new AppError(`من فضلك أدخل "${label}"`, 'VALIDATION');
  if (s.length > max) throw new AppError(`"${label}" أطول من المسموح (${max} حرف)`, 'VALIDATION');
  return s;
}

function idOrNull(v) {
  if (v === '' || v === null || v === undefined) return null;
  const n = Number(v);
  return Number.isInteger(n) && n > 0 ? n : null;
}

function reqId(v, label) {
  const n = idOrNull(v);
  if (!n) throw new AppError(`من فضلك اختر ${label}`, 'VALIDATION');
  return n;
}

function isoDate(v, label = 'التاريخ') {
  const s = str(v, label) || todayISO();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s) || isNaN(Date.parse(s))) throw new AppError(`${label} غير صحيح`, 'VALIDATION');
  return s;
}

function todayISO() {
  const d = new Date();
  const p = (x) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function nowISO() {
  return new Date().toISOString();
}

function fmtNum(n, d = 2) {
  return (Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
}

function fmtQty(n) {
  const v = round(n, 4);
  return Number.isInteger(v) ? String(v) : String(v);
}

function stamp(d = new Date()) {
  const p = (x) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
}

module.exports = {
  AppError, EPS, round, money, qtyR, costR, num, str, idOrNull, reqId, isoDate,
  todayISO, nowISO, fmtNum, fmtQty, stamp,
};
