'use strict';
/**
 * Server-side paging / sorting / searching so large tables never load fully
 * into the DOM. Sort columns are whitelisted to keep SQL safe.
 */
function paged(db, { select, from, where = [], params = [], sortMap = {}, defaultSort, sort, dir, page = 1, pageSize = 25, groupBy = '', all = false }) {
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const g = groupBy ? `GROUP BY ${groupBy}` : '';
  const orderCol = sortMap[sort] || defaultSort;
  const d = String(dir).toLowerCase() === 'asc' ? 'ASC' : 'DESC';
  const order = orderCol ? `ORDER BY ${orderCol} ${sortMap[sort] ? d : ''}` : '';
  const countSql = groupBy
    ? `SELECT COUNT(*) AS n FROM (SELECT 1 FROM ${from} ${w} ${g})`
    : `SELECT COUNT(*) AS n FROM ${from} ${w}`;
  const total = Number(db.val(countSql, ...params)) || 0;
  const size = Math.min(Math.max(Number(pageSize) || 25, 5), 1000);
  const pg = Math.max(1, Number(page) || 1);
  const limit = all ? '' : `LIMIT ${size} OFFSET ${(pg - 1) * size}`;
  const rows = db.all(`SELECT ${select} FROM ${from} ${w} ${g} ${order} ${limit}`, ...params);
  return { rows, total, page: pg, pageSize: size };
}

/** Adds a LIKE search across several columns. */
function addSearch(where, params, q, cols) {
  const s = (q || '').trim();
  if (!s) return;
  where.push('(' + cols.map((c) => `${c} LIKE ?`).join(' OR ') + ')');
  cols.forEach(() => params.push(`%${s}%`));
}

function addDateRange(where, params, col, from, to) {
  if (from) { where.push(`${col} >= ?`); params.push(from); }
  if (to) { where.push(`${col} <= ?`); params.push(to); }
}

module.exports = { paged, addSearch, addDateRange };
