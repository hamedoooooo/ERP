import { api, sys, isDesktop } from './api.js';
import { state, el, esc, $, $$, can, debounce, navigate } from './ui/dom.js';
import { icon } from './ui/icons.js';
import { toast, showError, formHtml, readForm, modal, formModal } from './ui/components.js';

const NAV = [
  { group: 'نظرة عامة', items: [['dashboard', 'لوحة التحكم', 'dashboard', 'dashboard.view']] },
  { group: 'الأصناف والمخزون', items: [['products', 'الأصناف', 'box', 'products.view'], ['inventory', 'المخزون والحركات', 'warehouse', 'inventory.view'], ['counts', 'الجرد', 'clipboard', ['stockcount.manage', 'inventory.view']]] },
  { group: 'المشتريات', items: [['purchases', 'فواتير الشراء', 'cart', 'purchases.view'], ['purchase-returns', 'مرتجعات الشراء', 'return', 'purchases.view'], ['suppliers', 'الموردون', 'truck', 'suppliers.manage']] },
  { group: 'المبيعات', items: [['sales', 'فواتير البيع', 'receipt', 'sales.view'], ['sales-returns', 'مرتجعات البيع', 'undo', 'sales.view'], ['customers', 'العملاء', 'users', 'customers.manage']] },
  { group: 'التصنيع', items: [['mo', 'أوامر التصنيع', 'factory', 'manufacturing.view'], ['boms', 'قوائم المواد (BOM)', 'layers', 'manufacturing.view'], ['workers', 'العمالة', 'worker', 'manufacturing.view']] },
  { group: 'المالية', items: [['payments', 'التحصيل والسداد', 'coins', 'payments.manage'], ['expenses', 'المصروفات', 'wallet', 'expenses.manage'], ['cash', 'الصندوق والبنك', 'cash', 'cash.view'], ['accounting', 'الحسابات والقوائم', 'ledger', 'accounting.view']] },
  { group: 'التقارير', items: [['reports', 'التقارير', 'chart', 'reports.view']] },
  { group: 'النظام', items: [['users', 'المستخدمون والصلاحيات', 'shield', 'users.manage'], ['settings', 'الإعدادات', 'settings', 'settings.manage'], ['backup', 'النسخ الاحتياطي', 'database', ['backup.create', 'backup.restore']], ['audit', 'سجل التدقيق', 'history', 'audit.view']] },
];

// route → [module, export]
const ROUTES = {
  dashboard: ['dashboard', 'dashboard'], products: ['products', 'products'], inventory: ['inventory', 'inventory'], counts: ['counts', 'counts'],
  purchases: ['docs', 'purchases'], 'purchase-returns': ['docs', 'purchaseReturns'], sales: ['docs', 'sales'], 'sales-returns': ['docs', 'salesReturns'],
  customers: ['parties', 'customers'], suppliers: ['parties', 'suppliers'], mo: ['manufacturing', 'orders'], boms: ['manufacturing', 'boms'], workers: ['manufacturing', 'workers'],
  payments: ['finance', 'payments'], expenses: ['finance', 'expenses'], cash: ['finance', 'cash'], accounting: ['accounting', 'accounting'],
  reports: ['reports', 'reports'], users: ['system', 'users'], settings: ['system', 'settings'], backup: ['system', 'backup'], audit: ['system', 'audit'],
};

export async function refreshSettings() {
  state.settings = await api('settings.get');
  const name = state.settings.company.appName;
  sys.setTitle(name);
  const b = $('.brand-name'); if (b) b.textContent = name;
  const s = $('.brand-sub'); if (s) s.textContent = state.settings.company.companyName || '';
}

function setUser(u) {
  state.user = u;
  state.perms = new Set(u ? u.permissions : []);
}

// ------------------------------------------------------------------ boot
async function boot() {
  const root = $('#app');
  try {
    const st = await api('auth.status');
    document.title = st.appName;
    if (st.needsSetup) return renderSetup(root, st);
    if (!st.user) return renderLogin(root, st);
    setUser(st.user);
    await startShell(root);
  } catch (e) {
    root.innerHTML = `<div class="auth"><div class="auth-card"><h1>تعذر فتح البرنامج</h1><div class="alert bad">${esc(e.message)}</div><button class="btn" data-reload>إعادة المحاولة</button></div></div>`;
  }
}

function renderSetup(root, st) {
  root.innerHTML = `<div class="auth"><form class="auth-card wide" autocomplete="off">
    <div class="brand-mark">${icon('factory', 'lg')}</div>
    <h1>مرحبًا بك</h1><p class="muted" style="margin-top:0">إعداد أول مرة: أنشئ حساب مدير النظام وبيانات منشأتك. كل البيانات تُحفظ على هذا الجهاز فقط.</p>
    ${formHtml([
    { name: 'companyName', label: 'اسم المنشأة / الورشة', required: true },
    { name: 'appName', label: 'اسم البرنامج (يمكن تغييره لاحقًا)', value: st.appName },
    { name: 'currencySymbol', label: 'رمز العملة', value: 'ج.م', required: true },
    { name: 'currencyCode', label: 'كود العملة', value: 'EGP' },
    { type: 'section', label: 'حساب مدير النظام' },
    { name: 'fullName', label: 'الاسم الكامل', required: true },
    { name: 'username', label: 'اسم المستخدم', required: true, value: 'admin' },
    { name: 'password', label: 'كلمة المرور', type: 'password', required: true, hint: '6 أحرف على الأقل' },
    { name: 'passwordConfirm', label: 'تأكيد كلمة المرور', type: 'password', required: true },
  ])}
    <div class="alert bad hide" data-err style="margin-top:12px"></div>
    <div class="form-actions"><button class="btn" type="submit">${icon('check', 'sm')} إنشاء الحساب والبدء</button></div></form></div>`;
  $('form', root).onsubmit = async (e) => {
    e.preventDefault();
    try { setUser(await api('auth.setup', readForm(e.target))); await startShell(root); } catch (err) { const x = $('[data-err]', root); x.textContent = err.message; x.classList.remove('hide'); }
  };
}

function renderLogin(root, st) {
  root.innerHTML = `<div class="auth"><form class="auth-card">
    <div class="brand-mark">${icon('factory', 'lg')}</div>
    <h1>${esc(st.appName)}</h1><p class="muted" style="margin-top:0">${esc(st.companyName || 'تسجيل الدخول')}</p>
    ${formHtml([{ name: 'username', label: 'اسم المستخدم', required: true }, { name: 'password', label: 'كلمة المرور', type: 'password', required: true }], {}, 'c1')}
    <div class="alert bad hide" data-err style="margin-top:12px"></div>
    <div class="form-actions"><button class="btn" type="submit">${icon('lock', 'sm')} دخول</button><span class="muted small">الإصدار ${esc(st.version)}</span></div></form></div>`;
  $('[name=username]', root).focus();
  $('form', root).onsubmit = async (e) => {
    e.preventDefault();
    try { setUser(await api('auth.login', readForm(e.target))); await startShell(root); } catch (err) { const x = $('[data-err]', root); x.textContent = err.message; x.classList.remove('hide'); }
  };
}

// ------------------------------------------------------------------ shell
async function startShell(root) {
  await refreshSettings();
  root.innerHTML = `<div class="shell">
    <aside class="side"><div class="brand"><div class="brand-mark">${icon('factory')}</div><div><div class="brand-name"></div><div class="brand-sub"></div></div></div>
      <nav class="nav" aria-label="القائمة الرئيسية"></nav>
      <div class="side-foot"><div class="who"><b>${esc(state.user.fullName)}</b>${esc(state.user.roleName)}</div>
        <button class="btn icon ghost" style="color:#C9C2AE;border-color:#33425e" data-pw title="تغيير كلمة المرور">${icon('key', 'sm')}</button>
        <button class="btn icon ghost" style="color:#C9C2AE;border-color:#33425e" data-logout title="تسجيل الخروج">${icon('logout', 'sm')}</button></div></aside>
    <div class="main"><header class="topbar"><div class="gsearch">${icon('search')}<input placeholder="بحث سريع: صنف، عميل، مورد، فاتورة، أمر تصنيع، تقرير…  (Ctrl+K)" aria-label="بحث"><div class="gsearch-results hide"></div></div>
      <div class="spacer"></div><span class="muted small" data-offline>${icon('shield', 'sm')} يعمل بدون إنترنت — البيانات على هذا الجهاز</span></header>
      <main class="content" id="page"></main></div></div>`;
  await refreshSettings();
  renderNav();
  bindSearch();
  $('[data-logout]', root).onclick = async () => { await api('auth.logout'); location.hash = ''; location.reload(); };
  $('[data-pw]', root).onclick = () => formModal({
    title: 'تغيير كلمة المرور', size: 'narrow', cols: 'c1',
    fields: [{ name: 'current', label: 'كلمة المرور الحالية', type: 'password', required: true }, { name: 'password', label: 'كلمة المرور الجديدة', type: 'password', required: true }, { name: 'passwordConfirm', label: 'تأكيد', type: 'password', required: true }],
    submit: async (v) => { await api('auth.changePassword', v); toast('تم تغيير كلمة المرور'); },
  });
  window.onhashchange = route;
  if (!location.hash) location.hash = can('dashboard.view') ? '#/dashboard' : '#/' + firstAllowed();
  else route();
}

function firstAllowed() {
  for (const g of NAV) for (const [id, , , perm] of g.items) if (can(perm)) return id;
  return 'dashboard';
}

async function renderNav() {
  const nav = $('.nav');
  let lowStock = 0;
  try { if (can('dashboard.view')) lowStock = (await api('dashboard.get')).kpis.low_stock; } catch (_) { /* ignore */ }
  nav.innerHTML = NAV.map((g) => {
    const items = g.items.filter(([, , , p]) => can(p));
    if (!items.length) return '';
    return `<div class="nav-group">${esc(g.group)}</div>` + items.map(([id, label, ic]) => `<a href="#/${id}" data-nav="${id}">${icon(ic)}<span>${esc(label)}</span>${id === 'products' && lowStock ? `<span class="badge" title="أصناف منخفضة المخزون">${lowStock}</span>` : ''}</a>`).join('');
  }).join('');
  markNav();
}
export const refreshNav = renderNav;

function markNav() {
  const cur = (location.hash.split('/')[1] || '').split('?')[0];
  $$('[data-nav]').forEach((a) => a.classList.toggle('active', a.dataset.nav === cur));
}

let routeSeq = 0;
async function route() {
  const seq = ++routeSeq;
  const [path, query] = location.hash.slice(2).split('?');
  const parts = path.split('/').filter(Boolean);
  const name = parts[0] || 'dashboard';
  const params = Object.fromEntries(new URLSearchParams(query || ''));
  markNav();
  const page = $('#page');
  const r = ROUTES[name];
  if (!r) { page.innerHTML = '<div class="empty"><b>الصفحة غير موجودة</b></div>'; return; }
  page.innerHTML = '<div class="empty muted">جارِ التحميل…</div>';
  try {
    const mod = await import(`./pages/${r[0]}.js`);
    if (seq !== routeSeq) return;
    page.innerHTML = '';
    await mod[r[1]](page, parts.slice(1), params);
    window.scrollTo(0, 0);
  } catch (e) {
    if (seq === routeSeq) page.innerHTML = `<div class="alert bad">${icon('alert', 'sm')} ${esc(e.message)}</div>`;
    if (!e.code) console.error(e);
  }
}

// ------------------------------------------------------------------ global search
const SEARCH_ROUTES = { product: (r) => `#/products/${r.id}`, customer: (r) => `#/customers/${r.id}`, supplier: (r) => `#/suppliers/${r.id}`, sale: (r) => `#/sales/${r.id}`, purchase: (r) => `#/purchases/${r.id}`, mo: (r) => `#/mo/${r.id}`, payment: () => '#/payments', expense: () => '#/expenses', report: (r) => `#/reports/${r.id}` };
function bindSearch() {
  const input = $('.gsearch input'); const box = $('.gsearch-results');
  let items = []; let sel = -1;
  const draw = () => {
    if (!items.length) { box.innerHTML = '<div class="gsr-item muted">لا توجد نتائج</div>'; box.classList.remove('hide'); return; }
    let g = ''; box.innerHTML = items.map((r, i) => `${r.group !== g ? `<div class="gsr-group">${esc(g = r.group)}</div>` : ''}<div class="gsr-item ${i === sel ? 'sel' : ''}" data-i="${i}"><span>${esc(r.title)}</span><small>${esc(r.sub || '')}</small></div>`).join('');
    box.classList.remove('hide');
  };
  const go = (r) => { box.classList.add('hide'); input.value = ''; navigate(SEARCH_ROUTES[r.route](r)); };
  input.addEventListener('input', debounce(async () => {
    const q = input.value.trim();
    if (!q) { box.classList.add('hide'); return; }
    try { items = await api('search.global', { q }); sel = items.length ? 0 : -1; draw(); } catch (e) { showError(e); }
  }, 220));
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') { sel = Math.min(items.length - 1, sel + 1); draw(); e.preventDefault(); }
    if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); draw(); e.preventDefault(); }
    if (e.key === 'Enter' && items[sel]) go(items[sel]);
    if (e.key === 'Escape') { box.classList.add('hide'); input.blur(); }
  });
  box.addEventListener('mousedown', (e) => { const it = e.target.closest('[data-i]'); if (it) { e.preventDefault(); go(items[Number(it.dataset.i)]); } });
  input.addEventListener('blur', () => setTimeout(() => box.classList.add('hide'), 150));
  document.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); input.focus(); } });
}

document.addEventListener('click', (e) => {
  if (e.target.closest('[data-reload]')) { location.reload(); return; }
  const t = e.target.closest('[data-href]');
  if (t && !e.target.closest('a,button,input,select,textarea')) navigate(t.dataset.href);
});
window.addEventListener('erp:auth-lost', () => { toast('انتهت الجلسة، سجّل الدخول مرة أخرى', 'warn'); setTimeout(() => location.reload(), 800); });
window.addEventListener('unhandledrejection', (e) => { if (e.reason && e.reason.message) showError(e.reason); });
if (isDesktop && window.erp.onAppEvent) window.erp.onAppEvent((ev) => { if (ev.type === 'toast') toast(ev.message, ev.kind || 'ok'); });

boot();

export { modal };
