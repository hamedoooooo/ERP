import { api } from '../api.js';
import { state, esc, fmt, qty, money, date, dateTime, can, today, $, $$, navigate, currencySymbol, KIND_LABELS, RATE_LABELS, PAY_LABELS } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { pageHead, dataTable, filterBar, bindFilters, formModal, confirmBox, toast, showError, modal, tabs, tableHtml, kvList, kvHtml, combo, formHtml, readForm, emptyState } from '../ui/components.js';
import { printMO } from '../ui/print.js';
import { lookup, invalidate, opt, whOptions, defaultWh, partyOptions, productComboOptions, lineEditor, moBadge } from './shared.js';

const LABOR_PAY = [{ value: 'accrued', label: 'مستحق للعامل (يُسدد لاحقًا)' }, { value: 'cash', label: 'مدفوع من الصندوق' }, { value: 'bank', label: 'مدفوع من البنك' }];
const COST_PAY = [{ value: 'cash', label: 'الصندوق' }, { value: 'bank', label: 'البنك' }, { value: 'accrued', label: 'مستحق (يُسدد لاحقًا)' }];
const OVERHEAD = [{ value: 'none', label: 'بدون' }, { value: 'percent', label: 'نسبة مئوية' }, { value: 'amount', label: 'مبلغ ثابت' }];
const overdue = (r) => r.due_date && r.due_date < today() && ['open', 'active'].includes(r.stage);

// =====================================================================================
// Orders
// =====================================================================================
export async function orders(root, parts, params) {
  if (parts[0] === 'new') return moNew(root, params);
  if (parts[0]) return moPage(root, Number(parts[0]), params);
  const costs = can('costs.view');
  const statuses = await lookup('moStatuses', true);
  root.innerHTML = pageHead('أوامر التصنيع', 'كل أمر يجمع الخامات المصروفة والعمالة والتكاليف المباشرة ليحسب التكلفة الفعلية والربح', can('manufacturing.manage') ? `<a class="btn" href="#/mo/new">${icon('plus', 'sm')} أمر تصنيع جديد</a>` : '')
    + `<div class="card">${filterBar([{ name: 'q', label: 'بحث', placeholder: 'رقم الأمر، المنتج، العميل، المواصفات' }, { name: 'from', label: 'من', type: 'date' }, { name: 'to', label: 'إلى', type: 'date' },
      { name: 'stage', label: 'المرحلة', type: 'select', options: [{ value: '', label: 'الكل' }, { value: 'open', label: 'لم يبدأ' }, { value: 'active', label: 'قيد التشغيل' }, { value: 'done', label: 'مكتمل' }, { value: 'cancelled', label: 'ملغي' }] },
      { name: 'status', label: 'الحالة', type: 'select', options: opt(statuses.filter((s) => s.active), 'name', 'code', 'الكل') },
      { name: 'overdue', label: 'المتأخرة فقط', type: 'check' }], { stage: params.stage || '', overdue: params.overdue ? true : '' })}<div data-t></div></div>`;
  let f = { stage: params.stage || '', overdue: params.overdue ? true : '' };
  const t = dataTable($('[data-t]', root), {
    title: 'أوامر التصنيع', exportName: 'manufacturing_orders', empty: 'لا توجد أوامر تصنيع', emptyIcon: 'factory', sort: 'date',
    fetch: (p) => api('mo.list', { ...f, ...p }),
    columns: [{ key: 'doc_no', label: 'الرقم', sort: true }, { key: 'date', label: 'التاريخ', type: 'date', sort: true }, { key: 'product_name', label: 'المنتج', sort: true },
      { key: 'qty', label: 'الكمية', type: 'qty', render: (r) => `${qty(r.qty)} ${esc(r.unit_name)}${r.produced_qty ? `<div class="small muted">أُنتج ${qty(r.produced_qty)}</div>` : ''}` },
      { key: 'customer_name', label: 'العميل' }, { key: 'status_name', label: 'الحالة', sort: true, render: moBadge, cls: 'keep' },
      { key: 'due_date', label: 'التسليم', type: 'date', sort: true, render: (r) => (r.due_date ? `<span class="${overdue(r) ? 'badge bad' : ''}">${esc(date(r.due_date))}</span>` : '') },
      ...(costs ? [{ key: 'total_cost', label: 'التكلفة الفعلية', type: 'money' }, { key: 'unit_cost', label: 'تكلفة الوحدة', type: 'money' }] : []), { key: 'agreed_price', label: 'السعر المتفق', type: 'money' }],
    rowClass: (r) => (r.stage === 'cancelled' ? 'void' : ''),
    onRow: (r) => navigate(`#/mo/${r.id}`),
  });
  bindFilters($('.filters', root), (v) => { f = v; t.reload(); });
}

// ------------------------------------------------------------------ new order
async function moNew(root, params) {
  const [prods, whs, custs, statuses] = await Promise.all([api('products.options', { stockable: 1 }), whOptions(), lookup('customers', true), lookup('moStatuses', true)]);
  const st = state0();
  const productOpts = productComboOptions(prods);
  const defWh = await defaultWh();
  root.innerHTML = pageHead('أمر تصنيع جديد', 'اختر المنتج؛ إذا كانت له قائمة مواد (BOM) ستُحسب الكميات المخططة تلقائيًا ويمكنك تعديلها', '', '<a href="#/mo">أوامر التصنيع</a> / جديد')
    + `<div class="card"><div class="form">
      <div class="field full"><label>المنتج المطلوب تصنيعه <span class="req">*</span></label><div class="combo" data-product><input class="inp" placeholder="ابحث عن المنتج… (يجب أن يكون صنفًا مخزنيًا)"><input type="hidden" name="product_id"></div>
        <span class="hint">لا يوجد المنتج؟ <a href="#/products">أضفه من صفحة الأصناف</a> بنوع "منتج نهائي".</span></div>
      <div class="field"><label>قائمة المواد (BOM)</label><select class="inp" name="bom_id"><option value="none">بدون قائمة مواد</option></select></div>
      <div class="field"><label>الكمية المطلوبة <span class="req">*</span></label><input class="inp num" type="number" step="any" min="0" name="qty" value="1"></div>
      <div class="field"><label>العميل (اختياري)</label><div class="combo" data-customer><input class="inp" placeholder="للتصنيع حسب الطلب"><input type="hidden" name="customer_id"></div></div>
      <div class="field"><label>السعر المتفق عليه للوحدة (${esc(currencySymbol())})</label><input class="inp num" type="number" step="any" min="0" name="agreed_price"></div>
      <div class="field"><label>التاريخ</label><input class="inp" type="date" name="date" value="${today()}"></div>
      <div class="field"><label>تاريخ البدء</label><input class="inp" type="date" name="start_date"></div>
      <div class="field"><label>تاريخ التسليم</label><input class="inp" type="date" name="due_date"></div>
      <div class="field"><label>الحالة المبدئية</label><select class="inp" name="status">${statuses.filter((s) => s.stage === 'open' && s.active).map((s) => `<option value="${esc(s.code)}">${esc(s.name)}</option>`).join('')}</select></div>
      <div class="field"><label>مخزن صرف الخامات</label><select class="inp" name="warehouse_id">${whs.map((w) => `<option value="${w.value}" ${w.value === defWh ? 'selected' : ''}>${esc(w.label)}</option>`).join('')}</select></div>
      <div class="field"><label>مخزن استلام الإنتاج</label><select class="inp" name="output_warehouse_id">${whs.map((w) => `<option value="${w.value}" ${w.value === defWh ? 'selected' : ''}>${esc(w.label)}</option>`).join('')}</select></div>
      <div class="field"><label>المصروفات الصناعية غير المباشرة</label><select class="inp" name="overhead_type">${OVERHEAD.map((o) => `<option value="${o.value}" ${o.value === st.overheadType ? 'selected' : ''}>${o.label}</option>`).join('')}</select></div>
      <div class="field"><label>قيمتها</label><input class="inp num" type="number" step="any" min="0" name="overhead_value" value="${esc(st.overheadValue)}"><span class="hint" data-oh-hint></span></div>
      <div class="field full"><label>المواصفات</label><textarea class="inp" rows="3" name="specs" placeholder="الخامة، اللون، التشطيب، أي تفاصيل فنية…"></textarea></div>
      <div class="field full"><label>المقاسات</label><textarea class="inp" rows="2" name="dimensions" placeholder="الطول × العرض × الارتفاع، أو أي مقاسات أخرى"></textarea></div>
      <div class="field full"><label>ملاحظات</label><textarea class="inp" rows="2" name="notes"></textarea></div>
    </div></div>
    <div class="card"><div class="card-title">${icon('layers', 'sm')} المواد المخططة (الخامات والإكسسوارات)</div><p class="muted small" style="margin-top:0">الكميات المخططة للمقارنة مع الفعلي وحساب الهالك. الصرف الفعلي من المخزن يتم لاحقًا من صفحة الأمر.</p><div data-lines></div></div>
    <div class="alert bad hide" data-err></div>
    <div class="form-actions"><button class="btn" data-save>${icon('save', 'sm')} إنشاء أمر التصنيع</button><a class="btn ghost" href="#/mo">إلغاء</a></div>`;
  const ohHint = () => { const tp = $('[name=overhead_type]', root).value; $('[data-oh-hint]', root).textContent = tp === 'percent' ? `% من ${st.overheadBase === 'labor' ? 'تكلفة العمالة' : 'التكلفة المباشرة (خامات + عمالة + أخرى)'}` : tp === 'amount' ? 'مبلغ ثابت يُحمّل عند الإكمال' : ''; };
  $('[name=overhead_type]', root).onchange = ohHint; ohHint();

  const matProds = prods;
  let bomProducts = new Set();
  const ed = lineEditor($('[data-lines]', root), {
    products: matProds, addLabel: 'إضافة مادة',
    columns: [{ key: 'planned_qty', label: 'الكمية المخططة', type: 'number', width: '140px' }, { key: 'unit', label: 'الوحدة', type: 'computed', format: 'text', compute: (l, p) => (p ? p.unit_name : '') },
      { key: 'stock', label: 'المتاح', type: 'computed', format: 'qty', compute: (l, p) => (p ? p.qty : 0) }],
    info: (l, p) => `${KIND_LABELS[p.kind] || ''}${Number(l.planned_qty) > Number(p.qty) ? ' · <span class="neg">الكمية المخططة أكبر من المتاح حاليًا</span>' : ''}`,
  });
  const loadBom = async () => {
    const bid = $('[name=bom_id]', root).value;
    bomProducts = new Set();
    if (bid === 'none') return;
    const b = await api('boms.get', { id: Number(bid) });
    const q = Number($('[name=qty]', root).value) || 0;
    const lines = b.items.map((i) => ({ product_id: i.product_id, planned_qty: Math.round(i.gross_qty * q / (b.output_qty || 1) * 10000) / 10000 }));
    lines.forEach((l) => bomProducts.add(l.product_id));
    ed.set(lines);
  };
  let productId = null;
  combo($('[data-product]', root), {
    options: productOpts, emptyHint: 'أضف المنتج من صفحة الأصناف',
    onChange: async (o) => {
      productId = o ? Number(o.value) : null;
      const sel = $('[name=bom_id]', root);
      sel.innerHTML = '<option value="none">بدون قائمة مواد</option>';
      if (!productId) return;
      const boms = await api('boms.list', { product_id: productId, onlyActive: true });
      boms.forEach((b) => sel.insertAdjacentHTML('beforeend', `<option value="${b.id}" ${b.is_default ? 'selected' : ''}>${esc(b.name)}${b.is_default ? ' (افتراضية)' : ''}</option>`));
      const p = o.p; if (p && !$('[name=agreed_price]', root).value && p.sale_price) $('[name=agreed_price]', root).value = p.sale_price;
      await loadBom();
    },
    value: params.product,
  });
  const custCombo = combo($('[data-customer]', root), { options: partyOptions(custs), value: params.customer });
  $('[name=bom_id]', root).onchange = () => loadBom().catch(showError);
  $('[name=qty]', root).addEventListener('change', () => { if ($('[name=bom_id]', root).value !== 'none') loadBom().catch(showError); });
  $('[data-save]', root).onclick = async (e) => {
    const err = $('[data-err]', root); err.classList.add('hide');
    const v = readForm($('.card', root));
    const lines = ed.get();
    const inEditor = new Set(lines.map((l) => Number(l.product_id)));
    const materials = [...lines.map((l) => ({ product_id: l.product_id, planned_qty: l.planned_qty || 0 })), ...[...bomProducts].filter((pid) => !inEditor.has(Number(pid))).map((pid) => ({ product_id: pid, planned_qty: 0 }))];
    e.target.disabled = true;
    try {
      const r = await api('mo.create', { ...v, product_id: productId, customer_id: custCombo.get() || null, materials });
      toast(`تم إنشاء أمر التصنيع ${r.doc_no}`);
      navigate(`#/mo/${r.id}`);
    } catch (x) { err.textContent = x.message; err.classList.remove('hide'); err.scrollIntoView({ block: 'center' }); } finally { e.target.disabled = false; }
  };
}

function state0() {
  return (state.settings && state.settings.manufacturing) || { overheadType: 'none', overheadValue: 0, overheadBase: 'direct' };
}

// ------------------------------------------------------------------ order detail
async function moPage(root, id, params) {
  const costs = can('costs.view');
  const manage = can('manufacturing.manage');
  let tab = params.tab || 'materials';
  const mo = await api('mo.get', { id });
  const statuses = await lookup('moStatuses', true);
  const editable = manage && ['open', 'active'].includes(mo.stage);
  const p = mo.profit;
  const statusChoices = statuses.filter((s) => s.active && ['open', 'active'].includes(s.stage));

  root.innerHTML = pageHead(`أمر تصنيع ${mo.doc_no}`, `${mo.product_name} — ${qty(mo.qty)} ${mo.unit_name}${mo.customer_name ? ' — ' + mo.customer_name : ''}`, `
      <button class="btn ghost" data-print>${icon('printer', 'sm')} طباعة</button>
      ${editable ? `<button class="btn ghost" data-edit>${icon('edit', 'sm')} تعديل البيانات</button><button class="btn sec" data-issue>${icon('upload', 'sm')} صرف خامات</button><button class="btn" data-complete>${icon('check', 'sm')} إكمال التصنيع</button>` : ''}
      ${mo.stage === 'done' && can('sales.create') && mo.produced_qty > (p ? p.sold_qty : 0) ? `<a class="btn gold" href="#/sales/new?mo=${mo.id}">${icon('receipt', 'sm')} فاتورة بيع</a>` : ''}
      ${mo.stage === 'done' && manage ? `<button class="btn ghost" data-reopen>${icon('refresh', 'sm')} إعادة فتح</button>` : ''}
      ${editable ? `<button class="btn ghost" data-cancel>${icon('ban', 'sm')} إلغاء الأمر</button>` : ''}`,
  '<a href="#/mo">أوامر التصنيع</a> / ' + esc(mo.doc_no))
    + `${mo.stage === 'cancelled' ? `<div class="alert bad">${icon('ban', 'sm')} هذا الأمر ملغي.</div>` : ''}
    ${overdue(mo) ? `<div class="alert warn">${icon('clock', 'sm')} تاريخ التسليم (${esc(date(mo.due_date))}) قد فات.</div>` : ''}
    <div class="grid g4" style="margin-bottom:14px">
      <div class="kpi"><div class="l">${icon('flag', 'sm')} الحالة</div><div class="v" style="font-size:16px;margin-top:8px">${moBadge(mo)}
        ${editable && statusChoices.length > 1 ? `<select class="inp" data-status style="margin-top:8px;min-height:30px">${statusChoices.map((s) => `<option value="${esc(s.code)}" ${s.code === mo.status ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select>` : ''}</div></div>
      <div class="kpi"><div class="l">${icon('cube', 'sm')} الكمية</div><div class="v num">${qty(mo.qty)}<small>${esc(mo.unit_name)}</small></div><div class="h">${mo.produced_qty ? `المُنتج فعلًا: ${qty(mo.produced_qty)}` : 'لم يُستلم إنتاج بعد'}</div></div>
      ${costs ? `<div class="kpi"><div class="l">${icon('calc', 'sm')} التكلفة ${mo.stage === 'done' ? 'النهائية' : 'حتى الآن'}</div><div class="v num">${fmt(p.total_cost)}<small>${esc(currencySymbol())}</small></div><div class="h">تكلفة الوحدة ${money(p.unit_cost)}</div></div>
      <div class="kpi ${p.gross_profit < 0 ? 'bad' : 'good'}"><div class="l">${icon('chart', 'sm')} ${p.revenue_basis === 'actual' ? 'الربح الفعلي' : 'الربح المتوقع'}</div><div class="v num ${p.gross_profit < 0 ? 'neg' : ''}">${p.revenue_basis === 'none' ? '—' : fmt(p.gross_profit)}</div><div class="h">${p.revenue_basis === 'none' ? 'حدد السعر المتفق عليه لحساب الربح المتوقع' : `إيراد ${money(p.revenue)} · هامش ${p.margin_pct === null ? '—' : fmt(p.margin_pct, 1) + '%'}`}</div></div>`
    : `<div class="kpi"><div class="l">${icon('calendar', 'sm')} التسليم</div><div class="v" style="font-size:16px">${esc(date(mo.due_date))}</div></div><div></div>`}
    </div>
    <div class="tabs"></div><div data-body></div>`;

  const TABS = [{ id: 'materials', label: 'المواد', icon: 'layers' }, { id: 'moves', label: 'سجل الصرف والرد', icon: 'history', badge: mo.moves.length || '' },
    { id: 'labor', label: 'العمالة', icon: 'worker', badge: mo.labor.filter((l) => l.status === 'posted').length || '' }, { id: 'costs', label: 'تكاليف مباشرة أخرى', icon: 'wallet', badge: mo.other_costs.filter((l) => l.status === 'posted').length || '' },
    ...(costs ? [{ id: 'profit', label: 'التكلفة والربحية', icon: 'chart' }] : []), { id: 'info', label: 'البيانات والمواصفات', icon: 'file' }];
  const body = $('[data-body]', root);
  const reload = (t = tab) => { navigate(`#/mo/${id}?tab=${t}`); };
  const guard = (fn) => async (...a) => { try { await fn(...a); } catch (e) { showError(e); } };

  const VIEWS = {
    materials() {
      const rows = mo.materials;
      body.innerHTML = `<div class="card">${editable ? `<div class="row between" style="margin-bottom:10px"><span class="muted small">المخطط يأتي من قائمة المواد؛ الفعلي = المصروف − المرتجع. الفرق الموجب = هالك/زيادة استهلاك.</span><button class="btn ghost sm" data-addplan>${icon('plus', 'sm')} إضافة مادة للخطة</button></div>` : ''}
        ${rows.length ? tableHtml([
    { key: 'product_name', label: 'المادة', render: (r) => `${esc(r.product_name)}<div class="small muted">${esc(r.product_code)} · ${esc(KIND_LABELS[r.kind] || '')}</div>` }, { key: 'unit_name', label: 'الوحدة' },
    { key: 'planned_qty', label: 'المخطط', type: 'qty' }, { key: 'actual_qty', label: 'الفعلي', type: 'qty' },
    { key: 'diff_qty', label: 'الفرق', type: 'qty', render: (r) => `<span class="${r.diff_qty > 0 ? 'neg' : r.diff_qty < 0 ? 'pos' : ''}">${qty(r.diff_qty)}</span>${r.waste_pct !== null && r.diff_qty > 0 ? ` <span class="badge bad">${fmt(r.waste_pct, 1)}%</span>` : ''}` },
    { key: 'remaining_to_issue', label: 'باقي للصرف', type: 'qty' }, { key: 'stock_qty', label: 'المتاح بالمخزن', type: 'qty' },
    ...(costs ? [{ key: 'unit_cost', label: 'تكلفة الوحدة', type: 'money' }, { key: 'actual_cost', label: 'التكلفة الفعلية', type: 'money' }] : []),
  ], rows, {
    totals: costs ? { actual_cost: rows.reduce((s, r) => s + (r.actual_cost || 0), 0) } : null,
    actions: editable ? (r) => `<button class="link-btn" data-plan="${r.product_id}" title="تعديل الكمية المخططة">${icon('edit', 'sm')}</button>${r.actual_qty > 0 ? `<button class="link-btn muted" data-ret="${r.product_id}">${icon('undo', 'sm')} رد للمخزن</button>` : ''}` : null,
  }) : emptyState('لا توجد مواد مخططة أو مصروفة', editable ? 'اصرف خامات مباشرة أو أضف مواد للخطة' : '', 'layers')}</div>`;
      if (!editable) return;
      body.onclick = guard(async (e) => {
        const pl = e.target.closest('[data-plan]'); const rt = e.target.closest('[data-ret]');
        if (e.target.closest('[data-addplan]')) return planForm();
        if (pl) { const r = rows.find((x) => x.product_id === Number(pl.dataset.plan)); return planForm(r); }
        if (rt) {
          const r = rows.find((x) => x.product_id === Number(rt.dataset.ret));
          const ok = await formModal({
            title: `رد ${r.product_name} للمخزن`, size: 'narrow', cols: 'c1', values: { qty: r.actual_qty, date: today(), warehouse_id: mo.warehouse_id },
            fields: [{ name: 'qty', label: `الكمية (صافي المصروف ${qty(r.actual_qty)} ${r.unit_name})`, type: 'number', min: 0, required: true }, { name: 'warehouse_id', label: 'إلى مخزن', type: 'select', options: await whOptions() }, { name: 'date', label: 'التاريخ', type: 'date' }, { name: 'notes', label: 'ملاحظات' }],
            extra: '<div class="alert info" style="margin-top:10px">تُرد المادة بنفس متوسط تكلفة صرفها لهذا الأمر.</div>',
            submit: (v) => api('mo.returnMaterial', { ...v, mo_id: mo.id, product_id: r.product_id }),
          });
          if (ok) { toast(`تم الرد ${ok.doc_no}`); reload('materials'); }
        }
      });
    },
    moves() {
      body.innerHTML = `<div class="card">${mo.moves.length ? tableHtml([{ key: 'doc_no', label: 'المستند' }, { key: 'date', label: 'التاريخ', type: 'date' }, { key: 'product_name', label: 'المادة' },
        { key: 'qty', label: 'الكمية', render: (r) => `<span class="${r.qty < 0 ? 'pos' : ''}">${r.qty < 0 ? 'رد ' + qty(-r.qty) : 'صرف ' + qty(r.qty)}</span>` }, { key: 'warehouse_name', label: 'المخزن' },
        ...(costs ? [{ key: 'unit_cost', label: 'التكلفة', type: 'money' }, { key: 'total_cost', label: 'القيمة', type: 'money' }] : []), { key: 'user_name', label: 'المستخدم' }, { key: 'notes', label: 'ملاحظات' }], mo.moves)
        : emptyState('لم تُصرف أي خامات لهذا الأمر بعد', '', 'history')}</div>`;
    },
    labor() {
      const rows = mo.labor;
      body.innerHTML = `<div class="card">${editable ? `<div class="row between" style="margin-bottom:10px"><span class="muted small">الأجر بالساعة / باليوم / بالقطعة / مبلغ ثابت / يدوي. "مستحق" يُسجل في الأجور المستحقة ويُسدد من الصندوق لاحقًا.</span><button class="btn sm" data-add>${icon('plus', 'sm')} تسجيل عمالة</button></div>` : ''}
        ${rows.length ? tableHtml([{ key: 'date', label: 'التاريخ', type: 'date' }, { key: 'worker_name', label: 'العامل' }, { key: 'rate_type_label', label: 'نوع الأجر' }, { key: 'qty', label: 'الكمية', type: 'qty' },
          ...(costs ? [{ key: 'rate', label: 'السعر', type: 'money' }, { key: 'total', label: 'الإجمالي', type: 'money' }] : []), { key: 'pay_label', label: 'الدفع' }, { key: 'notes', label: 'ملاحظات' },
          { key: 'status', label: '', render: (r) => (r.status === 'void' ? '<span class="badge bad">ملغي</span>' : ''), cls: 'keep' }], rows,
        { rowClass: (r) => (r.status === 'void' ? 'void' : ''), totals: costs ? { total: rows.filter((r) => r.status === 'posted').reduce((s, r) => s + r.total, 0) } : null,
          actions: editable ? (r) => (r.status === 'posted' ? `<button class="link-btn danger" data-void="${r.id}">${icon('ban', 'sm')} إلغاء</button>` : '') : null })
        : emptyState('لا توجد عمالة مسجلة', '', 'worker')}</div>`;
      body.onclick = guard(async (e) => {
        if (e.target.closest('[data-add]')) { if (await laborForm(mo)) reload('labor'); return; }
        const v = e.target.closest('[data-void]');
        if (v) { const c = await confirmBox('إلغاء سجل العمالة؟ سيُعكس قيده المحاسبي.', { danger: true, ok: 'إلغاء السجل' }); if (c) { await api('mo.voidLabor', { id: Number(v.dataset.void) }); toast('تم الإلغاء'); reload('labor'); } }
      });
    },
    costs() {
      const rows = mo.other_costs;
      body.innerHTML = `<div class="card">${editable ? `<div class="row between" style="margin-bottom:10px"><span class="muted small">تكاليف مباشرة تخص هذا الأمر فقط: نقل، تشغيل خارجي، دهان عند الغير، كهرباء مخصصة…</span><button class="btn sm" data-add>${icon('plus', 'sm')} إضافة تكلفة</button></div>` : ''}
        ${rows.length ? tableHtml([{ key: 'date', label: 'التاريخ', type: 'date' }, { key: 'description', label: 'البيان' }, ...(costs ? [{ key: 'amount', label: 'المبلغ', type: 'money' }] : []), { key: 'pay_label', label: 'الدفع' }, { key: 'notes', label: 'ملاحظات' },
          { key: 'status', label: '', render: (r) => (r.status === 'void' ? '<span class="badge bad">ملغي</span>' : ''), cls: 'keep' }], rows,
        { rowClass: (r) => (r.status === 'void' ? 'void' : ''), totals: costs ? { amount: rows.filter((r) => r.status === 'posted').reduce((s, r) => s + r.amount, 0) } : null,
          actions: editable ? (r) => (r.status === 'posted' ? `<button class="link-btn danger" data-void="${r.id}">${icon('ban', 'sm')} إلغاء</button>` : '') : null })
        : emptyState('لا توجد تكاليف مباشرة أخرى', '', 'wallet')}</div>`;
      body.onclick = guard(async (e) => {
        if (e.target.closest('[data-add]')) {
          const ok = await formModal({
            title: 'تكلفة مباشرة على الأمر', values: { date: today(), pay_method: 'cash' },
            fields: [{ name: 'description', label: 'البيان', required: true, full: true }, { name: 'amount', label: `المبلغ (${currencySymbol()})`, type: 'number', min: 0, required: true },
              { name: 'pay_method', label: 'الدفع', type: 'select', options: COST_PAY }, { name: 'date', label: 'التاريخ', type: 'date' }, { name: 'notes', label: 'ملاحظات' }],
            submit: (v) => api('mo.addCost', { ...v, mo_id: mo.id }),
          });
          if (ok) { toast('تمت الإضافة'); reload('costs'); }
          return;
        }
        const v = e.target.closest('[data-void]');
        if (v) { const c = await confirmBox('إلغاء هذه التكلفة؟', { danger: true, ok: 'إلغاء' }); if (c) { await api('mo.voidCost', { id: Number(v.dataset.void) }); toast('تم الإلغاء'); reload('costs'); } }
      });
    },
    profit() {
      const parts = [['الخامات', p.material, '#1F4B3F'], ['الإكسسوارات', p.accessories, '#A8823C'], ['العمالة', p.labor, '#16233B'], ['تكاليف مباشرة أخرى', p.other, '#5E7C9A'], ['مصروفات صناعية', p.overhead, '#8B3A3A']];
      const tot = p.total_cost || 0;
      body.innerHTML = `<div class="grid g2">
        <div class="card"><div class="card-title">${icon('calc', 'sm')} تفصيل التكلفة ${mo.stage === 'done' ? '(نهائية)' : '(حتى الآن — المصروفات الصناعية تقديرية حتى الإكمال)'}</div>
          ${tot > 0 ? `<div class="cost-bar">${parts.filter((x) => x[1] > 0).map((x) => `<i style="width:${(x[1] / tot) * 100}%;background:${x[2]}" title="${esc(x[0])}"></i>`).join('')}</div>` : ''}
          ${kvHtml([...parts.map(([l, v, c]) => [l, `<span class="num"><i style="display:inline-block;width:9px;height:9px;border-radius:2px;background:${c};margin-inline-end:6px"></i>${money(v)}${tot ? ` <span class="muted small">(${fmt((v / tot) * 100, 1)}%)</span>` : ''}</span>`]),
    ['إجمالي التكلفة', `<b class="num">${money(tot)}</b>`], ['الكمية', `${qty(mo.produced_qty || mo.qty)} ${esc(mo.unit_name)}`], ['تكلفة الوحدة', `<b class="num">${money(p.unit_cost)}</b>`]])}</div>
        <div class="card"><div class="card-title">${icon('chart', 'sm')} الربحية</div>
          ${kvHtml([['أساس الإيراد', p.revenue_basis === 'actual' ? 'فواتير بيع فعلية' : p.revenue_basis === 'expected' ? 'السعر المتفق عليه (متوقع)' : 'لا يوجد سعر ولا مبيعات'],
    ['الكمية المباعة', qty(p.sold_qty)], ['الإيراد', `<span class="num">${money(p.revenue)}</span>`], ['التكلفة المقابلة', `<span class="num">${money(p.cost_basis)}</span>`],
    ['مجمل الربح', `<b class="num ${p.gross_profit < 0 ? 'neg' : 'pos'}">${money(p.gross_profit)}</b>`], ['هامش الربح من الإيراد', p.margin_pct === null ? '—' : fmt(p.margin_pct, 1) + '%'], ['نسبة الربح على التكلفة', p.markup_pct === null ? '—' : fmt(p.markup_pct, 1) + '%']])}
          <div class="alert info" style="margin-top:12px">${icon('percent', 'sm')} سعر البيع المقترح للوحدة (${p.pricing.method === 'markup' ? 'نسبة إضافة على التكلفة' : 'هامش ربح من سعر البيع'} ${fmt(p.pricing.pct, 1)}%): <b class="num">&nbsp;${money(p.pricing.suggested_unit_price)}</b></div>
          ${mo.sales.length ? `<div class="card-title" style="margin-top:14px">فواتير البيع المرتبطة</div>${tableHtml([{ key: 'doc_no', label: 'الفاتورة', render: (r) => `<a href="#/sales/${r.id}">${esc(r.doc_no)}</a>` }, { key: 'date', label: 'التاريخ', type: 'date' }, { key: 'qty', label: 'الكمية', type: 'qty' }, { key: 'net_total', label: 'الصافي', type: 'money' }, { key: 'status', label: '', render: (r) => (r.status === 'void' ? '<span class="badge bad">ملغاة</span>' : '') }], mo.sales)}` : ''}
        </div></div>`;
    },
    info() {
      body.innerHTML = `<div class="grid g2"><div class="card">${kvList([['رقم الأمر', mo.doc_no], ['التاريخ', date(mo.date)], ['المنتج', `${mo.product_name} (${mo.product_code})`], ['قائمة المواد', mo.bom_name || 'بدون'],
        ['العميل', mo.customer_name || '—'], ['السعر المتفق عليه للوحدة', money(mo.agreed_price)], ['تاريخ البدء', date(mo.start_date)], ['تاريخ التسليم', date(mo.due_date)], ['تاريخ الإكمال', date(mo.completed_at)],
        ['مخزن الخامات', mo.warehouse_name], ['مخزن الإنتاج', mo.output_warehouse_name], ['المصروفات الصناعية', mo.overhead_type === 'none' ? 'بدون' : mo.overhead_type === 'percent' ? `${fmt(mo.overhead_value, 2)}%` : money(mo.overhead_value)],
        ['أنشأه', `${mo.user_name || ''} — ${dateTime(mo.created_at)}`]])}</div>
        <div class="card"><div class="card-title">المواصفات</div><div style="white-space:pre-wrap">${esc(mo.specs || '—')}</div><div class="card-title" style="margin-top:14px">المقاسات</div><div style="white-space:pre-wrap">${esc(mo.dimensions || '—')}</div>
        <div class="card-title" style="margin-top:14px">ملاحظات</div><div style="white-space:pre-wrap">${esc(mo.notes || '—')}</div></div></div>`;
    },
  };
  const show = (t) => { tab = t; body.onclick = null; VIEWS[t](); };
  tabs($('.tabs', root), TABS, TABS.some((x) => x.id === tab) ? tab : 'materials', show);
  show(TABS.some((x) => x.id === tab) ? tab : 'materials');

  // ---------------- actions
  async function planForm(r) {
    const prods = r ? null : await api('products.options', { stockable: 1 });
    const ok = await formModal({
      title: r ? `الكمية المخططة — ${r.product_name}` : 'إضافة مادة للخطة', size: 'narrow', cols: 'c1', values: r ? { planned_qty: r.planned_qty } : {},
      fields: [...(r ? [] : [{ name: 'product_id', label: 'المادة', type: 'combo', required: true }]), { name: 'planned_qty', label: 'الكمية المخططة', type: 'number', min: 0, required: true },
        ...(r && r.actual_qty === 0 ? [{ name: 'remove', label: 'حذف المادة من الخطة', type: 'checkbox' }] : [])],
      combos: r ? {} : { product_id: { options: productComboOptions(prods.filter((x) => x.id !== mo.product_id)) } },
      submit: (v) => api('mo.setPlanned', { mo_id: mo.id, product_id: r ? r.product_id : v.product_id, planned_qty: v.planned_qty, remove: !!v.remove }),
    });
    if (ok) { toast('تم التحديث'); reload('materials'); }
  }

  const bind = (s, fn) => { const x = $(s, root); if (x) x.onclick = guard(fn); };
  bind('[data-print]', async () => printMO(mo));
  const stSel = $('[data-status]', root);
  if (stSel) stSel.onchange = guard(async () => { await api('mo.setStatus', { id: mo.id, status: stSel.value }); toast('تم تغيير الحالة'); reload(tab); });
  bind('[data-edit]', async () => {
    const [custs, whs] = await Promise.all([lookup('customers', true), whOptions()]);
    const hasMoves = mo.moves.length > 0;
    const ok = await formModal({
      title: `تعديل ${mo.doc_no}`, size: 'wide', values: { ...mo },
      fields: [{ name: 'qty', label: `الكمية (${mo.unit_name})`, type: 'number', min: 0, required: true, hint: mo.bom_id ? 'تغيير الكمية يعيد حساب الكميات المخططة من قائمة المواد' : '' },
        { name: 'customer_id', label: 'العميل', type: 'combo' }, { name: 'agreed_price', label: 'السعر المتفق عليه للوحدة', type: 'number', min: 0 },
        { name: 'start_date', label: 'تاريخ البدء', type: 'date' }, { name: 'due_date', label: 'تاريخ التسليم', type: 'date' },
        { name: 'warehouse_id', label: 'مخزن الخامات', type: 'select', options: whs, readonly: hasMoves, hint: hasMoves ? 'لا يمكن تغييره بعد صرف خامات' : '' },
        { name: 'output_warehouse_id', label: 'مخزن الإنتاج', type: 'select', options: whs },
        { name: 'overhead_type', label: 'المصروفات الصناعية', type: 'select', options: OVERHEAD }, { name: 'overhead_value', label: 'قيمتها', type: 'number', min: 0 },
        { name: 'specs', label: 'المواصفات', type: 'textarea', full: true, rows: 3 }, { name: 'dimensions', label: 'المقاسات', type: 'textarea', full: true }, { name: 'notes', label: 'ملاحظات', type: 'textarea', full: true }],
      combos: { customer_id: { options: partyOptions(custs) } },
      submit: (v) => api('mo.update', { ...v, id: mo.id, warehouse_id: hasMoves ? undefined : v.warehouse_id }),
    });
    if (ok) { toast('تم الحفظ'); reload(tab); }
  });
  bind('[data-issue]', async () => { if (await issueForm(mo)) reload('materials'); });
  bind('[data-complete]', async () => {
    const whs = await whOptions();
    const c = mo.profit;
    const summary = c ? `<div class="sum-strip" style="margin-top:12px"><div><span>خامات</span><b>${fmt(c.material)}</b></div><div><span>إكسسوارات</span><b>${fmt(c.accessories)}</b></div><div><span>عمالة</span><b>${fmt(c.labor)}</b></div><div><span>أخرى</span><b>${fmt(c.other)}</b></div><div><span>صناعية (تقديري)</span><b>${fmt(c.overhead)}</b></div><div><span>الإجمالي</span><b>${fmt(c.total_cost)}</b></div></div>` : '';
    const pendingMats = mo.materials.filter((m) => m.remaining_to_issue > 0);
    const noCosts = !mo.moves.length && !mo.labor.some((l) => l.status === 'posted') && !mo.other_costs.some((l) => l.status === 'posted');
    const run = async () => formModal({
      title: `إكمال التصنيع — ${mo.doc_no}`, values: { produced_qty: mo.qty, date: today(), output_warehouse_id: mo.output_warehouse_id },
      fields: [{ name: 'produced_qty', label: `الكمية المنتجة فعلًا (${mo.unit_name})`, type: 'number', min: 0, required: true }, { name: 'date', label: 'تاريخ الإكمال', type: 'date' },
        { name: 'output_warehouse_id', label: 'استلام الإنتاج في مخزن', type: 'select', options: whs },
        ...(noCosts ? [{ name: 'allowZeroCost', label: 'لم تُسجل أي تكاليف على هذا الأمر — أؤكد الإكمال بتكلفة صفرية', type: 'checkbox', full: true }] : [])],
      extra: `${pendingMats.length ? `<div class="alert warn" style="margin-top:12px">${icon('alert', 'sm')} توجد ${pendingMats.length} مادة لم تُصرف كميتها المخططة بالكامل. التكلفة تُحسب من المصروف فعليًا فقط.</div>` : ''}${summary}
        <div class="alert info">سيتم تحميل المصروفات الصناعية، ونقل التكلفة الكاملة من "تحت التشغيل" إلى مخزون المنتج التام بتكلفة الوحدة = الإجمالي ÷ الكمية المنتجة.</div>`,
      okLabel: 'إكمال واستلام الإنتاج',
      submit: (v) => api('mo.complete', { ...v, id: mo.id, allowZeroCost: !!v.allowZeroCost }),
    });
    try {
      const r = await run();
      if (r) { toast(`تم الإكمال — تكلفة الوحدة ${money(r.unit_cost)}`); reload('profit'); }
    } catch (e) { showError(e); }
  });
  bind('[data-reopen]', async () => {
    const c = await confirmBox(`إعادة فتح ${mo.doc_no}؟ سيُسحب الإنتاج المستلم من المخزن ويُلغى قيد الإكمال، ثم يعود الأمر "قيد التشغيل" لتعديل التكاليف.`, { reason: true, ok: 'إعادة فتح' });
    if (c) { await api('mo.reopen', { id: mo.id, reason: c.reason }); toast('تمت إعادة الفتح'); reload('materials'); }
  });
  bind('[data-cancel]', async () => {
    const c = await confirmBox(`إلغاء أمر التصنيع ${mo.doc_no}؟ ستُرد الخامات المصروفة للمخزن تلقائيًا، وتُحمّل العمالة والتكاليف الأخرى كخسارة.`, { danger: true, reason: true, typed: 'إلغاء', ok: 'إلغاء الأمر' });
    if (c) { const r = await api('mo.cancel', { id: mo.id, reason: c.reason }); toast(`تم الإلغاء — رُدّت خامات بقيمة ${money(r.returned)}`); reload('info'); }
  });
}

async function issueForm(mo) {
  const [prods, whs] = await Promise.all([api('products.options', { stockable: 1, warehouse_id: mo.warehouse_id }), whOptions()]);
  const costs = can('costs.view');
  const lines = mo.materials.filter((m) => m.remaining_to_issue > 0).map((m) => ({ product_id: m.product_id, qty: m.remaining_to_issue }));
  return new Promise((resolve) => {
    const m = modal({
      title: `صرف خامات لأمر ${mo.doc_no}`, size: 'wide',
      body: `<div class="form"><div class="field"><label>من مخزن</label><select class="inp" name="warehouse_id">${whs.map((w) => `<option value="${w.value}" ${w.value === mo.warehouse_id ? 'selected' : ''}>${esc(w.label)}</option>`).join('')}</select></div>
        <div class="field"><label>التاريخ</label><input class="inp" type="date" name="date" value="${today()}"></div></div>
        <p class="muted small">تم ملء الكميات المتبقية من الخطة. عدّل ما تريد صرفه فعلًا؛ يمكنك إضافة مواد غير مخططة.</p><div data-lines></div><div class="alert bad hide" data-err style="margin-top:10px"></div>`,
      foot: `<button class="btn" data-ok>${icon('upload', 'sm')} صرف</button><button class="btn ghost" data-close>إلغاء</button>`,
    });
    const ed = lineEditor($('[data-lines]', m.el), {
      products: prods.filter((p) => p.id !== mo.product_id), lines, stockKey: 'wh_qty', addLabel: 'إضافة مادة',
      columns: [{ key: 'qty', label: 'كمية الصرف', type: 'number', width: '130px' }, { key: 'unit', label: 'الوحدة', type: 'computed', format: 'text', compute: (l, p) => (p ? p.unit_name : '') },
        { key: 'avail', label: 'المتاح بالمخزن', type: 'computed', format: 'qty', compute: (l, p) => (p ? p.wh_qty : 0) },
        ...(costs ? [{ key: 'val', label: 'القيمة التقريبية', type: 'computed', compute: (l, p) => (p ? (Number(l.qty) || 0) * (p.avg_cost || 0) : 0) }] : []), { key: 'notes', label: 'ملاحظات', type: 'text' }],
      info: (l, p) => (Number(l.qty) > Number(p.wh_qty) ? '<span class="neg">الكمية أكبر من المتاح في هذا المخزن</span>' : ''),
    });
    let done = false;
    $$('[data-close]', m.el).forEach((b) => b.addEventListener('click', () => { if (!done) resolve(false); }));
    $('[data-ok]', m.el).onclick = async (e) => {
      const err = $('[data-err]', m.el); err.classList.add('hide');
      e.target.disabled = true;
      try {
        const r = await api('mo.issue', { mo_id: mo.id, warehouse_id: $('[name=warehouse_id]', m.el).value, date: $('[name=date]', m.el).value, lines: ed.get().map((l) => ({ product_id: l.product_id, qty: l.qty, notes: l.notes })) });
        done = true; m.close();
        toast(`تم الصرف ${r.doc_no}${costs ? ' بقيمة ' + money(r.total) : ''}`);
        (r.warnings || []).forEach((w) => toast(w, 'warn', 7000));
        resolve(r);
      } catch (x) { err.textContent = x.message; err.classList.remove('hide'); } finally { e.target.disabled = false; }
    };
  });
}

async function laborForm(mo) {
  const workers = (await api('workers.list', { onlyActive: true }));
  return formModal({
    title: 'تسجيل عمالة', values: { date: today(), pay_method: 'accrued', rate_type: 'day' },
    fields: [{ name: 'worker_id', label: 'العامل', type: 'select', options: [{ value: '', label: '— عامل غير مسجل (اكتب الاسم) —' }, ...workers.map((w) => ({ value: w.id, label: `${w.name}${w.job ? ' — ' + w.job : ''}` }))] },
      { name: 'worker_name', label: 'اسم العامل (إن لم يكن مسجلًا)' },
      { name: 'rate_type', label: 'نوع الأجر', type: 'select', options: Object.entries(RATE_LABELS).map(([value, label]) => ({ value, label })) },
      { name: 'qty', label: 'الكمية (ساعات/أيام/قطع)', type: 'number', min: 0 }, { name: 'rate', label: `سعر الوحدة (${currencySymbol()})`, type: 'number', min: 0 },
      { name: 'total', label: 'المبلغ (للثابت/اليدوي)', type: 'number', min: 0 },
      { type: 'html', full: true, html: '<div class="sum-strip" data-calc><div><span>الإجمالي</span><b>0</b></div></div>' },
      { name: 'pay_method', label: 'طريقة الدفع', type: 'select', options: LABOR_PAY }, { name: 'date', label: 'التاريخ', type: 'date' }, { name: 'notes', label: 'ملاحظات', full: true }],
    onOpen: (el) => {
      const f = (n) => $(`[name=${n}]`, el);
      const upd = () => {
        const t = f('rate_type').value; const fixed = t === 'fixed' || t === 'manual';
        f('qty').closest('.field').classList.toggle('hide', fixed); f('rate').closest('.field').classList.toggle('hide', fixed); f('total').closest('.field').classList.toggle('hide', !fixed);
        f('worker_name').closest('.field').classList.toggle('hide', !!f('worker_id').value);
        const tot = fixed ? Number(f('total').value) || 0 : (Number(f('qty').value) || 0) * (Number(f('rate').value) || 0);
        $('[data-calc] b', el).textContent = fmt(tot);
      };
      f('worker_id').onchange = () => { const w = workers.find((x) => x.id === Number(f('worker_id').value)); if (w) { f('rate_type').value = w.rate_type; if (['fixed', 'manual'].includes(w.rate_type)) f('total').value = w.rate || ''; else f('rate').value = w.rate || ''; } upd(); };
      el.addEventListener('input', upd); el.addEventListener('change', upd); upd();
    },
    submit: async (v) => { await api('mo.addLabor', { ...v, mo_id: mo.id }); toast('تم تسجيل العمالة'); },
  });
}

// =====================================================================================
// BOMs
// =====================================================================================
export async function boms(root, parts) {
  if (parts[0]) return bomEditor(root, parts[0] === 'new' ? null : Number(parts[0]));
  const costs = can('costs.view');
  root.innerHTML = pageHead('قوائم المواد (BOM)', 'المكونات القياسية لكل منتج بنسبة الهالك المتوقعة؛ تُستخدم لتخطيط أوامر التصنيع وتقدير التكلفة', can('manufacturing.manage') ? `<a class="btn" href="#/boms/new">${icon('plus', 'sm')} قائمة مواد جديدة</a>` : '')
    + `<div class="card">${filterBar([{ name: 'q', label: 'بحث', placeholder: 'اسم القائمة أو المنتج' }])}<div data-t></div></div>`;
  let rows = await api('boms.list', {});
  const t = dataTable($('[data-t]', root), {
    rows, title: 'قوائم المواد', exportName: 'boms', empty: 'لا توجد قوائم مواد', emptyIcon: 'layers', emptyHint: 'القائمة اختيارية: يمكنك إنشاء أوامر تصنيع بدونها وتحديد المواد يدويًا',
    columns: [{ key: 'product_name', label: 'المنتج' }, { key: 'name', label: 'اسم القائمة', render: (r) => `${esc(r.name)}${r.is_default ? ' <span class="badge ok">افتراضية</span>' : ''}${r.active ? '' : ' <span class="badge bad">موقوفة</span>'}` },
      { key: 'output_qty', label: 'تُنتج', type: 'qty' }, { key: 'items_count', label: 'عدد المكونات', type: 'qty' }, ...(costs ? [{ key: 'total_cost', label: 'التكلفة التقديرية', type: 'money' }, { key: 'unit_cost', label: 'للوحدة', type: 'money' }] : []),
      { key: 'mo_count', label: 'أوامر مستخدمة', type: 'qty' }],
    rowClass: (r) => (r.active ? '' : 'void'),
    onRow: (r) => navigate(`#/boms/${r.id}`),
  });
  bindFilters($('.filters', root), async (v) => { rows = await api('boms.list', v); t.setRows(rows); });
}

async function bomEditor(root, id) {
  const costs = can('costs.view'); const manage = can('manufacturing.manage');
  const [prods, bom] = await Promise.all([api('products.options', { stockable: 1 }), id ? api('boms.get', { id }) : null]);
  const b = bom || { name: '', output_qty: 1, items: [], is_default: 1 };
  root.innerHTML = pageHead(bom ? `قائمة مواد: ${b.name}` : 'قائمة مواد جديدة', bom ? `${b.product_name}` : '', bom && manage ? `
    <a class="btn ghost" href="#/mo/new?product=${b.product_id}">${icon('factory', 'sm')} أمر تصنيع بهذه القائمة</a>
    <button class="btn ghost" data-toggle>${b.active ? 'إيقاف' : 'تفعيل'}</button><button class="btn ghost" data-del>${icon('trash', 'sm')} حذف</button>` : '', '<a href="#/boms">قوائم المواد</a> / ' + esc(bom ? b.name : 'جديد'))
    + `<div class="card"><div class="form">
      <div class="field"><label>المنتج <span class="req">*</span></label><div class="combo" data-product><input class="inp" placeholder="المنتج النهائي" ${bom ? 'readonly' : ''}><input type="hidden" name="product_id"></div></div>
      <div class="field"><label>اسم القائمة</label><input class="inp" name="name" value="${esc(b.name)}" placeholder="مثال: الموديل القياسي"></div>
      <div class="field"><label>الكمية التي تنتجها القائمة</label><input class="inp num" type="number" step="any" min="0" name="output_qty" value="${esc(b.output_qty)}"><span class="hint">الكميات أدناه لإنتاج هذه الكمية</span></div>
      <div class="field"><label>&nbsp;</label><label class="check"><input type="checkbox" name="is_default" ${b.is_default ? 'checked' : ''}> القائمة الافتراضية لهذا المنتج</label></div>
      <div class="field full"><label>ملاحظات</label><input class="inp" name="notes" value="${esc(b.notes || '')}"></div></div></div>
    <div class="card"><div class="card-title">${icon('layers', 'sm')} المكونات</div><div data-lines></div>
      ${costs ? '<div class="totals" style="margin-top:12px"><div><span>التكلفة التقديرية للقائمة</span><b class="num" data-tot>0</b></div><div><span>تكلفة الوحدة من المواد</span><b class="num" data-unit>0</b></div></div><p class="muted small">التقدير بمتوسط التكلفة الحالي (أو آخر سعر شراء إذا لم يوجد مخزون). التكلفة الفعلية تُحسب من الصرف الفعلي في أمر التصنيع.</p>' : ''}</div>
    <div class="alert bad hide" data-err></div>
    ${manage ? `<div class="form-actions"><button class="btn" data-save>${icon('save', 'sm')} حفظ القائمة</button><a class="btn ghost" href="#/boms">رجوع</a></div>` : ''}`;
  const cost = (p) => (p ? (p.avg_cost > 0 ? p.avg_cost : (p.last_purchase_price || p.purchase_price || 0)) : 0);
  const gross = (l) => (Number(l.qty) || 0) * (1 + (Number(l.waste_pct) || 0) / 100);
  const recalc = (lines) => {
    if (!costs) return;
    const tot = lines.reduce((s, l) => s + gross(l) * cost(l.product), 0);
    $('[data-tot]', root).textContent = money(tot); $('[data-unit]', root).textContent = money(tot / (Number($('[name=output_qty]', root).value) || 1));
  };
  let productId = b.product_id || null;
  combo($('[data-product]', root), { options: productComboOptions(prods), value: b.product_id, onChange: (o) => { productId = o ? Number(o.value) : null; if (o && !$('[name=name]', root).value) $('[name=name]', root).value = `قائمة ${o.label}`; } });
  const ed = lineEditor($('[data-lines]', root), {
    products: prods, lines: b.items.map((i) => ({ product_id: i.product_id, qty: i.qty, waste_pct: i.waste_pct, notes: i.notes })), addLabel: 'إضافة مكوّن',
    columns: [{ key: 'qty', label: 'الكمية', type: 'number', width: '110px' }, { key: 'unit', label: 'الوحدة', type: 'computed', format: 'text', compute: (l, p) => (p ? p.unit_name : '') },
      { key: 'waste_pct', label: 'هالك %', type: 'number', width: '90px' }, { key: 'gross', label: 'الكمية شاملة الهالك', type: 'computed', format: 'qty', compute: (l) => gross(l) },
      ...(costs ? [{ key: 'cost', label: 'التكلفة التقديرية', type: 'computed', compute: (l, p) => gross(l) * cost(p) }] : []), { key: 'notes', label: 'ملاحظات', type: 'text' }],
    info: (l, p) => `${KIND_LABELS[p.kind] || ''}`, onChange: recalc,
  });
  recalc(ed.get());
  $('[name=output_qty]', root).addEventListener('input', () => recalc(ed.get()));
  const sv = $('[data-save]', root);
  if (sv) sv.onclick = async () => {
    const err = $('[data-err]', root); err.classList.add('hide');
    try {
      const v = readForm($('.card', root));
      const nid = await api('boms.save', { id, ...v, product_id: productId, items: ed.get().map(({ product, ...l }) => l) });
      toast('تم حفظ قائمة المواد');
      navigate(`#/boms/${nid}`);
    } catch (e) { err.textContent = e.message; err.classList.remove('hide'); }
  };
  const tg = $('[data-toggle]', root); if (tg) tg.onclick = async () => { try { await api('boms.toggle', { id }); toast('تم'); navigate(`#/boms/${id}`); } catch (e) { showError(e); } };
  const dl = $('[data-del]', root); if (dl) dl.onclick = async () => { if (await confirmBox(`حذف قائمة المواد "${b.name}"؟`, { danger: true, ok: 'حذف' })) { try { await api('boms.delete', { id }); toast('تم الحذف'); navigate('#/boms'); } catch (e) { showError(e); } } };
}

// =====================================================================================
// Workers
// =====================================================================================
export async function workers(root) {
  const manage = can('manufacturing.manage'); const costs = can('costs.view');
  root.innerHTML = pageHead('العمالة', 'العمال والأسطوات وأجورهم الافتراضية؛ الأجر الفعلي يُسجل على كل أمر تصنيع', manage ? `<button class="btn" data-new>${icon('plus', 'sm')} عامل جديد</button>` : '')
    + `<div class="card">${filterBar([{ name: 'q', label: 'بحث' }])}<div data-t></div></div>`;
  const load = (q) => api('workers.list', { q });
  let rows = await load('');
  const form = async (w) => formModal({
    title: w ? `تعديل: ${w.name}` : 'عامل جديد', values: w || { rate_type: 'day' },
    fields: [{ name: 'name', label: 'الاسم', required: true }, { name: 'job', label: 'الوظيفة / الحرفة' }, { name: 'phone', label: 'الهاتف' },
      { name: 'rate_type', label: 'نوع الأجر الافتراضي', type: 'select', options: Object.entries(RATE_LABELS).map(([value, label]) => ({ value, label })) },
      { name: 'rate', label: `الأجر الافتراضي (${currencySymbol()})`, type: 'number', min: 0 }, { name: 'notes', label: 'ملاحظات', full: true }],
    submit: (v) => api('workers.save', { ...v, id: w && w.id }),
  });
  const t = dataTable($('[data-t]', root), {
    rows, title: 'العمالة', exportName: 'workers', empty: 'لا يوجد عمال مسجلون', emptyIcon: 'worker', emptyHint: 'يمكنك أيضًا تسجيل عمالة باسم حر داخل أمر التصنيع',
    columns: [{ key: 'code', label: 'الكود' }, { key: 'name', label: 'الاسم' }, { key: 'job', label: 'الوظيفة' }, { key: 'phone', label: 'الهاتف' },
      { key: 'rate_type', label: 'نوع الأجر', render: (r) => esc(RATE_LABELS[r.rate_type]), exportValue: (r) => RATE_LABELS[r.rate_type] }, ...(costs ? [{ key: 'rate', label: 'الأجر', type: 'money' }, { key: 'labor_total', label: 'إجمالي المسجل على الأوامر', type: 'money' }] : []),
      { key: 'active', label: 'الحالة', render: (r) => (r.active ? '<span class="badge ok">نشط</span>' : '<span class="badge bad">موقوف</span>'), cls: 'keep' }],
    rowClass: (r) => (r.active ? '' : 'void'),
    actions: manage ? (r) => `<button class="link-btn" data-act="edit">${icon('edit', 'sm')}</button><button class="link-btn muted" data-act="toggle">${r.active ? 'إيقاف' : 'تفعيل'}</button>` : null,
    onAction: async (a, r) => {
      try {
        if (a === 'edit' && await form(r)) { toast('تم الحفظ'); rows = await load(''); t.setRows(rows); }
        if (a === 'toggle') { await api('workers.toggle', { id: r.id }); rows = await load(''); t.setRows(rows); }
      } catch (e) { showError(e); }
    },
  });
  bindFilters($('.filters', root), async (v) => { rows = await load(v.q); t.setRows(rows); });
  const n = $('[data-new]', root); if (n) n.onclick = async () => { if (await form()) { toast('تمت الإضافة'); rows = await load(''); t.setRows(rows); } };
}
export { invalidate };
