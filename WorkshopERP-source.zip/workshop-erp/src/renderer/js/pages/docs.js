import { api } from '../api.js';
import { esc, money, fmt, qty, date, can, today, $, $$, state, navigate, PAY_LABELS, currencySymbol } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { pageHead, dataTable, filterBar, bindFilters, confirmBox, toast, showError, combo, kvList, kvHtml, tableHtml } from '../ui/components.js';
import { printInvoice } from '../ui/print.js';
import { lookup, whOptions, defaultWh, partyOptions, lineEditor, statusBadge, invalidate } from './shared.js';

const CFG = {
  purchase: { api: 'purchases', route: 'purchases', title: 'فواتير الشراء', one: 'فاتورة شراء', party: 'supplier', partyLabel: 'المورد', view: 'purchases.view', create: 'purchases.create', void: 'purchases.void', isReturn: false, returnRoute: 'purchase-returns', print: 'purchase' },
  sale: { api: 'sales', route: 'sales', title: 'فواتير البيع', one: 'فاتورة بيع', party: 'customer', partyLabel: 'العميل', view: 'sales.view', create: 'sales.create', void: 'sales.void', isReturn: false, returnRoute: 'sales-returns', print: 'sale' },
  purchaseReturn: { api: 'purchaseReturns', route: 'purchase-returns', title: 'مرتجعات الشراء', one: 'مرتجع شراء', party: 'supplier', partyLabel: 'المورد', view: 'purchases.view', create: 'purchases.create', void: 'purchases.void', isReturn: true, invoiceApi: 'purchases', invoiceRoute: 'purchases', print: 'purchase_return' },
  saleReturn: { api: 'salesReturns', route: 'sales-returns', title: 'مرتجعات البيع', one: 'مرتجع بيع', party: 'customer', partyLabel: 'العميل', view: 'sales.view', create: 'sales.create', void: 'sales.void', isReturn: true, invoiceApi: 'sales', invoiceRoute: 'sales', print: 'sale_return' },
};

const router = (key) => async (root, parts, params) => {
  const c = CFG[key];
  if (parts[0] === 'new') return c.isReturn ? returnForm(root, c, params) : invoiceForm(root, c, params);
  if (parts[0]) return viewDoc(root, c, Number(parts[0]));
  return listDocs(root, c, params);
};
export const purchases = router('purchase');
export const sales = router('sale');
export const purchaseReturns = router('purchaseReturn');
export const salesReturns = router('saleReturn');

// ------------------------------------------------------------------ list
async function listDocs(root, c, params) {
  const parties = await lookup(c.party + 's', true);
  const costs = can('costs.view') && c.api === 'sales';
  root.innerHTML = pageHead(c.title, '', can(c.create) ? `<a class="btn" href="#/${c.route}/new">${icon('plus', 'sm')} ${esc(c.one)} جديدة</a>` : '')
    + `<div class="card"><div class="sum-strip hide" data-sum></div>${filterBar([
      { name: 'q', label: 'بحث', placeholder: 'رقم المستند أو الاسم…' }, { name: 'from', label: 'من', type: 'date' }, { name: 'to', label: 'إلى', type: 'date' },
      { name: `${c.party}_id`, label: c.partyLabel, type: 'combo' },
      { name: 'status', label: 'الحالة', type: 'select', options: [{ value: '', label: 'الكل' }, { value: 'posted', label: 'معتمد' }, { value: 'void', label: 'ملغي' }] },
    ], { [`${c.party}_id`]: params[`${c.party}_id`] || '' })}<div data-t></div></div>`;
  let f = { [`${c.party}_id`]: params[`${c.party}_id`] || '' };
  const sum = $('[data-sum]', root);
  const t = dataTable($('[data-t]', root), {
    title: c.title, exportName: c.route, emptyIcon: 'receipt', empty: 'لا توجد مستندات',
    fetch: async (p) => {
      const r = await api(`${c.api}.list`, { ...f, ...p });
      if (r.sum) { sum.classList.remove('hide'); sum.innerHTML = `<div><span>إجمالي المستندات المعتمدة</span><b>${money(r.sum.total)}</b></div><div><span>المدفوع</span><b>${money(r.sum.paid)}</b></div><div><span>المتبقي</span><b>${money(r.sum.total - r.sum.paid)}</b></div>`; }
      return r;
    },
    columns: [
      { key: 'doc_no', label: 'الرقم', sort: true, render: (r) => `<b>${esc(r.doc_no)}</b>` },
      { key: 'date', label: 'التاريخ', type: 'date', sort: true },
      { key: `${c.party}_name`, label: c.partyLabel, sortKey: `${c.party}_name`, sort: true, render: (r) => esc(r[`${c.party}_name`] || 'نقدي'), exportValue: (r) => r[`${c.party}_name`] || 'نقدي' },
      ...(c.isReturn ? [{ key: 'invoice_no', label: 'الفاتورة الأصلية' }, { key: 'settle', label: 'التسوية', render: (r) => esc(PAY_LABELS[r.settle]), exportValue: (r) => PAY_LABELS[r.settle] }] : [{ key: 'warehouse_name', label: 'المخزن' }]),
      { key: 'total', label: 'الإجمالي', type: 'money', sort: true },
      ...(c.isReturn ? [] : [{ key: 'paid', label: 'المدفوع', type: 'money' }, { key: 'remaining', label: 'المتبقي', type: 'money', render: (r) => (r.remaining > 0.004 && r.status === 'posted' ? `<span class="badge warn">${fmt(r.remaining)}</span>` : fmt(r.remaining)) }]),
      ...(costs ? [{ key: 'gross_profit', label: 'مجمل الربح', type: 'money' }] : []),
      { key: 'status', label: 'الحالة', render: (r) => statusBadge(r.status), cls: 'keep', exportValue: (r) => (r.status === 'void' ? 'ملغي' : 'معتمد') },
    ],
    rowClass: (r) => (r.status === 'void' ? 'void' : ''),
    onRow: (r) => navigate(`#/${c.route}/${r.id}`),
  });
  bindFilters($('.filters', root), (v) => { f = v; t.reload(); }, { [`${c.party}_id`]: partyOptions(parties) });
}

// ------------------------------------------------------------------ new invoice
async function invoiceForm(root, c, params) {
  if (!can(c.create)) { root.innerHTML = '<div class="alert bad">ليست لديك صلاحية إنشاء هذا المستند</div>'; return; }
  const isSale = c.api === 'sales';
  const s = state.settings;
  const [parties, whs, dw] = await Promise.all([lookup(c.party + 's', true), whOptions(), defaultWh()]);
  const moOpts = isSale && can('sales.create') ? await api('sales.moOptions', {}) : [];
  const costs = can('costs.view');
  root.innerHTML = pageHead(`${c.one} جديدة`, '', '', `<a href="#/${c.route}">${esc(c.title)}</a> / جديد`)
    + `<div class="card"><div class="form c4">
        <div class="field"><label>${esc(c.partyLabel)}</label><div class="combo" data-party><input class="inp" placeholder="${isSale ? 'عميل نقدي (اتركه فارغًا)' : 'مورد نقدي (اتركه فارغًا)'}"><input type="hidden" name="party"></div><span class="hint" data-party-info></span></div>
        <div class="field"><label>التاريخ</label><input class="inp" type="date" name="date" value="${today()}"></div>
        <div class="field"><label>المخزن</label><select class="inp" name="warehouse_id">${whs.map((w) => `<option value="${w.value}" ${w.value === dw ? 'selected' : ''}>${esc(w.label)}</option>`).join('')}</select></div>
        ${isSale ? `<div class="field"><label>ربط بأمر تصنيع مكتمل (اختياري)</label><select class="inp" name="mo"><option value="">—</option>${moOpts.map((m) => `<option value="${m.id}">${esc(m.doc_no)} — متبقٍ ${qty(m.remaining)}${m.customer_name ? ' — ' + esc(m.customer_name) : ''}</option>`).join('')}</select></div>`
    : '<div class="field"><label>رقم فاتورة المورد</label><input class="inp" name="supplier_ref"></div>'}
      </div><div data-lines style="margin-top:14px"></div></div>
      <div class="grid g2"><div class="card"><div class="field"><label>ملاحظات</label><textarea class="inp" name="notes" rows="3"></textarea></div></div>
      <div class="card"><div class="form c2">
        <div class="field"><label>خصم على الفاتورة (${esc(currencySymbol())})</label><input class="inp num" type="number" min="0" step="any" name="discount" value="0"></div>
        ${s.tax.enabled ? `<div class="field"><label>نسبة ${esc(s.tax.label)} %</label><input class="inp num" type="number" min="0" step="any" name="tax_rate" value="${esc(s.tax.defaultRate)}"></div>` : '<div></div>'}
        <div class="field"><label>المبلغ المدفوع</label><div class="row" style="flex-wrap:nowrap"><input class="inp num" type="number" min="0" step="any" name="paid" value="0"><button type="button" class="btn ghost sm" data-full>كامل</button></div></div>
        <div class="field"><label>طريقة الدفع</label><select class="inp" name="pay_method"><option value="cash">الصندوق</option><option value="bank">البنك</option></select></div>
      </div><div class="totals" data-totals style="margin-top:14px"></div>
      <div class="alert bad hide" data-err style="margin-top:10px"></div>
      <div class="form-actions"><button class="btn" data-save>${icon('save', 'sm')} حفظ واعتماد</button><button class="btn ghost" data-save-print>${icon('printer', 'sm')} حفظ وطباعة</button><a class="btn ghost" href="#/${c.route}">إلغاء</a></div></div></div>`;

  let party = null;
  const partyInfo = $('[data-party-info]', root);
  combo($('[data-party]', root), {
    options: partyOptions(parties.filter((p) => p.active)),
    onChange: (o) => {
      party = o ? parties.find((p) => p.id === Number(o.value)) : null;
      partyInfo.textContent = party ? `الرصيد الحالي: ${money(party.balance)}${party.credit_limit ? ` — حد الائتمان ${money(party.credit_limit)}` : ''}` : '';
      recalc();
    },
  });

  let ed;
  const loadLines = async (keep = []) => {
    const prods = await api('products.options', { warehouse_id: $('[name=warehouse_id]', root).value });
    ed = lineEditor($('[data-lines]', root), {
      products: prods, stockKey: 'wh_qty', lines: keep, addLabel: 'إضافة صنف',
      columns: [
        { key: 'qty', label: 'الكمية', type: 'number', width: '110px' },
        { key: 'unit_price', label: `السعر (${currencySymbol()})`, type: 'number', width: '130px' },
        { key: 'total', label: 'الإجمالي', type: 'computed', compute: (l) => (Number(l.qty) || 0) * (Number(l.unit_price) || 0) },
      ],
      onProduct: (l, p) => { if (!l.qty) l.qty = 1; if (!l.unit_price) l.unit_price = isSale ? p.sale_price : (p.last_purchase_price || p.purchase_price); },
      info: (l, p) => {
        const bits = [];
        if (p.is_stocked) bits.push(`المتاح: ${qty(p.wh_qty)} ${esc(p.unit_name)}`);
        if (l.mo_id) bits.push(`<span class="badge info">مرتبط بأمر التصنيع ${esc(l.mo_no)}</span>`);
        if (isSale && costs) {
          const cost = l.mo_cost || p.avg_cost || 0; const price = Number(l.unit_price) || 0;
          if (cost && price) bits.push(`التكلفة ${fmt(cost)} — هامش <b class="${price < cost ? 'neg' : 'pos'}">${fmt((price - cost) / price * 100, 1)}%</b>`);
        }
        if (isSale && p.is_stocked && Number(l.qty) > Number(p.wh_qty) && !s.inventory.allowNegative) bits.push('<span class="neg bold">الكمية أكبر من المتاح</span>');
        return bits.join(' · ');
      },
      onChange: recalc,
    });
    recalc();
  };
  function totals() {
    const lines = ed ? ed.get() : [];
    const sub = lines.reduce((a, l) => a + (Number(l.qty) || 0) * (Number(l.unit_price) || 0), 0);
    const disc = Number($('[name=discount]', root).value) || 0;
    const rate = s.tax.enabled ? Number($('[name=tax_rate]', root).value) || 0 : 0;
    const tax = Math.round((sub - disc) * rate) / 100;
    return { sub, disc, tax, total: Math.round((sub - disc + tax) * 100) / 100, rate };
  }
  function recalc() {
    const t = totals(); const paid = Number($('[name=paid]', root).value) || 0;
    $('[data-totals]', root).innerHTML = `<div><span>الإجمالي</span><b class="num">${money(t.sub)}</b></div>${t.disc ? `<div><span>الخصم</span><b class="num">− ${money(t.disc)}</b></div>` : ''}${t.tax ? `<div><span>الضريبة ${fmt(t.rate, 2)}%</span><b class="num">${money(t.tax)}</b></div>` : ''}
      <div class="grand"><span>الصافي</span><b class="num">${money(t.total)}</b></div><div><span>المتبقي ${party ? 'على الحساب' : ''}</span><b class="num ${t.total - paid > 0.004 && !party ? 'neg' : ''}">${money(t.total - paid)}</b></div>`;
  }
  root.addEventListener('input', (e) => { if (['discount', 'tax_rate', 'paid'].includes(e.target.name)) recalc(); });
  $('[data-full]', root).onclick = () => { $('[name=paid]', root).value = totals().total; recalc(); };
  $('[name=warehouse_id]', root).onchange = () => loadLines(ed ? ed.get().map(({ product, ...l }) => l) : []);
  if (isSale) {
    const moSel = $('[name=mo]', root);
    const addMo = (id) => {
      const m = moOpts.find((x) => x.id === Number(id)); if (!m) return;
      const cur = ed.get().map(({ product, ...l }) => l).filter((l) => l.mo_id !== m.id);
      cur.push({ product_id: m.product_id, qty: m.remaining, unit_price: m.agreed_price || (ed.products.get(String(m.product_id)) || {}).sale_price || 0, mo_id: m.id, mo_no: m.doc_no, mo_cost: m.unit_cost });
      ed.set(cur);
      if (m.customer_id && !$('[name=party]', root).value) { const cb = $('[data-party]', root); const o = parties.find((p) => p.id === m.customer_id); if (o) { cb.querySelector('input').value = o.name; $('[name=party]', root).value = o.id; party = o; recalc(); } }
    };
    moSel.onchange = () => { addMo(moSel.value); moSel.value = ''; };
    await loadLines();
    if (params.mo) addMo(params.mo);
  } else await loadLines();

  const save = async (andPrint, confirmOverLimit = false) => {
    const err = $('[data-err]', root); err.classList.add('hide');
    const lines = ed.get();
    if (!lines.length) { err.textContent = 'أضف صنفًا واحدًا على الأقل'; err.classList.remove('hide'); return; }
    const payload = {
      [`${c.party}_id`]: $('[name=party]', root).value || null, date: $('[name=date]', root).value, warehouse_id: $('[name=warehouse_id]', root).value,
      discount: $('[name=discount]', root).value, tax_rate: s.tax.enabled ? $('[name=tax_rate]', root).value : 0, paid: $('[name=paid]', root).value, pay_method: $('[name=pay_method]', root).value,
      notes: $('[name=notes]', root).value, supplier_ref: isSale ? undefined : $('[name=supplier_ref]', root).value, confirmOverLimit,
      lines: lines.map((l) => ({ product_id: l.product_id, qty: l.qty, unit_price: l.unit_price, mo_id: l.mo_id || null })),
    };
    $$('[data-save],[data-save-print]', root).forEach((b) => { b.disabled = true; });
    try {
      const r = await api(`${c.api}.create`, payload);
      invalidate(c.party + 's');
      toast(`تم حفظ ${c.one} ${r.doc_no}`);
      if (r.warning) toast(r.warning, 'warn');
      if (andPrint) printInvoice(await api(`${c.api}.get`, { id: r.id }), c.print);
      navigate(`#/${c.route}/${r.id}`);
    } catch (e) {
      if (e.code === 'CREDIT_LIMIT' && await confirmBox(`${e.message}\nهل تريد المتابعة رغم تجاوز حد الائتمان؟`, { ok: 'متابعة الحفظ' })) return save(andPrint, true);
      err.textContent = e.message; err.classList.remove('hide');
    } finally { $$('[data-save],[data-save-print]', root).forEach((b) => { b.disabled = false; }); }
  };
  $('[data-save]', root).onclick = () => save(false);
  $('[data-save-print]', root).onclick = () => save(true);
}

// ------------------------------------------------------------------ new return
async function returnForm(root, c, params) {
  if (!can(c.create)) { root.innerHTML = '<div class="alert bad">ليست لديك صلاحية</div>'; return; }
  const [parties, whs, dw] = await Promise.all([lookup(c.party + 's', true), whOptions(), defaultWh()]);
  const invoices = (await api(`${c.invoiceApi}.list`, { status: 'posted', all: true })).rows;
  const isSale = c.api === 'salesReturns';
  root.innerHTML = pageHead(`${c.one} جديد`, 'يمكن الإرجاع على فاتورة محددة (يُستخدم نفس السعر والتكلفة) أو بدون فاتورة', '', `<a href="#/${c.route}">${esc(c.title)}</a> / جديد`)
    + `<div class="card"><div class="form c4">
      <div class="field"><label>الفاتورة الأصلية</label><div class="combo" data-inv><input class="inp" placeholder="اختياري — ابحث برقم الفاتورة أو الاسم"><input type="hidden" name="invoice_id"></div></div>
      <div class="field" data-party-f><label>${esc(c.partyLabel)}</label><div class="combo" data-party><input class="inp" placeholder="اختر"><input type="hidden" name="party"></div></div>
      <div class="field"><label>التاريخ</label><input class="inp" type="date" name="date" value="${today()}"></div>
      <div class="field"><label>المخزن</label><select class="inp" name="warehouse_id">${whs.map((w) => `<option value="${w.value}" ${w.value === dw ? 'selected' : ''}>${esc(w.label)}</option>`).join('')}</select></div>
      <div class="field"><label>التسوية</label><select class="inp" name="settle"><option value="account">${isSale ? 'خصم من رصيد العميل' : 'خصم من رصيد المورد'}</option><option value="cash">${isSale ? 'رد نقدي من الصندوق' : 'استرداد نقدي للصندوق'}</option><option value="bank">عن طريق البنك</option></select></div>
      <div class="field full"><label>ملاحظات / سبب الإرجاع</label><input class="inp" name="notes"></div></div>
      <div data-lines style="margin-top:14px"></div><div class="totals" data-totals style="margin-top:12px"></div>
      <div class="alert bad hide" data-err style="margin-top:10px"></div>
      <div class="form-actions"><button class="btn" data-save>${icon('save', 'sm')} حفظ المرتجع</button><a class="btn ghost" href="#/${c.route}">إلغاء</a></div></div>`;
  const partyCombo = combo($('[data-party]', root), { options: partyOptions(parties) });
  let invoice = null; let ed = null;
  const drawTotal = () => {
    const rows = invoice ? invoice.lines.map((l) => ({ q: Number($(`[data-rq="${l.id}"]`, root)?.value) || 0, p: l.unit_price })) : (ed ? ed.get().map((l) => ({ q: Number(l.qty) || 0, p: Number(l.unit_price) || 0 })) : []);
    const sub = rows.reduce((a, r) => a + r.q * r.p, 0); const rate = invoice ? invoice.tax_rate : 0;
    $('[data-totals]', root).innerHTML = `<div><span>القيمة</span><b class="num">${money(sub)}</b></div>${rate ? `<div><span>الضريبة</span><b class="num">${money(sub * rate / 100)}</b></div>` : ''}<div class="grand"><span>الإجمالي</span><b class="num">${money(sub * (1 + rate / 100))}</b></div>`;
  };
  const drawLines = async () => {
    const box = $('[data-lines]', root);
    if (invoice) {
      $('[data-party-f]', root).classList.add('hide');
      box.innerHTML = `<div class="alert info">الفاتورة ${esc(invoice.doc_no)} — ${esc(invoice[`${c.party}_name`] || 'نقدي')} — ${esc(date(invoice.date))}. اكتب الكمية المرتجعة لكل صنف.</div>
        <div class="tbl-wrap"><table class="tbl lines"><thead><tr><th>الصنف</th><th class="n">الكمية بالفاتورة</th><th class="n">سبق إرجاعه</th><th class="n">السعر</th><th class="n" style="width:140px">كمية المرتجع</th></tr></thead><tbody>
        ${invoice.lines.map((l) => `<tr><td>${esc(l.product_name)} <span class="muted small">${esc(l.unit_name)}</span></td><td class="n">${qty(l.qty)}</td><td class="n">${qty(l.returned_qty)}</td><td class="n">${fmt(l.unit_price)}</td>
          <td><input class="inp num" type="number" min="0" max="${l.qty - l.returned_qty}" step="any" data-rq="${l.id}" value="0" ${l.qty - l.returned_qty <= 0 ? 'disabled' : ''}></td></tr>`).join('')}</tbody></table></div>`;
      box.oninput = drawTotal;
      $('[name=warehouse_id]', root).value = invoice.warehouse_id;
    } else {
      $('[data-party-f]', root).classList.remove('hide');
      const prods = await api('products.options', { stockable: !isSale });
      ed = lineEditor(box, { products: prods, columns: [{ key: 'qty', label: 'الكمية', type: 'number', width: '120px' }, { key: 'unit_price', label: 'السعر', type: 'number', width: '130px' }, { key: 'total', label: 'الإجمالي', type: 'computed', compute: (l) => (Number(l.qty) || 0) * (Number(l.unit_price) || 0) }],
        onProduct: (l, p) => { l.qty = l.qty || 1; l.unit_price = l.unit_price || (isSale ? p.sale_price : p.avg_cost || p.purchase_price); }, onChange: drawTotal });
    }
    drawTotal();
  };
  combo($('[data-inv]', root), {
    options: invoices.map((i) => ({ value: i.id, label: i.doc_no, sub: `${i[`${c.party}_name`] || 'نقدي'} — ${i.date} — ${fmt(i.total)}`, search: `${i.doc_no} ${i[`${c.party}_name`] || ''}` })),
    value: params.invoice,
    onChange: async (o) => { invoice = o ? await api(`${c.invoiceApi}.get`, { id: o.value }) : null; drawLines(); },
  });
  if (params.invoice) invoice = await api(`${c.invoiceApi}.get`, { id: params.invoice });
  await drawLines();
  $('[data-save]', root).onclick = async (e) => {
    const err = $('[data-err]', root); err.classList.add('hide');
    const lines = invoice
      ? invoice.lines.map((l) => ({ product_id: l.product_id, sales_item_id: l.id, qty: Number($(`[data-rq="${l.id}"]`, root).value) || 0, unit_price: l.unit_price })).filter((l) => l.qty > 0)
      : ed.get().map((l) => ({ product_id: l.product_id, qty: l.qty, unit_price: l.unit_price }));
    if (!lines.length) { err.textContent = 'أدخل كمية مرتجعة لصنف واحد على الأقل'; err.classList.remove('hide'); return; }
    e.target.disabled = true;
    try {
      const r = await api(`${c.api}.create`, { invoice_id: invoice ? invoice.id : null, [`${c.party}_id`]: invoice ? undefined : partyCombo.get() || null, date: $('[name=date]', root).value, warehouse_id: $('[name=warehouse_id]', root).value, settle: $('[name=settle]', root).value, notes: $('[name=notes]', root).value, lines });
      toast(`تم حفظ المرتجع ${r.doc_no}`); if (r.warning) toast(r.warning, 'warn'); invalidate(c.party + 's');
      navigate(`#/${c.route}/${r.id}`);
    } catch (x) { err.textContent = x.message; err.classList.remove('hide'); } finally { e.target.disabled = false; }
  };
}

// ------------------------------------------------------------------ view
async function viewDoc(root, c, id) {
  const d = await api(`${c.api}.get`, { id });
  const costs = can('costs.view') && d.cost_total !== undefined;
  const isSale = c.api === 'sales' || c.api === 'salesReturns';
  const party = d[`${c.party}_name`];
  root.innerHTML = pageHead(`${c.one} ${d.doc_no}`, `${date(d.date)} — ${party || 'نقدي'}`, `
      <button class="btn ghost" data-print>${icon('printer', 'sm')} طباعة</button>
      ${!c.isReturn && d.status === 'posted' && can(c.create) ? `<a class="btn ghost" href="#/${c.returnRoute}/new?invoice=${d.id}">${icon('return', 'sm')} عمل مرتجع</a>` : ''}
      ${!c.isReturn && d.status === 'posted' && d.remaining > 0.004 && d[`${c.party}_id`] && can('payments.manage') ? `<button class="btn gold" data-pay>${icon('coins', 'sm')} ${isSale ? 'تحصيل المتبقي' : 'سداد المتبقي'}</button>` : ''}
      ${d.status === 'posted' && can(c.void) ? `<button class="btn danger" data-void>${icon('ban', 'sm')} إلغاء المستند</button>` : ''}`,
  `<a href="#/${c.route}">${esc(c.title)}</a> / ${esc(d.doc_no)}`)
    + `${d.status === 'void' ? `<div class="alert bad">${icon('ban', 'sm')} هذا المستند ملغي${d.void_reason ? ' — السبب: ' + esc(d.void_reason) : ''}. تم عكس أثره على المخزون والحسابات.</div>` : ''}
    <div class="grid g3">
      <div class="card">${kvList([[c.partyLabel, party || 'نقدي'], ['التاريخ', date(d.date)], ['المخزن', d.warehouse_name], d.supplier_ref ? ['رقم فاتورة المورد', d.supplier_ref] : null, d.invoice_no ? ['الفاتورة الأصلية', d.invoice_no] : null, ['أنشأه', d.user_name || '—'], ['ملاحظات', d.notes || '—']])}</div>
      <div class="card">${kvHtml([['الإجمالي', money(d.subtotal)], !c.isReturn && d.discount ? ['الخصم', money(d.discount)] : null, d.tax ? ['الضريبة', `${money(d.tax)} (${fmt(d.tax_rate, 2)}%)`] : null, ['الصافي', `<b>${money(d.total)}</b>`], ...(c.isReturn ? [['التسوية', PAY_LABELS[d.settle]]] : [['المدفوع', `${money(d.paid)} (${PAY_LABELS[d.pay_method]})`], ['المتبقي', `<b class="${d.remaining > 0.004 ? 'neg' : ''}">${money(d.remaining)}</b>`]])].map((x) => (x && typeof x[1] === 'string' && x[1].startsWith('<') ? [x[0], { toString: () => x[1] }] : x)))}</div>
      ${costs ? `<div class="card">${kvList([[isSale ? 'تكلفة البضاعة' : 'تكلفة المخزون', money(d.cost_total)], ...(d.gross_profit !== undefined ? [['مجمل الربح', money(d.gross_profit)], ['هامش الربح', d.subtotal - d.discount ? `${fmt(d.gross_profit / (d.subtotal - d.discount) * 100, 1)}%` : '—']] : [])])}</div>` : ''}
    </div>
    <div class="card"><div class="card-title">${icon('boxes')} الأصناف</div>${tableHtml([
    { key: 'product_code', label: 'الكود' }, { key: 'product_name', label: 'الصنف', render: (l) => `${esc(l.product_name)}${l.mo_no ? ` <a class="badge info" href="#/mo/${l.mo_id}">${esc(l.mo_no)}</a>` : ''}` }, { key: 'unit_name', label: 'الوحدة' },
    { key: 'qty', label: 'الكمية', type: 'qty' }, ...(c.isReturn ? [] : [{ key: 'returned_qty', label: 'مرتجع', type: 'qty' }]), { key: 'unit_price', label: 'السعر', type: 'money' }, { key: 'line_total', label: 'الإجمالي', type: 'money' },
    ...(costs ? [{ key: 'unit_cost', label: 'تكلفة الوحدة', type: 'money' }] : []),
  ], d.lines)}</div>`;
  $('[data-print]', root).onclick = () => printInvoice(d, c.print);
  const v = $('[data-void]', root);
  if (v) v.onclick = async () => {
    const r = await confirmBox(`إلغاء ${c.one} ${d.doc_no} سيعكس أثرها على المخزون والحسابات${d.paid ? ' والمبلغ المدفوع' : ''}. لا يتم حذف المستند بل يبقى ظاهرًا كملغي.`, { title: 'إلغاء مستند', danger: true, ok: 'إلغاء المستند', reason: true, reasonLabel: 'سبب الإلغاء' });
    if (!r) return;
    try { await api(`${c.api}.void`, { id, reason: r.reason }); toast('تم إلغاء المستند'); invalidate(c.party + 's'); viewDoc(root, c, id); } catch (e) { showError(e); }
  };
  const pay = $('[data-pay]', root);
  if (pay) pay.onclick = async () => {
    const { paymentForm } = await import('./finance.js');
    if (await paymentForm({ direction: isSale ? 'in' : 'out', party_type: c.party, party_id: d[`${c.party}_id`], amount: d.remaining, notes: `عن ${c.one} ${d.doc_no}`, reference: d.doc_no })) viewDoc(root, c, id);
  };
}
export { qty };
