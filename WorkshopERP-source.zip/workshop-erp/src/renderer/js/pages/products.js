import { api } from '../api.js';
import { esc, money, fmt, qty, date, can, state, $, KIND_LABELS, currencySymbol, navigate } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { pageHead, dataTable, filterBar, bindFilters, formModal, confirmBox, toast, showError, modal, kvList, emptyState, combo } from '../ui/components.js';
import { printDoc, docHeader } from '../ui/print.js';
import { lookup, invalidate, opt, whOptions, partyOptions } from './shared.js';

export async function products(root, parts) {
  if (parts[0]) return productCard(root, Number(parts[0]));
  const [cats, kinds, whs] = await Promise.all([lookup('categories', true), lookup('kinds'), whOptions()]);
  const costs = can('costs.view');
  root.innerHTML = pageHead('الأصناف', 'خامات، إكسسوارات، قطع، مستلزمات، منتجات نهائية وخدمات', `
      ${can('products.edit') ? `<button class="btn ghost" data-cats>${icon('tag', 'sm')} التصنيفات</button><button class="btn ghost" data-units>${icon('ruler', 'sm')} الوحدات</button><button class="btn" data-new>${icon('plus', 'sm')} صنف جديد</button>` : ''}`)
    + `<div class="card">${filterBar([
      { name: 'q', label: 'بحث', placeholder: 'الاسم أو الكود أو الباركود…' },
      { name: 'category_id', label: 'التصنيف', type: 'select', options: opt(cats, 'name', 'id', 'كل التصنيفات') },
      { name: 'kind', label: 'النوع', type: 'select', options: [{ value: '', label: 'كل الأنواع' }, ...kinds] },
      { name: 'warehouse_id', label: 'المخزن', type: 'select', options: [{ value: '', label: 'كل المخازن' }, ...whs] },
      { name: 'stock', label: 'حالة المخزون', type: 'select', options: [{ value: '', label: 'الكل' }, { value: 'low', label: 'منخفض المخزون' }, { value: 'available', label: 'متوفر' }, { value: 'zero', label: 'رصيد صفر' }] },
      { name: 'active', label: 'الحالة', type: 'select', options: [{ value: 'active', label: 'نشط' }, { value: 'inactive', label: 'موقوف' }, { value: 'all', label: 'الكل' }] },
    ])}<div data-table></div></div>`;
  let filters = {};
  const table = dataTable(root.querySelector('[data-table]'), {
    title: 'قائمة الأصناف', exportName: 'products', emptyIcon: 'box', empty: 'لا توجد أصناف', emptyHint: 'أضف أول صنف من زر "صنف جديد".',
    fetch: (p) => api('products.list', { ...filters, ...p }),
    columns: [
      { key: 'code', label: 'الكود', sort: true },
      { key: 'name', label: 'الصنف', sort: true, render: (r) => `<b>${esc(r.name)}</b>${r.barcode ? `<div class="small muted">${esc(r.barcode)}</div>` : ''}` , exportValue: (r) => r.name },
      { key: 'kind', label: 'النوع', render: (r) => esc(KIND_LABELS[r.kind]), exportValue: (r) => KIND_LABELS[r.kind] },
      { key: 'category_name', label: 'التصنيف', sort: true },
      { key: 'unit_name', label: 'الوحدة' },
      { key: 'qty', label: 'الرصيد', type: 'qty', sort: true, render: (r) => (r.is_stocked ? `<span class="${r.min_qty > 0 && r.qty <= r.min_qty ? 'neg bold' : ''}">${qty(r.qty)}</span>` : '<span class="muted">خدمة</span>') },
      ...(costs ? [{ key: 'avg_cost', label: 'متوسط التكلفة', type: 'money', sort: true }, { key: 'value', label: 'القيمة', type: 'money', sort: true }] : []),
      { key: 'sale_price', label: 'سعر البيع', type: 'money', sort: true },
      { key: 'active', label: 'الحالة', render: (r) => (r.active ? '' : '<span class="badge bad">موقوف</span>'), exportValue: (r) => (r.active ? 'نشط' : 'موقوف') },
    ],
    footer: costs ? (r) => ({ value: r.rows.reduce((s, x) => s + (x.value || 0), 0) }) : null,
    onRow: (r) => navigate(`#/products/${r.id}`),
    actions: (r) => (can('products.edit') ? `<button class="link-btn" data-act="edit">${icon('edit', 'sm')} تعديل</button><button class="link-btn muted" data-act="toggle">${r.active ? 'إيقاف' : 'تفعيل'}</button>${can('data.delete') ? `<button class="link-btn danger" data-act="del">${icon('trash', 'sm')}</button>` : ''}` : ''),
    onAction: async (act, r) => {
      try {
        if (act === 'edit') { if (await productForm(r.id)) table.reload(false); }
        if (act === 'toggle') { await api('products.toggle', { id: r.id }); toast(r.active ? 'تم إيقاف الصنف' : 'تم تفعيل الصنف'); table.reload(false); }
        if (act === 'del' && await confirmBox(`حذف الصنف "${r.name}" نهائيًا؟ لا يمكن حذف صنف له أي حركات — استخدم الإيقاف بدلًا من ذلك.`, { danger: true, ok: 'حذف' })) { await api('products.delete', { id: r.id }); toast('تم حذف الصنف'); table.reload(false); }
      } catch (e) { showError(e); }
    },
  });
  bindFilters(root.querySelector('.filters'), (v) => { filters = v; table.reload(); });
  const btn = (s, f) => { const b = root.querySelector(s); if (b) b.onclick = f; };
  btn('[data-new]', async () => { const id = await productForm(); if (id) table.reload(); });
  btn('[data-cats]', () => simpleList('categories', 'التصنيفات', [{ name: 'name', label: 'اسم التصنيف', required: true }, { name: 'notes', label: 'ملاحظات' }], () => table.reload(false)));
  btn('[data-units]', () => simpleList('units', 'الوحدات', [{ name: 'name', label: 'اسم الوحدة', required: true, hint: 'مثل: متر، كيلو، لوح، لتر' }, { name: 'symbol', label: 'الرمز المختصر' }], () => {}));
}

/** Product create/edit modal. Returns the id or false. */
export async function productForm(id, preset = {}) {
  const [cats, units, kinds, sups] = await Promise.all([lookup('categories', true), lookup('units', true), lookup('kinds'), lookup('suppliers', true)]);
  const p = id ? await api('products.get', { id }) : { kind: 'raw', unit_id: units[0] && units[0].id, ...preset };
  const s = state.settings;
  const costRef = () => Number(p.avg_cost) || Number(p.purchase_price) || 0;
  const fields = [
    { name: 'name', label: 'اسم الصنف', required: true, full: true },
    { name: 'kind', label: 'نوع الصنف', type: 'select', options: kinds, required: true, hint: 'الخدمة لا تُخزَّن ولا تظهر في المخزون' },
    { name: 'code', label: 'الكود', placeholder: id ? '' : 'تلقائي إذا تُرك فارغًا' },
    { name: 'category_id', label: 'التصنيف', type: 'select', options: opt(cats.filter((c) => c.active !== 0), 'name', 'id', '— بدون —') },
    { name: 'unit_id', label: 'وحدة القياس', type: 'select', options: opt(units), required: true, readonly: false },
    { name: 'barcode', label: 'الباركود' },
    { name: 'default_supplier_id', label: 'المورد الافتراضي', type: 'combo' },
    { type: 'section', label: 'الأسعار' },
    { name: 'purchase_price', label: `سعر الشراء (${currencySymbol()})`, type: 'number', min: 0 },
    { name: 'sale_price', label: `سعر البيع (${currencySymbol()})`, type: 'number', min: 0 },
    { name: 'wholesale_price', label: 'سعر الجملة', type: 'number', min: 0 },
    { name: 'pricing_margin', label: `نسبة ${s.pricing.method === 'margin' ? 'هامش الربح' : 'الإضافة على التكلفة'} % (اختياري)`, type: 'number', min: 0, hint: `الافتراضي من الإعدادات: ${s.pricing.defaultPct}%` },
    { type: 'html', full: true, html: `<div class="alert info" data-suggest style="margin:0"></div>` },
    ...(s.tax.enabled ? [{ name: 'tax_rate', label: `نسبة ${s.tax.label} خاصة بالصنف %`, type: 'number', min: 0, hint: `اتركها فارغة لاستخدام النسبة العامة ${s.tax.defaultRate}%` }] : []),
    { type: 'section', label: 'المخزون' },
    { name: 'min_qty', label: 'الحد الأدنى (تنبيه)', type: 'number', min: 0 },
    { name: 'max_qty', label: 'الحد الأقصى', type: 'number', min: 0 },
    { name: 'description', label: 'الوصف', type: 'textarea', full: true },
    { name: 'notes', label: 'ملاحظات', type: 'textarea', full: true },
    { type: 'html', full: true, html: `<label style="font-size:12.5px;font-weight:700;color:#5a5443">صورة الصنف (اختياري)</label><div class="row"><div class="img-drop" data-img>${p.image ? `<img src="${esc(p.image)}" alt="">` : icon('image', 'lg')}</div><div class="stack small muted"><div>PNG أو JPG — يتم تصغيرها تلقائيًا.</div><button type="button" class="link-btn danger" data-img-clear>إزالة الصورة</button></div></div>` },
  ];
  let image;
  return formModal({
    title: id ? `تعديل الصنف — ${p.name}` : 'صنف جديد', size: 'wide', cols: 'c3', fields, values: p,
    combos: { default_supplier_id: { options: partyOptions(sups) } },
    onOpen: (m) => {
      const unitSel = $('[name=unit_id]', m);
      if (p.has_movements) { unitSel.disabled = true; unitSel.title = 'لا يمكن تغيير الوحدة لصنف له حركات'; }
      const sug = $('[data-suggest]', m);
      const upd = () => {
        const cost = Number($('[name=purchase_price]', m).value) || costRef();
        const pctv = $('[name=pricing_margin]', m).value === '' ? Number(s.pricing.defaultPct) : Number($('[name=pricing_margin]', m).value);
        const price = s.pricing.method === 'margin' ? (pctv < 100 ? cost / (1 - pctv / 100) : 0) : cost * (1 + pctv / 100);
        const avg = id && can('costs.view') ? ` — متوسط التكلفة الحالي: ${fmt(p.avg_cost)}` : '';
        sug.innerHTML = `${icon('calc', 'sm')} <span>سعر البيع المقترح: <b class="num">${fmt(price)}</b> (${s.pricing.method === 'margin' ? 'هامش' : 'إضافة'} ${fmt(pctv, 1)}% على تكلفة ${fmt(cost)})${avg}. <button type="button" class="link-btn" data-apply>تطبيق</button> — يمكنك كتابة السعر يدويًا دائمًا.</span>`;
      };
      m.addEventListener('input', (e) => { if (['purchase_price', 'pricing_margin'].includes(e.target.name)) upd(); });
      m.addEventListener('click', (e) => {
        if (e.target.closest('[data-apply]')) { const v = sug.querySelector('b').textContent.replace(/,/g, ''); $('[name=sale_price]', m).value = v; }
        if (e.target.closest('[data-img-clear]')) { image = null; $('[data-img]', m).innerHTML = icon('image', 'lg'); }
        if (e.target.closest('[data-img]')) pickImage().then((d) => { if (d) { image = d; $('[data-img]', m).innerHTML = `<img src="${d}" alt="">`; } });
      });
      upd();
    },
    submit: async (v) => {
      if (p.has_movements) v.unit_id = p.unit_id;
      const r = await api('products.save', { ...v, id: id || undefined, ...(image !== undefined ? { image } : {}) });
      toast(id ? 'تم حفظ الصنف' : 'تمت إضافة الصنف');
      return id || r;
    },
  });
}

function pickImage() {
  return new Promise((resolve) => {
    const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/png,image/jpeg,image/webp';
    i.onchange = () => {
      const f = i.files[0]; if (!f) return resolve(null);
      const img = new Image(); const url = URL.createObjectURL(f);
      img.onload = () => {
        const max = 600; const k = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
        resolve(c.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => { toast('تعذر قراءة الصورة', 'bad'); resolve(null); };
      img.src = url;
    };
    i.click();
  });
}

/** Small master-data manager (categories / units). */
export async function simpleList(kind, title, fields, after) {
  const m = modal({ title, size: '', body: '<div data-l></div>', foot: `<button class="btn" data-add>${icon('plus', 'sm')} إضافة</button><button class="btn ghost" data-close>إغلاق</button>` });
  const draw = async () => {
    const rows = await lookup(kind, true);
    $('[data-l]', m.el).innerHTML = rows.length ? `<table class="tbl"><thead><tr>${fields.map((f) => `<th>${esc(f.label)}</th>`).join('')}<th>عدد الأصناف</th><th></th></tr></thead><tbody>${rows.map((r) => `<tr data-id="${r.id}">${fields.map((f) => `<td>${esc(r[f.name] || '')}</td>`).join('')}<td class="n">${fmt(r.products_count || 0, 0)}</td><td class="actions"><button class="link-btn" data-e>${icon('edit', 'sm')}</button><button class="link-btn danger" data-d>${icon('trash', 'sm')}</button></td></tr>`).join('')}</tbody></table>` : emptyState('لا توجد عناصر');
  };
  const edit = async (row) => {
    const ok = await formModal({ title: row ? 'تعديل' : 'إضافة', size: 'narrow', cols: 'c1', fields, values: row || {}, submit: (v) => api(`${kind}.save`, { ...v, id: row && row.id }) });
    if (ok) { invalidate(kind); await draw(); after(); }
  };
  m.el.addEventListener('click', async (e) => {
    try {
      if (e.target.closest('[data-add]')) edit();
      const tr = e.target.closest('tr[data-id]'); if (!tr) return;
      const rows = await lookup(kind); const row = rows.find((r) => r.id === Number(tr.dataset.id));
      if (e.target.closest('[data-e]')) edit(row);
      if (e.target.closest('[data-d]') && await confirmBox(`حذف "${row.name}"؟`, { danger: true, ok: 'حذف' })) { await api(`${kind}.delete`, { id: row.id }); invalidate(kind); await draw(); after(); toast('تم الحذف'); }
    } catch (err) { showError(err); }
  });
  await draw();
}

// ------------------------------------------------------------------ item card
async function productCard(root, id) {
  const whs = await whOptions(false);
  let f = { from: '', to: '', warehouse_id: '' };
  const costs = can('costs.view');
  async function load() {
    const [p, card] = await Promise.all([api('products.get', { id }), api('products.card', { id, ...f })]);
    const s = card.summary;
    root.innerHTML = pageHead(p.name, `${p.code} — ${KIND_LABELS[p.kind]}${p.category_name ? ' — ' + p.category_name : ''}`,
      `${can('products.edit') ? `<button class="btn ghost" data-edit>${icon('edit', 'sm')} تعديل</button>` : ''}<button class="btn ghost" data-print>${icon('printer', 'sm')} طباعة الكارت</button>`,
      '<a href="#/products">الأصناف</a> / كارت الصنف')
      + `${p.active ? '' : '<div class="alert warn">هذا الصنف موقوف ولا يظهر في الفواتير الجديدة.</div>'}
      <div class="grid g4" style="margin-bottom:14px">
        <div class="kpi good"><div class="l">الرصيد الحالي</div><div class="v num">${qty(s.qty)}<small>${esc(p.unit_name)}</small></div><div class="h">${p.min_qty ? `الحد الأدنى ${qty(p.min_qty)}` : ''}</div></div>
        ${costs ? `<div class="kpi"><div class="l">قيمة المخزون</div><div class="v num">${fmt(s.value)}<small>${esc(currencySymbol())}</small></div><div class="h">متوسط التكلفة ${fmt(s.avg_cost)}</div></div>` : ''}
        <div class="kpi"><div class="l">إجمالي الوارد / المنصرف</div><div class="v num">${qty(s.total_in)} / ${qty(s.total_out)}</div></div>
        <div class="kpi"><div class="l">سعر البيع</div><div class="v num">${fmt(p.sale_price)}<small>${esc(currencySymbol())}</small></div><div class="h">${p.wholesale_price ? `جملة ${fmt(p.wholesale_price)}` : ''}</div></div>
      </div>
      <div class="grid g3">
        <div class="card"><div class="card-title">${icon('info')} بيانات الصنف</div>${kvList([
    ['الوحدة', p.unit_name], ['الباركود', p.barcode || '—'], ['سعر الشراء', money(p.purchase_price)], costs ? ['آخر سعر شراء', money(p.last_purchase_price)] : null,
    ['المورد الافتراضي', p.supplier_name || '—'], ['الحد الأقصى', p.max_qty ? qty(p.max_qty) : '—'], ['الوصف', p.description || '—'],
  ])}${p.image ? `<img src="${esc(p.image)}" alt="" style="max-width:100%;border-radius:8px;margin-top:10px;border:1px solid var(--line)">` : ''}</div>
        <div class="card"><div class="card-title">${icon('warehouse')} الرصيد حسب المخزن</div>${p.stock.length ? `<table class="tbl compact"><tbody>${p.stock.map((x) => `<tr><td>${esc(x.warehouse_name)}</td><td class="n bold">${qty(x.qty)}</td></tr>`).join('')}</tbody></table>` : emptyState('لا يوجد رصيد')}</div>
        <div class="card"><div class="card-title">${icon('history')} آخر الحركات</div>${kvList([
    ['آخر شراء', s.last_purchase ? `${s.last_purchase.date} — ${s.last_purchase.doc_no} (${qty(s.last_purchase.qty)}${costs ? ' × ' + fmt(s.last_purchase.unit_cost) : ''})` : '—'],
    ['آخر بيع', s.last_sale ? `${s.last_sale.date} — ${s.last_sale.doc_no} (${qty(s.last_sale.qty)} × ${fmt(s.last_sale.unit_price)})` : '—'],
    ['آخر حركة', s.last_move ? `${s.last_move.date} — ${s.last_move.type_label} ${s.last_move.doc_no || ''}` : '—'],
  ])}</div>
      </div>
      <div class="card"><div class="card-title">${icon('ledger')} حركة الصنف</div>
        <div class="filters"><div class="field"><label>من</label><input class="inp" type="date" name="from" value="${esc(f.from)}"></div><div class="field"><label>إلى</label><input class="inp" type="date" name="to" value="${esc(f.to)}"></div>
        <div class="field"><label>المخزن</label><select class="inp" name="warehouse_id"><option value="">كل المخازن</option>${whs.map((w) => `<option value="${w.value}" ${String(w.value) === String(f.warehouse_id) ? 'selected' : ''}>${esc(w.label)}</option>`).join('')}</select></div></div>
        <div data-mv></div></div>`;
    const rows = [...(f.from ? [{ date: f.from, type_label: 'رصيد أول المدة', balance: card.opening }] : []), ...card.rows];
    dataTable(root.querySelector('[data-mv]'), {
      rows, title: `كارت الصنف: ${p.name}`, exportName: `item_${p.code}`, empty: 'لا توجد حركات في الفترة', sort: null,
      printSub: () => `${p.code} — الرصيد ${qty(s.qty)} ${p.unit_name}`,
      columns: [
        { key: 'date', label: 'التاريخ', type: 'date' }, { key: 'type_label', label: 'الحركة' }, { key: 'doc_no', label: 'المستند' }, { key: 'warehouse_name', label: 'المخزن' },
        { key: 'qty_in', label: 'وارد', type: 'qty' }, { key: 'qty_out', label: 'منصرف', type: 'qty' }, { key: 'balance', label: 'الرصيد', type: 'qty', cls: 'bold' },
        ...(costs ? [{ key: 'unit_cost', label: 'تكلفة الوحدة', type: 'money' }, { key: 'avg_cost_after', label: 'المتوسط بعد الحركة', type: 'money' }] : []), { key: 'notes', label: 'ملاحظات' },
      ],
    });
    root.querySelector('.filters').onchange = (e) => { f[e.target.name] = e.target.value; load().catch(showError); };
    const ed = root.querySelector('[data-edit]'); if (ed) ed.onclick = async () => { if (await productForm(id)) load(); };
    root.querySelector('[data-print]').onclick = () => printDoc(`${docHeader('كارت صنف', `${p.code} — ${p.name}`)}
      <div class="meta"><div><b>الرصيد:</b> ${qty(s.qty)} ${esc(p.unit_name)}</div>${costs ? `<div><b>متوسط التكلفة:</b> ${fmt(s.avg_cost)}</div><div><b>القيمة:</b> ${money(s.value)}</div>` : ''}<div><b>الفترة:</b> ${esc(f.from || 'البداية')} — ${esc(f.to || 'اليوم')}</div></div>
      <table><thead><tr><th>التاريخ</th><th>الحركة</th><th>المستند</th><th>المخزن</th><th>وارد</th><th>منصرف</th><th>الرصيد</th>${costs ? '<th>التكلفة</th>' : ''}</tr></thead><tbody>${rows.map((r) => `<tr><td>${esc(date(r.date))}</td><td>${esc(r.type_label)}</td><td>${esc(r.doc_no || '')}</td><td>${esc(r.warehouse_name || '')}</td><td>${r.qty_in ? qty(r.qty_in) : ''}</td><td>${r.qty_out ? qty(r.qty_out) : ''}</td><td>${qty(r.balance)}</td>${costs ? `<td>${r.unit_cost ? fmt(r.unit_cost) : ''}</td>` : ''}</tr>`).join('')}</tbody></table>`);
  }
  await load();
}
