import { api } from '../api.js';
import { esc, fmt, qty, date, dateTime, can, today, $, $$, navigate, debounce } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { pageHead, dataTable, filterBar, bindFilters, formModal, confirmBox, toast, showError, kvList } from '../ui/components.js';
import { printCount } from '../ui/print.js';
import { lookup, opt, whOptions, defaultWh, statusBadge } from './shared.js';

export async function counts(root, parts) {
  if (parts[0]) return countPage(root, Number(parts[0]));
  root.innerHTML = pageHead('الجرد', 'جرد فعلي للمخزن: تُسجَّل الكميات الفعلية، ثم يولّد الاعتماد تسوية تلقائية بالفروقات', can('stockcount.manage') ? `<button class="btn" data-new>${icon('plus', 'sm')} جرد جديد</button>` : '')
    + `<div class="card">${filterBar([{ name: 'from', label: 'من', type: 'date' }, { name: 'to', label: 'إلى', type: 'date' },
      { name: 'status', label: 'الحالة', type: 'select', options: [{ value: '', label: 'الكل' }, { value: 'draft', label: 'مسودة' }, { value: 'approved', label: 'معتمد' }, { value: 'cancelled', label: 'ملغي' }] }])}<div data-t></div></div>`;
  let f = {};
  const t = dataTable($('[data-t]', root), {
    title: 'عمليات الجرد', exportName: 'stock_counts', empty: 'لا توجد عمليات جرد', emptyIcon: 'clipboard', emptyHint: 'ابدأ جردًا جديدًا لمخزن كامل أو لتصنيف محدد',
    fetch: (p) => api('counts.list', { ...f, ...p }),
    columns: [{ key: 'doc_no', label: 'الرقم' }, { key: 'date', label: 'التاريخ', type: 'date' }, { key: 'warehouse_name', label: 'المخزن' },
      { key: 'items_count', label: 'عدد الأصناف', type: 'qty' }, { key: 'counted_count', label: 'تم عدّه', type: 'qty' },
      { key: 'status', label: 'الحالة', render: (r) => statusBadge(r.status), cls: 'keep', exportValue: (r) => ({ draft: 'مسودة', approved: 'معتمد', cancelled: 'ملغي' }[r.status]) }, { key: 'notes', label: 'ملاحظات' }],
    rowClass: (r) => (r.status === 'cancelled' ? 'void' : ''),
    onRow: (r) => navigate(`#/counts/${r.id}`),
  });
  bindFilters($('.filters', root), (v) => { f = v; t.reload(); });
  const n = $('[data-new]', root);
  if (n) n.onclick = async () => {
    const [whs, cats] = await Promise.all([whOptions(), lookup('categories')]);
    const r = await formModal({
      title: 'جرد جديد', values: { warehouse_id: await defaultWh(), date: today(), onlyWithStock: false },
      fields: [{ name: 'warehouse_id', label: 'المخزن', type: 'select', options: whs, required: true }, { name: 'date', label: 'تاريخ الجرد', type: 'date' },
        { name: 'category_id', label: 'التصنيف (اختياري)', type: 'select', options: opt(cats, 'name', 'id', 'كل التصنيفات') },
        { name: 'onlyWithStock', label: 'الأصناف التي لها رصيد في هذا المخزن فقط', type: 'checkbox' },
        { name: 'notes', label: 'ملاحظات', full: true }],
      extra: '<div class="alert info" style="margin-top:12px">ستُنشأ ورقة جرد بكل الأصناف المطابقة وكمياتها الحالية. يمكنك طباعتها للعدّ اليدوي ثم إدخال الكميات الفعلية.</div>',
      submit: (v) => api('counts.create', v),
    });
    if (r) { toast(`تم إنشاء الجرد ${r.doc_no}`); navigate(`#/counts/${r.id}`); }
  };
}

async function countPage(root, id) {
  const costs = can('costs.view');
  const editable = (c) => c.status === 'draft' && can('stockcount.manage');
  let c = await api('counts.get', { id });
  const edits = new Map(); // product_id → {actual_qty, reason}
  const val = (i, k) => (edits.has(i.product_id) && edits.get(i.product_id)[k] !== undefined ? edits.get(i.product_id)[k] : i[k]);

  const draw = () => {
    const ed = editable(c);
    root.innerHTML = pageHead(`جرد ${c.doc_no}`, `${c.warehouse_name} — ${date(c.date)}`, `
      <button class="btn ghost" data-print>${icon('printer', 'sm')} طباعة ورقة الجرد</button>
      ${ed ? `<button class="btn ghost" data-fill title="للأصناف التي لم تُعدّ بعد">${icon('check', 'sm')} اعتبار غير المعدود مطابقًا</button><button class="btn sec" data-save>${icon('save', 'sm')} حفظ الكميات</button><button class="btn" data-approve>${icon('check', 'sm')} اعتماد الجرد</button><button class="btn ghost danger-text" data-cancel>${icon('ban', 'sm')} إلغاء</button>` : ''}`,
    '<a href="#/counts">الجرد</a> / ' + esc(c.doc_no))
      + `<div class="grid g4" style="margin-bottom:14px">
        <div class="kpi"><div class="l">${icon('clipboard', 'sm')} الحالة</div><div class="v" style="font-size:18px">${statusBadge(c.status)}</div><div class="h">${c.approved_at ? 'اعتمده ' + esc(c.approver_name || '') + ' في ' + esc(dateTime(c.approved_at)) : 'أعده ' + esc(c.user_name || '')}</div></div>
        <div class="kpi"><div class="l">${icon('boxes', 'sm')} الأصناف</div><div class="v num" data-counted>${fmt(c.counted, 0)} / ${fmt(c.items.length, 0)}</div><div class="h">تم عدّها</div></div>
        <div class="kpi"><div class="l">${icon('alert', 'sm')} أصناف بها فروق</div><div class="v num" data-ndiff>0</div></div>
        ${costs ? `<div class="kpi"><div class="l">${icon('scale', 'sm')} صافي قيمة الفروق</div><div class="v num" data-vdiff>0</div><div class="h">بمتوسط التكلفة</div></div>` : '<div></div>'}</div>
      ${c.adjustment_no ? `<div class="alert ok" style="margin-bottom:12px">${icon('check', 'sm')} تم توليد التسوية ${esc(c.adjustment_no)} بالفروقات عند الاعتماد.</div>` : ''}
      ${c.notes ? `<div class="alert info" style="margin-bottom:12px">${esc(c.notes)}</div>` : ''}
      <div class="card"><div class="filters"><div class="field grow"><label>بحث في الأصناف</label><input class="inp" data-q placeholder="الاسم أو الكود أو التصنيف"></div>
        <div class="field"><label>عرض</label><select class="inp" data-show><option value="">الكل</option><option value="pending">غير المعدود</option><option value="diff">به فروق</option></select></div></div>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>الكود</th><th>الصنف</th><th>التصنيف</th><th>الوحدة</th><th class="n">كمية النظام</th><th class="n" style="width:130px">الكمية الفعلية</th><th class="n">الفرق</th>${costs ? '<th class="n">قيمة الفرق</th>' : ''}<th style="width:180px">سبب الفرق</th></tr></thead><tbody data-rows></tbody></table></div></div>`;
    renderRows();
    bind();
  };

  const filterState = { q: '', show: '' };
  function rowCalc(i) {
    const a = val(i, 'actual_qty');
    const actual = a === null || a === undefined || a === '' ? null : Number(a);
    const diff = actual === null || Number.isNaN(actual) ? null : Math.round((actual - i.system_qty) * 10000) / 10000;
    return { actual, diff, value: diff === null ? null : diff * (i.unit_cost || 0) };
  }
  function renderRows() {
    const ed = editable(c);
    const q = filterState.q.toLowerCase();
    const rows = c.items.filter((i) => {
      if (q && !`${i.product_name} ${i.product_code} ${i.category_name || ''}`.toLowerCase().includes(q)) return false;
      const r = rowCalc(i);
      if (filterState.show === 'pending' && r.actual !== null) return false;
      if (filterState.show === 'diff' && !(r.diff && Math.abs(r.diff) > 0.00001)) return false;
      return true;
    });
    $('[data-rows]', root).innerHTML = rows.map((i) => {
      const r = rowCalc(i);
      const a = val(i, 'actual_qty');
      return `<tr data-p="${i.product_id}"><td>${esc(i.product_code)}</td><td>${esc(i.product_name)}</td><td>${esc(i.category_name || '')}</td><td>${esc(i.unit_name)}</td><td class="n">${qty(i.system_qty)}</td>
        <td class="n">${ed ? `<input class="inp num" type="number" step="any" min="0" data-k="actual_qty" value="${a === null || a === undefined ? '' : esc(a)}">` : (a === null ? '—' : qty(a))}</td>
        <td class="n bold ${r.diff < 0 ? 'neg' : r.diff > 0 ? 'pos' : ''}" data-diff>${r.diff === null ? '' : qty(r.diff)}</td>
        ${costs ? `<td class="n" data-val>${r.value === null ? '' : fmt(r.value)}</td>` : ''}
        <td>${ed ? `<input class="inp" data-k="reason" value="${esc(val(i, 'reason') || '')}" placeholder="مثال: تالف، خطأ عد…">` : esc(i.reason || '')}</td></tr>`;
    }).join('') || '<tr><td colspan="9"><div class="empty muted">لا توجد أصناف مطابقة</div></td></tr>';
    stats();
  }
  function stats() {
    let counted = 0; let nd = 0; let v = 0;
    c.items.forEach((i) => { const r = rowCalc(i); if (r.actual !== null) counted++; if (r.diff && Math.abs(r.diff) > 0.00001) { nd++; v += r.value || 0; } });
    $('[data-counted]', root).textContent = `${fmt(counted, 0)} / ${fmt(c.items.length, 0)}`;
    $('[data-ndiff]', root).textContent = fmt(nd, 0);
    const vd = $('[data-vdiff]', root); if (vd) { vd.textContent = fmt(v); vd.className = `v num ${v < 0 ? 'neg' : ''}`; }
  }
  const dirty = () => edits.size > 0;

  async function save(quiet) {
    if (!dirty()) { if (!quiet) toast('لا توجد تعديلات لحفظها', 'warn'); return true; }
    const items = [...edits.entries()].map(([pid, e]) => {
      const i = c.items.find((x) => x.product_id === pid);
      return { product_id: pid, actual_qty: e.actual_qty !== undefined ? e.actual_qty : i.actual_qty, reason: e.reason !== undefined ? e.reason : i.reason };
    });
    c = await api('counts.saveItems', { id: c.id, items });
    edits.clear();
    if (!quiet) toast('تم حفظ الكميات');
    return true;
  }

  function bind() {
    const tb = $('[data-rows]', root);
    tb.addEventListener('input', (e) => {
      const k = e.target.dataset.k; if (!k) return;
      const tr = e.target.closest('tr'); const pid = Number(tr.dataset.p);
      const cur = edits.get(pid) || {}; cur[k] = e.target.value === '' && k === 'actual_qty' ? null : e.target.value; edits.set(pid, cur);
      if (k === 'actual_qty') {
        const i = c.items.find((x) => x.product_id === pid); const r = rowCalc(i);
        const d = $('[data-diff]', tr); d.textContent = r.diff === null ? '' : qty(r.diff); d.className = `n bold ${r.diff < 0 ? 'neg' : r.diff > 0 ? 'pos' : ''}`;
        const v = $('[data-val]', tr); if (v) v.textContent = r.value === null ? '' : fmt(r.value);
        stats();
      }
    });
    tb.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && e.target.dataset.k === 'actual_qty') {
        e.preventDefault();
        const ins = $$('input[data-k="actual_qty"]', tb); const n = ins[ins.indexOf(e.target) + 1]; if (n) { n.focus(); n.select(); }
      }
    });
    $('[data-q]', root).addEventListener('input', debounce((e) => { filterState.q = e.target.value; renderRows(); }, 200));
    $('[data-show]', root).addEventListener('change', (e) => { filterState.show = e.target.value; renderRows(); });
    $('[data-print]', root).onclick = async () => { try { if (editable(c)) await save(true); printCount(c); } catch (e) { showError(e); } };
    const b = (s, fn) => { const x = $(s, root); if (x) x.onclick = async () => { try { await fn(); } catch (e) { showError(e); } }; };
    b('[data-save]', async () => { await save(false); draw(); });
    b('[data-fill]', async () => {
      const pending = c.items.filter((i) => rowCalc(i).actual === null);
      if (!pending.length) { toast('كل الأصناف تم عدّها', 'warn'); return; }
      if (!await confirmBox(`سيتم اعتبار ${pending.length} صنفًا غير معدود مطابقًا لكمية النظام (بدون فرق). متابعة؟`)) return;
      pending.forEach((i) => edits.set(i.product_id, { ...(edits.get(i.product_id) || {}), actual_qty: i.system_qty }));
      await save(true); toast('تم'); draw();
    });
    b('[data-approve]', async () => {
      await save(true);
      const r0 = c.items.map(rowCalc);
      const nd = r0.filter((r) => r.diff && Math.abs(r.diff) > 0.00001).length;
      const pending = r0.filter((r) => r.actual === null).length;
      const ok = await confirmBox(`اعتماد الجرد ${c.doc_no}؟ سيتم تعديل أرصدة ${nd} صنفًا بالفروقات وتسجيل قيد تسوية. لا يمكن التراجع إلا بإلغاء التسوية الناتجة.`, {
        ok: 'اعتماد', details: pending ? `<div class="alert warn" style="margin-bottom:10px">${pending} صنفًا لم تُدخل كمياتها الفعلية وسيتم تجاهلها (لن تتغير أرصدتها).</div>` : '',
      });
      if (!ok) return;
      const r = await api('counts.approve', { id: c.id });
      toast(r.differences ? `تم الاعتماد وإنشاء التسوية ${r.adjustment.doc_no}` : 'تم الاعتماد بدون فروق');
      c = await api('counts.get', { id: c.id }); draw();
    });
    b('[data-cancel]', async () => {
      if (!await confirmBox(`إلغاء الجرد ${c.doc_no}؟ لن تتأثر أرصدة المخزون.`, { danger: true, ok: 'إلغاء الجرد' })) return;
      await api('counts.cancel', { id: c.id }); toast('تم إلغاء الجرد'); c = await api('counts.get', { id: c.id }); draw();
    });
  }
  draw();
  // warn before leaving with unsaved quantities
  const leave = () => { if (dirty()) toast('تنبيه: لم تحفظ بعض الكميات المدخلة في الجرد', 'warn'); window.removeEventListener('hashchange', leave); };
  window.addEventListener('hashchange', leave);
}
export { kvList };
