import { api } from '../api.js';
import { esc, money, fmt, date, can, today, $, navigate, currencySymbol } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { pageHead, dataTable, filterBar, bindFilters, formModal, confirmBox, toast, showError, kvList } from '../ui/components.js';
import { printStatement } from '../ui/print.js';
import { invalidate } from './shared.js';

const T = {
  customer: { plural: 'العملاء', one: 'عميل', the: 'العميل', api: 'customers', route: 'customers', perm: 'customers.manage', docRoute: 'sales', docLabel: 'فاتورة بيع', payDir: 'in', payLabel: 'تحصيل', balHint: (b) => (b > 0 ? 'مستحق لنا على العميل' : b < 0 ? 'رصيد دائن للعميل' : 'لا يوجد رصيد') },
  supplier: { plural: 'الموردون', one: 'مورد', the: 'المورد', api: 'suppliers', route: 'suppliers', perm: 'suppliers.manage', docRoute: 'purchases', docLabel: 'فاتورة شراء', payDir: 'out', payLabel: 'سداد', balHint: (b) => (b > 0 ? 'مستحق للمورد علينا' : b < 0 ? 'رصيد مدين لنا على المورد' : 'لا يوجد رصيد') },
};

export const customers = (root, parts) => (parts[0] ? partyPage(root, 'customer', Number(parts[0])) : partyList(root, 'customer'));
export const suppliers = (root, parts) => (parts[0] ? partyPage(root, 'supplier', Number(parts[0])) : partyList(root, 'supplier'));

async function partyForm(type, row) {
  const t = T[type];
  const fields = [
    { name: 'name', label: `اسم ${t.the}`, required: true }, { name: 'code', label: 'الكود', placeholder: row ? '' : 'تلقائي' },
    { name: 'phone', label: 'الهاتف' }, { name: 'email', label: 'البريد الإلكتروني', type: 'email' },
    { name: 'contact_person', label: 'مسؤول التواصل' }, { name: 'tax_no', label: 'الرقم الضريبي' },
    ...(type === 'customer' ? [{ name: 'credit_limit', label: `حد الائتمان (${currencySymbol()})`, type: 'number', min: 0, hint: '0 = بدون حد' }] : []),
    { name: 'address', label: 'العنوان', full: true }, { name: 'notes', label: 'ملاحظات', type: 'textarea', full: true },
  ];
  if (!row) fields.push({ name: 'opening', label: `رصيد افتتاحي (${currencySymbol()})`, type: 'number', hint: type === 'customer' ? 'موجب = مستحق على العميل، سالب = له' : 'موجب = مستحق للمورد، سالب = عليه', full: false });
  return formModal({
    title: row ? `تعديل ${t.one} — ${row.name}` : `${t.one} جديد`, fields, values: row || {},
    submit: async (v) => {
      const { opening, ...data } = v;
      const id = await api(`${t.api}.save`, { ...data, id: row && row.id });
      if (!row && Number(opening)) await api('opening.create', { kind: type, party_id: id, amount: Number(opening), notes: 'رصيد افتتاحي عند الإضافة' });
      invalidate(t.api); toast('تم الحفظ'); return id;
    },
  });
}

async function openingForm(type, id, name) {
  return formModal({
    title: `رصيد افتتاحي — ${name}`, size: 'narrow', cols: 'c1',
    fields: [{ name: 'amount', label: `المبلغ (${currencySymbol()})`, type: 'number', required: true, hint: type === 'customer' ? 'موجب = مستحق على العميل، سالب = له' : 'موجب = مستحق للمورد، سالب = عليه' }, { name: 'date', label: 'التاريخ', type: 'date', value: today() }, { name: 'notes', label: 'ملاحظات' }],
    submit: async (v) => { await api('opening.create', { kind: type, party_id: id, ...v }); invalidate(T[type].api); toast('تم تسجيل الرصيد الافتتاحي'); },
  });
}

async function partyList(root, type) {
  const t = T[type];
  root.innerHTML = pageHead(t.plural, '', can(t.perm) ? `<button class="btn" data-new>${icon('plus', 'sm')} ${t.one} جديد</button>` : '')
    + `<div class="card">${filterBar([{ name: 'q', label: 'بحث', placeholder: 'الاسم أو الكود أو الهاتف…' },
      { name: 'balance', label: 'الرصيد', type: 'select', options: [{ value: '', label: 'الكل' }, { value: 'due', label: 'لهم رصيد مستحق' }] },
      { name: 'active', label: 'الحالة', type: 'select', options: [{ value: 'active', label: 'نشط' }, { value: 'inactive', label: 'موقوف' }, { value: '', label: 'الكل' }] }], { active: 'active' })}<div data-t></div></div>`;
  let f = { active: 'active' };
  const tbl = dataTable($('[data-t]', root), {
    title: t.plural, exportName: t.api, emptyIcon: 'users', empty: `لا يوجد ${t.plural}`,
    fetch: (p) => api(`${t.api}.list`, { ...f, ...p }),
    columns: [
      { key: 'code', label: 'الكود', sort: true }, { key: 'name', label: 'الاسم', sort: true, render: (r) => `<b>${esc(r.name)}</b>${r.active ? '' : ' <span class="badge bad">موقوف</span>'}` , exportValue: (r) => r.name },
      { key: 'phone', label: 'الهاتف' }, { key: 'invoices_total', label: type === 'customer' ? 'إجمالي المبيعات' : 'إجمالي المشتريات', type: 'money', sort: true },
      { key: 'returns_total', label: 'المرتجعات', type: 'money' }, { key: 'paid', label: 'المدفوع', type: 'money' },
      { key: 'balance', label: 'الرصيد المتبقي', type: 'money', sort: true, render: (r) => `<b class="${r.balance > 0.004 ? (type === 'customer' ? 'pos' : 'neg') : ''}">${fmt(r.balance)}</b>` },
      ...(type === 'customer' ? [{ key: 'credit_limit', label: 'حد الائتمان', type: 'money', render: (r) => (r.credit_limit ? `${fmt(r.credit_limit)}${r.balance > r.credit_limit ? ' <span class="badge bad">تجاوز</span>' : ''}` : '—') }] : []),
    ],
    footer: (r) => ({ invoices_total: r.rows.reduce((s, x) => s + x.invoices_total, 0), paid: r.rows.reduce((s, x) => s + x.paid, 0), balance: r.rows.reduce((s, x) => s + x.balance, 0), returns_total: r.rows.reduce((s, x) => s + x.returns_total, 0) }),
    onRow: (r) => navigate(`#/${t.route}/${r.id}`),
    actions: (r) => (can(t.perm) ? `<button class="link-btn" data-act="edit">${icon('edit', 'sm')} تعديل</button><button class="link-btn muted" data-act="toggle">${r.active ? 'إيقاف' : 'تفعيل'}</button>${can('data.delete') ? `<button class="link-btn danger" data-act="del">${icon('trash', 'sm')}</button>` : ''}` : ''),
    onAction: async (a, r) => {
      try {
        if (a === 'edit' && await partyForm(type, r)) tbl.reload(false);
        if (a === 'toggle') { if (r.active && Math.abs(r.balance) > 0.004 && !await confirmBox(`${t.the} عليه رصيد ${money(r.balance)}. إيقافه يمنع استخدامه في مستندات جديدة فقط. متابعة؟`)) return; await api(`${t.api}.toggle`, { id: r.id }); invalidate(t.api); tbl.reload(false); }
        if (a === 'del' && await confirmBox(`حذف "${r.name}" نهائيًا؟ لا يمكن حذف من له مستندات أو قيود — استخدم الإيقاف.`, { danger: true, ok: 'حذف' })) { await api(`${t.api}.delete`, { id: r.id }); invalidate(t.api); toast('تم الحذف'); tbl.reload(false); }
      } catch (e) { showError(e); }
    },
  });
  bindFilters($('.filters', root), (v) => { f = v; tbl.reload(); });
  const n = $('[data-new]', root); if (n) n.onclick = async () => { if (await partyForm(type)) tbl.reload(); };
}

async function partyPage(root, type, id) {
  const t = T[type];
  let f = { from: '', to: '' };
  const load = async () => {
    const [p, st] = await Promise.all([api(`${t.api}.get`, { id }), api('statements.party', { party_type: type, party_id: id, from: f.from || null, to: f.to || null })]);
    root.innerHTML = pageHead(p.name, `${p.code}${p.phone ? ' — ' + p.phone : ''}`, `
        ${can('payments.manage') ? `<button class="btn gold" data-pay>${icon('coins', 'sm')} ${t.payLabel}</button>` : ''}
        ${can(type === 'customer' ? 'sales.create' : 'purchases.create') ? `<a class="btn ghost" href="#/${t.docRoute}/new">${icon('plus', 'sm')} ${t.docLabel}</a>` : ''}
        ${can(t.perm) ? `<button class="btn ghost" data-edit>${icon('edit', 'sm')} تعديل</button>` : ''}${can('accounting.manage') || can(t.perm) ? `<button class="btn ghost" data-opening>${icon('plus', 'sm')} رصيد افتتاحي</button>` : ''}`,
    `<a href="#/${t.route}">${t.plural}</a> / كشف حساب`)
      + `<div class="grid g4" style="margin-bottom:14px">
        <div class="kpi ${p.balance > 0.004 ? 'bad' : 'good'}"><div class="l">الرصيد الحالي</div><div class="v num">${fmt(p.balance)}<small>${esc(currencySymbol())}</small></div><div class="h">${t.balHint(p.balance)}</div></div>
        <div class="kpi"><div class="l">${type === 'customer' ? 'إجمالي المبيعات' : 'إجمالي المشتريات'}</div><div class="v num">${fmt(p.invoices_total)}</div></div>
        <div class="kpi"><div class="l">المدفوع</div><div class="v num">${fmt(p.paid)}</div></div>
        <div class="kpi"><div class="l">المرتجعات</div><div class="v num">${fmt(p.returns_total)}</div>${type === 'customer' && p.credit_limit ? `<div class="h">حد الائتمان ${fmt(p.credit_limit)}</div>` : ''}</div></div>
      <div class="grid g3"><div class="card">${kvList([['الهاتف', p.phone], ['البريد', p.email], ['العنوان', p.address], ['مسؤول التواصل', p.contact_person], ['الرقم الضريبي', p.tax_no], ['ملاحظات', p.notes]])}</div>
      <div class="card" style="grid-column: span 2"><div class="card-title"><span>${icon('ledger')} كشف الحساب</span><button class="btn ghost sm" data-print>${icon('printer', 'sm')} طباعة الكشف</button></div>
        <div class="filters"><div class="field"><label>من</label><input class="inp" type="date" name="from" value="${esc(f.from)}"></div><div class="field"><label>إلى</label><input class="inp" type="date" name="to" value="${esc(f.to)}"></div></div>
        <div data-st></div></div></div>`;
    dataTable($('[data-st]', root), {
      rows: [{ date: f.from, description: 'رصيد أول المدة', balance: st.opening }, ...st.rows], title: `كشف حساب ${p.name}`, exportName: `statement_${p.code}`,
      columns: [{ key: 'date', label: 'التاريخ', type: 'date' }, { key: 'doc_no', label: 'المستند' }, { key: 'description', label: 'البيان' }, { key: 'debit', label: 'مدين', type: 'money' }, { key: 'credit', label: 'دائن', type: 'money' }, { key: 'balance', label: 'الرصيد', type: 'money', cls: 'bold' }],
      footer: () => ({ debit: st.total_debit, credit: st.total_credit, balance: st.closing }), pageSize: 50,
    });
    $('.filters', root).onchange = (e) => { f[e.target.name] = e.target.value; load().catch(showError); };
    $('[data-print]', root).onclick = () => printStatement(st);
    const b = (s, fn) => { const x = $(s, root); if (x) x.onclick = fn; };
    b('[data-edit]', async () => { if (await partyForm(type, p)) load(); });
    b('[data-opening]', async () => { if (await openingForm(type, id, p.name)) load(); });
    b('[data-pay]', async () => { const { paymentForm } = await import('./finance.js'); if (await paymentForm({ direction: t.payDir, party_type: type, party_id: id, amount: p.balance > 0 ? p.balance : '' })) load(); });
  };
  await load();
}
export { date };
