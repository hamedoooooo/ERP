import { api } from '../api.js';
import { esc, money, fmt, qty, date, can, monthStart, today, yearStart, state } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { pageHead, emptyState } from '../ui/components.js';
import { barChart, donut, hbars, PALETTE } from '../ui/charts.js';

const PERIODS = [['month', 'هذا الشهر'], ['year', 'هذه السنة'], ['all', 'كل الفترات']];
const KIND = { sale: ['فاتورة بيع', '#/sales/'], purchase: ['فاتورة شراء', '#/purchases/'], receipt: ['تحصيل', '#/payments?'], expense: ['مصروف', '#/expenses?'] };

export async function dashboard(root) {
  let period = sessionStorage.getItem('dash-period') || 'month';
  root.innerHTML = pageHead('لوحة التحكم', state.settings.company.companyName || '', `<div class="seg">${PERIODS.map(([k, l]) => `<button data-p="${k}">${l}</button>`).join('')}</div>`) + '<div data-body></div>';
  const seg = root.querySelector('.seg');
  const body = root.querySelector('[data-body]');
  seg.onclick = (e) => { const b = e.target.closest('[data-p]'); if (b) { period = b.dataset.p; sessionStorage.setItem('dash-period', period); load(); } };

  async function load() {
    seg.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.p === period));
    const from = period === 'month' ? monthStart() : period === 'year' ? yearStart() : '1900-01-01';
    const d = await api('dashboard.get', { from, to: today() });
    const k = d.kpis;
    const kpi = (label, v, ic, opts = {}) => (v === null ? '' : `<div class="kpi ${opts.cls || ''} ${opts.href ? 'link' : ''}" ${opts.href ? `data-href="${opts.href}"` : ''}><div class="l">${icon(ic, 'sm')} ${esc(label)}</div><div class="v num">${opts.count ? fmt(v, 0) : fmt(v)}${opts.count ? '' : `<small>${esc(state.settings.currency.symbol)}</small>`}</div>${opts.hint ? `<div class="h">${opts.hint}</div>` : ''}</div>`);
    body.innerHTML = `
      <div class="grid g4" style="margin-bottom:14px">
        ${kpi('المبيعات (صافي)', k.sales, 'receipt', { href: '#/sales', cls: 'good' })}
        ${kpi('المشتريات', k.purchases, 'cart', { href: '#/purchases' })}
        ${kpi('مجمل الربح', k.gross_profit, 'chart', { cls: k.gross_profit < 0 ? 'bad' : 'good' })}
        ${kpi('صافي الربح', k.net_profit, 'pie', { cls: k.net_profit < 0 ? 'bad' : 'good', href: '#/reports/income' })}
        ${kpi('المصروفات', k.expenses, 'wallet', { href: '#/expenses' })}
        ${kpi('قيمة المخزون', k.inventory_value, 'warehouse', { href: '#/reports/stock', hint: 'بمتوسط التكلفة المرجح' })}
        ${kpi('مستحقات العملاء', k.ar, 'users', { href: '#/customers', hint: 'أرصدة مدينة لنا' })}
        ${kpi('مستحقات الموردين', k.ap, 'truck', { href: '#/suppliers', hint: 'أرصدة دائنة علينا' })}
        ${kpi('الصندوق', k.cash, 'cash', { href: '#/cash' })}
        ${kpi('البنك', k.bank, 'bank', { href: '#/cash' })}
        ${kpi('أوامر جارية التصنيع', k.mo_active, 'factory', { count: true, href: '#/mo?stage=active', hint: `${fmt(k.mo_open, 0)} أمر جديد/مخطط — ${fmt(k.mo_done_period, 0)} اكتمل في الفترة` })}
        ${kpi('أصناف منخفضة المخزون', k.low_stock, 'bell', { count: true, cls: k.low_stock ? 'bad' : 'good', href: '#/reports/low_stock' })}
        ${kpi('العملاء', k.customers, 'user', { count: true, href: '#/customers' })}
        ${kpi('الموردون', k.suppliers, 'truck', { count: true, href: '#/suppliers' })}
      </div>
      <div class="grid g2">
        <div class="card"><div class="card-title">${icon('chart')} الأداء الشهري (آخر 12 شهرًا)</div>
          ${barChart(d.months.map((m) => m.label), [
    { name: 'المبيعات', color: '#1F4B3F', values: d.months.map((m) => m.sales) },
    { name: 'المشتريات', color: '#A8823C', values: d.months.map((m) => m.purchases) },
    { name: 'المصروفات', color: '#8B3A3A', values: d.months.map((m) => m.expenses) },
    ...(d.months[0].net_profit !== null ? [{ name: 'صافي الربح', color: '#3d5a80', type: 'line', values: d.months.map((m) => m.net_profit) }] : []),
  ])}</div>
        <div class="card"><div class="card-title">${icon('pie')} المصروفات حسب التصنيف</div>${donut(d.exp_by_cat.map((x, i) => ({ ...x, color: PALETTE[i % PALETTE.length] })), { center: fmt(d.exp_by_cat.reduce((s, x) => s + x.value, 0), 0) })}</div>
      </div>
      <div class="grid g3">
        <div class="card"><div class="card-title">${icon('factory')} أوامر التصنيع حسب الحالة</div>${hbars(d.mo_by_status.map((x) => ({ label: x.label, value: x.value, color: x.color })))}</div>
        <div class="card"><div class="card-title">${icon('calendar')} مواعيد تسليم قريبة أو متأخرة</div>
          ${d.overdue.length ? `<table class="tbl compact"><tbody>${d.overdue.map((m) => `<tr class="click" data-href="#/mo/${m.id}"><td><b>${esc(m.doc_no)}</b><div class="small muted">${esc(m.product_name)}${m.customer_name ? ' — ' + esc(m.customer_name) : ''}</div></td><td class="n"><span class="badge ${m.due_date < today() ? 'bad' : 'warn'}">${esc(date(m.due_date))}</span></td></tr>`).join('')}</tbody></table>` : emptyState('لا توجد مواعيد متأخرة', '', 'check')}
        </div>
        <div class="card"><div class="card-title">${icon('bell')} أصناف تحت الحد الأدنى</div>
          ${d.low_stock.length ? `<table class="tbl compact"><tbody>${d.low_stock.map((p) => `<tr class="click" data-href="#/products/${p.id}"><td>${esc(p.name)}</td><td class="n"><span class="neg bold">${qty(p.qty)}</span> <span class="muted small">/ ${qty(p.min_qty)} ${esc(p.unit)}</span></td></tr>`).join('')}</tbody></table>` : emptyState('المخزون فوق الحد الأدنى', '', 'check')}
        </div>
      </div>
      <div class="card"><div class="card-title">${icon('history')} آخر المستندات</div>
        ${d.recent.length ? `<table class="tbl"><thead><tr><th>النوع</th><th>الرقم</th><th>التاريخ</th><th class="n">المبلغ</th><th>الحالة</th></tr></thead><tbody>${d.recent.map((r) => `<tr class="click ${r.status === 'void' ? 'void' : ''}" data-href="${KIND[r.kind][1]}${r.kind === 'sale' || r.kind === 'purchase' ? r.id : ''}"><td>${KIND[r.kind][0]}</td><td>${esc(r.doc_no)}</td><td>${esc(date(r.date))}</td><td class="n">${money(r.amount)}</td><td class="keep">${r.status === 'void' ? '<span class="badge bad">ملغي</span>' : '<span class="badge ok">معتمد</span>'}</td></tr>`).join('')}</tbody></table>`
    : emptyState('لم تُسجل أي مستندات بعد', 'ابدأ بإضافة الأصناف والموردين ثم أول فاتورة شراء.', 'file', can('products.edit') ? '<a class="btn" href="#/products">إضافة الأصناف</a>' : '')}</div>`;
  }
  await load();
}
