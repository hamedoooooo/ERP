import { api, sys, isDesktop } from '../api.js';
import { state, esc, fmt, date, dateTime, can, $, $$, navigate } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { pageHead, dataTable, filterBar, bindFilters, formModal, confirmBox, toast, showError, modal, tabs, tableHtml, kvList, kvHtml, formHtml, readForm, emptyState } from '../ui/components.js';
import { invalidate } from './shared.js';
import { refreshSettings, refreshNav } from '../app.js';

const KIND_LABEL = { manual: 'يدوية', auto: 'تلقائية', 'pre-restore': 'قبل الاستعادة', 'pre-import': 'قبل الاستيراد', 'pre-migration': 'قبل الترقية' };
const size = (b) => (b > 1048576 ? `${fmt(b / 1048576, 1)} م.ب` : `${fmt(b / 1024, 0)} ك.ب`);

// =====================================================================================
// Users & roles
// =====================================================================================
export async function users(root, parts, params) {
  root.innerHTML = pageHead('المستخدمون والصلاحيات', 'كل مستخدم له دور، وكل دور له صلاحيات قابلة للتعديل. الصلاحيات تُفحص في قاعدة البيانات وليس في الواجهة فقط.')
    + '<div class="tabs"></div><div data-body></div>';
  const body = $('[data-body]', root);
  const show = (t) => (t === 'roles' ? rolesView(body) : usersView(body)).catch(showError);
  tabs($('.tabs', root), [{ id: 'users', label: 'المستخدمون', icon: 'users' }, { id: 'roles', label: 'الأدوار والصلاحيات', icon: 'shield' }], params.tab || 'users', show);
  show(params.tab || 'users');
}

async function usersView(el) {
  const [rows, { roles }] = await Promise.all([api('users.list'), api('roles.list')]);
  el.innerHTML = `<div class="card"><div class="row between" style="margin-bottom:10px"><span class="muted small">لا يمكن حذف مستخدم له عمليات مسجلة؛ أوقفه بدلًا من ذلك.</span><button class="btn sm" data-new>${icon('plus', 'sm')} مستخدم جديد</button></div><div data-t></div></div>`;
  const form = (u) => formModal({
    title: u ? `تعديل: ${u.full_name}` : 'مستخدم جديد', values: u ? { ...u, active: !!u.active } : { active: true, role_id: roles[roles.length - 1].id },
    fields: [{ name: 'full_name', label: 'الاسم الكامل', required: true }, { name: 'username', label: 'اسم الدخول', required: true },
      { name: 'role_id', label: 'الدور', type: 'select', options: roles.map((r) => ({ value: r.id, label: r.name })) }, { name: 'active', label: 'الحساب نشط', type: 'checkbox' },
      { name: 'password', label: u ? 'كلمة مرور جديدة (اتركها فارغة للإبقاء)' : 'كلمة المرور', type: 'password', required: !u, hint: `${state.settings.security.minPasswordLength} أحرف على الأقل` }],
    submit: (v) => api('users.save', { ...v, id: u && u.id }),
  });
  const t = dataTable($('[data-t]', el), {
    rows, title: 'المستخدمون', exportName: 'users',
    columns: [{ key: 'username', label: 'اسم الدخول' }, { key: 'full_name', label: 'الاسم' }, { key: 'role_name', label: 'الدور' }, { key: 'last_login_at', label: 'آخر دخول', render: (r) => esc(dateTime(r.last_login_at)) },
      { key: 'active', label: 'الحالة', render: (r) => (r.active ? '<span class="badge ok">نشط</span>' : '<span class="badge bad">موقوف</span>'), cls: 'keep' }],
    rowClass: (r) => (r.active ? '' : 'void'),
    actions: () => `<button class="link-btn" data-act="edit">${icon('edit', 'sm')} تعديل</button>`,
    onAction: async (a, r) => { if (await form(r)) { toast('تم الحفظ'); usersView(el); } },
  });
  $('[data-new]', el).onclick = async () => { if (await form()) { toast('تمت الإضافة'); usersView(el); } };
  return t;
}

async function rolesView(el) {
  const { roles, permissions } = await api('roles.list');
  const groups = [...new Set(permissions.map((p) => p.group_name))];
  el.innerHTML = `<div class="card"><div class="row between" style="margin-bottom:10px"><span class="muted small">اضغط على الدور لتعديل صلاحياته. الأدوار الأساسية لا تُحذف لكن يمكن تعديل صلاحياتها.</span><button class="btn sm" data-new>${icon('plus', 'sm')} دور جديد</button></div>
    <div class="tbl-wrap"><table class="tbl matrix"><thead><tr><th>الصلاحية</th>${roles.map((r) => `<th class="c"><button class="link-btn" data-role="${r.id}">${esc(r.name)} ${icon('edit', 'sm')}</button><div class="small muted">${r.users_count} مستخدم</div></th>`).join('')}</tr></thead>
    <tbody>${groups.map((g) => `<tr class="grp"><td colspan="${roles.length + 1}">${esc(g)}</td></tr>${permissions.filter((p) => p.group_name === g).map((p) => `<tr><td>${esc(p.name)}</td>${roles.map((r) => `<td class="c">${r.permissions.includes(p.code) ? `<span class="pos">${icon('check', 'sm')}</span>` : '<span class="muted">—</span>'}</td>`).join('')}</tr>`).join('')}`).join('')}</tbody></table></div></div>`;
  const edit = (r) => new Promise((resolve) => {
    const has = new Set(r ? r.permissions : []);
    const m = modal({
      title: r ? `صلاحيات الدور: ${r.name}` : 'دور جديد', size: 'wide',
      body: `${formHtml([{ name: 'name', label: 'اسم الدور', required: true }, { name: 'description', label: 'الوصف' }], r || {})}
        <div class="row" style="margin:12px 0 6px"><button class="btn ghost sm" data-all>تحديد الكل</button><button class="btn ghost sm" data-none>إلغاء الكل</button></div>
        <div class="grid g3">${groups.map((g) => `<div class="card" style="margin:0"><div class="card-title">${esc(g)}</div>${permissions.filter((p) => p.group_name === g).map((p) => `<label class="check" style="display:flex;margin:6px 0"><input type="checkbox" data-perm="${esc(p.code)}" ${has.has(p.code) ? 'checked' : ''}> ${esc(p.name)}</label>`).join('')}</div>`).join('')}</div>
        <div class="alert bad hide" data-err style="margin-top:10px"></div>`,
      foot: `<button class="btn" data-ok>${icon('save', 'sm')} حفظ</button>${r && !r.is_system ? `<button class="btn ghost" data-del>${icon('trash', 'sm')} حذف الدور</button>` : ''}<button class="btn ghost" data-close>إلغاء</button>`,
    });
    $('[data-all]', m.el).onclick = () => $$('[data-perm]', m.el).forEach((c) => { c.checked = true; });
    $('[data-none]', m.el).onclick = () => $$('[data-perm]', m.el).forEach((c) => { c.checked = false; });
    const err = $('[data-err]', m.el);
    $('[data-ok]', m.el).onclick = async () => {
      try {
        const v = readForm($('.form', m.el));
        await api('roles.save', { id: r && r.id, name: v.name, description: v.description, permissions: $$('[data-perm]', m.el).filter((c) => c.checked).map((c) => c.dataset.perm) });
        m.close(); resolve(true);
      } catch (e) { err.textContent = e.message; err.classList.remove('hide'); }
    };
    const d = $('[data-del]', m.el);
    if (d) d.onclick = async () => { try { if (await confirmBox(`حذف الدور "${r.name}"؟`, { danger: true, ok: 'حذف' })) { await api('roles.delete', { id: r.id }); m.close(); resolve(true); } } catch (e) { err.textContent = e.message; err.classList.remove('hide'); } };
    $$('[data-close]', m.el).forEach((b) => b.addEventListener('click', () => resolve(false)));
  });
  el.onclick = async (e) => {
    const b = e.target.closest('[data-role]'); const n = e.target.closest('[data-new]');
    if (!b && !n) return;
    if (await edit(b ? roles.find((r) => r.id === Number(b.dataset.role)) : null)) {
      toast('تم حفظ الصلاحيات');
      // own permissions may have changed
      const me = await api('auth.me'); state.user = me; state.perms = new Set(me.permissions); refreshNav();
      rolesView(el);
    }
  };
}

// =====================================================================================
// Settings
// =====================================================================================
export async function settings(root, parts, params) {
  root.innerHTML = pageHead('الإعدادات', 'بيانات المنشأة، العملة، الضريبة، المخزون، التصنيع والتسعير')
    + '<div class="tabs"></div><div data-body></div>';
  const body = $('[data-body]', root);
  const TABS = [{ id: 'company', label: 'المنشأة والبرنامج', icon: 'factory' }, { id: 'money', label: 'العملة والضريبة', icon: 'coins' }, { id: 'inventory', label: 'المخزون', icon: 'boxes' },
    { id: 'manufacturing', label: 'التصنيع والتسعير', icon: 'calc' }, { id: 'statuses', label: 'حالات أوامر التصنيع', icon: 'flag' }, { id: 'system', label: 'النظام والأمان', icon: 'shield' }];
  const show = (t) => SETTINGS_VIEWS[t](body).catch(showError);
  const start = TABS.some((t) => t.id === params.tab) ? params.tab : 'company';
  tabs($('.tabs', root), TABS, start, show);
  show(start);
}

async function saveSections(pairs) {
  for (const [section, value] of pairs) await api('settings.save', { section, value });
  await refreshSettings();
  toast('تم حفظ الإعدادات');
}

function sectionForm(el, fields, values, onSave, extra = '') {
  el.innerHTML = `<div class="card">${formHtml(fields, values)}${extra}<div class="alert bad hide" data-err style="margin-top:12px"></div><div class="form-actions"><button class="btn" data-save>${icon('save', 'sm')} حفظ</button></div></div>`;
  $('[data-save]', el).onclick = async (e) => {
    const err = $('[data-err]', el); err.classList.add('hide'); e.target.disabled = true;
    try { await onSave(readForm($('.card', el))); } catch (x) { err.textContent = x.message; err.classList.remove('hide'); } finally { e.target.disabled = false; }
  };
}

function resizeImage(file, max = 360) {
  return new Promise((resolve, reject) => {
    if (!/^image\//.test(file.type)) { reject(new Error('اختر ملف صورة (PNG أو JPG)')); return; }
    const img = new Image(); const url = URL.createObjectURL(file);
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/png'));
    };
    img.onerror = () => reject(new Error('تعذر قراءة الصورة'));
    img.src = url;
  });
}

const SETTINGS_VIEWS = {
  async company(el) {
    const s = state.settings.company;
    let logo = s.logo || '';
    sectionForm(el, [{ name: 'appName', label: 'اسم البرنامج (يظهر في العنوان والقائمة)', required: true }, { name: 'companyName', label: 'اسم المنشأة / الورشة' },
      { name: 'phone', label: 'الهاتف' }, { name: 'taxNo', label: 'الرقم الضريبي / السجل التجاري' }, { name: 'address', label: 'العنوان', full: true },
      { name: 'invoiceFooter', label: 'تذييل الفواتير والإيصالات المطبوعة', full: true, type: 'textarea' },
      { type: 'html', full: true, html: `<label>الشعار (يظهر في المطبوعات)</label><div class="row"><div class="img-drop" data-logo title="اختر صورة">${logo ? `<img src="${esc(logo)}" alt="">` : icon('image')}</div><button type="button" class="btn ghost sm" data-rmlogo>إزالة الشعار</button></div>` }],
    s, async (v) => { await saveSections([['company', { ...v, logo }]]); });
    const drop = $('[data-logo]', el);
    drop.onclick = () => {
      const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*';
      i.onchange = async () => { try { logo = await resizeImage(i.files[0]); drop.innerHTML = `<img src="${logo}" alt="">`; } catch (e) { showError(e); } };
      i.click();
    };
    $('[data-rmlogo]', el).onclick = () => { logo = ''; drop.innerHTML = icon('image'); };
  },
  async money(el) {
    const { currency: c, tax: t } = state.settings;
    sectionForm(el, [{ type: 'section', label: 'العملة' }, { name: 'symbol', label: 'رمز العملة', required: true, value: c.symbol }, { name: 'code', label: 'كود العملة', value: c.code },
      { name: 'decimals', label: 'عدد الخانات العشرية', type: 'select', value: c.decimals, options: [0, 1, 2, 3].map((n) => ({ value: n, label: String(n) })) },
      { type: 'section', label: 'الضريبة (اختيارية)' }, { name: 'taxEnabled', label: 'تفعيل الضريبة في الفواتير', type: 'checkbox', value: t.enabled },
      { name: 'taxLabel', label: 'اسم الضريبة', value: t.label }, { name: 'defaultRate', label: 'النسبة الافتراضية %', type: 'number', min: 0, value: t.defaultRate }],
    {}, async (v) => { await saveSections([['currency', { symbol: v.symbol, code: v.code, decimals: v.decimals }], ['tax', { enabled: v.taxEnabled, label: v.taxLabel, defaultRate: v.defaultRate }]]); },
    '<div class="alert info" style="margin-top:12px">تغيير العملة يغيّر طريقة العرض فقط ولا يحوّل المبالغ المسجلة.</div>');
  },
  async inventory(el) {
    const s = state.settings.inventory;
    sectionForm(el, [{ name: 'allowNegative', label: 'السماح بالصرف بالسالب (بيع/صرف أكثر من الرصيد)', type: 'checkbox', full: true, hint: 'غير مستحسن: يجعل متوسط التكلفة أقل دقة. عند الإيقاف يرفض النظام أي صرف يتجاوز الرصيد.' },
      { name: 'defaultLowStock', label: 'حد التنبيه الافتراضي للأصناف بدون حد أدنى', type: 'number', min: 0, hint: '0 = لا تنبيه إلا للأصناف التي لها حد أدنى محدد' },
      { name: 'pageSize', label: 'عدد الصفوف في الجداول', type: 'select', value: state.settings.ui.pageSize, options: [10, 25, 50, 100].map((n) => ({ value: n, label: String(n) })) }],
    s, async (v) => { await saveSections([['inventory', { allowNegative: v.allowNegative, defaultLowStock: Number(v.defaultLowStock) || 0 }], ['ui', { pageSize: Number(v.pageSize) }]]); refreshNav(); });
  },
  async manufacturing(el) {
    const m = state.settings.manufacturing; const p = state.settings.pricing;
    sectionForm(el, [{ type: 'section', label: 'المصروفات الصناعية غير المباشرة (الافتراضي لأوامر التصنيع الجديدة)' },
      { name: 'overheadType', label: 'طريقة التحميل', type: 'select', value: m.overheadType, options: [{ value: 'none', label: 'بدون' }, { value: 'percent', label: 'نسبة مئوية' }, { value: 'amount', label: 'مبلغ ثابت لكل أمر' }] },
      { name: 'overheadValue', label: 'القيمة', type: 'number', min: 0, value: m.overheadValue },
      { name: 'overheadBase', label: 'أساس النسبة', type: 'select', value: m.overheadBase, options: [{ value: 'direct', label: 'التكلفة المباشرة (خامات + عمالة + أخرى)' }, { value: 'labor', label: 'تكلفة العمالة فقط' }] },
      { name: 'warnOverIssuePct', label: 'تنبيه عند تجاوز الصرف للمخطط بنسبة %', type: 'number', min: 0, value: m.warnOverIssuePct },
      { type: 'section', label: 'التسعير المقترح' },
      { name: 'method', label: 'طريقة حساب السعر', type: 'select', value: p.method, options: [{ value: 'margin', label: 'هامش ربح من سعر البيع (السعر = التكلفة ÷ (1 − النسبة))' }, { value: 'markup', label: 'نسبة إضافة على التكلفة (السعر = التكلفة × (1 + النسبة))' }] },
      { name: 'defaultPct', label: 'النسبة الافتراضية %', type: 'number', min: 0, value: p.defaultPct }],
    {}, async (v) => { await saveSections([['manufacturing', { overheadType: v.overheadType, overheadValue: Number(v.overheadValue) || 0, overheadBase: v.overheadBase, warnOverIssuePct: Number(v.warnOverIssuePct) || 0 }], ['pricing', { method: v.method, defaultPct: Number(v.defaultPct) || 0 }]]); },
    '<div class="alert info" style="margin-top:12px">السعر المقترح إرشادي فقط؛ يمكنك دائمًا كتابة سعر البيع يدويًا في الفاتورة أو أمر التصنيع.</div>');
  },
  async statuses(el) {
    const rows = await api('moStatuses.list');
    const STAGE = { open: 'لم يبدأ', active: 'قيد التشغيل', done: 'مكتمل', cancelled: 'ملغي' };
    el.innerHTML = `<div class="card"><div class="row between" style="margin-bottom:10px"><span class="muted small">الحالات الأساسية تتحكم في منطق النظام (الإكمال والإلغاء). يمكنك إعادة تسميتها وتلوينها وإضافة مراحل تشغيل خاصة بورشتك (مثل: قص، تجميع، دهان).</span><button class="btn sm" data-new>${icon('plus', 'sm')} حالة جديدة</button></div><div data-t></div></div>`;
    $('[data-t]', el).innerHTML = tableHtml([{ key: 'name', label: 'الحالة', render: (r) => `<span class="badge dot" style="color:${esc(r.color)};background:${esc(r.color)}18">${esc(r.name)}</span>` }, { key: 'stage', label: 'المرحلة', render: (r) => esc(STAGE[r.stage]) },
      { key: 'sort', label: 'الترتيب' }, { key: 'is_system', label: 'النوع', render: (r) => (r.is_system ? 'أساسية' : 'مخصصة') }, { key: 'active', label: 'الحالة', render: (r) => (r.active ? '' : '<span class="badge bad">موقوفة</span>') }], rows,
    { actions: () => `<button class="link-btn" data-e>${icon('edit', 'sm')} تعديل</button>` });
    const form = (r) => formModal({
      title: r ? `تعديل الحالة: ${r.name}` : 'حالة تشغيل جديدة', size: 'narrow', cols: 'c1', values: r ? { ...r, active: !!r.active } : { color: '#5E7C9A', sort: 50, stage: 'active', active: true },
      fields: [{ name: 'name', label: 'الاسم', required: true }, { name: 'color', label: 'اللون', type: 'color' }, { name: 'sort', label: 'الترتيب', type: 'number' },
        ...(r ? [] : [{ name: 'stage', label: 'تُعتبر', type: 'select', options: [{ value: 'active', label: 'قيد التشغيل' }, { value: 'open', label: 'لم يبدأ' }] }]),
        ...(r && r.is_system ? [] : [{ name: 'active', label: 'مفعلة', type: 'checkbox' }])],
      submit: (v) => api('moStatuses.save', { ...v, code: r && r.code }),
    });
    el.onclick = async (e) => {
      const b = e.target.closest('[data-e]'); const n = e.target.closest('[data-new]');
      if (!b && !n) return;
      if (await form(b ? rows[Number(b.closest('tr').dataset.i)] : null)) { invalidate('moStatuses'); toast('تم الحفظ'); SETTINGS_VIEWS.statuses(el); }
    };
  },
  async system(el) {
    const [info, sec] = [await api('system.info'), state.settings.security];
    el.innerHTML = `<div class="grid g2"><div class="card"><div class="card-title">${icon('database', 'sm')} معلومات النظام</div>${kvList([['إصدار البرنامج', info.appVersion], ['إصدار قاعدة البيانات', `v${info.schemaVersion}`], ['محرك قاعدة البيانات', `SQLite (${info.driver})`], ['مجلد البيانات', info.dataDir], ['ملف قاعدة البيانات', info.dbPath], ['النظام', info.platform], ['وضع التشغيل', isDesktop ? 'تطبيق سطح المكتب — بدون إنترنت' : 'معاينة المتصفح (للتطوير)']])}
      ${isDesktop ? `<div class="form-actions"><button class="btn ghost sm" data-open>${icon('folder', 'sm')} فتح مجلد البيانات</button></div>` : ''}</div>
      <div class="card"><div class="card-title">${icon('lock', 'sm')} الأمان</div><div data-sec></div></div></div>`;
    sectionForm($('[data-sec]', el), [{ name: 'minPasswordLength', label: 'الحد الأدنى لطول كلمة المرور', type: 'number', min: 4 }, { name: 'lockAfterFailures', label: 'قفل الحساب بعد محاولات فاشلة', type: 'number', min: 0, hint: '0 = بدون قفل' }, { name: 'lockMinutes', label: 'مدة القفل (دقائق)', type: 'number', min: 1 }],
      sec, async (v) => { await saveSections([['security', { minPasswordLength: Math.max(4, Number(v.minPasswordLength) || 6), lockAfterFailures: Number(v.lockAfterFailures) || 0, lockMinutes: Math.max(1, Number(v.lockMinutes) || 5) }]]); });
    const o = $('[data-open]', el); if (o) o.onclick = () => sys.showInFolder(info.dbPath);
  },
};

// =====================================================================================
// Backup & restore
// =====================================================================================
export async function backup(root) {
  const info = await api('backup.info');
  const b = info.settings;
  const canCreate = can('backup.create'); const canRestore = can('backup.restore');
  root.innerHTML = pageHead('النسخ الاحتياطي والاستعادة', 'كل النسخ محلية على جهازك أو على فلاشة/قرص خارجي — لا يوجد أي رفع على الإنترنت')
    + `${info.fallback ? `<div class="alert warn">${icon('alert', 'sm')} ${esc(info.fallback)}</div>` : ''}
    <div class="grid g2">
      ${canCreate ? `<div class="card"><div class="card-title">${icon('save', 'sm')} إنشاء نسخة احتياطية الآن</div>
        <p class="muted small" style="margin-top:0">اسم الملف: <span class="num">Workshop_Backup_YYYY-MM-DD_HH-mm-ss.backup</span><br>مكان الحفظ الحالي: <b class="num" style="word-break:break-all">${esc(info.resolvedDir)}</b></p>
        <label class="check"><input type="checkbox" data-enc> حماية النسخة بكلمة مرور (تشفير AES-256)</label>
        <div class="form hide" data-pw style="margin-top:8px">${formHtml([{ name: 'password', label: 'كلمة مرور النسخة', type: 'password' }, { name: 'passwordConfirm', label: 'تأكيدها', type: 'password' }])}
          <div class="field full"><div class="alert warn" style="margin:0">${icon('alert', 'sm')} تنبيه مهم: إذا نسيت كلمة المرور فلن يمكن استعادة هذه النسخة إطلاقًا. لا توجد طريقة لاسترجاعها.</div></div></div>
        <div class="form-actions"><button class="btn" data-create>${icon('save', 'sm')} إنشاء نسخة</button>${isDesktop ? `<button class="btn ghost" data-saveas>${icon('usb', 'sm')} حفظ باسم… (فلاشة / مكان آخر)</button>` : ''}</div>
        <div data-result></div></div>` : ''}
      ${canRestore ? `<div class="card"><div class="card-title">${icon('upload', 'sm')} استعادة نسخة احتياطية</div>
        <p class="muted small" style="margin-top:0">سيتم أولًا فحص الملف وعرض بياناته، ثم يُنشأ تلقائيًا نسخة أمان من بياناتك الحالية قبل الاستبدال.</p>
        <div class="form-actions" style="margin-top:0"><button class="btn sec" data-pick>${icon('folder', 'sm')} اختيار ملف .backup</button></div><div data-inspect></div></div>` : ''}
    </div>
    ${canCreate ? `<div class="card"><div class="card-title">${icon('clock', 'sm')} إعدادات النسخ التلقائي ومكان الحفظ</div><div data-auto></div></div>` : ''}
    <div class="card"><div class="card-title">${icon('history', 'sm')} سجل النسخ</div><div data-hist></div></div>
    <div class="grid g2">
      <div class="card"><div class="card-title">${icon('usb', 'sm')} نقل البيانات إلى جهاز آخر</div>
        <ol class="steps"><li>على الجهاز القديم: أنشئ نسخة احتياطية (يُفضل "حفظ باسم…" مباشرة على الفلاشة).</li><li>انقل ملف <span class="num">.backup</span> إلى الجهاز الجديد (فلاشة USB أو قرص خارجي).</li>
          <li>على الجهاز الجديد: ثبّت البرنامج بملف Setup.exe وأنشئ أي حساب مدير مؤقت.</li><li>من هذه الصفحة: "اختيار ملف .backup" ← راجع بيانات النسخة ← أدخل كلمة المرور إن وجدت ← أكّد الاستعادة.</li>
          <li>سجّل الدخول بحسابات الجهاز القديم. كل البيانات والإعدادات والمستخدمين تنتقل كما هي.</li></ol>
        <p class="muted small">لا يلزم أي اتصال بالإنترنت أو حساب سحابي.</p></div>
      ${canRestore ? `<div class="card"><div class="card-title">${icon('refresh', 'sm')} استيراد بيانات البرنامج القديم (دفتري التجاري)</div>
        <p class="muted small" style="margin-top:0">افتح أداة <b>tools/legacy-export.html</b> في نفس المتصفح الذي كنت تستخدم فيه البرنامج القديم، وانسخ البيانات أو احفظها كملف JSON، ثم الصقها هنا. تُنقل الحسابات، العملاء، الموردون، الأصناف وأرصدتها، وأرصدة الصندوق والبنك، ويُحفظ السجل القديم كاملًا في أرشيف داخل قاعدة البيانات.</p>
        <textarea class="inp" rows="4" data-legacy placeholder='{"coa":[…],"customers":[…],"items":[…],"transactions":[…]}' style="direction:ltr"></textarea>
        <div class="form-actions"><button class="btn ghost" data-legfile>${icon('file', 'sm')} اختيار ملف JSON</button><button class="btn" data-legrun>${icon('download', 'sm')} استيراد</button></div><div data-legout></div>
        ${info.legacyImported ? '<div class="alert info">تم استيراد بيانات النظام القديم من قبل.</div>' : ''}</div>` : ''}
    </div>
    <div class="card"><div class="card-title">${icon('database', 'sm')} مكان قاعدة البيانات</div>${kvHtml([['ملف قاعدة البيانات', `<span class="num" style="word-break:break-all">${esc(info.dbPath)}</span>`], ['الحجم', size(info.dbSize)], ['إصدار البرنامج / قاعدة البيانات', `${esc(info.appVersion)} / v${info.schemaVersion}`], ['المحرك', `SQLite (${esc(info.driver)})`]])}</div>`;

  // ---- create
  const enc = $('[data-enc]', root);
  if (enc) enc.onchange = () => $('[data-pw]', root).classList.toggle('hide', !enc.checked);
  const doCreate = async (filePath) => {
    const pw = enc && enc.checked ? readForm($('[data-pw]', root)) : {};
    if (enc && enc.checked && !pw.password) { toast('أدخل كلمة مرور النسخة أو ألغِ خيار الحماية', 'bad'); return; }
    const r = await api('backup.create', { ...pw, filePath });
    $('[data-result]', root).innerHTML = `<div class="alert ok" style="margin-top:12px">${icon('check', 'sm')}<div>تم إنشاء النسخة ${r.encrypted ? '(مشفرة)' : ''}: <b class="num" style="word-break:break-all">${esc(r.path)}</b> — ${size(r.size)}
      ${isDesktop ? `<div><button class="link-btn" data-show>${icon('folder', 'sm')} فتح المجلد</button></div>` : ''}</div></div>${r.warning ? `<div class="alert warn">${esc(r.warning)}</div>` : ''}`;
    const s = $('[data-show]', root); if (s) s.onclick = () => sys.showInFolder(r.path);
    if (enc) { enc.checked = false; $('[data-pw]', root).classList.add('hide'); $$('[data-pw] input', root).forEach((i) => { i.value = ''; }); }
    toast('تم إنشاء النسخة الاحتياطية');
    drawHistory();
  };
  const guard = (fn) => async (e) => { const btn = e && e.currentTarget; if (btn) btn.disabled = true; try { await fn(); } catch (x) { showError(x); } finally { if (btn) btn.disabled = false; } };
  const cb = $('[data-create]', root); if (cb) cb.onclick = guard(() => doCreate(null));
  const sa = $('[data-saveas]', root);
  if (sa) sa.onclick = guard(async () => {
    const p = new Date(); const z = (x) => String(x).padStart(2, '0');
    const name = `Workshop_Backup_${p.getFullYear()}-${z(p.getMonth() + 1)}-${z(p.getDate())}_${z(p.getHours())}-${z(p.getMinutes())}-${z(p.getSeconds())}.backup`;
    const fp = await sys.saveBackupAs(name);
    if (fp) await doCreate(fp);
  });

  // ---- restore
  const startRestore = async (path) => {
    const box = $('[data-inspect]', root);
    let h;
    try { h = await api('backup.inspect', { path }); } catch (e) { box.innerHTML = `<div class="alert bad" style="margin-top:12px">${icon('alert', 'sm')} ${esc(e.message)}</div>`; return; }
    const counts = h.counts || {};
    const C = { products: 'الأصناف', customers: 'العملاء', suppliers: 'الموردون', sales_invoices: 'فواتير البيع', purchase_invoices: 'فواتير الشراء', manufacturing_orders: 'أوامر التصنيع', journal_entries: 'القيود' };
    box.innerHTML = `<div style="margin-top:12px">${h.compatible ? '' : `<div class="alert bad">${icon('alert', 'sm')} هذه النسخة من إصدار أحدث (قاعدة بيانات v${h.schemaVersion}) من البرنامج الحالي (v${h.currentSchema}). ثبّت الإصدار الأحدث أولًا.</div>`}
      ${kvHtml([['الملف', `<span class="num" style="word-break:break-all">${esc(path)}</span>`], ['تاريخ النسخة', esc(dateTime(h.createdAt))], ['المنشأة', esc(h.companyName || '—')], ['نوع النسخة', esc(KIND_LABEL[h.kind] || h.kind || '—')],
    ['إصدار البرنامج / قاعدة البيانات', `${esc(h.appVersion)} / v${h.schemaVersion}`], ['الحجم', size(h.fileSize)], ['مشفرة', h.encrypted ? 'نعم — تحتاج كلمة مرور' : 'لا'],
    ['محتوى النسخة', Object.keys(counts).length ? Object.entries(counts).map(([k, v]) => `${esc(C[k] || k)}: <b class="num">${fmt(v, 0)}</b>`).join(' · ') : '—']])}
      ${h.compatible ? `${h.encrypted ? `<div class="field" style="margin-top:10px"><label>كلمة مرور النسخة</label><input class="inp" type="password" data-rpw autocomplete="off"></div>` : ''}
      <div class="alert warn" style="margin-top:10px">${icon('alert', 'sm')} الاستعادة ستستبدل كل البيانات الحالية ببيانات هذه النسخة. سيتم عمل نسخة أمان تلقائية من بياناتك الحالية قبل الاستبدال.</div>
      <div class="form-actions"><button class="btn danger" data-restore>${icon('upload', 'sm')} استعادة هذه النسخة</button><button class="btn ghost" data-rcancel>إلغاء</button></div>` : ''}</div>`;
    const cancel = $('[data-rcancel]', box); if (cancel) cancel.onclick = () => { box.innerHTML = ''; };
    const rb = $('[data-restore]', box);
    if (rb) rb.onclick = guard(async () => {
      const pw = h.encrypted ? $('[data-rpw]', box).value : '';
      if (h.encrypted && !pw) { toast('أدخل كلمة مرور النسخة', 'bad'); return; }
      const ok = await confirmBox(`تأكيد استعادة نسخة ${dateTime(h.createdAt)}؟ ستُستبدل كل البيانات الحالية.`, { danger: true, typed: 'استعادة', ok: 'استعادة الآن' });
      if (!ok) return;
      const r = await api('backup.restore', { path, password: pw, confirm: true });
      modal({
        title: 'تمت الاستعادة بنجاح', size: 'narrow', closable: false,
        body: `<div class="alert ok">${icon('check', 'sm')} تمت استعادة البيانات من نسخة ${esc(dateTime(r.header.createdAt))}.</div><p class="small">نسخة الأمان من بياناتك السابقة محفوظة في:<br><span class="num" style="word-break:break-all">${esc(r.safetyBackup)}</span></p>${r.sessionKept ? '' : '<p class="small">حسابك غير موجود في النسخة المستعادة؛ سجّل الدخول بأحد حساباتها.</p>'}`,
        foot: '<button class="btn" data-reload>متابعة</button>',
      });
    });
  };
  const pick = $('[data-pick]', root);
  if (pick) pick.onclick = guard(async () => { const p = await sys.pickBackupFile(); if (p) await startRestore(p); });

  // ---- auto settings
  const auto = $('[data-auto]', root);
  if (auto) {
    auto.innerHTML = `${formHtml([
      { name: 'location', label: 'مجلد حفظ النسخ (فارغ = المجلد الافتراضي)', value: b.location, placeholder: info.defaultDir, readonly: isDesktop, full: true, hint: 'يمكن اختيار مجلد على فلاشة أو قرص خارجي. إذا لم يكن متصلًا وقت النسخ تُحفظ النسخة في المجلد الافتراضي مع تنبيه.' },
      { name: 'schedule', label: 'نسخ تلقائي مجدول', type: 'select', value: b.schedule, options: [{ value: 'off', label: 'متوقف' }, { value: 'daily', label: 'يوميًا' }, { value: 'weekly', label: 'أسبوعيًا' }] },
      { name: 'keepLast', label: 'الاحتفاظ بآخر (نسخة تلقائية)', type: 'number', min: 1, value: b.keepLast },
      { name: 'autoOnClose', label: 'نسخة تلقائية عند إغلاق البرنامج', type: 'checkbox', value: b.autoOnClose },
    ])}<p class="muted small">آخر نسخة تلقائية: ${b.lastAutoAt ? esc(dateTime(b.lastAutoAt)) : 'لا يوجد'}. النسخ التلقائية غير مشفرة، وتُحذف الأقدم تلقائيًا مع الإبقاء على العدد المحدد.</p>
      <div class="form-actions">${isDesktop ? `<button class="btn ghost" data-choose>${icon('folder', 'sm')} اختيار مجلد…</button>` : ''}<button class="btn ghost" data-default>المجلد الافتراضي</button><button class="btn" data-savea>${icon('save', 'sm')} حفظ الإعدادات</button><button class="btn ghost" data-runauto>${icon('play', 'sm')} تشغيل نسخة تلقائية الآن</button></div>`;
    const ch = $('[data-choose]', auto); if (ch) ch.onclick = async () => { const d = await sys.chooseFolder('اختر مجلد النسخ الاحتياطية'); if (d) $('[name=location]', auto).value = d; };
    $('[data-default]', auto).onclick = () => { $('[name=location]', auto).value = ''; };
    $('[data-savea]', auto).onclick = guard(async () => { const v = readForm(auto); await api('settings.save', { section: 'backup', value: { location: v.location, schedule: v.schedule, keepLast: v.keepLast, autoOnClose: v.autoOnClose } }); await refreshSettings(); toast('تم حفظ إعدادات النسخ'); backup(root); });
    $('[data-runauto]', auto).onclick = guard(async () => { const r = await api('backup.runAutoNow'); if (r.error) throw new Error(r.error); toast('تم إنشاء نسخة تلقائية'); if (r.warning) toast(r.warning, 'warn'); drawHistory(); });
  }

  // ---- history
  async function drawHistory() {
    const i = await api('backup.info');
    const el = $('[data-hist]', root);
    if (!i.history.length) { el.innerHTML = emptyState('لم تُنشأ نسخ احتياطية بعد', 'أنشئ أول نسخة الآن واحتفظ بها على فلاشة خارجية', 'database'); return; }
    el.innerHTML = tableHtml([{ key: 'created_at', label: 'التاريخ', render: (r) => esc(dateTime(r.created_at)) }, { key: 'file_name', label: 'الملف', render: (r) => `<span class="num">${esc(r.file_name)}</span>${r.exists ? '' : ' <span class="badge bad">غير موجود</span>'}` },
      { key: 'kind', label: 'النوع', render: (r) => esc(KIND_LABEL[r.kind] || r.kind) }, { key: 'size_bytes', label: 'الحجم', render: (r) => size(r.size_bytes || 0) }, { key: 'encrypted', label: 'مشفرة', render: (r) => (r.encrypted ? icon('lock', 'sm') : '') },
      { key: 'app_version', label: 'الإصدار' }], i.history, {
      actions: (r) => (r.exists ? `${isDesktop ? `<button class="link-btn" data-h="show" title="${esc(r.file_path)}">${icon('folder', 'sm')}</button>` : ''}${canRestore ? `<button class="link-btn muted" data-h="restore">استعادة</button>` : ''}` : ''),
    });
    el.onclick = (e) => {
      const b2 = e.target.closest('[data-h]'); if (!b2) return;
      const r = i.history[Number(b2.closest('tr').dataset.i)];
      if (b2.dataset.h === 'show') sys.showInFolder(r.file_path);
      else { startRestore(r.file_path); $('[data-inspect]', root).scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    };
  }
  drawHistory().catch(showError);

  // ---- legacy import
  const lf = $('[data-legfile]', root);
  if (lf) lf.onclick = async () => { const t = await sys.pickJsonText(); if (t) $('[data-legacy]', root).value = t; };
  const lr = $('[data-legrun]', root);
  if (lr) lr.onclick = guard(async () => {
    const text = $('[data-legacy]', root).value.trim();
    if (!text) { toast('الصق البيانات أو اختر ملف JSON أولًا', 'bad'); return; }
    if (!await confirmBox('استيراد بيانات النظام القديم؟ سيتم عمل نسخة أمان تلقائية قبل الاستيراد.', { ok: 'استيراد' })) return;
    let r;
    try { r = await api('backup.importLegacy', { data: text }); } catch (e) {
      if (e.code !== 'ALREADY_IMPORTED') throw e;
      if (!await confirmBox(`${e.message} هل تريد الاستيراد مرة أخرى رغم ذلك؟`, { danger: true, typed: 'تكرار', ok: 'استيراد مرة أخرى' })) return;
      r = await api('backup.importLegacy', { data: text, force: true });
    }
    invalidate('customers', 'suppliers', 'categories', 'units');
    $('[data-legout]', root).innerHTML = `<div class="alert ok" style="margin-top:10px">${icon('check', 'sm')}<div>تم الاستيراد: ${esc(JSON.stringify({ عملاء: r.customers, موردون: r.suppliers, أصناف: r.products, حسابات: r.accounts, 'أرصدة افتتاحية': r.openings, 'أصناف بمخزون': r.stockLines || 0, 'حركات مؤرشفة': r.transactionsArchived }).replace(/[{}"]/g, '').replace(/,/g, ' · ').replace(/:/g, ': '))}
      ${r.skipped && r.skipped.length ? `<div class="small">ملاحظات: ${esc(r.skipped.join('، '))}</div>` : ''}<div class="small">نسخة الأمان: <span class="num">${esc(r.safetyBackup)}</span></div></div></div>`;
    toast('تم استيراد البيانات القديمة');
  });
}

// =====================================================================================
// Audit log
// =====================================================================================
const ACTIONS = { create: 'إنشاء', update: 'تعديل', void: 'إلغاء', delete: 'حذف', login: 'دخول', logout: 'خروج', login_failed: 'دخول فاشل', settings: 'إعدادات', restore: 'استعادة', restore_start: 'بدء استعادة', backup: 'نسخ احتياطي', legacy_import: 'استيراد قديم', mo_issue: 'صرف خامات', mo_return: 'رد خامات', mo_labor: 'عمالة', mo_cost: 'تكلفة مباشرة', mo_complete: 'إكمال تصنيع', mo_reopen: 'إعادة فتح', mo_cancel: 'إلغاء أمر', status: 'تغيير حالة', count_approve: 'اعتماد جرد', cancel: 'إلغاء', opening: 'رصيد افتتاحي', activate: 'تفعيل', deactivate: 'إيقاف', plan_material: 'تخطيط مواد', change_password: 'تغيير كلمة المرور', setup: 'إعداد أول', inventory_adjust: 'تسوية مخزون', restore_start: 'بدء استعادة' };
export async function audit(root) {
  root.innerHTML = pageHead('سجل التدقيق', 'كل عملية إنشاء أو تعديل أو إلغاء تُسجل باسم المستخدم ووقتها مع البيانات قبل وبعد')
    + `<div class="card">${filterBar([{ name: 'q', label: 'بحث', placeholder: 'المستخدم، العملية، رقم المستند…' }, { name: 'from', label: 'من', type: 'date' }, { name: 'to', label: 'إلى', type: 'date' },
      { name: 'action', label: 'العملية', type: 'select', options: [{ value: '', label: 'الكل' }, ...Object.entries(ACTIONS).map(([value, label]) => ({ value, label }))] }])}<div data-t></div></div>`;
  let f = {};
  const t = dataTable($('[data-t]', root), {
    title: 'سجل التدقيق', exportName: 'audit_log', fetch: (p) => api('audit.list', { ...f, ...p }), empty: 'لا توجد سجلات', emptyIcon: 'history',
    columns: [{ key: 'ts', label: 'الوقت', render: (r) => esc(dateTime(r.ts)), exportValue: (r) => r.ts }, { key: 'username', label: 'المستخدم' }, { key: 'action', label: 'العملية', render: (r) => esc(ACTIONS[r.action] || r.action), exportValue: (r) => ACTIONS[r.action] || r.action },
      { key: 'entity', label: 'الجدول' }, { key: 'doc_no', label: 'المستند', render: (r) => esc(r.doc_no || r.entity_id || '') }, { key: 'notes', label: 'ملاحظات' }],
    onRow: (r) => {
      const pretty = (s) => { if (!s) return '—'; try { return esc(JSON.stringify(JSON.parse(s), null, 2)); } catch (_) { return esc(s); } };
      modal({ title: `${ACTIONS[r.action] || r.action} — ${r.doc_no || r.entity || ''}`, size: 'wide',
        body: `${kvList([['الوقت', dateTime(r.ts)], ['المستخدم', r.username], ['الجدول / المعرف', `${r.entity || '—'} / ${r.entity_id || '—'}`], ['ملاحظات', r.notes || '—']])}
          <div class="grid g2" style="margin-top:12px"><div><div class="card-title">قبل</div><pre class="json">${pretty(r.old_data)}</pre></div><div><div class="card-title">بعد</div><pre class="json">${pretty(r.new_data)}</pre></div></div>` });
    },
  });
  bindFilters($('.filters', root), (v) => { f = v; t.reload(); });
}
export { navigate, date };
