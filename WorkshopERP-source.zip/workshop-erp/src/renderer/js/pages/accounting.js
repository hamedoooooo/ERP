import { api } from '../api.js';
import { esc, fmt, money, date, can, today, $, monthStart, yearStart, currencySymbol, dateTime } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { pageHead, dataTable, filterBar, bindFilters, formModal, confirmBox, toast, showError, tabs, tableHtml, combo, emptyState } from '../ui/components.js';
import { printDoc, docHeader } from '../ui/print.js';
import { lookup, invalidate, partyOptions } from './shared.js';

const TYPE_LABELS = { asset: 'أصول', liability: 'خصوم', equity: 'حقوق ملكية', revenue: 'إيرادات', cogs: 'تكلفة مبيعات', expense: 'مصروفات' };
const DOC_TYPES = { purchase: 'فاتورة شراء', purchase_return: 'مرتجع شراء', sale: 'فاتورة بيع', sale_return: 'مرتجع بيع', payment: 'سند قبض/صرف', expense: 'مصروف', cash_move: 'حركة نقدية', opening: 'رصيد افتتاحي', adjustment: 'تسوية مخزون', transfer: 'تحويل', mo_issue: 'صرف/رد خامات', mo_labor: 'عمالة تصنيع', mo_cost: 'تكلفة تصنيع', mo_complete: 'إكمال تصنيع', mo_cancel: 'إلغاء تصنيع', inv_diff: 'فرق تقييم' };

export async function accounting(root, parts, params) {
  root.innerHTML = pageHead('الحسابات والقوائم المالية', 'نظام القيد المزدوج: كل عملية تُسجل قيدًا متوازنًا تلقائيًا')
    + '<div class="tabs"></div><div data-body></div>';
  const body = $('[data-body]', root);
  const TABS = [{ id: 'income', label: 'قائمة الدخل', icon: 'chart' }, { id: 'balance', label: 'الميزانية', icon: 'scale' }, { id: 'trial', label: 'ميزان المراجعة', icon: 'ledger' },
    { id: 'journal', label: 'دفتر اليومية', icon: 'file' }, { id: 'ledger', label: 'دفتر الأستاذ', icon: 'report' }, { id: 'coa', label: 'دليل الحسابات', icon: 'layers' },
    ...(can('accounting.manage') ? [{ id: 'opening', label: 'الأرصدة الافتتاحية', icon: 'flag' }] : []), { id: 'check', label: 'فحص التوازن', icon: 'shield' }];
  const show = async (t) => { body.innerHTML = '<div class="empty muted">جارِ التحميل…</div>'; try { await VIEWS[t](body, params); } catch (e) { body.innerHTML = `<div class="alert bad">${esc(e.message)}</div>`; } };
  const start = TABS.some((t) => t.id === params.tab) ? params.tab : 'income';
  tabs($('.tabs', root), TABS, start, show);
  show(start);
}

const periodBar = (from = yearStart(), to = today(), extra = '') => `<div class="filters"><div class="field"><label>من</label><input class="inp" type="date" name="from" value="${from || ''}"></div><div class="field"><label>إلى</label><input class="inp" type="date" name="to" value="${to || ''}"></div>${extra}
  <div class="field"><label>&nbsp;</label><div class="row"><button class="btn ghost sm" data-print>${icon('printer', 'sm')} طباعة</button></div></div></div>`;
const line = (label, v, cls = '', indent = 0) => `<tr class="${cls}"><td style="padding-inline-start:${12 + indent * 22}px">${esc(label)}</td><td class="n ${Number(v) < -0.004 ? 'neg' : ''}">${fmt(v)}</td></tr>`;

const VIEWS = {
  async income(el) {
    el.innerHTML = `<div class="card">${periodBar()}<div data-out></div></div>`;
    const run = async () => {
      const f = { from: $('[name=from]', el).value, to: $('[name=to]', el).value };
      const i = await api('accounting.income', f);
      const html = `<table class="tbl statement"><tbody>
        ${line('إجمالي المبيعات', i.sales)}${line('(-) مردودات المبيعات', -i.returns, '', 1)}${line('صافي المبيعات', i.net_sales, 'bold')}
        ${i.cogs_rows.map((r) => line(r.name, -r.balance, '', 1)).join('')}${line('إجمالي تكلفة المبيعات', -i.cogs, 'bold')}
        ${line(`مجمل الربح${i.gross_margin !== null ? ` (${fmt(i.gross_margin, 1)}%)` : ''}`, i.gross_profit, 'bold hl')}
        ${i.opex_rows.map((r) => line(r.name, -r.balance, '', 1)).join('')}${line('إجمالي المصروفات التشغيلية', -i.opex, 'bold')}
        ${i.other_rows.length ? i.other_rows.map((r) => line(r.name, r.balance, '', 1)).join('') + line('إيرادات أخرى', i.other_income, 'bold') : ''}
        ${line(`صافي ${i.net_profit < 0 ? 'الخسارة' : 'الربح'}${i.net_margin !== null ? ` (${fmt(i.net_margin, 1)}%)` : ''}`, i.net_profit, 'bold grand')}</tbody></table>
        <p class="muted small">المبالغ بـ ${esc(currencySymbol())}. تكلفة المبيعات تشمل تكلفة البضاعة المباعة وفروق تقييم المخزون والجرد وخسائر أوامر التصنيع الملغاة، مخصومًا منها المصروفات الصناعية المحمّلة على الإنتاج.</p>`;
      $('[data-out]', el).innerHTML = html;
      $('[data-print]', el).onclick = () => printDoc(`${docHeader('قائمة الدخل', `من ${f.from || 'البداية'} إلى ${f.to || 'اليوم'}`)}${html}`);
    };
    el.addEventListener('change', () => run().catch(showError));
    await run();
  },

  async balance(el) {
    el.innerHTML = `<div class="card"><div class="filters"><div class="field"><label>في تاريخ</label><input class="inp" type="date" name="to" value="${today()}"></div><div class="field"><label>&nbsp;</label><button class="btn ghost sm" data-print>${icon('printer', 'sm')} طباعة</button></div></div><div data-out></div></div>`;
    const run = async () => {
      const to = $('[name=to]', el).value;
      const b = await api('accounting.balanceSheet', { to });
      const sec = (title, rows, total) => `<tr class="bold hl"><td colspan="2">${esc(title)}</td></tr>${rows.map((r) => line(`${r.code} — ${r.name}`, r.balance, '', 1)).join('')}${line('الإجمالي', total, 'bold')}`;
      const html = `${b.balanced ? '' : `<div class="alert bad">${icon('alert', 'sm')} الميزانية غير متوازنة! راجع صفحة "فحص التوازن".</div>`}
        <div class="grid g2"><table class="tbl statement"><tbody>${sec('الأصول', b.assets, b.total_assets)}</tbody></table>
        <table class="tbl statement"><tbody>${sec('الخصوم (الالتزامات)', b.liabilities, b.total_liabilities)}
          <tr class="bold hl"><td colspan="2">حقوق الملكية</td></tr>${b.equity.map((r) => line(`${r.code} — ${r.name}`, r.balance, '', 1)).join('')}${line('صافي ربح (خسارة) الفترة حتى التاريخ', b.net_profit, '', 1)}${line('إجمالي حقوق الملكية', b.total_equity, 'bold')}
          ${line('الخصوم + حقوق الملكية', b.total_liabilities + b.total_equity, 'bold grand')}</tbody></table></div>
        <div class="sum-strip" style="margin-top:12px"><div><span>إجمالي الأصول</span><b>${fmt(b.total_assets)}</b></div><div><span>الخصوم + حقوق الملكية</span><b>${fmt(b.total_liabilities + b.total_equity)}</b></div><div><span>التوازن</span><b class="${b.balanced ? 'pos' : 'neg'}">${b.balanced ? 'متوازنة' : 'غير متوازنة'}</b></div></div>`;
      $('[data-out]', el).innerHTML = html;
      $('[data-print]', el).onclick = () => printDoc(`${docHeader('الميزانية العمومية', `في ${to}`)}${html}`);
    };
    el.addEventListener('change', () => run().catch(showError));
    await run();
  },

  async trial(el) {
    el.innerHTML = `<div class="card">${periodBar('', today())}<div data-out></div></div>`;
    const run = async () => {
      const f = { from: $('[name=from]', el).value, to: $('[name=to]', el).value };
      const t = await api('accounting.trial', f);
      const cols = [{ key: 'code', label: 'الكود' }, { key: 'name', label: 'الحساب' }, { key: 'type', label: 'النوع', render: (r) => esc(TYPE_LABELS[r.type]) }, { key: 'debit', label: 'مدين', type: 'money' }, { key: 'credit', label: 'دائن', type: 'money' },
        { key: 'bal_d', label: 'رصيد مدين', type: 'money' }, { key: 'bal_c', label: 'رصيد دائن', type: 'money' }];
      const rows = t.rows.map((r) => { const d = r.debit - r.credit; return { ...r, bal_d: d > 0.004 ? d : null, bal_c: d < -0.004 ? -d : null }; });
      const tot = { debit: t.total_debit, credit: t.total_credit, bal_d: rows.reduce((s, r) => s + (r.bal_d || 0), 0), bal_c: rows.reduce((s, r) => s + (r.bal_c || 0), 0) };
      const html = `<div class="alert ${t.balanced ? 'ok' : 'bad'}">${icon(t.balanced ? 'check' : 'alert', 'sm')} ${t.balanced ? 'ميزان المراجعة متوازن' : 'ميزان المراجعة غير متوازن!'} — المدين ${fmt(t.total_debit)} / الدائن ${fmt(t.total_credit)}</div>${tableHtml(cols, rows, { totals: tot })}`;
      $('[data-out]', el).innerHTML = html;
      $('[data-print]', el).onclick = () => printDoc(`${docHeader('ميزان المراجعة', `من ${f.from || 'البداية'} إلى ${f.to || 'اليوم'}`)}${html}`);
    };
    el.addEventListener('change', () => run().catch(showError));
    await run();
  },

  async journal(el) {
    el.innerHTML = `<div class="card">${filterBar([{ name: 'q', label: 'بحث', placeholder: 'رقم المستند أو البيان' }, { name: 'from', label: 'من', type: 'date', value: monthStart() }, { name: 'to', label: 'إلى', type: 'date' },
      { name: 'doc_type', label: 'النوع', type: 'select', options: [{ value: '', label: 'الكل' }, ...Object.entries(DOC_TYPES).map(([value, label]) => ({ value, label }))] }, { name: 'includeVoid', label: 'إظهار الملغاة', type: 'check' }])}<div data-t></div></div>`;
    let f = { from: monthStart() };
    const t = dataTable($('[data-t]', el), {
      title: 'دفتر اليومية', exportName: 'journal', empty: 'لا توجد قيود', fetch: (p) => api('accounting.journal', { ...f, ...p }),
      columns: [{ key: 'date', label: 'التاريخ', type: 'date' }, { key: 'doc_no', label: 'المستند' }, { key: 'doc_type', label: 'النوع', render: (r) => esc(DOC_TYPES[r.doc_type] || r.doc_type), exportValue: (r) => DOC_TYPES[r.doc_type] || r.doc_type },
        { key: 'description', label: 'البيان', render: (r) => `${esc(r.description)}<table class="tbl compact je">${r.lines.map((l) => `<tr><td>${esc(l.account_code)} ${esc(l.account_name)}${l.memo ? ` <span class="muted small">— ${esc(l.memo)}</span>` : ''}</td><td class="n">${l.debit ? fmt(l.debit) : ''}</td><td class="n">${l.credit ? fmt(l.credit) : ''}</td></tr>`).join('')}</table>`,
          exportValue: (r) => `${r.description} | ${r.lines.map((l) => `${l.account_code}:${l.debit ? 'مدين ' + l.debit : 'دائن ' + l.credit}`).join(' ؛ ')}` },
        { key: 'total', label: 'المبلغ', type: 'money', render: (r) => fmt(r.lines.reduce((s, l) => s + l.debit, 0)), exportValue: (r) => r.lines.reduce((s, l) => s + l.debit, 0).toFixed(2) },
        { key: 'user_name', label: 'المستخدم' }, { key: 'status', label: '', render: (r) => (r.status === 'void' ? '<span class="badge bad">ملغي</span>' : ''), cls: 'keep' }],
      rowClass: (r) => (r.status === 'void' ? 'void' : ''),
    });
    bindFilters($('.filters', el), (v) => { f = v; t.reload(); });
  },

  async ledger(el, params) {
    const accounts = await api('accounts.list');
    el.innerHTML = `<div class="card"><div class="filters"><div class="field" style="min-width:260px"><label>الحساب</label><select class="inp" name="account">${accounts.map((a) => `<option value="${a.code}" ${a.code === (params.account || '1100') ? 'selected' : ''}>${esc(a.code)} — ${esc(a.name)}</option>`).join('')}</select></div>
      <div class="field"><label>من</label><input class="inp" type="date" name="from" value="${yearStart()}"></div><div class="field"><label>إلى</label><input class="inp" type="date" name="to"></div></div><div data-t></div></div>`;
    const run = async () => {
      const f = { account: $('[name=account]', el).value, from: $('[name=from]', el).value, to: $('[name=to]', el).value };
      const l = await api('accounting.ledger', f);
      dataTable($('[data-t]', el), {
        rows: [...(f.from ? [{ date: f.from, description: 'رصيد أول المدة', balance: l.opening }] : []), ...l.rows], title: `دفتر أستاذ: ${l.account.code} — ${l.account.name}`, exportName: `ledger_${l.account.code}`, pageSize: 50,
        columns: [{ key: 'date', label: 'التاريخ', type: 'date' }, { key: 'doc_no', label: 'المستند' }, { key: 'description', label: 'البيان', render: (r) => `${esc(r.description || '')}${r.memo ? `<div class="small muted">${esc(r.memo)}</div>` : ''}` }, { key: 'debit', label: 'مدين', type: 'money' }, { key: 'credit', label: 'دائن', type: 'money' }, { key: 'balance', label: 'الرصيد', type: 'money', cls: 'bold' }],
        footer: () => ({ debit: l.total_debit, credit: l.total_credit, balance: l.closing }),
      });
    };
    el.addEventListener('change', () => run().catch(showError));
    await run();
  },

  async coa(el) {
    const rows = await api('accounts.list');
    el.innerHTML = `<div class="card"><div class="row between" style="margin-bottom:10px"><span class="muted small">الحسابات الأساسية (نظامية) مطلوبة لعمل القيود التلقائية ولا يمكن حذفها. حسابات تصنيفات المصروفات تُنشأ تلقائيًا.</span>
      ${can('accounting.manage') ? `<button class="btn sm" data-add>${icon('plus', 'sm')} حساب جديد</button>` : ''}</div><div data-t></div></div>`;
    const t = dataTable($('[data-t]', el), {
      rows, title: 'دليل الحسابات', exportName: 'chart_of_accounts', pageSize: 100, sort: 'code', dir: 'asc',
      columns: [{ key: 'code', label: 'الكود' }, { key: 'name', label: 'الحساب', render: (r) => `${esc(r.name)}${r.is_system ? ' <span class="badge">نظامي</span>' : ''}` }, { key: 'type', label: 'النوع', render: (r) => esc(TYPE_LABELS[r.type]), exportValue: (r) => TYPE_LABELS[r.type] },
        { key: 'nature', label: 'الطبيعة', render: (r) => (r.nature === 'debit' ? 'مدين' : 'دائن') }, { key: 'debit', label: 'مدين', type: 'money' }, { key: 'credit', label: 'دائن', type: 'money' }, { key: 'balance', label: 'الرصيد', type: 'money', cls: 'bold' }],
      actions: can('accounting.manage') ? () => `<button class="link-btn" data-act="edit">${icon('edit', 'sm')} تسمية</button><button class="link-btn muted" data-act="ledger">الأستاذ</button>` : () => '<button class="link-btn muted" data-act="ledger">الأستاذ</button>',
      onAction: async (a, r) => {
        if (a === 'ledger') { location.hash = `#/accounting?tab=ledger&account=${r.code}`; return; }
        if (await formModal({ title: `إعادة تسمية ${r.code}`, size: 'narrow', cols: 'c1', values: r, fields: [{ name: 'name', label: 'اسم الحساب', required: true }], submit: (v) => api('accounts.save', { code: r.code, name: v.name }) })) { toast('تم'); VIEWS.coa(el); }
      },
    });
    const add = $('[data-add]', el);
    if (add) add.onclick = async () => {
      if (await formModal({
        title: 'حساب جديد', values: { nature: 'debit', type: 'expense' },
        fields: [{ name: 'code', label: 'الكود (أرقام)', required: true, hint: 'مثال: 1xxx أصول، 2xxx خصوم، 3xxx ملكية، 4xxx إيرادات، 5xxx تكلفة، 6xxx مصروفات' }, { name: 'name', label: 'الاسم', required: true },
          { name: 'type', label: 'النوع', type: 'select', options: Object.entries(TYPE_LABELS).map(([value, label]) => ({ value, label })) }, { name: 'nature', label: 'الطبيعة', type: 'select', options: [{ value: 'debit', label: 'مدين' }, { value: 'credit', label: 'دائن' }] }],
        submit: (v) => api('accounts.save', { ...v, isNew: true }),
      })) { toast('تمت الإضافة'); VIEWS.coa(el); }
    };
    return t;
  },

  async opening(el) {
    el.innerHTML = `<div class="card"><div class="row between" style="margin-bottom:10px"><span class="muted small">أرصدة بداية التشغيل: مديونيات العملاء، مستحقات الموردين، النقدية والبنك. أرصدة المخزون الافتتاحية من صفحة المخزون ← رصيد افتتاحي. الطرف المقابل: حساب "أرصدة افتتاحية" (حقوق ملكية).</span>
      <button class="btn sm" data-add>${icon('plus', 'sm')} رصيد افتتاحي</button></div><div data-t></div></div>`;
    const K = { customer: 'عميل (مدين لنا)', supplier: 'مورد (دائن لنا)', cash: 'الصندوق', bank: 'البنك' };
    const rows = await api('opening.list');
    dataTable($('[data-t]', el), {
      rows, title: 'الأرصدة الافتتاحية', exportName: 'opening_balances', empty: 'لا توجد أرصدة افتتاحية',
      columns: [{ key: 'doc_no', label: 'الرقم' }, { key: 'date', label: 'التاريخ', type: 'date' }, { key: 'kind', label: 'النوع', render: (r) => esc(K[r.kind]), exportValue: (r) => K[r.kind] }, { key: 'party_name', label: 'الطرف' }, { key: 'amount', label: 'المبلغ', type: 'money' }, { key: 'notes', label: 'ملاحظات' },
        { key: 'status', label: '', render: (r) => (r.status === 'void' ? '<span class="badge bad">ملغي</span>' : ''), cls: 'keep' }],
      rowClass: (r) => (r.status === 'void' ? 'void' : ''),
      actions: (r) => (r.status === 'posted' ? `<button class="link-btn danger" data-act="void">${icon('ban', 'sm')} إلغاء</button>` : ''),
      onAction: async (a, r) => { const c = await confirmBox(`إلغاء الرصيد الافتتاحي ${r.doc_no} (${money(r.amount)})؟`, { danger: true, ok: 'إلغاء' }); if (c) { try { await api('opening.void', { id: r.id }); invalidate('customers', 'suppliers'); toast('تم'); VIEWS.opening(el); } catch (e) { showError(e); } } },
    });
    $('[data-add]', el).onclick = async () => {
      const [custs, sups] = await Promise.all([lookup('customers', true), lookup('suppliers', true)]);
      let ctl;
      const ok = await formModal({
        title: 'رصيد افتتاحي', values: { kind: 'customer', date: today() },
        fields: [{ name: 'kind', label: 'النوع', type: 'select', options: Object.entries(K).map(([value, label]) => ({ value, label })) }, { name: 'party_id', label: 'الطرف', type: 'combo' },
          { name: 'amount', label: `المبلغ (${currencySymbol()})`, type: 'number', required: true, hint: 'موجب عادةً. للعميل: ما هو مستحق عليه. للمورد: ما هو مستحق له.' }, { name: 'date', label: 'التاريخ', type: 'date' }, { name: 'notes', label: 'ملاحظات', full: true }],
        onOpen: (m) => {
          const cb = m.querySelector('[data-combo="party_id"]'); const kind = $('[name=kind]', m);
          const setup = () => {
            const k = kind.value; cb.closest('.field').classList.toggle('hide', !['customer', 'supplier'].includes(k));
            cb.innerHTML = '<input class="inp" autocomplete="off" placeholder="ابحث واختر…"><input type="hidden" name="party_id">';
            ctl = combo(cb, { options: partyOptions(k === 'supplier' ? sups : custs) });
          };
          kind.onchange = setup; setup();
        },
        submit: (v) => api('opening.create', v),
      });
      if (ok) { invalidate('customers', 'suppliers'); toast(`تم التسجيل ${ok.doc_no}`); VIEWS.opening(el); }
    };
  },

  async check(el) {
    const [c, t, b] = await Promise.all([api('accounting.inventoryCheck'), api('accounting.trial'), api('accounting.balanceSheet', {})]);
    const item = (ok, title, detail) => `<div class="alert ${ok ? 'ok' : 'bad'}">${icon(ok ? 'check' : 'alert', 'sm')}<div><b>${esc(title)}</b><div class="small" style="font-weight:500">${detail}</div></div></div>`;
    el.innerHTML = `<div class="card"><div class="card-title">${icon('shield', 'sm')} فحص سلامة البيانات المحاسبية</div>
      ${item(t.balanced, 'ميزان المراجعة', `إجمالي المدين ${fmt(t.total_debit)} — إجمالي الدائن ${fmt(t.total_credit)}`)}
      ${item(b.balanced, 'الميزانية العمومية', `الأصول ${fmt(b.total_assets)} — الخصوم وحقوق الملكية ${fmt(b.total_liabilities + b.total_equity)}`)}
      ${item(Math.abs(c.inventory_diff) < 0.05, 'حساب المخزون = تقييم أرصدة الأصناف', `رصيد حساب المخزون ${fmt(c.gl_inventory)} — قيمة الأرصدة بمتوسط التكلفة ${fmt(c.stock_valuation)} — الفرق ${fmt(c.inventory_diff)}`)}
      ${item(Math.abs(c.wip_diff) < 0.05, 'حساب إنتاج تحت التشغيل = تكاليف الأوامر المفتوحة', `رصيد الحساب ${fmt(c.gl_wip)} — تكاليف الأوامر المفتوحة ${fmt(c.open_orders_cost)} — الفرق ${fmt(c.wip_diff)}`)}
      <p class="muted small">يتم هذا الفحص تلقائيًا في اختبارات النظام بعد كل عملية. إذا ظهر فرق، راجع آخر العمليات المعدلة أو استعد نسخة احتياطية سليمة.</p></div>`;
  },
};
export { emptyState, dateTime };
