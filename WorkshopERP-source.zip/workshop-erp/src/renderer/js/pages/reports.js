import { api } from '../api.js';
import { esc, fmt, qty, money, pct, date, dateTime, $, navigate, monthStart, today, KIND_LABELS, debounce } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { pageHead, dataTable, showError, combo, emptyState } from '../ui/components.js';
import { lookup, opt, whOptions, partyOptions, productComboOptions } from './shared.js';

const GROUP_ICONS = { 'المخزون': 'boxes', 'المشتريات والمبيعات': 'receipt', 'العملاء والموردون': 'users', 'المالية': 'wallet', 'التصنيع': 'factory', 'الأرباح': 'chart' };

export async function reports(root, parts, params) {
  const catalog = await api('reports.catalog');
  if (parts[0]) return viewer(root, catalog, parts[0], params);
  const groups = [...new Set(catalog.map((r) => r.group))];
  root.innerHTML = pageHead('التقارير', `${catalog.length} تقريرًا من البيانات الفعلية — كل تقرير يدعم الفلترة بالتاريخ والبحث والترتيب والتصدير والطباعة`)
    + `<div class="filters" style="margin-bottom:14px"><div class="field grow"><label>بحث عن تقرير</label><input class="inp" data-q placeholder="اكتب جزءًا من اسم التقرير…"></div></div>
    <div class="grid g3" data-groups>${groups.map((g) => `<div class="card" data-group><div class="card-title">${icon(GROUP_ICONS[g] || 'report', 'sm')} ${esc(g)}</div>
      <div class="stack">${catalog.filter((r) => r.group === g).map((r) => `<a class="report-link" href="#/reports/${r.id}" data-title="${esc(r.title)}">${icon('report', 'sm')} <span>${esc(r.title)}</span>${icon('chevronL', 'sm')}</a>`).join('')}</div></div>`).join('')}</div>`;
  $('[data-q]', root).addEventListener('input', (e) => {
    const q = e.target.value.trim();
    root.querySelectorAll('[data-title]').forEach((a) => { a.style.display = !q || a.dataset.title.includes(q) ? '' : 'none'; });
    root.querySelectorAll('[data-group]').forEach((g) => { g.style.display = [...g.querySelectorAll('[data-title]')].some((a) => a.style.display !== 'none') ? '' : 'none'; });
  });
}

async function filterFields(keys, params) {
  const out = []; const combos = {};
  for (const raw of keys) {
    const req = raw.endsWith('*'); const k = raw.replace('*', '');
    const L = (s) => `${s}${req ? ' *' : ''}`;
    if (k === 'date') {
      out.push(`<div class="field"><label>من</label><input class="inp" type="date" name="from" value="${esc(params.from ?? monthStart())}"></div>`);
      out.push(`<div class="field"><label>إلى</label><input class="inp" type="date" name="to" value="${esc(params.to ?? today())}"></div>`);
    } else if (k === 'warehouse') {
      const w = await whOptions(false);
      out.push(`<div class="field"><label>المخزن</label><select class="inp" name="warehouse_id"><option value="">كل المخازن</option>${w.map((o) => `<option value="${o.value}" ${String(o.value) === String(params.warehouse_id) ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}</select></div>`);
    } else if (k === 'category') {
      const c = await lookup('categories');
      out.push(`<div class="field"><label>التصنيف</label><select class="inp" name="category_id">${opt(c, 'name', 'id', 'الكل').map((o) => `<option value="${o.value}">${esc(o.label)}</option>`).join('')}</select></div>`);
    } else if (k === 'kind') {
      out.push(`<div class="field"><label>النوع</label><select class="inp" name="kind"><option value="">الكل</option>${Object.entries(KIND_LABELS).map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select></div>`);
    } else if (k === 'product') {
      const p = await api('products.options', {});
      combos.product_id = productComboOptions(p);
      out.push(`<div class="field" style="min-width:240px"><label>${L('الصنف')}</label><div class="combo" data-combo="product_id"><input class="inp" placeholder="${req ? 'اختر الصنف' : 'الكل'}"><input type="hidden" name="product_id" value="${esc(params.product_id || '')}"></div></div>`);
    } else if (k === 'customer' || k === 'supplier') {
      const rows = await lookup(k === 'customer' ? 'customers' : 'suppliers', true);
      combos[`${k}_id`] = partyOptions(rows);
      out.push(`<div class="field" style="min-width:220px"><label>${L(k === 'customer' ? 'العميل' : 'المورد')}</label><div class="combo" data-combo="${k}_id"><input class="inp" placeholder="${req ? 'اختر' : 'الكل'}"><input type="hidden" name="${k}_id" value="${esc(params[`${k}_id`] || '')}"></div></div>`);
    } else if (k === 'status') {
      out.push('<div class="field"><label>الحالة</label><select class="inp" name="status"><option value="posted">المعتمدة</option><option value="void">الملغاة</option></select></div>');
    } else if (k === 'mostatus') {
      const s = await lookup('moStatuses');
      out.push(`<div class="field"><label>الحالة</label><select class="inp" name="status">${opt(s, 'name', 'code', 'الكل').map((o) => `<option value="${esc(o.value)}">${esc(o.label)}</option>`).join('')}</select></div>`);
    } else if (k === 'expcat') {
      const c = await lookup('expenseCategories');
      out.push(`<div class="field"><label>التصنيف</label><select class="inp" name="category_id">${opt(c, 'name', 'id', 'الكل').map((o) => `<option value="${o.value}">${esc(o.label)}</option>`).join('')}</select></div>`);
    } else if (k === 'movetype') {
      const t = await api('inventory.types');
      out.push(`<div class="field"><label>نوع الحركة</label><select class="inp" name="type"><option value="">الكل</option>${t.map((o) => `<option value="${esc(o.value)}">${esc(o.label)}</option>`).join('')}</select></div>`);
    } else if (k === 'cashacct') {
      out.push('<div class="field"><label>الحساب</label><select class="inp" name="account"><option value="1100">الصندوق</option><option value="1200">البنك</option></select></div>');
    } else if (k === 'due') {
      out.push('<div class="field"><label>&nbsp;</label><label class="check"><input type="checkbox" name="due"> أصحاب الأرصدة فقط</label></div>');
    } else if (k === 'q') {
      out.push('<div class="field grow"><label>بحث</label><input class="inp" name="q" placeholder="بحث داخل التقرير…"></div>');
    }
  }
  return { html: out.join(''), combos };
}

const fmtVal = (v, type) => (type === 'money' ? money(v) : type === 'qty' ? qty(v) : type === 'pct' ? pct(v) : type === 'date' ? date(v) : esc(v ?? '—'));

async function viewer(root, catalog, id, params) {
  const meta = catalog.find((r) => r.id === id);
  if (!meta) { root.innerHTML = emptyState('التقرير غير موجود أو ليست لديك صلاحية عرضه', '', 'report', '<a class="btn ghost" href="#/reports">كل التقارير</a>'); return; }
  const { html, combos } = await filterFields(meta.filters, params);
  const needs = meta.filters.filter((f) => f.endsWith('*')).map((f) => `${f.replace('*', '')}_id`);
  root.innerHTML = pageHead(meta.title, meta.group, `<a class="btn ghost" href="#/reports">${icon('arrowR', 'sm')} كل التقارير</a>`, `<a href="#/reports">التقارير</a> / ${esc(meta.title)}`)
    + `<div class="card"><div class="filters" data-f>${html}${meta.filters.includes('q') ? '' : '<div class="field grow"><label>بحث في النتائج</label><input class="inp" data-local placeholder="تصفية الصفوف المعروضة…"></div>'}</div>
      <div data-sub class="muted small" style="margin-bottom:8px"></div><div data-sum></div><div data-t></div></div>`;
  const fbox = $('[data-f]', root);
  const values = () => { const o = {}; fbox.querySelectorAll('[name]').forEach((i) => { if (i.type === 'checkbox') { if (i.checked) o[i.name] = 1; } else if (i.value !== '') o[i.name] = i.value; }); return o; };
  let table = null; let last = null;
  const describe = (v) => {
    const bits = [];
    if (v.from || v.to) bits.push(`الفترة: ${v.from || 'البداية'} — ${v.to || 'اليوم'}`);
    fbox.querySelectorAll('select[name]').forEach((s) => { if (s.value) bits.push(`${s.closest('.field').querySelector('label').textContent}: ${s.options[s.selectedIndex].text}`); });
    fbox.querySelectorAll('.combo').forEach((c) => { const t = c.querySelector('input:not([type=hidden])').value; if (t) bits.push(`${c.closest('.field').querySelector('label').textContent.replace('*', '').trim()}: ${t}`); });
    if (v.q) bits.push(`بحث: ${v.q}`);
    return bits.join(' · ');
  };
  const run = async () => {
    const v = values();
    const missing = needs.filter((k) => !v[k]);
    if (missing.length) { $('[data-t]', root).innerHTML = emptyState('اختر القيم المطلوبة (*) لعرض التقرير', '', 'search'); $('[data-sum]', root).innerHTML = ''; return; }
    $('[data-t]', root).innerHTML = '<div class="empty muted">جارِ إعداد التقرير…</div>';
    try {
      last = await api('reports.run', { id, params: v });
      const r = last;
      const sub = [r.subtitle, describe(v)].filter(Boolean).join(' — ');
      $('[data-sub]', root).textContent = `${sub}${sub ? ' — ' : ''}أُعد في ${dateTime(r.generated_at)} — ${fmt(r.rows.length, 0)} سطرًا`;
      $('[data-sum]', root).innerHTML = r.summary && r.summary.length ? `<div class="sum-strip">${r.summary.map((s) => `<div><span>${esc(s.label)}</span><b>${fmtVal(s.value, s.type)}</b></div>`).join('')}</div>` : '';
      const cols = r.columns.map((c, i) => {
        const col = { key: c.key, label: c.label, type: c.type === 'text' ? undefined : c.type };
        if (r.layout === 'statement' && i === 0) col.render = (row) => `<span style="padding-inline-start:${(row.level || 0) * 22}px;${row.strong ? 'font-weight:800' : ''}">${esc(row[c.key])}</span>`;
        return col;
      });
      table = dataTable($('[data-t]', root), {
        rows: r.rows, columns: cols, title: r.title, exportName: `report_${id}`, pageSize: r.layout === 'statement' ? 100 : undefined,
        printSub: () => [r.subtitle, describe(v)].filter(Boolean).join(' — '),
        footer: r.totals && Object.keys(r.totals).length ? () => r.totals : null,
        rowClass: (row) => (row.strong ? 'bold' : ''), empty: 'لا توجد بيانات مطابقة للفلاتر المحددة', emptyIcon: 'report',
      });
    } catch (e) { $('[data-t]', root).innerHTML = `<div class="alert bad">${icon('alert', 'sm')} ${esc(e.message)}</div>`; }
  };
  const debounced = debounce(run, 300);
  fbox.addEventListener('change', (e) => { if (!e.target.matches('[data-local]')) run(); });
  fbox.addEventListener('input', (e) => { if (e.target.name === 'q') debounced(); });
  const local = $('[data-local]', root);
  if (local) local.addEventListener('input', debounce(() => { if (table) table.setSearch(local.value.trim()); }, 200));
  Object.entries(combos).forEach(([name, options]) => { const c = fbox.querySelector(`[data-combo="${name}"]`); if (c) combo(c, { options, value: params[name], onChange: () => run() }); });
  await run();
}
export { navigate, showError };
