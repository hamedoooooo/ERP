import { api } from '../api.js';
import { state, esc, el, $, $$, fmt, qty, KIND_LABELS } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { combo } from '../ui/components.js';

const cache = {};
export async function lookup(name, force = false) {
  const M = { warehouses: 'warehouses.list', units: 'units.list', categories: 'categories.list', customers: 'customers.options', suppliers: 'suppliers.options', expenseCategories: 'expenseCategories.list', moStatuses: 'moStatuses.list', kinds: 'products.kinds' };
  if (force || !cache[name]) cache[name] = await api(M[name]);
  return cache[name];
}
export const invalidate = (...names) => names.forEach((n) => delete cache[n]);

export const opt = (rows, label = 'name', value = 'id', empty = null) => [...(empty ? [{ value: '', label: empty }] : []), ...rows.map((r) => ({ value: r[value], label: typeof label === 'function' ? label(r) : r[label] }))];
export async function whOptions(onlyActive = true) { const w = await lookup('warehouses'); return w.filter((x) => !onlyActive || x.active).map((x) => ({ value: x.id, label: x.name })); }
export async function defaultWh() { const w = await lookup('warehouses'); return (w.find((x) => x.is_default) || w[0] || {}).id; }
export function partyOptions(rows) { return rows.map((r) => ({ value: r.id, label: r.name, sub: [r.code, r.phone].filter(Boolean).join(' — '), search: `${r.name} ${r.code} ${r.phone || ''}` })); }
export function productComboOptions(rows, { stockKey = 'qty' } = {}) {
  return rows.map((p) => ({ value: p.id, label: p.name, sub: `${p.code} · ${KIND_LABELS[p.kind] || ''}${p.is_stocked ? ` · متاح ${qty(p[stockKey] ?? p.qty)} ${p.unit_name}` : ' · خدمة'}`, search: `${p.name} ${p.code} ${p.barcode || ''}`, p }));
}

/**
 * Editable document lines.
 * cfg: { products:[product option rows], columns:[{key,label,type:'number'|'text'|'computed'|'select', compute(line), options, width, step}],
 *        onProduct(line, product), info(line, product) → html, onChange(lines), lines, addLabel, minRows }
 */
export function lineEditor(container, cfg) {
  let lines = (cfg.lines && cfg.lines.length ? cfg.lines : [{}]).map((l) => ({ ...l }));
  const prodMap = new Map(cfg.products.map((p) => [String(p.id), p]));
  const options = productComboOptions(cfg.products, cfg.stockKey ? { stockKey: cfg.stockKey } : {});

  function computed(l, c) { const v = c.compute(l, prodMap.get(String(l.product_id))); return c.format === 'qty' ? qty(v) : c.format === 'text' ? esc(v) : fmt(v); }
  function render() {
    container.innerHTML = `<div class="tbl-wrap"><table class="tbl lines"><thead><tr><th style="width:34%">الصنف</th>${cfg.columns.map((c) => `<th class="${c.type === 'text' ? '' : 'n'}" style="${c.width ? `width:${c.width}` : ''}">${esc(c.label)}</th>`).join('')}<th style="width:36px"></th></tr></thead>
      <tbody>${lines.map((l, i) => {
    const p = prodMap.get(String(l.product_id));
    return `<tr data-i="${i}"><td><div class="combo"><input class="inp" placeholder="ابحث بالاسم أو الكود أو الباركود…"><input type="hidden" value="${esc(l.product_id || '')}"></div>${cfg.info && p ? `<div class="small muted" data-info>${cfg.info(l, p)}</div>` : '<div class="small muted" data-info></div>'}</td>
          ${cfg.columns.map((c) => {
    if (c.type === 'computed') return `<td class="n bold" data-c="${c.key}">${computed(l, c)}</td>`;
    if (c.type === 'select') return `<td><select class="inp" data-k="${c.key}">${c.options.map((o) => `<option value="${esc(o.value)}" ${String(o.value) === String(l[c.key] ?? '') ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}</select></td>`;
    return `<td><input class="inp ${c.type === 'number' ? 'num' : ''}" ${c.type === 'number' ? `type="number" step="${c.step || 'any'}"` : ''} data-k="${c.key}" value="${esc(l[c.key] ?? '')}" placeholder="${esc(c.placeholder || '')}"></td>`;
  }).join('')}
          <td><button type="button" class="btn icon ghost" data-rm title="حذف السطر">${icon('x', 'sm')}</button></td></tr>`;
  }).join('')}</tbody></table></div>
      <button type="button" class="btn ghost sm" data-add style="margin-top:8px">${icon('plus', 'sm')} ${esc(cfg.addLabel || 'إضافة سطر')}</button>`;
    $$('tbody tr', container).forEach((tr) => {
      const i = Number(tr.dataset.i);
      combo($('.combo', tr), {
        options, value: lines[i].product_id, emptyHint: 'تأكد من إضافة الصنف أولًا',
        onChange: (o) => {
          lines[i].product_id = o ? o.value : '';
          if (o && cfg.onProduct) cfg.onProduct(lines[i], o.p);
          if (o && i === lines.length - 1) lines.push({});
          render(); changed();
          const next = container.querySelector(`tr[data-i="${i}"] input[data-k]`); if (next) next.focus();
        },
      });
    });
  }
  function changed() { if (cfg.onChange) cfg.onChange(get()); }
  function refreshRow(tr) {
    const l = lines[Number(tr.dataset.i)];
    cfg.columns.filter((c) => c.type === 'computed').forEach((c) => { tr.querySelector(`[data-c="${c.key}"]`).innerHTML = computed(l, c); });
    const p = prodMap.get(String(l.product_id));
    if (cfg.info && p) tr.querySelector('[data-info]').innerHTML = cfg.info(l, p);
  }
  container.addEventListener('input', (e) => {
    const k = e.target.dataset.k; if (!k) return;
    const tr = e.target.closest('tr'); lines[Number(tr.dataset.i)][k] = e.target.value; refreshRow(tr); changed();
  });
  container.addEventListener('change', (e) => { const k = e.target.dataset.k; if (k && e.target.tagName === 'SELECT') { const tr = e.target.closest('tr'); lines[Number(tr.dataset.i)][k] = e.target.value; refreshRow(tr); changed(); } });
  container.addEventListener('click', (e) => {
    if (e.target.closest('[data-add]')) { lines.push({}); render(); const rows = $$('tbody tr', container); $('.combo input', rows[rows.length - 1]).focus(); }
    const rm = e.target.closest('[data-rm]');
    if (rm) { lines.splice(Number(rm.closest('tr').dataset.i), 1); if (!lines.length) lines.push({}); render(); changed(); }
  });
  function get() { return lines.filter((l) => l.product_id).map((l) => ({ ...l, product: prodMap.get(String(l.product_id)) })); }
  render();
  return { get, set(ls) { lines = ls.length ? ls.map((l) => ({ ...l })) : [{}]; render(); changed(); }, products: prodMap };
}

export function statusBadge(s) {
  return { posted: '<span class="badge ok">معتمد</span>', void: '<span class="badge bad">ملغي</span>', draft: '<span class="badge warn">مسودة</span>', approved: '<span class="badge ok">معتمد</span>', cancelled: '<span class="badge bad">ملغي</span>' }[s] || esc(s);
}
export function moBadge(r) { return `<span class="badge dot" style="color:${esc(r.status_color)};background:${esc(r.status_color)}18">${esc(r.status_name)}</span>`; }
export const taxOn = () => !!(state.settings && state.settings.tax.enabled);
