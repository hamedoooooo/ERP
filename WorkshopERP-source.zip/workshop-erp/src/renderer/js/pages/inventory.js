import { api } from '../api.js';
import { esc, fmt, qty, date, can, today, $, currencySymbol } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { pageHead, dataTable, filterBar, bindFilters, formModal, confirmBox, toast, showError, modal, tabs, tableHtml, kvList } from '../ui/components.js';
import { printDoc, docHeader } from '../ui/print.js';
import { lookup, invalidate, opt, whOptions, defaultWh, lineEditor, statusBadge } from './shared.js';

export async function inventory(root, parts, params) {
  const costs = can('costs.view');
  root.innerHTML = pageHead('المخزون والحركات', 'الأرصدة، سجل الحركات، التحويل بين المخازن، التسويات والأرصدة الافتتاحية', `
    ${can('inventory.adjust') ? `<button class="btn ghost" data-transfer>${icon('swap', 'sm')} تحويل بين مخازن</button><button class="btn ghost" data-adjust>${icon('scale', 'sm')} تسوية مخزون</button><button class="btn" data-opening>${icon('plus', 'sm')} رصيد افتتاحي</button>` : ''}`)
    + '<div class="tabs"></div><div data-tab-body></div>';
  const body = $('[data-tab-body]', root);
  const TABS = [{ id: 'stock', label: 'الأرصدة', icon: 'boxes' }, { id: 'moves', label: 'حركة المخزون', icon: 'history' }, { id: 'transfers', label: 'التحويلات', icon: 'swap' }, { id: 'adjustments', label: 'التسويات والافتتاحي', icon: 'scale' }, { id: 'warehouses', label: 'المخازن', icon: 'warehouse' }];
  let current = params.tab || 'stock';
  const show = async (t) => { current = t; body.innerHTML = ''; try { await VIEWS[t](body); } catch (e) { showError(e); } };
  tabs($('.tabs', root), TABS, current, show);
  const act = (s, f) => { const b = $(s, root); if (b) b.onclick = async () => { if (await f()) show(current); }; };
  act('[data-transfer]', transferForm); act('[data-adjust]', () => adjustForm('manual')); act('[data-opening]', () => adjustForm('opening'));

  const VIEWS = {
    async stock(el) {
      const [whs, cats] = await Promise.all([whOptions(false), lookup('categories')]);
      el.innerHTML = `<div class="card">${filterBar([
        { name: 'q', label: 'بحث' }, { name: 'warehouse_id', label: 'المخزن', type: 'select', options: [{ value: '', label: 'كل المخازن' }, ...whs] },
        { name: 'category_id', label: 'التصنيف', type: 'select', options: opt(cats, 'name', 'id', 'الكل') },
        { name: 'stock', label: 'عرض', type: 'select', options: [{ value: 'available', label: 'الأصناف المتوفرة' }, { value: '', label: 'كل الأصناف' }, { value: 'low', label: 'المنخفضة فقط' }] },
      ], { stock: 'available' })}<div data-t></div></div>`;
      let f = { stock: 'available' };
      const t = dataTable($('[data-t]', el), {
        title: 'أرصدة المخزون', exportName: 'stock', fetch: (p) => api('products.list', { ...f, ...p, stockable: 1 }),
        columns: [{ key: 'code', label: 'الكود', sort: true }, { key: 'name', label: 'الصنف', sort: true }, { key: 'category_name', label: 'التصنيف' }, { key: 'unit_name', label: 'الوحدة' },
          { key: 'qty', label: 'الرصيد', type: 'qty', sort: true }, ...(costs ? [{ key: 'avg_cost', label: 'متوسط التكلفة', type: 'money' }, { key: 'value', label: 'القيمة', type: 'money', sort: true }] : []),
          { key: 'min_qty', label: 'الحد الأدنى', type: 'qty', render: (r) => (r.min_qty ? `${qty(r.min_qty)} ${r.qty <= r.min_qty ? '<span class="badge bad">منخفض</span>' : ''}` : '') }],
        footer: costs ? (r) => ({ value: r.rows.reduce((s, x) => s + (x.value || 0), 0) }) : null,
        onRow: (r) => { location.hash = `#/products/${r.id}`; },
      });
      bindFilters($('.filters', el), (v) => { f = v; t.reload(); });
    },
    async moves(el) {
      const [whs, types] = await Promise.all([whOptions(false), api('inventory.types')]);
      el.innerHTML = `<div class="card">${filterBar([
        { name: 'q', label: 'بحث', placeholder: 'الصنف أو رقم المستند' }, { name: 'from', label: 'من', type: 'date' }, { name: 'to', label: 'إلى', type: 'date' },
        { name: 'warehouse_id', label: 'المخزن', type: 'select', options: [{ value: '', label: 'الكل' }, ...whs] },
        { name: 'type', label: 'نوع الحركة', type: 'select', options: [{ value: '', label: 'الكل' }, ...types] },
      ])}<div data-t></div></div>`;
      let f = {};
      const t = dataTable($('[data-t]', el), {
        title: 'حركة المخزون', exportName: 'inventory_movements', fetch: (p) => api('inventory.movements', { ...f, ...p }),
        columns: [{ key: 'date', label: 'التاريخ', type: 'date', sort: true }, { key: 'type_label', label: 'الحركة' }, { key: 'doc_no', label: 'المستند' }, { key: 'product_name', label: 'الصنف', sort: true }, { key: 'warehouse_name', label: 'المخزن' },
          { key: 'qty_in', label: 'وارد', type: 'qty' }, { key: 'qty_out', label: 'منصرف', type: 'qty' }, ...(costs ? [{ key: 'unit_cost', label: 'التكلفة', type: 'money' }, { key: 'total_cost', label: 'القيمة', type: 'money' }] : []), { key: 'user_name', label: 'المستخدم' }, { key: 'notes', label: 'ملاحظات' }],
        onRow: (r) => { location.hash = `#/products/${r.product_id}`; },
      });
      bindFilters($('.filters', el), (v) => { f = v; t.reload(); });
    },
    async transfers(el) {
      el.innerHTML = `<div class="card">${filterBar([{ name: 'from', label: 'من', type: 'date' }, { name: 'to', label: 'إلى', type: 'date' }])}<div data-t></div></div>`;
      let f = {};
      const t = dataTable($('[data-t]', el), {
        title: 'التحويلات بين المخازن', exportName: 'transfers', fetch: (p) => api('transfers.list', { ...f, ...p }), empty: 'لا توجد تحويلات',
        columns: [{ key: 'doc_no', label: 'الرقم' }, { key: 'date', label: 'التاريخ', type: 'date' }, { key: 'from_name', label: 'من مخزن' }, { key: 'to_name', label: 'إلى مخزن' }, { key: 'items_count', label: 'عدد الأصناف', type: 'qty' }, { key: 'status', label: 'الحالة', render: (r) => statusBadge(r.status) }],
        rowClass: (r) => (r.status === 'void' ? 'void' : ''),
        onRow: async (r) => { if (await viewTransfer(r.id)) t.reload(false); },
      });
      bindFilters($('.filters', el), (v) => { f = v; t.reload(); });
    },
    async adjustments(el) {
      el.innerHTML = `<div class="card">${filterBar([{ name: 'q', label: 'بحث' }, { name: 'from', label: 'من', type: 'date' }, { name: 'to', label: 'إلى', type: 'date' },
        { name: 'source', label: 'النوع', type: 'select', options: [{ value: '', label: 'الكل' }, { value: 'manual', label: 'تسوية يدوية' }, { value: 'opening', label: 'رصيد افتتاحي' }, { value: 'count', label: 'تسوية جرد' }] }])}<div data-t></div></div>`;
      let f = {};
      const SRC = { manual: 'تسوية يدوية', opening: 'رصيد افتتاحي', count: 'تسوية جرد' };
      const t = dataTable($('[data-t]', el), {
        title: 'تسويات المخزون', exportName: 'adjustments', fetch: (p) => api('adjustments.list', { ...f, ...p }), empty: 'لا توجد تسويات',
        columns: [{ key: 'doc_no', label: 'الرقم' }, { key: 'date', label: 'التاريخ', type: 'date' }, { key: 'source', label: 'النوع', render: (r) => esc(SRC[r.source]), exportValue: (r) => SRC[r.source] }, { key: 'warehouse_name', label: 'المخزن' }, { key: 'reason', label: 'السبب' },
          ...(costs ? [{ key: 'total_value', label: 'صافي القيمة', type: 'money' }] : []), { key: 'user_name', label: 'المستخدم' }, { key: 'status', label: 'الحالة', render: (r) => statusBadge(r.status) }],
        rowClass: (r) => (r.status === 'void' ? 'void' : ''),
        onRow: async (r) => { if (await viewAdjustment(r.id)) t.reload(false); },
      });
      bindFilters($('.filters', el), (v) => { f = v; t.reload(); });
    },
    async warehouses(el) {
      const rows = await lookup('warehouses', true);
      el.innerHTML = `<div class="card"><div class="card-title"><span>${icon('warehouse')} المخازن</span>${can('inventory.adjust') ? `<button class="btn sm" data-add>${icon('plus', 'sm')} مخزن جديد</button>` : ''}</div>
        ${tableHtml([{ key: 'code', label: 'الكود' }, { key: 'name', label: 'الاسم', render: (r) => `<b>${esc(r.name)}</b> ${r.is_default ? '<span class="badge info">افتراضي</span>' : ''}` }, { key: 'location', label: 'الموقع' }, { key: 'items_count', label: 'أصناف بها رصيد', type: 'qty' }, ...(costs ? [{ key: 'stock_value', label: 'قيمة المخزون', type: 'money' }] : []), { key: 'active', label: 'الحالة', render: (r) => (r.active ? '<span class="badge ok">نشط</span>' : '<span class="badge bad">موقوف</span>') }],
    rows, { actions: can('inventory.adjust') ? (r) => `<button class="link-btn" data-e="${r.id}">${icon('edit', 'sm')} تعديل</button>${r.is_default ? '' : `<button class="link-btn muted" data-tg="${r.id}">${r.active ? 'إيقاف' : 'تفعيل'}</button><button class="link-btn danger" data-d="${r.id}">${icon('trash', 'sm')}</button>`}` : null })}</div>`;
      const edit = async (r) => { if (await formModal({ title: r ? 'تعديل مخزن' : 'مخزن جديد', size: 'narrow', cols: 'c1', values: r || {}, fields: [{ name: 'name', label: 'اسم المخزن', required: true }, { name: 'location', label: 'الموقع' }, { name: 'is_default', label: 'المخزن الافتراضي', type: 'checkbox' }, { name: 'notes', label: 'ملاحظات', type: 'textarea' }], submit: (v) => api('warehouses.save', { ...v, id: r && r.id }) })) { invalidate('warehouses'); show('warehouses'); } };
      el.onclick = async (e) => {
        try {
          if (e.target.closest('[data-add]')) return edit();
          const b = e.target.closest('[data-e],[data-tg],[data-d]'); if (!b) return;
          const r = rows.find((x) => x.id === Number(b.dataset.e || b.dataset.tg || b.dataset.d));
          if (b.dataset.e) return edit(r);
          if (b.dataset.tg) { await api('warehouses.toggle', { id: r.id }); invalidate('warehouses'); return show('warehouses'); }
          if (b.dataset.d && await confirmBox(`حذف المخزن "${r.name}"؟`, { danger: true, ok: 'حذف' })) { await api('warehouses.delete', { id: r.id }); invalidate('warehouses'); toast('تم الحذف'); show('warehouses'); }
        } catch (err) { showError(err); }
      };
    },
  };
  await show(current);
}

// ------------------------------------------------------------------ forms
async function docModal({ title, head, submitLabel = 'حفظ', build, submit }) {
  return new Promise((resolve) => {
    const m = modal({ title, size: 'wide', body: `${head}<div data-lines style="margin-top:14px"></div><div class="alert bad hide" data-err style="margin-top:10px"></div>`, foot: `<button class="btn" data-ok>${icon('save', 'sm')} ${esc(submitLabel)}</button><button class="btn ghost" data-close>إلغاء</button>` });
    let resolved = false;
    m.el.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => { if (!resolved) resolve(false); }));
    Promise.resolve(build(m.el)).then((ctl) => {
      $('[data-ok]', m.el).onclick = async (e) => {
        const err = $('[data-err]', m.el); err.classList.add('hide'); e.target.disabled = true;
        try { const r = await submit(ctl, m.el); resolved = true; m.close(); resolve(r || true); } catch (x) { err.textContent = x.message; err.classList.remove('hide'); } finally { e.target.disabled = false; }
      };
    }).catch(showError);
  });
}

export async function transferForm() {
  const whs = await whOptions(); const dw = await defaultWh();
  const head = `<div class="form c4"><div class="field"><label>من مخزن *</label><select class="inp" name="from_warehouse_id">${whs.map((w) => `<option value="${w.value}" ${w.value === dw ? 'selected' : ''}>${esc(w.label)}</option>`).join('')}</select></div>
    <div class="field"><label>إلى مخزن *</label><select class="inp" name="to_warehouse_id">${whs.map((w) => `<option value="${w.value}" ${w.value !== dw ? 'selected' : ''}>${esc(w.label)}</option>`).join('')}</select></div>
    <div class="field"><label>التاريخ</label><input class="inp" type="date" name="date" value="${today()}"></div><div class="field"><label>ملاحظات</label><input class="inp" name="notes"></div></div>`;
  if (whs.length < 2) { toast('أضف مخزنًا ثانيًا أولًا من تبويب المخازن', 'warn'); return false; }
  let ed;
  return docModal({
    title: 'تحويل بين المخازن', head, submitLabel: 'تنفيذ التحويل',
    build: async (m) => {
      const load = async () => {
        const prods = await api('products.options', { stockable: true, warehouse_id: $('[name=from_warehouse_id]', m).value });
        ed = lineEditor($('[data-lines]', m), { products: prods, stockKey: 'wh_qty', columns: [{ key: 'qty', label: 'الكمية', type: 'number', width: '140px' }], info: (l, p) => `المتاح في المخزن: ${qty(p.wh_qty)} ${esc(p.unit_name)}` });
      };
      $('[name=from_warehouse_id]', m).onchange = load; await load();
    },
    submit: async (_, m) => {
      const v = Object.fromEntries(['from_warehouse_id', 'to_warehouse_id', 'date', 'notes'].map((k) => [k, $(`[name=${k}]`, m).value]));
      const r = await api('transfers.create', { ...v, lines: ed.get().map((l) => ({ product_id: l.product_id, qty: l.qty })) });
      toast(`تم التحويل ${r.doc_no}`); return r;
    },
  });
}

export async function adjustForm(kind) {
  const whs = await whOptions(); const dw = await defaultWh();
  const opening = kind === 'opening';
  const head = `${opening ? '<div class="alert info">الرصيد الافتتاحي يُستخدم عند بدء العمل على البرنامج لتسجيل الكميات الموجودة فعليًا وتكلفتها. يُسجل قيده مقابل حساب الأرصدة الافتتاحية.</div>' : '<div class="alert info">التسوية اليدوية لتصحيح الرصيد (تلف، فقد، زيادة). اكتب الفرق بالموجب للزيادة وبالسالب للنقص. الفرق يُحمَّل على حساب فروقات المخزون.</div>'}
    <div class="form c3"><div class="field"><label>المخزن *</label><select class="inp" name="warehouse_id">${whs.map((w) => `<option value="${w.value}" ${w.value === dw ? 'selected' : ''}>${esc(w.label)}</option>`).join('')}</select></div>
    <div class="field"><label>التاريخ</label><input class="inp" type="date" name="date" value="${today()}"></div>
    <div class="field"><label>${opening ? 'ملاحظات' : 'سبب التسوية *'}</label><input class="inp" name="reason"></div></div>`;
  let ed;
  return docModal({
    title: opening ? 'رصيد مخزون افتتاحي' : 'تسوية مخزون', head, submitLabel: 'اعتماد',
    build: async (m) => {
      const load = async () => {
        const prods = await api('products.options', { stockable: true, warehouse_id: $('[name=warehouse_id]', m).value });
        ed = lineEditor($('[data-lines]', m), {
          products: prods, stockKey: 'wh_qty',
          columns: opening
            ? [{ key: 'qty', label: 'الكمية', type: 'number', width: '120px' }, { key: 'unit_cost', label: `تكلفة الوحدة (${currencySymbol()})`, type: 'number', width: '150px' }, { key: 'total', label: 'القيمة', type: 'computed', compute: (l) => (Number(l.qty) || 0) * (Number(l.unit_cost) || 0) }]
            : [{ key: 'qty_diff', label: 'الفرق (+ / −)', type: 'number', width: '130px' }, { key: 'reason', label: 'سبب السطر', type: 'text' }],
          onProduct: (l, p) => { if (opening && !l.unit_cost) l.unit_cost = p.avg_cost || p.purchase_price || 0; },
          info: (l, p) => `الرصيد الحالي: ${qty(p.wh_qty)} ${esc(p.unit_name)}${!opening && l.qty_diff ? ` ← بعد التسوية ${qty(Number(p.wh_qty) + Number(l.qty_diff || 0))}` : ''}`,
        });
      };
      $('[name=warehouse_id]', m).onchange = load; await load();
    },
    submit: async (_, m) => {
      const base = { warehouse_id: $('[name=warehouse_id]', m).value, date: $('[name=date]', m).value };
      const reason = $('[name=reason]', m).value;
      const lines = ed.get().map((l) => ({ product_id: l.product_id, qty: l.qty, unit_cost: l.unit_cost, qty_diff: l.qty_diff, reason: l.reason }));
      const r = opening ? await api('inventory.opening', { ...base, notes: reason, lines }) : await api('adjustments.create', { ...base, reason, lines });
      toast(`تم الاعتماد ${r.doc_no}`); return r;
    },
  });
}

async function viewTransfer(id) {
  const d = await api('transfers.get', { id });
  return new Promise((resolve) => {
    const m = modal({
      title: `تحويل ${d.doc_no}`, size: 'wide',
      body: `${kvList([['التاريخ', date(d.date)], ['من', d.from_name], ['إلى', d.to_name], ['الحالة', d.status === 'void' ? 'ملغي' : 'معتمد'], ['ملاحظات', d.notes || '—']])}
        ${tableHtml([{ key: 'product_code', label: 'الكود' }, { key: 'product_name', label: 'الصنف' }, { key: 'unit_name', label: 'الوحدة' }, { key: 'qty', label: 'الكمية', type: 'qty' }], d.lines)}`,
      foot: `<button class="btn ghost" data-print>${icon('printer', 'sm')} طباعة</button>${d.status === 'posted' && can('inventory.adjust') ? `<button class="btn danger" data-void>${icon('ban', 'sm')} إلغاء التحويل</button>` : ''}<button class="btn ghost" data-close>إغلاق</button>`,
    });
    $('[data-print]', m.el).onclick = () => printDoc(`${docHeader('إذن تحويل مخزني', d.doc_no)}<div class="meta"><div><b>التاريخ:</b> ${esc(date(d.date))}</div><div><b>من:</b> ${esc(d.from_name)} <b>إلى:</b> ${esc(d.to_name)}</div></div>${tableHtml([{ key: 'product_code', label: 'الكود' }, { key: 'product_name', label: 'الصنف' }, { key: 'unit_name', label: 'الوحدة' }, { key: 'qty', label: 'الكمية', type: 'qty' }], d.lines)}<div class="sign"><div>أمين المخزن المُسلِّم</div><div>أمين المخزن المستلم</div></div>`);
    const v = $('[data-void]', m.el);
    if (v) v.onclick = async () => { if (await confirmBox('إلغاء التحويل يعيد الكميات إلى المخزن الأصلي. متابعة؟', { danger: true, ok: 'إلغاء التحويل' })) { try { await api('transfers.void', { id }); toast('تم إلغاء التحويل'); m.close(); resolve(true); } catch (e) { showError(e); } } };
  });
}

async function viewAdjustment(id) {
  const d = await api('adjustments.get', { id });
  const costs = can('costs.view');
  return new Promise((resolve) => {
    const m = modal({
      title: `تسوية ${d.doc_no}`, size: 'wide',
      body: `${kvList([['التاريخ', date(d.date)], ['المخزن', d.warehouse_name], ['السبب', d.reason || '—'], ['المستخدم', d.user_name || '—'], ['الحالة', d.status === 'void' ? `ملغي — ${d.void_reason || ''}` : 'معتمد']])}
        ${tableHtml([{ key: 'product_name', label: 'الصنف' }, { key: 'unit_name', label: 'الوحدة' }, { key: 'qty_diff', label: 'الفرق', type: 'qty' }, ...(costs ? [{ key: 'unit_cost', label: 'التكلفة', type: 'money' }, { key: 'value', label: 'القيمة', type: 'money' }] : []), { key: 'reason', label: 'السبب' }], d.lines)}`,
      foot: `${d.status === 'posted' && d.source !== 'count' && can('inventory.adjust') ? `<button class="btn danger" data-void>${icon('ban', 'sm')} إلغاء التسوية</button>` : ''}<button class="btn ghost" data-close>إغلاق</button>`,
    });
    const v = $('[data-void]', m.el);
    if (v) v.onclick = async () => { const c = await confirmBox('سيتم عكس أثر التسوية على المخزون والقيود.', { danger: true, ok: 'إلغاء', reason: true }); if (c) { try { await api('adjustments.void', { id, reason: c.reason }); toast('تم الإلغاء'); m.close(); resolve(true); } catch (e) { showError(e); } } };
  });
}
export { fmt };
