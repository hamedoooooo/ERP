import { api } from '../api.js';
import { esc, money, fmt, date, can, today, $, currencySymbol, PAY_LABELS, monthStart } from '../ui/dom.js';
import { icon } from '../ui/icons.js';
import { pageHead, dataTable, filterBar, bindFilters, formModal, confirmBox, toast, showError, tabs, modal, tableHtml, combo } from '../ui/components.js';
import { printPayment, printDoc, docHeader } from '../ui/print.js';
import { lookup, invalidate, partyOptions, statusBadge, opt } from './shared.js';

/** Receipt / payment voucher modal. Returns created {id} or false. */
export async function paymentForm(preset = {}) {
  const [custs, sups] = await Promise.all([lookup('customers', true), lookup('suppliers', true)]);
  const dirLabel = (d) => (d === 'in' ? 'تحصيل (قبض)' : 'سداد (صرف)');
  const v = { direction: 'in', party_type: 'customer', method: 'cash', date: today(), ...preset };
  let partyType = v.party_type;
  const r = await formModal({
    title: preset.direction ? `${dirLabel(v.direction)}` : 'سند قبض / صرف', values: v,
    fields: [
      { name: 'direction', label: 'نوع السند', type: 'select', options: [{ value: 'in', label: 'تحصيل (قبض) — يزيد الصندوق/البنك' }, { value: 'out', label: 'سداد (صرف) — ينقص الصندوق/البنك' }] },
      { name: 'party_type', label: 'الطرف', type: 'select', options: [{ value: 'customer', label: 'عميل' }, { value: 'supplier', label: 'مورد' }] },
      { name: 'party_id', label: 'الاسم', type: 'combo', required: true, full: true },
      { type: 'html', full: true, html: '<div class="hint" data-bal></div>' },
      { name: 'amount', label: `المبلغ (${currencySymbol()})`, type: 'number', min: 0, required: true },
      { name: 'method', label: 'طريقة الدفع', type: 'select', options: [{ value: 'cash', label: 'الصندوق (نقدي)' }, { value: 'bank', label: 'البنك' }] },
      { name: 'date', label: 'التاريخ', type: 'date' }, { name: 'reference', label: 'المرجع (رقم شيك/تحويل)' },
      { name: 'notes', label: 'ملاحظات', full: true },
      { name: 'print', label: 'طباعة الإيصال بعد الحفظ', type: 'checkbox', value: true },
    ],
    onOpen: (m) => {
      const cb = m.querySelector('[data-combo="party_id"]');
      const opts = (t) => partyOptions(t === 'customer' ? custs : sups);
      const bal = $('[data-bal]', m);
      let ctl;
      const setup = () => {
        cb.innerHTML = '<input class="inp" autocomplete="off" placeholder="ابحث واختر…"><input type="hidden" name="party_id">';
        ctl = combo(cb, { options: opts(partyType), value: partyType === v.party_type ? v.party_id : '', onChange: (o) => showBal(o) });
        showBal(ctl.get() ? { value: ctl.get() } : null);
      };
      const showBal = (o) => {
        const list = partyType === 'customer' ? custs : sups;
        const p = o ? list.find((x) => x.id === Number(o.value)) : null;
        bal.textContent = p ? `الرصيد الحالي: ${money(p.balance)} ${partyType === 'customer' ? (p.balance >= 0 ? '(مستحق على العميل)' : '(للعميل)') : (p.balance >= 0 ? '(مستحق للمورد)' : '(على المورد)')}` : '';
      };
      $('[name=party_type]', m).onchange = (e) => { partyType = e.target.value; setup(); };
      setup();
    },
    submit: async (x) => {
      const res = await api('payments.create', { ...x, reference: x.reference || preset.reference, notes: x.notes });
      invalidate('customers', 'suppliers');
      toast(`تم حفظ السند ${res.doc_no}`);
      if (res.warning) toast(res.warning, 'warn');
      if (x.print) printPayment(await api('payments.get', { id: res.id }));
      return res;
    },
  });
  return r;
}

export async function payments(root, parts, params) {
  root.innerHTML = pageHead('التحصيل والسداد', 'سندات القبض من العملاء والصرف للموردين', can('payments.manage') ? `<button class="btn" data-in>${icon('download', 'sm')} تحصيل من عميل</button><button class="btn gold" data-out>${icon('upload', 'sm')} سداد لمورد</button>` : '')
    + `<div class="card">${filterBar([{ name: 'q', label: 'بحث' }, { name: 'from', label: 'من', type: 'date' }, { name: 'to', label: 'إلى', type: 'date' },
      { name: 'direction', label: 'النوع', type: 'select', options: [{ value: '', label: 'الكل' }, { value: 'in', label: 'تحصيل' }, { value: 'out', label: 'سداد' }] },
      { name: 'party_type', label: 'الطرف', type: 'select', options: [{ value: '', label: 'الكل' }, { value: 'customer', label: 'عملاء' }, { value: 'supplier', label: 'موردون' }] }])}<div data-t></div></div>`;
  let f = {};
  const t = dataTable($('[data-t]', root), {
    title: 'سندات القبض والصرف', exportName: 'payments', empty: 'لا توجد سندات', emptyIcon: 'coins',
    fetch: (p) => api('payments.list', { ...f, ...p }),
    columns: [{ key: 'doc_no', label: 'الرقم', sort: true }, { key: 'date', label: 'التاريخ', type: 'date', sort: true },
      { key: 'direction', label: 'النوع', render: (r) => (r.direction === 'in' ? '<span class="badge ok">تحصيل</span>' : '<span class="badge warn">سداد</span>'), exportValue: (r) => (r.direction === 'in' ? 'تحصيل' : 'سداد') },
      { key: 'party_name', label: 'الطرف' }, { key: 'amount', label: 'المبلغ', type: 'money', sort: true },
      { key: 'method', label: 'الطريقة', render: (r) => esc(PAY_LABELS[r.method]), exportValue: (r) => PAY_LABELS[r.method] }, { key: 'reference', label: 'المرجع' },
      { key: 'status', label: 'الحالة', render: (r) => statusBadge(r.status), cls: 'keep' }],
    rowClass: (r) => (r.status === 'void' ? 'void' : ''),
    actions: (r) => `<button class="link-btn" data-act="print">${icon('printer', 'sm')}</button>${r.status === 'posted' && can('payments.manage') ? `<button class="link-btn danger" data-act="void">${icon('ban', 'sm')} إلغاء</button>` : ''}`,
    onAction: async (a, r) => {
      try {
        if (a === 'print') printPayment(await api('payments.get', { id: r.id }));
        if (a === 'void') { const c = await confirmBox(`إلغاء السند ${r.doc_no} بمبلغ ${money(r.amount)}؟ سيُعكس أثره على الصندوق ورصيد الطرف.`, { danger: true, ok: 'إلغاء السند', reason: true }); if (c) { await api('payments.void', { id: r.id, reason: c.reason }); invalidate('customers', 'suppliers'); toast('تم الإلغاء'); t.reload(false); } }
      } catch (e) { showError(e); }
    },
  });
  bindFilters($('.filters', root), (v) => { f = v; t.reload(); });
  const b = (s, d, pt) => { const x = $(s, root); if (x) x.onclick = async () => { if (await paymentForm({ direction: d, party_type: pt })) t.reload(); }; };
  b('[data-in]', 'in', 'customer'); b('[data-out]', 'out', 'supplier');
}

// ------------------------------------------------------------------ expenses
export async function expenses(root) {
  const cats = await lookup('expenseCategories', true);
  root.innerHTML = pageHead('المصروفات', 'مصروفات تشغيلية عامة (للتكاليف المباشرة على أمر تصنيع استخدم صفحة الأمر نفسه)', can('expenses.manage') ? `<button class="btn ghost" data-cats>${icon('tag', 'sm')} تصنيفات المصروفات</button><button class="btn" data-new>${icon('plus', 'sm')} مصروف جديد</button>` : '')
    + `<div class="card"><div class="sum-strip" data-sum></div>${filterBar([{ name: 'q', label: 'بحث' }, { name: 'from', label: 'من', type: 'date', value: monthStart() }, { name: 'to', label: 'إلى', type: 'date' },
      { name: 'category_id', label: 'التصنيف', type: 'select', options: opt(cats, 'name', 'id', 'الكل') }, { name: 'status', label: 'الحالة', type: 'select', options: [{ value: 'posted', label: 'معتمد' }, { value: 'void', label: 'ملغي' }, { value: '', label: 'الكل' }] }], { status: 'posted' })}<div data-t></div></div>`;
  let f = { from: monthStart(), status: 'posted' };
  const t = dataTable($('[data-t]', root), {
    title: 'المصروفات', exportName: 'expenses', emptyIcon: 'wallet', empty: 'لا توجد مصروفات في الفترة',
    fetch: async (p) => { const r = await api('expenses.list', { ...f, ...p }); $('[data-sum]', root).innerHTML = `<div><span>إجمالي المصروفات المعتمدة (حسب الفلتر)</span><b>${money(r.sum.total)}</b></div>`; return r; },
    columns: [{ key: 'doc_no', label: 'الرقم' }, { key: 'date', label: 'التاريخ', type: 'date', sort: true }, { key: 'category_name', label: 'التصنيف', sort: true }, { key: 'description', label: 'البيان' }, { key: 'payee', label: 'المستفيد' },
      { key: 'method', label: 'الدفع', render: (r) => esc(PAY_LABELS[r.method]), exportValue: (r) => PAY_LABELS[r.method] }, { key: 'amount', label: 'المبلغ', type: 'money', sort: true }, { key: 'user_name', label: 'المستخدم' }, { key: 'status', label: 'الحالة', render: (r) => statusBadge(r.status), cls: 'keep' }],
    rowClass: (r) => (r.status === 'void' ? 'void' : ''),
    actions: (r) => (r.status === 'posted' && can('expenses.manage') ? `<button class="link-btn danger" data-act="void">${icon('ban', 'sm')} إلغاء</button>` : ''),
    onAction: async (a, r) => { if (a === 'void') { const c = await confirmBox(`إلغاء المصروف ${r.doc_no} (${money(r.amount)})؟`, { danger: true, ok: 'إلغاء', reason: true }); if (c) { try { await api('expenses.void', { id: r.id, reason: c.reason }); toast('تم الإلغاء'); t.reload(false); } catch (e) { showError(e); } } } },
  });
  bindFilters($('.filters', root), (v) => { f = v; t.reload(); });
  const n = $('[data-new]', root);
  if (n) n.onclick = async () => {
    const active = (await lookup('expenseCategories')).filter((c) => c.active);
    if (await formModal({
      title: 'مصروف جديد', values: { date: today(), method: 'cash' },
      fields: [{ name: 'category_id', label: 'التصنيف', type: 'select', options: opt(active), required: true }, { name: 'amount', label: `المبلغ (${currencySymbol()})`, type: 'number', min: 0, required: true },
        { name: 'description', label: 'البيان', required: true, full: true }, { name: 'payee', label: 'المستفيد' }, { name: 'date', label: 'التاريخ', type: 'date' },
        { name: 'method', label: 'طريقة الدفع', type: 'select', options: [{ value: 'cash', label: 'الصندوق' }, { value: 'bank', label: 'البنك' }, { value: 'credit', label: 'آجل (مستحق الدفع)' }] }, { name: 'notes', label: 'ملاحظات' }],
      submit: async (v) => { const r = await api('expenses.create', v); toast(`تم تسجيل المصروف ${r.doc_no}`); if (r.warning) toast(r.warning, 'warn'); },
    })) t.reload();
  };
  const c = $('[data-cats]', root);
  if (c) c.onclick = async () => {
    const m = modal({ title: 'تصنيفات المصروفات', body: '<div data-l></div>', foot: `<button class="btn" data-add>${icon('plus', 'sm')} تصنيف جديد</button><button class="btn ghost" data-close>إغلاق</button>` });
    const draw = async () => {
      const rows = await lookup('expenseCategories', true);
      $('[data-l]', m.el).innerHTML = tableHtml([{ key: 'name', label: 'التصنيف' }, { key: 'account_code', label: 'الحساب' }, { key: 'total', label: 'إجمالي المصروف', type: 'money' }, { key: 'active', label: 'الحالة', render: (r) => (r.active ? '' : '<span class="badge bad">موقوف</span>') }], rows,
        { actions: (r) => `<button class="link-btn" data-e="${r.id}">${icon('edit', 'sm')}</button><button class="link-btn muted" data-tg="${r.id}">${r.active ? 'إيقاف' : 'تفعيل'}</button>` });
      return rows;
    };
    let rows = await draw();
    m.el.addEventListener('click', async (e) => {
      try {
        const edit = async (r) => { if (await formModal({ title: r ? 'تعديل تصنيف' : 'تصنيف مصروف جديد', size: 'narrow', cols: 'c1', values: r || {}, fields: [{ name: 'name', label: 'الاسم', required: true, hint: r ? '' : 'يُنشأ له حساب مصروف تلقائيًا في دليل الحسابات' }], submit: (v) => api('expenseCategories.save', { ...v, id: r && r.id }) })) { rows = await draw(); } };
        if (e.target.closest('[data-add]')) await edit();
        const x = e.target.closest('[data-e],[data-tg]'); if (!x) return;
        const r = rows.find((y) => y.id === Number(x.dataset.e || x.dataset.tg));
        if (x.dataset.e) await edit(r); else { await api('expenseCategories.toggle', { id: r.id }); rows = await draw(); }
      } catch (err) { showError(err); }
    });
    const onClose = () => { invalidate('expenseCategories'); expenses(root); };
    m.el.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', onClose));
  };
}

// ------------------------------------------------------------------ cash & bank
export async function cash(root, parts, params) {
  const s = await api('cash.summary');
  root.innerHTML = pageHead('الصندوق والبنك', 'الأرصدة والحركات النقدية', can('cash.manage') ? `<button class="btn" data-move>${icon('swap', 'sm')} حركة نقدية</button>` : '')
    + `<div class="grid g4" style="margin-bottom:14px">
      <div class="kpi ${s.cash < 0 ? 'bad' : 'good'}"><div class="l">${icon('cash', 'sm')} رصيد الصندوق</div><div class="v num">${fmt(s.cash)}<small>${esc(currencySymbol())}</small></div></div>
      <div class="kpi ${s.bank < 0 ? 'bad' : 'good'}"><div class="l">${icon('bank', 'sm')} رصيد البنك</div><div class="v num">${fmt(s.bank)}<small>${esc(currencySymbol())}</small></div></div>
      <div class="kpi"><div class="l">${icon('worker', 'sm')} أجور مستحقة غير مدفوعة</div><div class="v num">${fmt(s.wages_payable)}</div><div class="h">تُسدد من "حركة نقدية ← سداد أجور مستحقة"</div></div>
      <div class="kpi"><div class="l">${icon('wallet', 'sm')} مصروفات مستحقة غير مدفوعة</div><div class="v num">${fmt(s.accrued)}</div></div></div>
    <div class="tabs"></div><div data-body></div>`;
  const body = $('[data-body]', root);
  const show = (tab) => {
    body.innerHTML = '';
    if (tab === 'moves') {
      body.innerHTML = `<div class="card">${filterBar([{ name: 'from', label: 'من', type: 'date' }, { name: 'to', label: 'إلى', type: 'date' }])}<div data-t></div></div>`;
      let f = {};
      const t = dataTable($('[data-t]', body), {
        title: 'الحركات النقدية', exportName: 'cash_moves', fetch: (p) => api('cash.moves', { ...f, ...p }), empty: 'لا توجد حركات نقدية يدوية',
        columns: [{ key: 'doc_no', label: 'الرقم' }, { key: 'date', label: 'التاريخ', type: 'date' }, { key: 'kind_label', label: 'النوع' }, { key: 'method', label: 'الحساب', render: (r) => esc(PAY_LABELS[r.method]) }, { key: 'amount', label: 'المبلغ', type: 'money' }, { key: 'description', label: 'البيان' }, { key: 'status', label: 'الحالة', render: (r) => statusBadge(r.status), cls: 'keep' }],
        rowClass: (r) => (r.status === 'void' ? 'void' : ''),
        actions: (r) => (r.status === 'posted' && can('cash.manage') ? `<button class="link-btn danger" data-act="void">${icon('ban', 'sm')} إلغاء</button>` : ''),
        onAction: async (a, r) => { const c = await confirmBox(`إلغاء الحركة ${r.doc_no}؟`, { danger: true, ok: 'إلغاء', reason: true }); if (c) { try { await api('cash.voidMove', { id: r.id, reason: c.reason }); toast('تم الإلغاء'); cash(root); } catch (e) { showError(e); } } },
      });
      bindFilters($('.filters', body), (v) => { f = v; t.reload(); });
      return;
    }
    const account = tab === 'bank' ? '1200' : '1100';
    body.innerHTML = `<div class="card">${filterBar([{ name: 'from', label: 'من', type: 'date', value: monthStart() }, { name: 'to', label: 'إلى', type: 'date' }])}<div data-t></div></div>`;
    const load = async (f) => {
      const l = await api('cash.ledger', { account, ...f });
      dataTable($('[data-t]', body), {
        rows: [...(f.from ? [{ date: f.from, description: 'رصيد أول المدة', balance: l.opening }] : []), ...l.rows], title: `دفتر ${l.account.name}`, exportName: `ledger_${account}`, pageSize: 50,
        columns: [{ key: 'date', label: 'التاريخ', type: 'date' }, { key: 'doc_no', label: 'المستند' }, { key: 'description', label: 'البيان' }, { key: 'debit', label: 'مقبوضات', type: 'money' }, { key: 'credit', label: 'مدفوعات', type: 'money' }, { key: 'balance', label: 'الرصيد', type: 'money', cls: 'bold' }],
        footer: () => ({ debit: l.total_debit, credit: l.total_credit, balance: l.closing }),
      });
    };
    bindFilters($('.filters', body), (v) => load(v).catch(showError));
    load({ from: monthStart() }).catch(showError);
  };
  tabs($('.tabs', root), [{ id: 'cash', label: 'دفتر الصندوق', icon: 'cash' }, { id: 'bank', label: 'دفتر البنك', icon: 'bank' }, { id: 'moves', label: 'حركات نقدية يدوية', icon: 'swap' }], params.tab || 'cash', show);
  show(params.tab || 'cash');
  const mv = $('[data-move]', root);
  if (mv) mv.onclick = async () => {
    if (await formModal({
      title: 'حركة نقدية', values: { date: today(), method: 'cash', kind: 'deposit' },
      fields: [{ name: 'kind', label: 'نوع الحركة', type: 'select', options: s.kinds, full: true }, { name: 'amount', label: `المبلغ (${currencySymbol()})`, type: 'number', min: 0, required: true },
        { name: 'method', label: 'من/إلى', type: 'select', options: [{ value: 'cash', label: 'الصندوق' }, { value: 'bank', label: 'البنك' }], hint: 'لا يُستخدم في الإيداع/السحب بين الصندوق والبنك' },
        { name: 'date', label: 'التاريخ', type: 'date' }, { name: 'description', label: 'البيان' }],
      submit: async (v) => { const r = await api('cash.createMove', v); toast(`تم الحفظ ${r.doc_no}`); if (r.warning) toast(r.warning, 'warn'); },
    })) cash(root, parts, params);
  };
}
export { printDoc, docHeader, date };
