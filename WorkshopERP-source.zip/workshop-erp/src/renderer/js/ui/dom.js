// Small DOM + formatting toolkit shared by all pages.
export const state = { user: null, perms: new Set(), settings: null, lookups: {} };

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (v) => (v === null || v === undefined ? '' : String(v).replace(/[&<>"']/g, (c) => ESC[c]));

/** Tagged template that escapes interpolations unless wrapped with raw(). */
export class Raw { constructor(s) { this.s = s; } toString() { return this.s; } }
export const raw = (s) => new Raw(s);
export function html(strings, ...vals) {
  let out = '';
  strings.forEach((s, i) => {
    out += s;
    if (i < vals.length) {
      const v = vals[i];
      if (v instanceof Raw) out += v.s;
      else if (Array.isArray(v)) out += v.map((x) => (x instanceof Raw ? x.s : esc(x))).join('');
      else out += esc(v);
    }
  });
  return new Raw(out);
}

export function el(markup) {
  const t = document.createElement('template');
  t.innerHTML = String(markup).trim();
  return t.content.firstElementChild;
}

export function on(root, event, selector, handler) {
  root.addEventListener(event, (e) => {
    const t = e.target.closest(selector);
    if (t && root.contains(t)) handler(e, t);
  });
}

export const can = (p) => (Array.isArray(p) ? p.some((x) => state.perms.has(x)) : state.perms.has(p));

// ---------------- formatting ----------------
const cur = () => (state.settings && state.settings.currency) || { symbol: 'ج.م', decimals: 2 };
export function fmt(n, d) {
  const dec = d === undefined ? cur().decimals : d;
  const v = Number(n) || 0;
  return v.toLocaleString('en-US', { minimumFractionDigits: dec, maximumFractionDigits: dec });
}
export const money = (n, withSymbol = true) => (n === null || n === undefined || n === '' ? '—' : (withSymbol ? `${fmt(n)} ${cur().symbol}` : fmt(n)));
export const qty = (n) => {
  if (n === null || n === undefined || n === '') return '—';
  const v = Math.round(Number(n) * 10000) / 10000;
  return v.toLocaleString('en-US', { maximumFractionDigits: 4 });
};
export const pct = (n) => (n === null || n === undefined ? '—' : `${fmt(n, 1)}%`);
export const date = (d) => (d ? String(d).slice(0, 10) : '—');
export const dateTime = (d) => (d ? new Date(d).toLocaleString('en-GB', { hour12: false }).replace(',', '') : '—');
export const today = () => { const d = new Date(); const p = (x) => String(x).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; };
export const monthStart = () => today().slice(0, 8) + '01';
export const yearStart = () => today().slice(0, 5) + '01-01';
export const signCls = (n) => (Number(n) < -0.004 ? 'neg' : '');
export const currencySymbol = () => cur().symbol;

export function debounce(fn, ms = 250) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

export const STATUS_BADGE = {
  posted: '<span class="badge ok">معتمد</span>', void: '<span class="badge bad">ملغي</span>',
  draft: '<span class="badge warn">مسودة</span>', approved: '<span class="badge ok">معتمد</span>', cancelled: '<span class="badge bad">ملغي</span>',
};
export const KIND_LABELS = { raw: 'خامة', accessory: 'إكسسوار', part: 'قطعة', supply: 'مستلزم', finished: 'منتج نهائي', service: 'خدمة', other: 'أخرى' };
export const PAY_LABELS = { cash: 'الصندوق', bank: 'البنك', credit: 'آجل', accrued: 'مستحق', account: 'على الحساب' };
export const RATE_LABELS = { hour: 'بالساعة', day: 'باليوم', piece: 'بالقطعة', fixed: 'مبلغ ثابت', manual: 'مبلغ يدوي' };

export function navigate(hash) { if (location.hash === hash) window.dispatchEvent(new HashChangeEvent('hashchange')); else location.hash = hash; }
