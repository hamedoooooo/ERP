import { esc, state, money, qty, fmt, date, dateTime, KIND_LABELS, PAY_LABELS } from './dom.js';
import { sys } from '../api.js';

let busy = false;
export async function printDoc(inner) {
  if (busy) return;
  busy = true;
  let root = document.getElementById('print-root');
  if (!root) { root = document.createElement('div'); root.id = 'print-root'; document.body.appendChild(root); }
  root.innerHTML = `<div class="doc">${inner}</div>`;
  document.body.classList.add('printing');
  await new Promise((r) => setTimeout(r, 60));
  try { await sys.print(); } finally {
    setTimeout(() => { document.body.classList.remove('printing'); root.innerHTML = ''; busy = false; }, 300);
  }
}

export function docHeader(title, sub = '', right = '') {
  const c = (state.settings && state.settings.company) || {};
  return `<div class="doc-head"><div>
      ${c.logo ? `<img class="logo" src="${esc(c.logo)}" alt="">` : ''}
      <div class="co">${esc(c.companyName || c.appName || '')}<small>${esc([c.address, c.phone, c.taxNo ? 'الرقم الضريبي: ' + c.taxNo : ''].filter(Boolean).join(' — '))}</small></div>
    </div><div class="doc-title"><h2>${esc(title)}</h2>${sub ? `<div>${esc(sub)}</div>` : ''}${right}<div style="font-size:10.5px;color:#777">طُبع في ${esc(dateTime(new Date().toISOString()))}</div></div></div>`;
}
const foot = () => { const c = (state.settings && state.settings.company) || {}; return c.invoiceFooter ? `<div class="foot">${esc(c.invoiceFooter)}</div>` : ''; };
const voidStamp = (d) => (d.status === 'void' || d.status === 'cancelled' ? `<div class="void-stamp">ملغي</div>${d.void_reason ? `<div>سبب الإلغاء: ${esc(d.void_reason)}</div>` : ''}` : '');

export function printInvoice(d, kind) {
  const T = { sale: 'فاتورة بيع', purchase: 'فاتورة شراء', sale_return: 'مرتجع بيع', purchase_return: 'مرتجع شراء' }[kind];
  const party = d.customer_name || d.supplier_name || 'نقدي';
  const isReturn = kind.endsWith('return');
  const lines = d.lines.map((l, i) => `<tr><td>${i + 1}</td><td>${esc(l.product_code)}</td><td>${esc(l.product_name)}${l.mo_no ? ` <small>(${esc(l.mo_no)})</small>` : ''}</td><td>${esc(l.unit_name)}</td><td>${qty(l.qty)}</td><td>${fmt(l.unit_price)}</td><td>${fmt(l.line_total)}</td></tr>`).join('');
  printDoc(`${docHeader(T, `رقم ${d.doc_no}`)}${voidStamp(d)}
    <div class="meta"><div><b>التاريخ:</b> ${esc(date(d.date))}</div><div><b>${kind.startsWith('sale') ? 'العميل' : 'المورد'}:</b> ${esc(party)}</div>
      <div><b>المخزن:</b> ${esc(d.warehouse_name)}</div>${d.invoice_no ? `<div><b>الفاتورة الأصلية:</b> ${esc(d.invoice_no)}</div>` : ''}${d.supplier_ref ? `<div><b>رقم فاتورة المورد:</b> ${esc(d.supplier_ref)}</div>` : ''}
      ${d.customer_phone ? `<div><b>الهاتف:</b> ${esc(d.customer_phone)}</div>` : ''}</div>
    <table><thead><tr><th>#</th><th>الكود</th><th>الصنف</th><th>الوحدة</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>${lines}</tbody></table>
    <table style="width:auto;margin-inline-start:auto"><tbody>
      <tr><td>الإجمالي</td><td>${money(d.subtotal)}</td></tr>
      ${!isReturn && d.discount ? `<tr><td>الخصم</td><td>${money(d.discount)}</td></tr>` : ''}
      ${d.tax ? `<tr><td>الضريبة (${fmt(d.tax_rate, 2)}%)</td><td>${money(d.tax)}</td></tr>` : ''}
      <tr><td><b>الصافي</b></td><td><b>${money(d.total)}</b></td></tr>
      ${!isReturn ? `<tr><td>المدفوع</td><td>${money(d.paid)} (${esc(PAY_LABELS[d.pay_method])})</td></tr><tr><td>المتبقي</td><td>${money(d.total - d.paid)}</td></tr>` : `<tr><td>التسوية</td><td>${esc(PAY_LABELS[d.settle])}</td></tr>`}
    </tbody></table>
    ${d.notes ? `<div><b>ملاحظات:</b> ${esc(d.notes)}</div>` : ''}
    <div class="sign"><div>المستلم</div><div>المحاسب (${esc(d.user_name || '')})</div></div>${foot()}`);
}

export function printPayment(d) {
  const T = d.direction === 'in' ? 'إيصال تحصيل' : 'إيصال صرف';
  printDoc(`${docHeader(T, `رقم ${d.doc_no}`)}${voidStamp(d)}
    <table><tbody>
      <tr><th style="width:30%">التاريخ</th><td>${esc(date(d.date))}</td></tr>
      <tr><th>${d.direction === 'in' ? 'استلمنا من' : 'صرفنا إلى'}</th><td>${esc(d.party_name)} (${d.party_type === 'customer' ? 'عميل' : 'مورد'})</td></tr>
      <tr><th>المبلغ</th><td style="font-size:16px"><b>${money(d.amount)}</b></td></tr>
      <tr><th>طريقة الدفع</th><td>${esc(PAY_LABELS[d.method])}</td></tr>
      ${d.reference ? `<tr><th>المرجع</th><td>${esc(d.reference)}</td></tr>` : ''}
      ${d.notes ? `<tr><th>ملاحظات</th><td>${esc(d.notes)}</td></tr>` : ''}
      <tr><th>الرصيد بعد السند</th><td>${money(d.party_balance)}</td></tr>
    </tbody></table>
    <div class="sign"><div>المستلم</div><div>أمين الصندوق (${esc(d.user_name || '')})</div></div>${foot()}`);
}

export function printMO(mo) {
  const canCost = mo.total_cost !== undefined || mo.profit;
  const mats = mo.materials.map((m) => `<tr><td>${esc(m.product_name)}</td><td>${esc(KIND_LABELS[m.kind])}</td><td>${esc(m.unit_name)}</td><td>${qty(m.planned_qty)}</td><td>${qty(m.actual_qty)}</td><td>${qty(m.diff_qty)}</td>${canCost ? `<td>${fmt(m.actual_cost)}</td>` : ''}</tr>`).join('');
  const labor = mo.labor.filter((l) => l.status === 'posted').map((l) => `<tr><td>${esc(l.worker_name)}</td><td>${esc(l.rate_type_label)}</td><td>${qty(l.qty)}</td><td>${fmt(l.rate)}</td><td>${fmt(l.total)}</td></tr>`).join('');
  const p = mo.profit;
  printDoc(`${docHeader('أمر تصنيع', `رقم ${mo.doc_no}`)}${mo.stage === 'cancelled' ? '<div class="void-stamp">ملغي</div>' : ''}
    <div class="meta"><div><b>التاريخ:</b> ${esc(date(mo.date))}</div><div><b>الحالة:</b> ${esc(mo.status_name)}</div>
      <div><b>المنتج:</b> ${esc(mo.product_name)}</div><div><b>الكمية:</b> ${qty(mo.qty)} ${esc(mo.unit_name)}${mo.produced_qty ? ` (المنتج فعلًا ${qty(mo.produced_qty)})` : ''}</div>
      <div><b>العميل:</b> ${esc(mo.customer_name || '—')}</div><div><b>تاريخ البدء / التسليم:</b> ${esc(date(mo.start_date))} / ${esc(date(mo.due_date))}</div></div>
    ${mo.specs ? `<div><b>المواصفات:</b><div style="white-space:pre-wrap">${esc(mo.specs)}</div></div>` : ''}
    ${mo.dimensions ? `<div><b>المقاسات:</b><div style="white-space:pre-wrap">${esc(mo.dimensions)}</div></div>` : ''}
    <h3>المواد</h3><table><thead><tr><th>المادة</th><th>النوع</th><th>الوحدة</th><th>المخطط</th><th>الفعلي</th><th>الفرق</th>${canCost ? '<th>التكلفة</th>' : ''}</tr></thead><tbody>${mats || '<tr><td colspan="7">—</td></tr>'}</tbody></table>
    ${labor ? `<h3>العمالة</h3><table><thead><tr><th>العامل</th><th>نوع الأجر</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>${labor}</tbody></table>` : ''}
    ${p ? `<h3>التكلفة والربحية</h3><table><tbody>
      <tr><td>الخامات</td><td>${money(p.material)}</td><td>الإكسسوارات</td><td>${money(p.accessories)}</td></tr>
      <tr><td>العمالة</td><td>${money(p.labor)}</td><td>تكاليف مباشرة أخرى</td><td>${money(p.other)}</td></tr>
      <tr><td>مصروفات صناعية</td><td>${money(p.overhead)}</td><td><b>إجمالي التكلفة</b></td><td><b>${money(p.total_cost)}</b></td></tr>
      <tr><td>الإيراد</td><td>${money(p.revenue)}</td><td><b>مجمل الربح</b></td><td><b>${money(p.gross_profit)}</b> (${fmt(p.margin_pct ?? 0, 1)}%)</td></tr></tbody></table>` : ''}
    ${mo.notes ? `<div><b>ملاحظات:</b> <span style="white-space:pre-wrap">${esc(mo.notes)}</span></div>` : ''}
    <div class="sign"><div>مسؤول الإنتاج</div><div>المدير</div></div>`);
}

export function printStatement(s) {
  const rows = s.rows.map((r) => `<tr><td>${esc(date(r.date))}</td><td>${esc(r.doc_no || '')}</td><td>${esc(r.description || '')}</td><td>${r.debit ? fmt(r.debit) : ''}</td><td>${r.credit ? fmt(r.credit) : ''}</td><td>${fmt(r.balance)}</td></tr>`).join('');
  printDoc(`${docHeader('كشف حساب ' + (s.party.type === 'customer' ? 'عميل' : 'مورد'), s.party.name, `<div>الفترة: ${esc(s.from || 'البداية')} — ${esc(s.to || 'اليوم')}</div>`)}
    <table><thead><tr><th>التاريخ</th><th>المستند</th><th>البيان</th><th>مدين</th><th>دائن</th><th>الرصيد</th></tr></thead>
    <tbody><tr><td colspan="5">رصيد أول المدة</td><td>${fmt(s.opening)}</td></tr>${rows}</tbody>
    <tfoot><tr><td colspan="3"><b>الإجمالي</b></td><td><b>${fmt(s.total_debit)}</b></td><td><b>${fmt(s.total_credit)}</b></td><td><b>${fmt(s.closing)}</b></td></tr></tfoot></table>
    <p>الرصيد الختامي: <b>${money(s.closing)}</b> ${s.party.type === 'customer' ? (s.closing >= 0 ? '(مستحق على العميل)' : '(مستحق للعميل)') : (s.closing >= 0 ? '(مستحق للمورد)' : '(مستحق على المورد)')}</p>${foot()}`);
}

export function printCount(c) {
  const rows = c.items.map((i) => `<tr><td>${esc(i.product_code)}</td><td>${esc(i.product_name)}</td><td>${esc(i.unit_name)}</td><td>${qty(i.system_qty)}</td><td>${i.actual_qty === null ? '' : qty(i.actual_qty)}</td><td>${i.diff === null ? '' : qty(i.diff)}</td><td>${i.diff_value === null ? '' : fmt(i.diff_value)}</td><td>${esc(i.reason || '')}</td></tr>`).join('');
  printDoc(`${docHeader('ورقة جرد مخزون', `رقم ${c.doc_no}`)}
    <div class="meta"><div><b>المخزن:</b> ${esc(c.warehouse_name)}</div><div><b>التاريخ:</b> ${esc(date(c.date))}</div><div><b>الحالة:</b> ${c.status === 'approved' ? 'معتمد' : c.status === 'draft' ? 'مسودة' : 'ملغي'}</div><div><b>أعده:</b> ${esc(c.user_name || '')}</div></div>
    <table><thead><tr><th>الكود</th><th>الصنف</th><th>الوحدة</th><th>كمية النظام</th><th>الكمية الفعلية</th><th>الفرق</th><th>قيمة الفرق</th><th>السبب</th></tr></thead><tbody>${rows}</tbody>
    <tfoot><tr><td colspan="6"><b>إجمالي قيمة الفروقات</b></td><td><b>${fmt(c.total_diff_value)}</b></td><td></td></tr></tfoot></table>
    <div class="sign"><div>القائم بالجرد</div><div>المعتمِد</div></div>`);
}
