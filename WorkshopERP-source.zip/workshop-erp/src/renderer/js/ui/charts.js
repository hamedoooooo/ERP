import { esc, fmt } from './dom.js';

const niceMax = (v) => { if (v <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(v))); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p; };
const short = (v) => { const a = Math.abs(v); if (a >= 1e6) return fmt(v / 1e6, 1) + 'م'; if (a >= 1e3) return fmt(v / 1e3, 1) + 'ك'; return fmt(v, 0); };

/** Grouped bars + optional line series. series: [{name,color,values,type:'bar'|'line'}] */
export function barChart(labels, series, { height = 240 } = {}) {
  const W = 760; const H = height; const pl = 8; const pr = 46; const pt = 12; const pb = 26;
  const vals = series.flatMap((s) => s.values.map(Number));
  const maxV = niceMax(Math.max(0, ...vals)); const minV = Math.min(0, ...vals) < 0 ? -niceMax(-Math.min(...vals)) : 0;
  const y = (v) => pt + (H - pt - pb) * (1 - (v - minV) / (maxV - minV || 1));
  const cw = (W - pl - pr) / labels.length;
  const bars = series.filter((s) => s.type !== 'line');
  const bw = Math.min(22, (cw * 0.72) / Math.max(1, bars.length));
  let g = '';
  for (let i = 0; i <= 4; i++) { const v = minV + (maxV - minV) * i / 4; g += `<line class="grid-line" x1="${pl}" x2="${W - pr}" y1="${y(v)}" y2="${y(v)}"/><text x="${W - pr + 6}" y="${y(v) + 4}">${short(v)}</text>`; }
  // RTL: first label on the right
  const x0 = (i) => W - pr - cw * (i + 1);
  labels.forEach((l, i) => { g += `<text x="${x0(i) + cw / 2}" y="${H - 8}" text-anchor="middle">${esc(l)}</text>`; });
  bars.forEach((s, si) => s.values.forEach((v, i) => {
    const x = x0(i) + (cw - bw * bars.length) / 2 + si * bw; const top = y(Math.max(0, v)); const h = Math.abs(y(v) - y(0));
    g += `<rect x="${x}" y="${top}" width="${bw - 2}" height="${Math.max(0.5, h)}" rx="2" fill="${s.color}"><title>${esc(s.name)} — ${esc(labels[i])}: ${fmt(v)}</title></rect>`;
  }));
  series.filter((s) => s.type === 'line').forEach((s) => {
    const pts = s.values.map((v, i) => `${x0(i) + cw / 2},${y(v)}`).join(' ');
    g += `<polyline points="${pts}" fill="none" stroke="${s.color}" stroke-width="2.2"/>` + s.values.map((v, i) => `<circle cx="${x0(i) + cw / 2}" cy="${y(v)}" r="3" fill="${s.color}"><title>${esc(s.name)}: ${fmt(v)}</title></circle>`).join('');
  });
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img">${g}</svg><div class="chart-legend">${series.map((s) => `<span style="--c:${s.color}">${esc(s.name)}</span>`).join('')}</div>`;
}

export function donut(items, { size = 170, center = '' } = {}) {
  const total = items.reduce((s, i) => s + Math.max(0, Number(i.value) || 0), 0);
  if (!total) return '<div class="empty small">لا توجد بيانات للفترة</div>';
  const r = 60; const c = 2 * Math.PI * r; let off = 0;
  const arcs = items.map((i) => { const len = (Math.max(0, i.value) / total) * c; const s = `<circle r="${r}" cx="85" cy="85" fill="none" stroke="${i.color}" stroke-width="26" stroke-dasharray="${len} ${c - len}" stroke-dashoffset="${-off}" transform="rotate(-90 85 85)"><title>${esc(i.label)}: ${fmt(i.value)}</title></circle>`; off += len; return s; }).join('');
  return `<div class="row" style="align-items:center;gap:18px;flex-wrap:nowrap"><svg viewBox="0 0 170 170" width="${size}" height="${size}" style="flex-shrink:0">${arcs}<text x="85" y="90" text-anchor="middle" style="font:700 14px Cairo;fill:#16233B">${esc(center)}</text></svg>
    <div style="flex:1;min-width:0">${items.map((i) => `<div class="row between small" style="margin-bottom:5px;flex-wrap:nowrap"><span style="--c:${i.color}" class="legend"><span style="--c:${i.color}">${esc(i.label)}</span></span><b class="num">${fmt(i.value)}</b></div>`).join('')}</div></div>`;
}

export function hbars(items, color = '#1F4B3F') {
  const max = Math.max(1, ...items.map((i) => Number(i.value) || 0));
  return items.map((i) => `<div class="hbar"><span>${esc(i.label)}</span><div class="track"><i style="width:${(Math.max(0, i.value) / max) * 100}%;background:${i.color || color}"></i></div><b class="num">${fmt(i.value, i.decimals ?? 0)}</b></div>`).join('');
}

export const PALETTE = ['#1F4B3F', '#A8823C', '#3d5a80', '#8B3A3A', '#6b8f71', '#c9a45f', '#5b6f95', '#b26a4f', '#7a7a52', '#4b3f72'];
