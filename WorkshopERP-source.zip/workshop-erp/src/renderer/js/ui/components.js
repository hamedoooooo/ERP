import { el, esc, html, raw, money, qty, pct, date, fmt, debounce, state, $, $$ } from './dom.js';
import { icon } from './icons.js';
import { sys } from '../api.js';
import { printDoc, docHeader } from './print.js';

// ================= toast =================
export function toast(msg, kind = 'ok', ms = 3800) {
  let box = $('.toasts');
  if (!box) { box = el('<div class="toasts" role="status" aria-live="polite"></div>'); document.body.appendChild(box); }
  const ic = kind === 'bad' ? 'alert' : kind === 'warn' ? 'info' : 'check';
  const t = el(`<div class="toast ${kind}">${icon(ic, 'sm')}<span>${esc(msg)}</span></div>`);
  box.appendChild(t);
  setTimeout(() => t.remove(), kind === 'bad' ? ms * 1.8 : ms);
}
export function showError(e) { toast(e && e.message ? e.message : String(e), 'bad'); if (e && e.technical) console.error(e.technical); }

// ================= modal =================
export function modal({ title, body, size = '', foot = '', onOpen, closable = true }) {
  const ov = el(`<div class="overlay"><div class="modal ${size}" role="dialog" aria-modal="true">
    <div class="modal-head"><h2>${esc(title)}</h2>${closable ? `<button class="btn icon ghost" data-close aria-label="إغلاق">${icon('x')}</button>` : ''}</div>
    <div class="modal-body"></div>${foot ? `<div class="modal-foot">${foot}</div>` : ''}</div></div>`);
  const b = $('.modal-body', ov);
  if (typeof body === 'string' || body instanceof Object && !(body instanceof Node)) b.innerHTML = String(body); else b.appendChild(body);
  const close = () => { ov.remove(); document.removeEventListener('keydown', key); };
  const key = (e) => { if (e.key === 'Escape' && closable) close(); };
  document.addEventListener('keydown', key);
  ov.addEventListener('mousedown', (e) => { if (e.target === ov && closable) close(); });
  $$('[data-close]', ov).forEach((x) => x.addEventListener('click', close));
  document.body.appendChild(ov);
  const first = ov.querySelector('.modal-body input:not([type=hidden]):not([readonly]), .modal-body select, .modal-body textarea');
  if (first) setTimeout(() => first.focus(), 30);
  if (onOpen) onOpen(ov, close);
  return { el: ov, body: b, close };
}

/** Confirmation dialog. opts.reason → asks for a reason; opts.typed → requires typing a word. Resolves to false or {reason}. */
export function confirmBox(message, { title = 'تأكيد', ok = 'تأكيد', danger = false, reason = false, reasonLabel = 'السبب', typed = null, details = '' } = {}) {
  return new Promise((resolve) => {
    const m = modal({
      title, size: 'narrow',
      body: `<p style="margin:0 0 12px;line-height:1.7">${esc(message)}</p>${details}
        ${reason ? `<div class="field"><label>${esc(reasonLabel)} <span class="req">*</span></label><textarea class="inp" data-reason rows="2"></textarea></div>` : ''}
        ${typed ? `<div class="field" style="margin-top:10px"><label>للتأكيد اكتب: <b>${esc(typed)}</b></label><input class="inp" data-typed autocomplete="off"></div>` : ''}
        <div class="alert bad hide" data-err style="margin-top:10px"></div>`,
      foot: `<button class="btn ${danger ? 'danger' : ''}" data-ok>${esc(ok)}</button><button class="btn ghost" data-cancel>رجوع</button>`,
    });
    let done = false;
    const finish = (v) => { if (!done) { done = true; m.close(); resolve(v); } };
    $('[data-cancel]', m.el).onclick = () => finish(false);
    $('[data-close]', m.el).onclick = () => finish(false);
    $('[data-ok]', m.el).onclick = () => {
      const err = $('[data-err]', m.el);
      const r = reason ? $('[data-reason]', m.el).value.trim() : '';
      if (reason && !r) { err.textContent = `من فضلك اكتب ${reasonLabel}`; err.classList.remove('hide'); return; }
      if (typed && $('[data-typed]', m.el).value.trim() !== typed) { err.textContent = `اكتب "${typed}" كما هي للتأكيد`; err.classList.remove('hide'); return; }
      finish({ reason: r });
    };
  });
}

// ================= forms =================
/**
 * field spec: {name, label, type:'text'|'number'|'date'|'select'|'textarea'|'checkbox'|'combo'|'color'|'password',
 *   options:[{value,label}], required, full, hint, min, step, placeholder, value, readonly, attrs}
 */
export function formHtml(fields, values = {}, cols = '') {
  return `<div class="form ${cols}">${fields.map((f) => fieldHtml(f, values[f.name] !== undefined ? values[f.name] : f.value)).join('')}</div>`;
}

export function fieldHtml(f, v) {
  if (f.type === 'section') return `<div class="field full"><div class="card-title" style="margin:8px 0 0">${esc(f.label)}</div></div>`;
  if (f.type === 'html') return `<div class="field ${f.full ? 'full' : ''}">${f.html}</div>`;
  const val = v === null || v === undefined ? '' : v;
  const req = f.required ? ' <span class="req">*</span>' : '';
  const common = `name="${f.name}" id="f_${f.name}" ${f.readonly ? 'readonly' : ''} ${f.required ? 'required' : ''} ${f.attrs || ''}`;
  let input;
  switch (f.type) {
    case 'select':
      input = `<select class="inp" ${common}>${(f.options || []).map((o) => `<option value="${esc(o.value)}" ${String(o.value) === String(val) ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}</select>`; break;
    case 'textarea': input = `<textarea class="inp" rows="${f.rows || 2}" ${common} placeholder="${esc(f.placeholder || '')}">${esc(val)}</textarea>`; break;
    case 'checkbox': return `<div class="field ${f.full ? 'full' : ''}"><label class="check"><input type="checkbox" ${common} ${val ? 'checked' : ''}> ${esc(f.label)}</label>${f.hint ? `<span class="hint">${esc(f.hint)}</span>` : ''}</div>`;
    case 'number': input = `<input class="inp num" type="number" step="${f.step || 'any'}" ${f.min !== undefined ? `min="${f.min}"` : ''} value="${esc(val)}" ${common} placeholder="${esc(f.placeholder || '')}">`; break;
    case 'combo': input = `<div class="combo" data-combo="${f.name}"><input class="inp" autocomplete="off" placeholder="${esc(f.placeholder || 'ابحث واختر…')}" ${f.readonly ? 'readonly' : ''}><input type="hidden" ${common} value="${esc(val)}"></div>`; break;
    default: input = `<input class="inp" type="${f.type || 'text'}" value="${esc(val)}" ${common} placeholder="${esc(f.placeholder || '')}" ${f.type === 'password' ? 'autocomplete="new-password"' : ''}>`;
  }
  return `<div class="field ${f.full ? 'full' : ''}"><label for="f_${f.name}">${esc(f.label)}${req}</label>${input}${f.hint ? `<span class="hint">${esc(f.hint)}</span>` : ''}</div>`;
}

export function readForm(root) {
  const out = {};
  $$('[name]', root).forEach((i) => {
    if (i.type === 'checkbox') out[i.name] = i.checked;
    else out[i.name] = i.value;
  });
  return out;
}

/** Modal form. submit(values) may throw; errors are shown inline and the modal stays open. */
export function formModal({ title, fields, values = {}, submit, okLabel = 'حفظ', size = '', cols = '', extra = '', combos = {}, onOpen }) {
  return new Promise((resolve) => {
    const m = modal({
      title, size,
      body: `${formHtml(fields, values, cols)}${extra}<div class="alert bad hide" data-err style="margin:12px 0 0"></div>`,
      foot: `<button class="btn" data-ok>${icon('save', 'sm')} ${esc(okLabel)}</button><button class="btn ghost" data-close>إلغاء</button>`,
    });
    Object.entries(combos).forEach(([name, cfg]) => { const c = m.el.querySelector(`[data-combo="${name}"]`); if (c) combo(c, { ...cfg, value: values[name] }); });
    if (onOpen) onOpen(m.el);
    const btn = $('[data-ok]', m.el);
    const go = async () => {
      const err = $('[data-err]', m.el); err.classList.add('hide');
      btn.disabled = true;
      try {
        const r = await submit(readForm(m.body), m.el);
        m.close(); resolve(r === undefined ? true : r);
      } catch (e) { err.textContent = e.message || String(e); err.classList.remove('hide'); } finally { btn.disabled = false; }
    };
    btn.onclick = go;
    m.el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.tagName === 'INPUT' && !e.target.closest('.combo')) { e.preventDefault(); go(); } });
    $$('[data-close]', m.el).forEach((x) => x.addEventListener('click', () => resolve(false)));
  });
}

// ================= combobox (searchable select) =================
/**
 * combo(container, {options:[{value,label,sub,search}], value, onChange(opt), placeholder, allowEmpty})
 * container has an <input> (visible) and <input type=hidden> (value).
 */
export function combo(container, cfg) {
  const vis = container.querySelector('input:not([type=hidden])');
  const hid = container.querySelector('input[type=hidden]');
  let options = cfg.options || [];
  let list = null; let sel = -1; let shown = [];
  const byVal = (v) => options.find((o) => String(o.value) === String(v));
  const setValue = (v, fire = true) => {
    const o = byVal(v);
    hid.value = o ? o.value : '';
    vis.value = o ? o.label : '';
    if (fire && cfg.onChange) cfg.onChange(o || null);
  };
  const close = () => { if (list) { list.remove(); list = null; } };
  const render = () => {
    const q = vis.value.trim().toLowerCase();
    shown = (q ? options.filter((o) => (o.search || `${o.label} ${o.sub || ''}`).toLowerCase().includes(q)) : options).slice(0, 80);
    if (!list) { list = el('<div class="combo-list"></div>'); container.appendChild(list); }
    sel = shown.length ? 0 : -1;
    list.innerHTML = shown.length ? shown.map((o, i) => `<div class="combo-opt ${i === sel ? 'sel' : ''}" data-i="${i}"><span>${esc(o.label)}</span>${o.sub ? `<small>${esc(o.sub)}</small>` : ''}</div>`).join('')
      : `<div class="combo-empty">لا توجد نتائج${cfg.emptyHint ? ' — ' + esc(cfg.emptyHint) : ''}</div>`;
  };
  vis.addEventListener('focus', () => { if (!vis.readOnly) { vis.select(); render(); } });
  vis.addEventListener('input', render);
  vis.addEventListener('keydown', (e) => {
    if (!list) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(shown.length - 1, sel + 1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); }
    else if (e.key === 'Enter') { e.preventDefault(); if (shown[sel]) { setValue(shown[sel].value); close(); } return; }
    else if (e.key === 'Escape') { close(); setValue(hid.value, false); return; } else return;
    $$('.combo-opt', list).forEach((x, i) => x.classList.toggle('sel', i === sel));
    const s = list.querySelector('.sel'); if (s) s.scrollIntoView({ block: 'nearest' });
  });
  container.addEventListener('mousedown', (e) => {
    const o = e.target.closest('.combo-opt');
    if (o) { e.preventDefault(); setValue(shown[Number(o.dataset.i)].value); close(); }
  });
  vis.addEventListener('blur', () => setTimeout(() => {
    close();
    if (!vis.value.trim() && cfg.allowEmpty !== false) setValue('', hid.value !== '');
    else setValue(hid.value, false);
  }, 120));
  if (cfg.value !== undefined && cfg.value !== null) setValue(cfg.value, false);
  return { set: setValue, get: () => hid.value, setOptions: (o) => { options = o; }, input: vis };
}

// ================= data table =================
function cell(c, r) {
  if (c.render) return c.render(r);
  const v = r[c.key];
  switch (c.type) {
    case 'money': return v === null || v === undefined || v === '' ? '' : `<span class="${Number(v) < -0.004 ? 'neg' : ''}">${fmt(v)}</span>`;
    case 'qty': return v === null || v === undefined || v === '' ? '' : qty(v);
    case 'pct': return pct(v);
    case 'date': return v ? date(v) : '';
    case 'badge': return v ? `<span class="badge ${/ملغي|منخفض|متأخر/.test(v) ? 'bad' : ''}">${esc(v)}</span>` : '';
    default: return esc(v);
  }
}
const isNum = (c) => ['money', 'qty', 'pct'].includes(c.type);
function plain(c, r) {
  if (c.exportValue) return c.exportValue(r);
  const v = r[c.key];
  if (v === null || v === undefined) return '';
  if (c.type === 'money') return (Math.round(Number(v) * 100) / 100).toFixed(2);
  return String(v);
}

export function csvOf(columns, rows, totals) {
  const cols = columns.filter((c) => c.key && !c.noExport);
  const q = (s) => `"${String(s).replace(/"/g, '""')}"`;
  const lines = [cols.map((c) => q(c.label)).join(',')];
  rows.forEach((r) => lines.push(cols.map((c) => q(plain(c, r))).join(',')));
  if (totals) lines.push(cols.map((c, i) => q(i === 0 ? 'الإجمالي' : (totals[c.key] !== undefined && totals[c.key] !== null ? plain(c, totals) : ''))).join(','));
  return '\ufeff' + lines.join('\r\n');
}

export function tableHtml(columns, rows, { totals = null, rowClass = null, actions = null, click = false } = {}) {
  const head = columns.map((c) => `<th class="${isNum(c) ? 'n' : ''}">${esc(c.label)}</th>`).join('') + (actions ? '<th></th>' : '');
  const body = rows.map((r, i) => `<tr data-i="${i}" class="${click ? 'click' : ''} ${rowClass ? rowClass(r) : ''}">${columns.map((c) => `<td class="${isNum(c) ? 'n' : ''} ${c.cls || ''}">${cell(c, r)}</td>`).join('')}${actions ? `<td class="actions">${actions(r)}</td>` : ''}</tr>`).join('');
  const foot = totals ? `<tfoot><tr>${columns.map((c, i) => `<td class="${isNum(c) ? 'n' : ''}">${i === 0 ? 'الإجمالي' : (totals[c.key] !== undefined && totals[c.key] !== null ? cell(c, totals) : '')}</td>`).join('')}${actions ? '<td></td>' : ''}</tr></tfoot>` : '';
  return `<div class="tbl-wrap"><table class="tbl"><thead><tr>${head}</tr></thead><tbody>${body}</tbody>${foot}</table></div>`;
}

/**
 * dataTable(container, {columns, fetch(params)→{rows,total,sum}, rows (client mode), pageSize, onRow, rowClass,
 *   actions(row)→html, onAction(name,row,btn), footer(result)→totals obj, exportName, title, empty})
 */
export function dataTable(container, opts) {
  const st = { page: 1, pageSize: opts.pageSize || (state.settings && state.settings.ui.pageSize) || 25, sort: opts.sort || null, dir: opts.dir || 'desc', q: '', result: null, clientRows: opts.rows || null };
  container.innerHTML = `<div data-body></div><div class="pager"><div data-info></div><div class="pg">
      ${opts.exportName !== false ? `<button class="btn ghost sm" data-export>${icon('filecsv', 'sm')} تصدير Excel/CSV</button><button class="btn ghost sm" data-print>${icon('printer', 'sm')} طباعة</button>` : ''}
      <select class="inp" data-size style="min-height:30px;width:auto;padding:2px 6px">${[10, 25, 50, 100].map((n) => `<option ${n === st.pageSize ? 'selected' : ''}>${n}</option>`).join('')}</select>
      <button class="btn ghost sm icon" data-prev aria-label="السابق">${icon('chevronR', 'sm')}</button><span data-pg></span><button class="btn ghost sm icon" data-next aria-label="التالي">${icon('chevronL', 'sm')}</button></div></div>`;
  const body = $('[data-body]', container);

  async function load() {
    body.innerHTML = '<div class="empty muted">جارِ التحميل…</div>';
    try {
      if (st.clientRows) {
        let rows = st.clientRows;
        if (st.q) { const q = st.q.toLowerCase(); rows = rows.filter((r) => opts.columns.some((c) => String(r[c.key] ?? '').toLowerCase().includes(q))); }
        if (st.sort) {
          const c = opts.columns.find((x) => x.key === st.sort);
          rows = [...rows].sort((a, b) => { const x = a[st.sort]; const y = b[st.sort]; const r = c && isNum(c) ? (Number(x) || 0) - (Number(y) || 0) : String(x ?? '').localeCompare(String(y ?? ''), 'ar'); return st.dir === 'asc' ? r : -r; });
        }
        st.result = { rows: rows.slice((st.page - 1) * st.pageSize, st.page * st.pageSize), total: rows.length, all: rows };
      } else {
        st.result = await opts.fetch({ page: st.page, pageSize: st.pageSize, sort: st.sort, dir: st.dir });
      }
      render();
    } catch (e) { body.innerHTML = `<div class="alert bad">${icon('alert', 'sm')} ${esc(e.message)}</div>`; }
  }

  function render() {
    const { rows, total } = st.result;
    const pages = Math.max(1, Math.ceil(total / st.pageSize));
    $('[data-info]', container).textContent = total ? `${fmt((st.page - 1) * st.pageSize + 1, 0)}–${fmt(Math.min(total, st.page * st.pageSize), 0)} من ${fmt(total, 0)}` : '';
    $('[data-pg]', container).textContent = `${st.page} / ${pages}`;
    $('[data-prev]', container).disabled = st.page <= 1; $('[data-next]', container).disabled = st.page >= pages;
    if (!rows.length) {
      body.innerHTML = `<div class="empty">${icon(opts.emptyIcon || 'file')}<b>${esc(opts.empty || 'لا توجد بيانات')}</b>${opts.emptyHint ? `<div class="small">${esc(opts.emptyHint)}</div>` : ''}</div>`;
      return;
    }
    const totals = opts.footer ? opts.footer(st.result) : null;
    const head = opts.columns.map((c) => {
      const sortable = c.sort !== false && (st.clientRows || c.sort);
      const arrow = st.sort === (c.sortKey || c.key) ? (st.dir === 'asc' ? '▲' : '▼') : '';
      return `<th class="${isNum(c) ? 'n' : ''} ${sortable ? 'sortable' : ''}" data-sort="${sortable ? esc(c.sortKey || c.key) : ''}">${esc(c.label)}<span class="sort">${arrow}</span></th>`;
    }).join('') + (opts.actions ? '<th></th>' : '');
    const trs = rows.map((r, i) => `<tr data-i="${i}" class="${opts.onRow ? 'click' : ''} ${opts.rowClass ? opts.rowClass(r) : ''}">${opts.columns.map((c) => `<td class="${isNum(c) ? 'n' : ''} ${c.cls || ''}">${cell(c, r)}</td>`).join('')}${opts.actions ? `<td class="actions">${opts.actions(r)}</td>` : ''}</tr>`).join('');
    const foot = totals ? `<tfoot><tr>${opts.columns.map((c, i) => `<td class="${isNum(c) ? 'n' : ''}">${i === 0 ? 'الإجمالي' : (totals[c.key] !== undefined ? cell(c, totals) : '')}</td>`).join('')}${opts.actions ? '<td></td>' : ''}</tr></tfoot>` : '';
    body.innerHTML = `<div class="tbl-wrap"><table class="tbl"><thead><tr>${head}</tr></thead><tbody>${trs}</tbody>${foot}</table></div>`;
  }

  container.addEventListener('click', async (e) => {
    const th = e.target.closest('th[data-sort]');
    if (th && th.dataset.sort) { const k = th.dataset.sort; if (st.sort === k) st.dir = st.dir === 'asc' ? 'desc' : 'asc'; else { st.sort = k; st.dir = 'asc'; } st.page = 1; load(); return; }
    const act = e.target.closest('[data-act]');
    const tr = e.target.closest('tbody tr');
    if (act && tr) { e.stopPropagation(); opts.onAction && opts.onAction(act.dataset.act, st.result.rows[Number(tr.dataset.i)], act); return; }
    if (tr && opts.onRow && !e.target.closest('a,button,input,select')) opts.onRow(st.result.rows[Number(tr.dataset.i)]);
    if (e.target.closest('[data-prev]')) { st.page--; load(); }
    if (e.target.closest('[data-next]')) { st.page++; load(); }
    if (e.target.closest('[data-export]')) exportAll('csv');
    if (e.target.closest('[data-print]')) exportAll('print');
  });
  $('[data-size]', container).addEventListener('change', (e) => { st.pageSize = Number(e.target.value); st.page = 1; load(); });

  async function allRows() {
    if (st.clientRows) return { rows: st.result.all || st.clientRows };
    return opts.fetch({ page: 1, pageSize: 1000, sort: st.sort, dir: st.dir, all: true });
  }
  async function exportAll(kind) {
    try {
      const r = await allRows();
      const cols = opts.columns.filter((c) => !c.noExport);
      const totals = opts.footer ? opts.footer(r) : null;
      if (kind === 'csv') {
        const res = await sys.saveText(`${opts.exportName || 'export'}_${new Date().toISOString().slice(0, 10)}.csv`, csvOf(cols, r.rows, totals), [{ name: 'CSV', extensions: ['csv'] }]);
        if (res && res.path) toast('تم تصدير الملف');
      } else {
        printDoc(`${docHeader(opts.title || opts.exportName || '', opts.printSub ? opts.printSub() : '')}${tableHtml(cols, r.rows, { totals })}`);
      }
    } catch (e) { showError(e); }
  }

  load();
  return {
    reload(reset = true) { if (reset) st.page = 1; return load(); },
    setRows(rows) { st.clientRows = rows; st.page = 1; return load(); },
    setSearch(q) { st.q = q; st.page = 1; return load(); },
    get result() { return st.result; },
  };
}

// ================= misc =================
export function pageHead(title, sub = '', actions = '', crumbs = '') {
  return `<div class="page-head"><div>${crumbs ? `<div class="crumbs">${crumbs}</div>` : ''}<h1>${esc(title)}</h1>${sub ? `<div class="sub">${esc(sub)}</div>` : ''}</div><div class="actions">${actions}</div></div>`;
}

export function tabs(container, items, active, onChange) {
  container.innerHTML = items.map((t) => `<button type="button" data-tab="${t.id}" class="${t.id === active ? 'on' : ''}">${t.icon ? icon(t.icon, 'sm') : ''}${esc(t.label)}${t.badge ? ` <span class="badge">${esc(t.badge)}</span>` : ''}</button>`).join('');
  container.onclick = (e) => { const b = e.target.closest('[data-tab]'); if (!b) return; $$('[data-tab]', container).forEach((x) => x.classList.toggle('on', x === b)); onChange(b.dataset.tab); };
}

export function filterBar(fields, values = {}) {
  return `<div class="filters">${fields.map((f) => {
    const v = values[f.name] ?? f.value ?? '';
    if (f.type === 'select') return `<div class="field"><label>${esc(f.label)}</label><select class="inp" name="${f.name}">${f.options.map((o) => `<option value="${esc(o.value)}" ${String(o.value) === String(v) ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}</select></div>`;
    if (f.type === 'date') return `<div class="field"><label>${esc(f.label)}</label><input class="inp" type="date" name="${f.name}" value="${esc(v)}"></div>`;
    if (f.type === 'combo') return `<div class="field" style="min-width:200px"><label>${esc(f.label)}</label><div class="combo" data-combo="${f.name}"><input class="inp" placeholder="الكل"><input type="hidden" name="${f.name}" value="${esc(v)}"></div></div>`;
    if (f.type === 'check') return `<div class="field"><label>&nbsp;</label><label class="check"><input type="checkbox" name="${f.name}" ${v ? 'checked' : ''}> ${esc(f.label)}</label></div>`;
    return `<div class="field grow"><label>${esc(f.label)}</label><input class="inp" name="${f.name}" value="${esc(v)}" placeholder="${esc(f.placeholder || 'بحث…')}"></div>`;
  }).join('')}</div>`;
}

/** Wires a filter bar: calls onChange(values) on input (debounced) / change. */
export function bindFilters(root, onChange, combos = {}) {
  const read = () => readForm(root);
  const fire = debounce(() => onChange(read()), 280);
  root.addEventListener('input', (e) => { if (e.target.name && e.target.type !== 'hidden') fire(); });
  root.addEventListener('change', (e) => { if (e.target.name) onChange(read()); });
  Object.entries(combos).forEach(([name, options]) => {
    const c = root.querySelector(`[data-combo="${name}"]`);
    if (c) combo(c, { options, onChange: () => onChange(read()) });
  });
  return read;
}

export function emptyState(title, hint = '', ic = 'file', action = '') {
  return `<div class="empty">${icon(ic)}<b>${esc(title)}</b>${hint ? `<div class="small">${esc(hint)}</div>` : ''}${action ? `<div style="margin-top:12px">${action}</div>` : ''}</div>`;
}

export function kvList(pairs) {
  return `<dl class="kv">${pairs.filter(Boolean).map(([k, v]) => `<dt>${esc(k)}</dt><dd>${v instanceof Object ? v : esc(v ?? '—')}</dd>`).join('')}</dl>`;
}

/** kvList whose values are trusted HTML built by the caller (escape any user data yourself). */
export function kvHtml(pairs) { return kvList(pairs.filter(Boolean).map(([k, v]) => [k, raw(v === null || v === undefined ? '—' : String(v))])); }

export { html, raw, money, qty };
