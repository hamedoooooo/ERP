// All data access goes through here. In the desktop app `window.erp` is exposed by the
// preload script (IPC to the main process). In browser-preview mode it falls back to the
// local preview server (scripts/preview-server.js), which runs the exact same backend.
export const isDesktop = !!(window.erp && window.erp.invoke);

export class ApiError extends Error {
  constructor(err) { super(err.message); this.code = err.code; this.details = err.details; this.technical = err.technical; }
}

export async function api(method, args = {}) {
  let res;
  if (isDesktop) res = await window.erp.invoke(method, args);
  else {
    const r = await fetch('/api', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ method, args }) });
    res = await r.json();
  }
  if (!res || !res.ok) {
    const e = new ApiError((res && res.error) || { message: 'تعذر الاتصال بقاعدة البيانات', code: 'NO_RESPONSE' });
    if (e.code === 'AUTH' && method !== 'auth.login') window.dispatchEvent(new CustomEvent('erp:auth-lost'));
    throw e;
  }
  return res.data;
}

/** Native helpers (file dialogs etc.). Browser fallbacks keep preview mode usable. */
export const sys = {
  async saveText(defaultName, content, filters) {
    if (isDesktop) return window.erp.saveText({ defaultName, content, filters });
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = defaultName; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    return { path: defaultName };
  },
  async pickBackupFile() {
    if (isDesktop) return window.erp.openFile({ title: 'اختر ملف النسخة الاحتياطية', filters: [{ name: 'نسخة احتياطية', extensions: ['backup'] }] });
    const file = await pickLocal('.backup');
    if (!file) return null;
    const b64 = await toBase64(file);
    const r = await api('backup.stageUpload', { name: file.name, base64: b64 });
    return r.path;
  },
  async pickJsonText() {
    const file = await pickLocal('.json,.txt');
    return file ? file.text() : null;
  },
  async chooseFolder(title) { return isDesktop ? window.erp.chooseFolder({ title }) : null; },
  async saveBackupAs(defaultName) { return isDesktop ? window.erp.saveFile({ defaultName, filters: [{ name: 'نسخة احتياطية', extensions: ['backup'] }] }) : null; },
  async showInFolder(p) { if (isDesktop) return window.erp.showInFolder(p); return null; },
  async print() { if (isDesktop && window.erp.print) return window.erp.print(); window.print(); return true; },
  async printToPDF(name) { return isDesktop && window.erp.printToPDF ? window.erp.printToPDF({ defaultName: name }) : null; },
  setTitle(t) { document.title = t; if (isDesktop && window.erp.setTitle) window.erp.setTitle(t); },
};

function pickLocal(accept) {
  return new Promise((resolve) => {
    const i = document.createElement('input'); i.type = 'file'; i.accept = accept;
    i.onchange = () => resolve(i.files[0] || null);
    i.click();
  });
}
function toBase64(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1]);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}
